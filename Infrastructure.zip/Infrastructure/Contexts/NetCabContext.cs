﻿using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Models.Chat;
using NetCabManager.Infrastructure.Models.Identity;
using NetCabManager.Domain.Contracts;
using NetCabManager.Domain.Entities.Catalog;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NetCabManager.Domain.Entities.ExtendedAttributes;
using NetCabManager.Domain.Entities.Misc;
using Microsoft.Extensions.Configuration;
using System;

namespace NetCabManager.Infrastructure.Contexts
{
    public class NetCabContext : AuditableContext
    {
        private readonly ICurrentUserService _currentUserService;
        private readonly IDateTimeService _dateTimeService;
        private readonly IConfiguration _configuration;

        public NetCabContext(DbContextOptions<NetCabContext> options, ICurrentUserService currentUserService, IDateTimeService dateTimeService, IConfiguration configuration)
            : base(options)
        {
            _currentUserService = currentUserService;
            _dateTimeService = dateTimeService;
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"), builder =>
            {
                builder.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
            });

            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<Company> Companies { get; set; }
        public DbSet<UpdateParameter> UpdateParameters { get; set; }
        public DbSet<ChatHistory<NetCabUser>> ChatHistories { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<DocumentType> DocumentTypes { get; set; }
        public DbSet<DocumentExtendedAttribute> DocumentExtendedAttributes { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<NetCabToFleet> NetCabToFleets { get; set; }
        public DbSet<DriverInvoice> DriverInvoices { get; set; }
        //public DbSet<TargetHistory> TargetHistories { get; set; }
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new())
        {
            foreach (var entry in ChangeTracker.Entries<IAuditableEntity>().ToList())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.CreatedOn = _dateTimeService.NowUtc;
                        entry.Entity.CreatedBy = _currentUserService.UserId;
                        break;

                    case EntityState.Modified:
                        entry.Entity.LastModifiedOn = _dateTimeService.NowUtc;
                        entry.Entity.LastModifiedBy = _currentUserService.UserId;
                        break;
                }
            }
            if (_currentUserService.UserId == null)
            {
                return await base.SaveChangesAsync(cancellationToken);
            }
            else
            {
                return await base.SaveChangesAsync(_currentUserService.UserId, cancellationToken);
            }
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            foreach (var property in builder.Model.GetEntityTypes()
            .SelectMany(t => t.GetProperties())
            .Where(p => p.ClrType == typeof(decimal) || p.ClrType == typeof(decimal?)))
            {
                property.SetColumnType("decimal(18,2)");
            }

            foreach (var property in builder.Model.GetEntityTypes()
                .SelectMany(t => t.GetProperties())
                .Where(p => p.Name is "LastModifiedBy" or "CreatedBy"))
            {
                property.SetColumnType("nvarchar(128)");
            }

            base.OnModelCreating(builder);

            builder.Entity<Company>(entity =>
            {
                entity.ToTable(name: "Companies", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "CompanyIdentification").HasColumnType(typeName: "nvarchar(450)").IsRequired(required: true);
                entity.Property(e => e.CanIssueUpdate).HasColumnName(name: "CanIssueUpdate").HasColumnType(typeName: "bit").IsRequired(required: true);
                entity.Property(e => e.SqlServerIp).HasColumnName(name: "SqlServerIp").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.SqlInstanceName).HasColumnName(name: "SqlInstanceName").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.SqlInstancePort).HasColumnName(name: "SqlInstancePort").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.SqlDatabaseName).HasColumnName(name: "SqlDatabaseName").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.SqlServerUsername).HasColumnName(name: "SqlServerUsername").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.SqlServerPassword).HasColumnName(name: "SqlServerPassword").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: true);
                entity.Property(e => e.CompanyTitle).HasColumnName(name: "CompanyTitle").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.Note).HasColumnName(name: "Note").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.UpdateParameterId).HasColumnName(name: "UpdateParameterIdUpdateparameter").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.UnitServerHost).HasColumnName(name: "UnitServerHost").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.UnitServerPort).HasColumnName(name: "UnitServerPort").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.WebServiceHost).HasColumnName(name: "WebServiceHost").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.PrimaryColor).HasColumnName(name: "PrimaryColor").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.CompanyCounter).HasColumnName(name: "CompanyCounter").UseIdentityColumn(seed: 1, increment: 1);

                entity.HasKey(e => e.Id);
                entity.HasOne(e => e.UpdateParameter)
                      .WithMany(e => e.Companies)
                      .HasForeignKey(e => e.UpdateParameterId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            //builder.Entity<TargetHistory>(entity =>
            //{
            //    entity.ToTable(name: "target_history", schema: "dbo");

            //    entity.Property(e => e.Id).HasColumnName(name: "id_target").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
            //    entity.Property(e => e.Phone).HasColumnName(name: "phone").HasColumnType(typeName: "varchar(55)").IsRequired(required: false);
            //    entity.Property(e => e.Street).HasColumnName(name: "street").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
            //    entity.Property(e => e.Number).HasColumnName(name: "num").HasColumnType(typeName: "varchar(15)").IsRequired(required: false);
            //    entity.Property(e => e.Lbl).HasColumnName(name: "lbl").HasColumnType(typeName: "varchar(10)").IsRequired(required: false);
            //    entity.Property(e => e.Status).HasColumnName(name: "status").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.UnitId).HasColumnName(name: "unit_id").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
            //    entity.Property(e => e.AssignedAt).HasColumnName(name: "assigned_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.Remark).HasColumnName(name: "remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
            //    entity.Property(e => e.DatetimeUpdate).HasColumnName(name: "dt_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.IdClient).HasColumnName(name: "id_client").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.IdRecord).HasColumnName(name: "IdRecord").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.Inserted).HasColumnName(name: "inserted").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.Preorder).HasColumnName(name: "preorder").HasColumnType(typeName: "bit").IsRequired(required: false);
            //    entity.Property(e => e.Dispatchat).HasColumnName(name: "dispatchat").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.RemindAt).HasColumnName(name: "remind_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.DispatchNow).HasColumnName(name: "dispatchnow").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.IdOperator).HasColumnName(name: "id_operator").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.IdDispatcher).HasColumnName(name: "id_dispatcher").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.IdPartnerCompany).HasColumnName(name: "id_company").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.PurchaseOrder).HasColumnName(name: "purchase_order").HasColumnType(typeName: "decimal(10,2)").IsRequired(required: false);
            //    entity.Property(e => e.HsMid).HasColumnName(name: "hs_mid").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.TaxiNumber).HasColumnName(name: "taxi_number").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.Latitude).HasColumnName(name: "lat").HasColumnType(typeName: "float").IsRequired(required: false);
            //    entity.Property(e => e.Longitude).HasColumnName(name: "lon").HasColumnType(typeName: "float").IsRequired(required: false);
            //    entity.Property(e => e.OrientLatitude).HasColumnName(name: "orient_lat").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
            //    entity.Property(e => e.OrientLongitude).HasColumnName(name: "orient_lon").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
            //    entity.Property(e => e.AutoDispatch).HasColumnName(name: "autodispatch").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.AutoDispatched).HasColumnName(name: "autodispatched").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.DatetimePreorder).HasColumnName(name: "dt_preorder").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.Destination).HasColumnName(name: "destination").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
            //    entity.Property(e => e.Customer).HasColumnName(name: "customer").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
            //    entity.Property(e => e.Type1).HasColumnName(name: "type1").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type2).HasColumnName(name: "type2").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type3).HasColumnName(name: "type3").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type4).HasColumnName(name: "type4").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type5).HasColumnName(name: "type5").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type6).HasColumnName(name: "type6").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type7).HasColumnName(name: "type7").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type8).HasColumnName(name: "type8").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type9).HasColumnName(name: "type9").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type10).HasColumnName(name: "type10").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type11).HasColumnName(name: "type11").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type12).HasColumnName(name: "type12").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type13).HasColumnName(name: "type13").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type14).HasColumnName(name: "type14").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type15).HasColumnName(name: "type15").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type16).HasColumnName(name: "type16").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type17).HasColumnName(name: "type17").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type18).HasColumnName(name: "type18").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type19).HasColumnName(name: "type19").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Type20).HasColumnName(name: "type20").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.IdStand).HasColumnName(name: "id_stand").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.IdZone).HasColumnName(name: "id_zone").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.Distance).HasColumnName(name: "distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
            //    entity.Property(e => e.TimeOfArrival).HasColumnName(name: "time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
            //    entity.Property(e => e.IdCompanyCredential).HasColumnName(name: "id_company_credential").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.Gdistance).HasColumnName(name: "g_distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
            //    entity.Property(e => e.GtimeOfArrival).HasColumnName(name: "g_time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
            //    entity.Property(e => e.PhoneLine).HasColumnName(name: "phone_line").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.RequestedTime).HasColumnName(name: "requeste_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.ManualAssignReason).HasColumnName(name: "manual_assign_reason").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
            //    entity.Property(e => e.CompanyOrderNote).HasColumnName(name: "company_order_note").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
            //    entity.Property(e => e.Paid).HasColumnName(name: "paid").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.DispatchType).HasColumnName(name: "dispatch_type").HasColumnType(typeName: "numeric(2,0)").IsRequired(required: true);
            //    entity.Property(e => e.CancellationReason).HasColumnName(name: "cancellation_reason").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.CpuPickupTime).HasColumnName(name: "cpu_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.DriverPickupTime).HasColumnName(name: "driver_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.DriverDelay).HasColumnName(name: "driver_delay").HasColumnType(typeName: "smallint").IsRequired(required: false);
            //    entity.Property(e => e.OrderByDriver).HasColumnName(name: "order_by_driver").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
            //    entity.Property(e => e.DelayedPayment).HasColumnName(name: "delayed_payment").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.Pickup).HasColumnName(name: "pickup").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.DropOffTime).HasColumnName(name: "drop_off_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.CpuFirstTime).HasColumnName(name: "cpu_first_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.DriverPickupMin).HasColumnName(name: "driver_pickup_min").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.DriverAtLocation).HasColumnName(name: "driver_at_location").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.BillingCenter).HasColumnName(name: "BillingCenter").HasColumnType(typeName: "varchar(150)").IsRequired(required: true);
            //    entity.Property(e => e.Billingcenterr).HasColumnName(name: "billing_center").HasColumnType(typeName: "varchar(150)").IsRequired(required: false);
            //    entity.Property(e => e.OrdererName).HasColumnName(name: "orderer_name").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
            //    entity.Property(e => e.OrdererNote).HasColumnName(name: "orderer_note").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
            //    entity.Property(e => e.DestinationLatitude).HasColumnName(name: "destination_lat").HasColumnType(typeName: "float").IsRequired(required: false);
            //    entity.Property(e => e.DestinationLongitude).HasColumnName(name: "destination_lon").HasColumnType(typeName: "float").IsRequired(required: false);
            //    entity.Property(e => e.DispatchSubtype).HasColumnName(name: "dispatch_subtype").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.Passenger).HasColumnName(name: "passenger").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
            //    entity.Property(e => e.IdTariff).HasColumnName(name: "id_tariff").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.IdPaymentType).HasColumnName(name: "id_payment_type").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "int").IsRequired(required: true);
            //    entity.Property(e => e.PrimaryDistanceRequestTime).HasColumnName(name: "primary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.SecondaryDistanceRequestTime).HasColumnName(name: "secondary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName(name: "id_internal_department_used").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.PurchaseQuantity).HasColumnName(name: "purchase_quantity").HasColumnType(typeName: "nvarchar(20)").IsRequired(required: false);
            //    entity.Property(e => e.ReceiptedInvoices).HasColumnName(name: "receipted_invoices").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.TripRemark).HasColumnName(name: "trip_remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
            //    entity.Property(e => e.NoCustomerRequest).HasColumnName(name: "no_customer_request").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.NotifyUnitPending).HasColumnName(name: "notify_unit_pending").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.StreetPickup).HasColumnName(name: "street_pickup").HasColumnType(typeName: "bit");
            //    entity.Property(e => e.LastUpdate).HasColumnName(name: "last_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.LastUpdateBy).HasColumnName(name: "last_update_by").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.AssignedIdDriver).HasColumnName(name: "assigned_id_driver").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.AssignedIdUnit).HasColumnName(name: "assigned_id_unit").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.AssignedIdVehicle).HasColumnName(name: "assigned_id_vehicle").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.IdServiceType).HasColumnName(name: "id_service_type").HasColumnType(typeName: "int").IsRequired(required: false);
            //    entity.Property(e => e.PassengerPhone).HasColumnName(name: "passenger_phone").HasColumnType(typeName: "varchar(20)").IsRequired(required: false);
            //    entity.Property(e => e.DispatchTriggered).HasColumnName(name: "dispatch_triggered").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.CpuFinalDestinationTime).HasColumnName(name: "cpu_final_destination_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
            //    entity.Property(e => e.CardNumber).HasColumnName(name: "card_number").HasColumnType(typeName: "nvarchar(30)").IsRequired(required: false);

            //    entity.HasKey(e => e.Id);
            //});
            builder.Entity<Invoice>(entity =>
            {
                entity.ToTable(name: "Invoices", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "Id").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.InvoiceDate).HasColumnName(name: "InvoiceDate").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverName).HasColumnName(name: "DriverName").HasColumnType(typeName: "nvarchar(450)").IsRequired(required: false);
                entity.Property(e => e.Address).HasColumnName(name: "Address").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.Price).HasColumnName(name: "Price").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PaymentMethod).HasColumnName(name: "PaymentMethod").HasColumnType(typeName: "nvarchar(450)").IsRequired(required: false);
                entity.Property(e => e.CompanyIdentification).HasColumnName(name: "CompanyIdentification").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.HasKey(e => e.Id);

            });
            builder.Entity<NetCabToFleet>(entity =>
            {
                entity.ToTable(name: "NetCabToFleets", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "Id").HasColumnType(typeName: "nvarchar(Max)").IsRequired(required: true);
                entity.Property(e => e.InvoiceDate).HasColumnName(name: "InvoiceDate").HasColumnType(typeName: "date").IsRequired(required: false);
                entity.Property(e => e.DateFrom).HasColumnName(name: "DateFrom").HasColumnType(typeName: "date").IsRequired(required: false);
                entity.Property(e => e.DateTo).HasColumnName(name: "DateTo").HasColumnType(typeName: "date").IsRequired(required: false);
                entity.Property(e => e.Price).HasColumnName(name: "Price").HasColumnType(typeName: "decimal(10,4)").IsRequired(required: false);
                entity.Property(e => e.CompanyIdentification).HasColumnName(name: "CompanyIdentification").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.UserId).HasColumnName(name: "UserId").HasColumnType(typeName: "nvarchar(450)").IsRequired(required: false);
                entity.HasKey(e => e.Id);

            });
            builder.Entity<UpdateParameter>(entity =>
            {
                entity.ToTable(name: "UpdateParameters", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "IdUpdateparameter").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.CompanyIdentification).HasColumnName(name: "CompanyIdentification").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.UpdateWeight).HasColumnName(name: "UpdateWeight").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.HourFrom).HasColumnName(name: "HourFrom").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.HourTo).HasColumnName(name: "HourTo").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.DaysOfWeek).HasColumnName(name: "DaysOfWeek").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });

            builder.Entity<ChatHistory<NetCabUser>>(entity =>
            {
                entity.ToTable("ChatHistory");

                entity.HasOne(d => d.FromUser)
                    .WithMany(p => p.ChatHistoryFromUsers)
                    .HasForeignKey(d => d.FromUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.ToUser)
                    .WithMany(p => p.ChatHistoryToUsers)
                    .HasForeignKey(d => d.ToUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });
            builder.Entity<NetCabUser>(entity =>
            {
                entity.ToTable(name: "Users", schema: "Identity");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.CompanyIdentification).HasColumnName(name: "CompanyIdentification").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.InternalDepartmentId).HasColumnName(name: "InternalDepartmentId").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PartnerCompanyId).HasColumnName(name: "PartnerCompanyId").HasColumnType(typeName: "int").IsRequired(required: false);
            });

            builder.Entity<NetCabRole>(entity =>
            {
                entity.ToTable(name: "Roles", "Identity");
            });
            builder.Entity<IdentityUserRole<string>>(entity =>
            {
                entity.ToTable("UserRoles", "Identity");
            });

            builder.Entity<IdentityUserClaim<string>>(entity =>
            {
                entity.ToTable("UserClaims", "Identity");
            });

            builder.Entity<IdentityUserLogin<string>>(entity =>
            {
                entity.ToTable("UserLogins", "Identity");
            });

            builder.Entity<NetCabRoleClaim>(entity =>
            {
                entity.ToTable(name: "RoleClaims", "Identity");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleClaims)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            builder.Entity<IdentityUserToken<string>>(entity =>
            {
                entity.ToTable("UserTokens", "Identity");
            });
        }
    }
}
