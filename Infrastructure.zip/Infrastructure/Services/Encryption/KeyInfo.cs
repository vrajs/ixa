﻿using System;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Services.Encryption
{
    public class KeyInfo
    {
        // secret key
        public byte[] Key { get; }
        // initial vector
        public byte[] Iv { get; }

        public string KeyString => Convert.ToBase64String(Key);
        public string IVString => Convert.ToBase64String(Iv);

        /// <summary>
        /// Use this parameterless constructor in Startup.cs to create new secret key and iv. 
        /// </summary>
        public KeyInfo()
        {
            using var aes = Aes.Create();
            Key = aes.Key;
            Iv = aes.IV;
            //aes.Padding = PaddingMode.PKCS7;
        }

        public KeyInfo(string key, string iv)
        {
            Key = Convert.FromBase64String(key);
            Iv = Convert.FromBase64String(iv);
        }

        public KeyInfo(byte[] key, byte[] iv)
        {
            Key = key;
            Iv = iv;
        }
    }
}