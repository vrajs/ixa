﻿namespace NetCabManager.Infrastructure.Services.TaxiCompany
{
    using Microsoft.EntityFrameworkCore;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Interfaces.Services;
    using NetCabManager.Application.Interfaces.Services.Identity;
    using NetCabManager.Application.Responses.Identity;
    using NetCabManager.Shared.Constants.Role;
    using NetCabManager.Shared.TaxiCompany.Context;
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using NetCabManager.Application.Features;
    using NetCabManager.Application.Features.Companies.Queries.GetAll;

    public class TaxiCompanyService : ITaxiCompanyService
    {
        private readonly IUserService _userService;
        private readonly ICompanyRepository _companyRepository;
        private DbContextOptions<TaxiCompanyContext> _options;

        public UserResponse User { get; set; } = new();
        public GetAllCompaniesResponse Company { get; set; } = new();
        public string ConnectionString { get; set; }

        public TaxiCompanyService(IUserService userService,
                                  ICompanyRepository companyRepository)
        {
            _userService = userService;
            _companyRepository = companyRepository;
        }

        public Task GetCurrentUser(string userId)
        {
            var userResponse = _userService.GetAsync(userId);

            if (userResponse.Result.Succeeded)
            {
                User = userResponse.Result.Data;

                if (User is not null)
                {
                    GetUserRolesAsync();
                }
            }
            else
            {
                foreach (var message in userResponse.Result.Messages)
                {
                    throw new Exception(message);
                }
            }

            return Task.CompletedTask;
        }

        private Task GetUserRolesAsync()
        {
            var userRoleResponse = _userService.GetRolesAsync(User.Id);

            if (userRoleResponse.Result.Succeeded)
            {
                var userRoles = userRoleResponse.Result.Data.UserRoles;

                if (userRoles != null)
                {
                    var roles = userRoles.Where(u => u.Selected == true).Select(u => u.RoleName).ToList();
                    User.Role = string.Join(", ", roles.ToArray());
                }
            }
            else
            {
                foreach (var message in userRoleResponse.Result.Messages)
                {
                    message.ToString();
                }
            }

            return Task.CompletedTask;
        }


        public Task GetCurrentUserCompany(UserResponse user)
        {
            var companyResponse = _companyRepository.GetAllCompaniesAsync();

            if (companyResponse.Result.Succeeded)
            {
                var companyList = companyResponse.Result.Data.ToList();

                if (companyList is not null)
                {
                    if (!string.IsNullOrEmpty(User.Id))
                    {
                        if (!string.IsNullOrEmpty(User.CompanyIdentification))
                        {
                            Company = companyList.FirstOrDefault(c => c.Id == User.CompanyIdentification);
                        }
                    }
                    else
                    {
                        Company = companyList.FirstOrDefault(c => c.Id == user.CompanyIdentification);
                    }
                }
            }
            else
            {
                foreach (var message in companyResponse.Result.Messages)
                {
                    message.ToString();
                }
            }

            return Task.CompletedTask;
        }

        public string CreateConnectionString(GetAllCompaniesResponse Company)
        {
            if (Company == null)
            {
                return string.Empty;
            }
            if (User.Role == RoleConstants.CompanyManagerRole ||
                User.Role == RoleConstants.PartnerCompanyManagerInternalRole ||
                User.Role == RoleConstants.PartnerCompanyManagerExternalRole ||
                User.Role == RoleConstants.AdministratorRole || User.Role == RoleConstants.DriverRole)
            {
                try
                {
                    if (!string.IsNullOrEmpty(Company.Id))
                    {
                        //var decryptedPassword = encryptionService.Decrypt(Company.SqlServerPassword);
                        ConnectionString = $"Data Source={Company.SqlServerIp},{Company.SqlInstancePort}\\{Company.SqlInstanceName};Initial Catalog={Company.SqlDatabaseName};User ID={Company.SqlServerUsername};Password={Company.SqlServerPassword}";
                    }
                    else
                    {
                        //var decryptedPassword = encryptionService.Decrypt(Company.SqlServerPassword);
                        ConnectionString = $"Data Source={Company.SqlServerIp},{Company.SqlInstancePort}\\{Company.SqlInstanceName};Initial Catalog={Company.SqlDatabaseName};User ID={Company.SqlServerUsername};Password={Company.SqlServerPassword}";
                    }
                }
                catch (Exception exp)
                {
                    exp.Message.ToString();
                }

                return ConnectionString;
            }
            else
            {
                //implement admin logic
                ConnectionString = "";
                return ConnectionString;
            }
        }

        public TaxiCompanyContext CreateDbContext(string connectionString)
        {
            if (User.Role == RoleConstants.CompanyManagerRole ||
                User.Role == RoleConstants.PartnerCompanyManagerInternalRole ||
                User.Role == RoleConstants.PartnerCompanyManagerExternalRole ||
                User.Role == RoleConstants.AdministratorRole || User.Role == RoleConstants.DriverRole)
            {
                if (!string.IsNullOrEmpty(ConnectionString))
                {
                    _options = new DbContextOptionsBuilder<TaxiCompanyContext>()
                        .UseSqlServer(ConnectionString).Options;
                }
                else
                {
                    _options = new DbContextOptionsBuilder<TaxiCompanyContext>()
                        .UseSqlServer(connectionString).Options;
                }

                return new TaxiCompanyContext(_options);
            }
            else
            {
                //implement admin logic
                return new TaxiCompanyContext(new DbContextOptions<TaxiCompanyContext>());
            }
        }
    }
}