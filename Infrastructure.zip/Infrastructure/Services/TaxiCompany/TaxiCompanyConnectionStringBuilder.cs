﻿namespace NetCabManager.Infrastructure.Services.TaxiCompany
{
    using NetCabManager.Application.Features;
    using NetCabManager.Application.Features.Companies.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Services;
    using System;

    public class TaxiCompanyConnectionStringBuilder : ITaxiCompanyConnectionStringBuilder
    {
        //private readonly IEncryptionService _encryptionService;
        private string _connString;

        public TaxiCompanyConnectionStringBuilder(/*IEncryptionService encryptionService*/)
        {
            //_encryptionService = encryptionService;
        }

        public string CreateConnectionString(GetAllCompaniesResponse Company)
        {
            try
            {
                if (Company is not null)
                {
                    //var decryptedPassword = _encryptionService.Decrypt(Company.SqlServerPassword);
                    _connString = $@"Data Source={Company.SqlServerIp},{Company.SqlInstancePort}\{Company.SqlInstanceName};Initial Catalog={Company.SqlDatabaseName};User ID={Company.SqlServerUsername};Password={Company.SqlServerPassword}";
                }
            }
            catch (Exception exp)
            {
                exp.Message.ToString();
            }

            return _connString;
        }
    }
}