﻿using NetCabManager.Domain.Contracts;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using NetCabManager.Application.Interfaces.Chat;
using NetCabManager.Application.Models.Chat;

namespace NetCabManager.Infrastructure.Models.Identity
{
    public class NetCabUser : IdentityUser<string>, IChatUser, IAuditableEntity<string>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
        public string CreatedBy { get; set; }

        [Column(TypeName = "text")]
        public string ProfilePictureDataUrl { get; set; }

        public DateTime CreatedOn { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTime? LastModifiedOn { get; set; }
        public string CompanyIdentification { get; set; }
        public int? InternalDepartmentId { get; set; }
        public int? DriverId { get; set; }
        public int? PartnerCompanyId { get; set; }
        public bool IsDeleted { get; set; }

        public DateTime? DeletedOn { get; set; }
        public bool IsActive { get; set; }
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }
        public virtual ICollection<ChatHistory<NetCabUser>> ChatHistoryFromUsers { get; set; }
        public virtual ICollection<ChatHistory<NetCabUser>> ChatHistoryToUsers { get; set; }

        public NetCabUser()
        {
            ChatHistoryFromUsers = new HashSet<ChatHistory<NetCabUser>>();
            ChatHistoryToUsers = new HashSet<ChatHistory<NetCabUser>>();
        }
    }
}