﻿using AutoMapper;
using NetCabManager.Application.Interfaces.Chat;
using NetCabManager.Application.Models.Chat;
using NetCabManager.Infrastructure.Models.Identity;

namespace NetCabManager.Infrastructure.Mappings
{
    public class ChatHistoryProfile : Profile
    {
        public ChatHistoryProfile()
        {
            CreateMap<ChatHistory<IChatUser>, ChatHistory<NetCabUser>>().ReverseMap();
        }
    }
}