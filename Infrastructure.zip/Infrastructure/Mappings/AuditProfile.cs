﻿using AutoMapper;
using NetCabManager.Infrastructure.Models.Audit;
using NetCabManager.Application.Responses.Audit;

namespace NetCabManager.Infrastructure.Mappings
{
    public class AuditProfile : Profile
    {
        public AuditProfile()
        {
            CreateMap<AuditResponse, Audit>().ReverseMap();
        }
    }
}