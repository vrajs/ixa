﻿using AutoMapper;
using NetCabManager.Application.Requests.Identity;
using NetCabManager.Application.Responses.Identity;
using NetCabManager.Infrastructure.Models.Identity;

namespace NetCabManager.Infrastructure.Mappings
{
    public class RoleClaimProfile : Profile
    {
        public RoleClaimProfile()
        {
            CreateMap<RoleClaimResponse, NetCabRoleClaim>()
                .ForMember(nameof(NetCabRoleClaim.ClaimType), opt => opt.MapFrom(c => c.Type))
                .ForMember(nameof(NetCabRoleClaim.ClaimValue), opt => opt.MapFrom(c => c.Value))
                .ReverseMap();

            CreateMap<RoleClaimRequest, NetCabRoleClaim>()
                .ForMember(nameof(NetCabRoleClaim.ClaimType), opt => opt.MapFrom(c => c.Type))
                .ForMember(nameof(NetCabRoleClaim.ClaimValue), opt => opt.MapFrom(c => c.Value))
                .ReverseMap();
        }
    }
}