﻿using AutoMapper;
using NetCabManager.Infrastructure.Models.Identity;
using NetCabManager.Application.Responses.Identity;
using Microsoft.AspNetCore.Identity;

namespace NetCabManager.Infrastructure.Mappings
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<UserResponse, NetCabUser>().ReverseMap();
            CreateMap<UserResponse, IdentityUserRole<string>> ().ReverseMap();
            CreateMap<ChatUserResponse, NetCabUser>().ReverseMap()
                .ForMember(dest => dest.EmailAddress, source => source.MapFrom(source => source.Email)); //Specific Mapping
        }
    }
}