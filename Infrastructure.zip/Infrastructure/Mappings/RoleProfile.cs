﻿using AutoMapper;
using NetCabManager.Infrastructure.Models.Identity;
using NetCabManager.Application.Responses.Identity;

namespace NetCabManager.Infrastructure.Mappings
{
    public class RoleProfile : Profile
    {
        public RoleProfile()
        {
            CreateMap<RoleResponse, NetCabRole>().ReverseMap();
        }
    }
}