﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NetCabManager.Infrastructure.Migrations
{
    public partial class target_history : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "target_history",
                schema: "dbo",
                columns: table => new
                {
                    id_target = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    phone = table.Column<string>(type: "varchar(55)", nullable: true),
                    street = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    num = table.Column<string>(type: "varchar(15)", nullable: true),
                    lbl = table.Column<string>(type: "varchar(10)", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true),
                    unit_id = table.Column<string>(type: "varchar(45)", nullable: true),
                    assigned_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    remark = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    dt_update = table.Column<DateTime>(type: "datetime", nullable: true),
                    id_client = table.Column<int>(type: "int", nullable: true),
                    isdeleted = table.Column<bool>(type: "bit", nullable: true),
                    IdRecord = table.Column<int>(type: "int", nullable: true),
                    inserted = table.Column<DateTime>(type: "datetime", nullable: true),
                    preorder = table.Column<bool>(type: "bit", nullable: true),
                    dispatchat = table.Column<DateTime>(type: "datetime", nullable: true),
                    remind_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    dispatchnow = table.Column<bool>(type: "bit", nullable: true),
                    id_operator = table.Column<int>(type: "int", nullable: false),
                    id_dispatcher = table.Column<int>(type: "int", nullable: true),
                    id_company = table.Column<int>(type: "int", nullable: true),
                    purchase_order = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    hs_mid = table.Column<int>(type: "int", nullable: true),
                    taxi_number = table.Column<int>(type: "int", nullable: true),
                    lat = table.Column<double>(type: "float", nullable: true),
                    lon = table.Column<double>(type: "float", nullable: true),
                    orient_lat = table.Column<string>(type: "nvarchar(1)", nullable: true),
                    orient_lon = table.Column<string>(type: "nvarchar(1)", nullable: true),
                    autodispatch = table.Column<bool>(type: "bit", nullable: true),
                    autodispatched = table.Column<bool>(type: "bit", nullable: true),
                    dt_preorder = table.Column<DateTime>(type: "datetime", nullable: true),
                    destination = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    customer = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    type1 = table.Column<bool>(type: "bit", nullable: true),
                    type2 = table.Column<bool>(type: "bit", nullable: true),
                    type3 = table.Column<bool>(type: "bit", nullable: true),
                    type4 = table.Column<bool>(type: "bit", nullable: true),
                    type5 = table.Column<bool>(type: "bit", nullable: true),
                    type6 = table.Column<bool>(type: "bit", nullable: true),
                    type7 = table.Column<bool>(type: "bit", nullable: true),
                    type8 = table.Column<bool>(type: "bit", nullable: true),
                    type9 = table.Column<bool>(type: "bit", nullable: true),
                    type10 = table.Column<bool>(type: "bit", nullable: true),
                    type11 = table.Column<bool>(type: "bit", nullable: true),
                    type12 = table.Column<bool>(type: "bit", nullable: true),
                    type13 = table.Column<bool>(type: "bit", nullable: true),
                    type14 = table.Column<bool>(type: "bit", nullable: true),
                    type15 = table.Column<bool>(type: "bit", nullable: true),
                    type16 = table.Column<bool>(type: "bit", nullable: true),
                    type17 = table.Column<bool>(type: "bit", nullable: true),
                    type18 = table.Column<bool>(type: "bit", nullable: true),
                    type19 = table.Column<bool>(type: "bit", nullable: true),
                    type20 = table.Column<bool>(type: "bit", nullable: true),
                    id_stand = table.Column<int>(type: "int", nullable: false),
                    id_zone = table.Column<int>(type: "int", nullable: false),
                    distance = table.Column<string>(type: "varchar(50)", nullable: true),
                    time_of_arrival = table.Column<string>(type: "varchar(50)", nullable: true),
                    id_company_credential = table.Column<int>(type: "int", nullable: true),
                    g_distance = table.Column<string>(type: "varchar(50)", nullable: true),
                    g_time_of_arrival = table.Column<string>(type: "varchar(50)", nullable: true),
                    phone_line = table.Column<int>(type: "int", nullable: true),
                    requeste_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    manual_assign_reason = table.Column<string>(type: "nvarchar(200)", nullable: true),
                    company_order_note = table.Column<string>(type: "nvarchar(200)", nullable: true),
                    paid = table.Column<bool>(type: "bit", nullable: false),
                    dispatch_type = table.Column<decimal>(type: "numeric(2,0)", nullable: false),
                    cancellation_reason = table.Column<int>(type: "int", nullable: false),
                    cpu_pickup_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    driver_pickup_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    driver_delay = table.Column<short>(type: "smallint", nullable: true),
                    order_by_driver = table.Column<string>(type: "varchar(45)", nullable: true),
                    delayed_payment = table.Column<bool>(type: "bit", nullable: true),
                    pickup = table.Column<DateTime>(type: "datetime", nullable: true),
                    drop_off_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    cpu_first_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    driver_pickup_min = table.Column<int>(type: "int", nullable: true),
                    driver_at_location = table.Column<bool>(type: "bit", nullable: true),
                    BillingCenter = table.Column<string>(type: "varchar(150)", nullable: false),
                    billing_center = table.Column<string>(type: "varchar(150)", nullable: true),
                    orderer_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    orderer_note = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    destination_lat = table.Column<double>(type: "float", nullable: true),
                    destination_lon = table.Column<double>(type: "float", nullable: true),
                    dispatch_subtype = table.Column<int>(type: "int", nullable: false),
                    passenger = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    id_tariff = table.Column<int>(type: "int", nullable: true),
                    id_payment_type = table.Column<int>(type: "int", nullable: true),
                    id_internal_department = table.Column<int>(type: "int", nullable: false),
                    primary_distance_request_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    secondary_distance_request_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    id_internal_department_used = table.Column<int>(type: "int", nullable: true),
                    purchase_quantity = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    receipted_invoices = table.Column<bool>(type: "bit", nullable: false),
                    trip_remark = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    no_customer_request = table.Column<bool>(type: "bit", nullable: true),
                    notify_unit_pending = table.Column<bool>(type: "bit", nullable: false),
                    street_pickup = table.Column<bool>(type: "bit", nullable: true),
                    last_update = table.Column<DateTime>(type: "datetime", nullable: true),
                    last_update_by = table.Column<int>(type: "int", nullable: true),
                    assigned_id_driver = table.Column<int>(type: "int", nullable: true),
                    assigned_id_unit = table.Column<int>(type: "int", nullable: true),
                    assigned_id_vehicle = table.Column<int>(type: "int", nullable: true),
                    id_service_type = table.Column<int>(type: "int", nullable: true),
                    passenger_phone = table.Column<string>(type: "varchar(20)", nullable: true),
                    dispatch_triggered = table.Column<DateTime>(type: "datetime", nullable: true),
                    cpu_final_destination_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    card_number = table.Column<string>(type: "nvarchar(30)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_target_history", x => x.id_target);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "target_history",
                schema: "dbo");

           
        }
    }
}
