﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NetCabManager.Infrastructure.Migrations
{
    public partial class Driver_Invoice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DriverInvoices",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DriverId = table.Column<int>(type: "int", nullable: true),
                    UnitId = table.Column<int>(type: "int", nullable: true),
                    DriverName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateFrom = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateTo = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Num = table.Column<int>(type: "int", nullable: true),
                    DriverPrice = table.Column<double>(type: "float", nullable: true),
                    DriverShare = table.Column<double>(type: "float", nullable: true),
                    CardNum = table.Column<int>(type: "int", nullable: true),
                    CardSum = table.Column<double>(type: "float", nullable: true),
                    PaymentToDriver = table.Column<double>(type: "float", nullable: true),
                    PaymentOfDriver = table.Column<double>(type: "float", nullable: true),
                    DriverCommission = table.Column<double>(type: "float", nullable: true),
                    NetCabCommission = table.Column<double>(type: "float", nullable: true),
                    CompanyIdentification = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DriverInvoices", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DriverInvoices");
        }
    }
}
