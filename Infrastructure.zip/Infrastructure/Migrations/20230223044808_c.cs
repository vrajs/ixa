﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NetCabManager.Infrastructure.Migrations
{
    public partial class c : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Companies",
                columns: table => new
                {
                    CompanyIdentification = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CanIssueUpdate = table.Column<bool>(type: "bit", nullable: false),
                    SqlServerIp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SqlInstanceName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SqlInstancePort = table.Column<int>(type: "int", nullable: false),
                    SqlDatabaseName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SqlServerUsername = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SqlServerPassword = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CompanyTitle = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Note = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UnitServerHost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UnitServerPort = table.Column<int>(type: "int", nullable: false),
                    WebServiceHost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PrimaryColor = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Companies", x => x.CompanyIdentification);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Companies");
        }
    }
}
