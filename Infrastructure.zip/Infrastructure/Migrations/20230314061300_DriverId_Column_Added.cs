﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NetCabManager.Infrastructure.Migrations
{
    public partial class DriverId_Column_Added : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DriverId",
                schema: "Identity",
                table: "Users",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DriverId",
                schema: "Identity",
                table: "Users");
        }
    }
}
