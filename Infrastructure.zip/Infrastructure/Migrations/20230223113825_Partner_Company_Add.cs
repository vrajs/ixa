﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

#nullable disable

namespace NetCabManager.Infrastructure.Migrations
{
    public partial class Partner_Company_Add : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PartnerCompanies",
                schema: "dbo",
                columns: table => new
                {
                    id_company = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    address = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    id_post = table.Column<int>(type: "int", nullable: true),
                    tax_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    deleted = table.Column<bool>(type: "bit", nullable: true),
                    id_record = table.Column<int>(type: "int", nullable: true),
                    internal_company = table.Column<bool>(type: "bit", nullable: true),
                    delayed_payment_default = table.Column<bool>(type: "bit", nullable: false),
                    post = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    phone = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    id_payment_type_default = table.Column<int>(type: "int", nullable: true),
                    id_tariff_default = table.Column<int>(type: "int", nullable: true),
                    short_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    contract_number = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    inserted = table.Column<DateTime>(type: "datetime", nullable: true),
                    comment = table.Column<string>(type: "text", nullable: true),
                    coupon_value = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    contract_text = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    payment_due_date_text = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    booking_remarks = table.Column<string>(type: "text", nullable: true),
                    einvoice = table.Column<bool>(type: "bit", nullable: true),
                    iban = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    register_number = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    discount = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    signature_invoice = table.Column<bool>(type: "bit", nullable: false),
                    default_type1 = table.Column<bool>(type: "bit", nullable: false),
                    default_type2 = table.Column<bool>(type: "bit", nullable: false),
                    default_type3 = table.Column<bool>(type: "bit", nullable: false),
                    default_type4 = table.Column<bool>(type: "bit", nullable: false),
                    default_type5 = table.Column<bool>(type: "bit", nullable: false),
                    default_type6 = table.Column<bool>(type: "bit", nullable: false),
                    default_type7 = table.Column<bool>(type: "bit", nullable: false),
                    default_type8 = table.Column<bool>(type: "bit", nullable: false),
                    default_type9 = table.Column<bool>(type: "bit", nullable: false),
                    default_type10 = table.Column<bool>(type: "bit", nullable: false),
                    default_type11 = table.Column<bool>(type: "bit", nullable: false),
                    default_type12 = table.Column<bool>(type: "bit", nullable: false),
                    default_type13 = table.Column<bool>(type: "bit", nullable: false),
                    default_type14 = table.Column<bool>(type: "bit", nullable: false),
                    default_type15 = table.Column<bool>(type: "bit", nullable: false),
                    default_type16 = table.Column<bool>(type: "bit", nullable: false),
                    default_type17 = table.Column<bool>(type: "bit", nullable: false),
                    default_type18 = table.Column<bool>(type: "bit", nullable: false),
                    default_type19 = table.Column<bool>(type: "bit", nullable: false),
                    default_type20 = table.Column<bool>(type: "bit", nullable: false),
                    pass_validation = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    default_vehicle_type1 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type2 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type3 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type4 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type5 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type6 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type7 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type8 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type9 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type10 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type11 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type12 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type13 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type14 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type15 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type16 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type17 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type18 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type19 = table.Column<bool>(type: "bit", nullable: false),
                    default_vehicle_type20 = table.Column<bool>(type: "bit", nullable: false),
                    id_company_block = table.Column<int>(type: "int", nullable: true),
                    id_company_slip = table.Column<int>(type: "int", nullable: true),
                    outsourcing_company = table.Column<bool>(type: "bit", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PartnerCompanies", x => x.id_company);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PartnerCompanies",
                schema: "dbo");
        }
    }
}
