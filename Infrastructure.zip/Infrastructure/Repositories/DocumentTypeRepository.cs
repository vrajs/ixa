﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Misc;

namespace NetCabManager.Infrastructure.Repositories
{
    public class DocumentTypeRepository : IDocumentTypeRepository
    {
        private readonly IRepositoryAsync<DocumentType, int> _repository;

        public DocumentTypeRepository(IRepositoryAsync<DocumentType, int> repository)
        {
            _repository = repository;
        }
    }
}