﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    class VehicleRepository : IVehicleRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<Vehicle, int> _repository;

        public VehicleRepository(ITaxiCompanyRepositoryAsync<Vehicle, int> repository)
        {
            _repository = repository;
        }
    }
}