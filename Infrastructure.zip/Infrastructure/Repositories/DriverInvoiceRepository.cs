﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class DriverInvoiceRepository : IDriverInvoiceRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<DriverInvoice, int> _repository;

        public DriverInvoiceRepository(ITaxiCompanyRepositoryAsync<DriverInvoice, int> repository)
        {
            _repository = repository;
        }
    }
}
