﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class PartnerCompanyRepository : IPartnerCompanyRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<PartnerCompany, int> _repository;

        public PartnerCompanyRepository(ITaxiCompanyRepositoryAsync<PartnerCompany, int> repository)
        {
            _repository = repository;
        }
    }
}