﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class UnitRepository : IUnitRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<Unit, int> _repository;

        public UnitRepository(ITaxiCompanyRepositoryAsync<Unit, int> repository)
        {
            _repository = repository;
        }
    }
}