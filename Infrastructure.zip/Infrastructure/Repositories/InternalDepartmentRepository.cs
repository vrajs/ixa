﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class InternalDepartmentRepository : IInternalDepartmentRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<InternalDepartment, int> _repository;

        public InternalDepartmentRepository(ITaxiCompanyRepositoryAsync<InternalDepartment, int> repository)
        {
            _repository = repository;
        }
    }
}