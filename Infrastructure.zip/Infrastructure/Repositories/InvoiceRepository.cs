﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<Invoice, int> _repository;

        public InvoiceRepository(ITaxiCompanyRepositoryAsync<Invoice, int> repository)
        {
            _repository = repository;
        }
    }
}
