﻿using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Infrastructure.Contexts;
using NetCabManager.Infrastructure.Services.TaxiCompany;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class DriverRepository : IDriverRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<Driver, int> _repository;
        
        public DriverRepository(ITaxiCompanyRepositoryAsync<Driver, int> repository)
        {
            _repository = repository;
        }
    }
}