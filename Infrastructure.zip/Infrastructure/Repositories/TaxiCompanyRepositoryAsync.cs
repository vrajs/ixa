﻿namespace NetCabManager.Infrastructure.Repositories
{
    using LazyCache;
    using Microsoft.AspNetCore.Components;
    using Microsoft.EntityFrameworkCore;
    using NetCabManager.Application.Features.Companies.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Interfaces.Services;
    using NetCabManager.Client.Infrastructure.Managers.Catalog.Company;
    using NetCabManager.Domain.Contracts;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.TaxiCompany.Context;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Application.Features;

    public class TaxiCompanyRepositoryAsync<T, TId> : ITaxiCompanyRepositoryAsync<T, TId> where T : AuditableEntityTaxiCompany<TId>
    {
        private TaxiCompanyContext _dbContext;
        private readonly ITaxiCompanyService _taxiCompanyService;
        private readonly ICurrentUserService _currentUserService;
        private readonly IAppCache _appCache;
        private GetAllCompaniesResponse _company = new();
        private List<GetAllCompaniesResponse> _companyList = new();
        [Inject]
        private ICompanyManager CompanyManager { get; set; }
        [Parameter]
        public string Id { get; set; }
        public TaxiCompanyRepositoryAsync(ITaxiCompanyService taxiCompanyService,
                                          ICurrentUserService currentUserService,
                                          IAppCache appCache)
        {
            _taxiCompanyService = taxiCompanyService;
            _currentUserService = currentUserService;
            _appCache = appCache;
            _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            _taxiCompanyService.GetCurrentUserCompany(_taxiCompanyService.User);
            //_company.SqlDatabaseName = "NetCabWeb";
            //_company.SqlServerIp = "developement.net-informatika.com";
            //_company.SqlInstanceName = "MSSQLSERVER";
            //_company.SqlInstancePort = 1433;
            //_company.SqlServerUsername = "sa";
            //_company.SqlServerPassword = "h1F5ltiyH_341NXYQObZ0Z";
            //_company.CompanyTitle = "NET Informatika Test";
            //_company.UnitServerHost = "developement.net-informatika.com";
            //_company.UnitServerPort = 59999;
            //_company.WebServiceHost = "developement.net-informatika.com";
            
            //var response = CompanyManager.GetAllAsync();

            //if (response.IsCompletedSuccessfully)
            //{
            //    //_companyList = response.Data.ToList();

            //    //if (_companyList is not null)
            //    //{
            //    //    _companyList.ForEach(Company =>
            //    //    {
            //    //        Company.ConnectionString = ConnectionStringBuilder.CreateConnectionString(Company);
            //    //    });
            //    //}
            //}
            _dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(_taxiCompanyService.Company));
        }

        public IQueryable<T> Entities => _dbContext.Set<T>();

        public async Task<List<T>> GetAllAsync()
        {
            //await _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //await _taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            return await _dbContext.Set<T>().ToListAsync();
        }

        public async Task<T> GetByIdAsync(TId id)
        {
            //await _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //await _taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            return await _dbContext.Set<T>().FindAsync(id);
        }

        public async Task<List<T>> GetPagedResponseAsync(int pageNumber, int pageSize)
        {
            //await _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //await _taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            return await _dbContext.Set<T>()
                                   .Skip((pageNumber - 1) * pageSize)
                                   .Take(pageSize)
                                   .AsNoTracking()
                                   .ToListAsync();
        }

        public async Task<T> AddAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys)
        {
            //await _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //await _taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            await _dbContext.Set<T>().AddAsync(entity);

            await _dbContext.SaveChangesAsync(cancellationToken);

            foreach (var cacheKey in cacheKeys)
            {
                _appCache.Remove(cacheKey);
            }

            return entity;
        }

        public async Task<int> UpdateAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys)
        {
            //_taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //_taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            T exist = _dbContext.Set<T>().Find(entity.Id);

            _dbContext.Entry(exist).CurrentValues.SetValues(entity);

            var result = await _dbContext.SaveChangesAsync(cancellationToken);

            foreach (var cacheKey in cacheKeys)
            {
                _appCache.Remove(cacheKey);
            }

            return result;
        }

        public async Task<int> DeleteAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys)
        {
            //await _taxiCompanyService.GetCurrentUser(_currentUserService.UserId);
            //await _taxiCompanyService.GetCurrentUserCompany(null);
            //_dbContext = _taxiCompanyService.CreateDbContext(_taxiCompanyService.CreateConnectionString(null));

            _dbContext.Set<T>().Remove(entity);

            var result = await _dbContext.SaveChangesAsync(cancellationToken);

            foreach (var cacheKey in cacheKeys)
            {
                _appCache.Remove(cacheKey);
            }

            return result;
        }
    }
}