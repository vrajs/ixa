﻿using AutoMapper;
using NetCabManager.Application.Features;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Wrapper;
using Microsoft.EntityFrameworkCore;
using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly IRepositoryAsync<Company, string> _repository;
        private readonly IMapper _mapper;

        public CompanyRepository(IRepositoryAsync<Company, string> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<Result<List<GetAllCompaniesResponse>>> GetAllCompaniesAsync()
        {
            var companies = await _repository.GetAllAsync();

            var mappedCompanies = _mapper.Map<List<GetAllCompaniesResponse>>(companies);

            return await Result<List<GetAllCompaniesResponse>>.SuccessAsync(mappedCompanies);
        }
    }
}