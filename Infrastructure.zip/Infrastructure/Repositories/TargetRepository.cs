﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class TargetRepository : ITargetRepository
    {
        private readonly ITaxiCompanyRepositoryAsync<TargetHistory, int> _repository;

        public TargetRepository(ITaxiCompanyRepositoryAsync<TargetHistory, int> repository)
        {
            _repository = repository;
        }
    }
}