﻿using AutoMapper;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Infrastructure.Repositories
{
    public class NetCabToFleetRepository : INetCabToFleetRepository
    {
        private readonly IRepositoryAsync<NetCabToFleet, string> _repository;
        private readonly IMapper _mapper;

        public NetCabToFleetRepository(IRepositoryAsync<NetCabToFleet, string> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<Result<List<GetAllNetCabToFleetsResponse>>> GetAllNetCabFleetsAsync()
        {
            var netcabfleets = await _repository.GetAllAsync();

            var mappednetcabfleets = _mapper.Map<List<GetAllNetCabToFleetsResponse>>(netcabfleets);

            return await Result<List<GetAllNetCabToFleetsResponse>>.SuccessAsync(mappednetcabfleets);
        }
    }
}
