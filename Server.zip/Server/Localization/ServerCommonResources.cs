﻿namespace NetCabManager.Server.Localization
{
    internal class ServerCommonResources
    {
        // Used to localize strings in static classes
    }
}