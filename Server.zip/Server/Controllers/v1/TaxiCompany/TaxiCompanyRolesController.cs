﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCabManager.Server.Controllers.v1.TaxiCompany
{
    public class TaxiCompanyRolesController : BaseApiController<TaxiCompanyRolesController>
    {
        [Authorize(Policy = Permissions.TaxiCompanyRoles.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var taxiCompanyRoles = await _mediator.Send(new GetAllTaxiCompanyRolesQuery());

            return Ok(taxiCompanyRoles);
        }
    }
}