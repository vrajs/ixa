﻿namespace NetCabManager.Server.Controllers.v1.TaxiCompany
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.Delete;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll;
    using NetCabManager.Shared.Constants.Permission;
    using System.Threading.Tasks;

    public class TaxiCompanyUsersController : BaseApiController<TaxiCompanyUsersController>
    {
        [Authorize(Policy = Permissions.TaxiCompanyUsers.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var taxiCompanyUsers = await _mediator.Send(new GetAllTaxiCompanyUsersQuery());

            return Ok(taxiCompanyUsers);
        }

        [Authorize(Policy = Permissions.TaxiCompanyUsers.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var taxiCompanyUsers = await _mediator.Send(new GetAllPagedTaxiCompanyUsersQuery(pageNumber, pageSize, searchString));

            return Ok(taxiCompanyUsers);
        }

        [Authorize(Policy = Permissions.TaxiCompanyUsers.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditTaxiCompanyUserCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.TaxiCompanyUsers.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteTaxiCompanyUserCommand() { Id = id }));
        }
    }
}