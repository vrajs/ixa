﻿namespace NetCabManager.Server.Controllers.v1.TaxiCompany
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using NetCabManager.Application.Features.Settings.Queries.GetAll;
    using NetCabManager.Shared.Constants.Permission;
    using System.Threading.Tasks;

    public class SettingsController : BaseApiController<SettingsController>
    {
        [Authorize(Policy = Permissions.Settings.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var settings = await _mediator.Send(new GetAllSettingsQuery());
            
            return Ok(settings);
        }
    }
}