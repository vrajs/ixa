﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Commands.Delete;
using NetCabManager.Application.Features.Invoices.Queries.Export;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using NetCabManager.Application.Features.Invoices.Queries.GetById;
using NetCabManager.Shared.Constants.Permission;
using Polly;
using System.Threading.Tasks;
using NetCabManager.Application.Features.DriverInvoices.Queries.Export;
using NetCabManager.Application.Features.DriverInvoices.Queries.GetAll;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class DriverInvoiceController : BaseApiController<DriverInvoiceController>
    {
        //[Authorize(Policy = Permissions.DriverInvoices.View)]
        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    var invoices = await _mediator.Send(new GetAllDriverInvoiceQuery());

        //    return Ok(invoices);
        //}

        [Authorize(Policy = Permissions.DriverInvoices.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString,int? month,string driverName)
        {
            var invoices = await _mediator.Send(new GetAllDriverInvoicePagedQuery(pageNumber, pageSize, searchString,month,driverName));

            return Ok(invoices);
        }
        [Authorize(Policy = Permissions.DriverInvoices.View)]
        [HttpGet("getAllRides")]
        public async Task<IActionResult> GetAllRides(int pageNumber, int pageSize, string searchString,int driverId)
        {
            var invoices = await _mediator.Send(new GetAllRidesPagedQuery(pageNumber, pageSize, searchString,  driverId));

            return Ok(invoices);
        }

        //[Authorize(Policy = Permissions.DriverInvoices.View)]
        //[HttpGet("{id}")]
        //public async Task<IActionResult> GetById(int id)
        //{
        //    var invoice = await _mediator.Send(new GetInvoiceByIdQuery() { Id = id });

        //    return Ok(invoice);
        //}

        //[Authorize(Policy = Permissions.DriverInvoices.Create)]
        //[HttpPost]
        //public async Task<IActionResult> Post(AddEditInvoiceCommand command)
        //{
        //    return Ok(await _mediator.Send(command));
        //}

        //[Authorize(Policy = Permissions.DriverInvoices.Delete)]
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    return Ok(await _mediator.Send(new DeleteInvoiceCommand() { Id = id }));
        //}

        [Authorize(Policy = Permissions.DriverInvoices.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportDriverInvoiceQuery(searchString)));
        }
    }
}
