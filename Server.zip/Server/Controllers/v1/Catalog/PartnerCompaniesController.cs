﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit;
using NetCabManager.Application.Features.PartnerCompanies.Commands.Delete;
using NetCabManager.Application.Features.PartnerCompanies.Queries.Export;
using NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll;
using NetCabManager.Application.Features.PartnerCompanies.Queries.GetById;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class PartnerCompaniesController : BaseApiController<PartnerCompaniesController>
    {
        [Authorize(Policy = Permissions.PartnerCompanies.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var partnerCompanies = await _mediator.Send(new GetAllPartnerCompaniesQuery());

            return Ok(partnerCompanies);
        }

        [Authorize(Policy = Permissions.PartnerCompanies.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var partnerCompanies = await _mediator.Send(new GetAllPartnerCompaniesPagedQuery(pageNumber, pageSize, searchString));

            return Ok(partnerCompanies);
        }

        [Authorize(Policy = Permissions.PartnerCompanies.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var partnerCompany = await _mediator.Send(new GetPartnerCompanyByIdQuery() { Id = id });

            return Ok(partnerCompany);
        }

        [Authorize(Policy = Permissions.PartnerCompanies.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditPartnerCompanyCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.PartnerCompanies.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeletePartnerCompanyCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.PartnerCompanies.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportPartnerCompaniesQuery(searchString)));
        }
    }
}