﻿namespace NetCabManager.Server.Controllers.v1.Catalog
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using NetCabManager.Application.Features.Targets.Commands.AddEdit;
    using NetCabManager.Application.Features.Targets.Commands.Delete;
    using NetCabManager.Application.Features.Targets.Queries.Export;
    using NetCabManager.Application.Features.Targets.Queries.GetAll;
    using NetCabManager.Application.Features.Targets.Queries.GetById;
    using NetCabManager.Shared.Constants.Permission;
    using System;
    using System.Threading.Tasks;

    public class TargetsController : BaseApiController<TargetsController>
    {
        
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var targets = await _mediator.Send(new GetAllTargetsQuery());

            return Ok(targets);
        }
      
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString, int radioValue, DateTime startDate, DateTime endDate)
        {
            var targets = await _mediator.Send(new GetAllTargetsPagedQuery(pageNumber, pageSize, searchString, radioValue, startDate, endDate));
            
            return Ok(targets);
        }

        [HttpGet("pagedInternal")]
        public async Task<IActionResult> GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            var targets = await _mediator.Send(new GetAllTargetsPagedInternalQuery(pageNumber, pageSize, searchString, idInternalDepartment));

            return Ok(targets);
        }
      
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var target = await _mediator.Send(new GetTargetByIdQuery() { Id = id });

            return Ok(target);
        }
        
        [HttpPost]
        public async Task<IActionResult> Post(AddEditTargetCommand command)
        {
            return Ok(await _mediator.Send(command));
        }
       
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteTargetCommand() { Id = id }));
        }

        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportTargetsQuery(searchString)));
        }
    }
}