﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit;
using NetCabManager.Application.Features.InternalDepartments.Commands.Delete;
using NetCabManager.Application.Features.InternalDepartments.Queries.Export;
using NetCabManager.Application.Features.InternalDepartments.Queries.GetAll;
using NetCabManager.Application.Features.InternalDepartments.Queries.GetById;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class InternalDepartmentsController : BaseApiController<InternalDepartmentsController>
    {
        [Authorize(Policy = Permissions.InternalDepartments.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var internalDepartments = await _mediator.Send(new GetAllInternalDepartmentsQuery());

            return Ok(internalDepartments);
        }

        [Authorize(Policy = Permissions.InternalDepartments.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var vehicles = await _mediator.Send(new GetAllInternalDepartmentsPagedQuery(pageNumber, pageSize, searchString));

            return Ok(vehicles);
        }

        [Authorize(Policy = Permissions.InternalDepartments.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var internalDepartment = await _mediator.Send(new GetInternalDepartmentByIdQuery() { Id = id });

            return Ok(internalDepartment);
        }

        [Authorize(Policy = Permissions.InternalDepartments.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditInternalDepartmentCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.InternalDepartments.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteInternalDepartmentCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.InternalDepartments.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportInternalDepartmentsQuery(searchString)));
        }
    }
}