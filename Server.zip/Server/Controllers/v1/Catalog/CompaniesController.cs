﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using NetCabManager.Server.Controllers;
using NetCabManager.Shared.Constants.Permission;
using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Application.Features.Companies.Commands.AddEdit;
using NetCabManager.Application.Features.Companies.Commands.Delete;
using NetCabManager.Application.Features.Companies.Queries.GetById;
using NetCabManager.Application.Features.Companies.Queries.Export;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class CompaniesController : BaseApiController<CompaniesController>
    {
        [HttpGet]
        [Authorize(Policy = Permissions.Companies.View)]
        public async Task<IActionResult> GetAll()
        {
            var companies = await _mediator.Send(new GetAllCompaniesQuery());

            return Ok(companies);
        }

        [HttpGet("{id}")]
        [Authorize(Policy = Permissions.Companies.View)]
        public async Task<IActionResult> GetById(string id)
        {
            var company = await _mediator.Send(new GetCompanyByIdQuery() { Id = id });

            return Ok(company);
        }

        [HttpPost]
        [Authorize(Permissions.Companies.Create)]
        public async Task<IActionResult> Post(AddEditCompanyCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [HttpDelete("{id}")]
        [Authorize(Policy = Permissions.Companies.Delete)]
        public async Task<IActionResult> Delete(string id)
        {
            return Ok(await _mediator.Send(new DeleteCompanyCommand { Id = id }));
        }

        [HttpGet("export")]
        [Authorize(Permissions.Companies.Export)]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportCompaniesQuery(searchString)));
        }
    }
}