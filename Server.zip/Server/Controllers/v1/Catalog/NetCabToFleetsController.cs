﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetById;
using NetCabManager.Application.Features.NetCabToFleets.Commands.AddEdit;
using NetCabManager.Application.Features.NetCabToFleets.Commands.Delete;
using NetCabManager.Application.Features.NetCabToFleets.Queries.Export;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class NetCabToFleetsController : BaseApiController<NetCabToFleetsController>
    {
        [Authorize(Policy = Permissions.NetCabToFleets.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var netCabFleets = await _mediator.Send(new GetAllNetCabToFleetsQuery());

            return Ok(netCabFleets);
        }

        //[Authorize(Policy = Permissions.NetCabToFleets.View)]
        //[HttpGet("paged")]
        //public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        //{
        //    var vehicles = await _mediator.Send(new GetAllNetCabToFleetsPagedQuery(pageNumber, pageSize, searchString));

        //    return Ok(vehicles);
        //}

        [Authorize(Policy = Permissions.NetCabToFleets.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var netcabFleet = await _mediator.Send(new GetNetCabFleetByIdQuery() { Id = id });

            return Ok(netcabFleet);
        }

        [Authorize(Policy = Permissions.NetCabToFleets.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditNetCabToFleetCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.NetCabToFleets.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            return Ok(await _mediator.Send(new DeleteNetCabToFleetCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.NetCabToFleets.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportNetCabToFleetsQuery(searchString)));
        }
    }
}