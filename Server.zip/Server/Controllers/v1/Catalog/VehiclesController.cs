﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.Vehicles.Commands.AddEdit;
using NetCabManager.Application.Features.Vehicles.Commands.Delete;
using NetCabManager.Application.Features.Vehicles.Queries.Export;
using NetCabManager.Application.Features.Vehicles.Queries.GetById;
using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class VehiclesController : BaseApiController<VehiclesController>
    {
        [Authorize(Policy = Permissions.Vehicles.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var vehicles = await _mediator.Send(new GetAllVehiclesQuery());

            return Ok(vehicles);
        }

        [Authorize(Policy = Permissions.Vehicles.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var vehicles = await _mediator.Send(new GetAllVehiclesPagedQuery(pageNumber, pageSize, searchString));

            return Ok(vehicles);
        }

        [Authorize(Policy = Permissions.Vehicles.View)]
        [HttpGet("pagedInternal")]
        public async Task<IActionResult> GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            var vehicles = await _mediator.Send(new GetAllVehiclesPagedInternalQuery(pageNumber, pageSize, searchString, idInternalDepartment));

            return Ok(vehicles);
        }

        [Authorize(Policy = Permissions.Vehicles.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var vehicle = await _mediator.Send(new GetVehicleByIdQuery() { Id = id });

            return Ok(vehicle);
        }

        [Authorize(Policy = Permissions.Vehicles.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditVehicleCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.Vehicles.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteVehicleCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.Vehicles.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportVehiclesQuery(searchString)));
        }
    }
}