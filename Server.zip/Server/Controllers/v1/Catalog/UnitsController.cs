﻿namespace NetCabManager.Server.Controllers.v1.Catalog
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using NetCabManager.Application.Features.Units.Commands.AddEdit;
    using NetCabManager.Application.Features.Units.Commands.Delete;
    using NetCabManager.Application.Features.Units.Queries.Export;
    using NetCabManager.Application.Features.Units.Queries.GetAll;
    using NetCabManager.Application.Features.Units.Queries.GetById;
    using NetCabManager.Shared.Constants.Permission;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class UnitsController : BaseApiController<UnitsController>
    {
        [Authorize(Policy = Permissions.Units.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var units = await _mediator.Send(new GetAllUnitsQuery());

            return Ok(units);
        }

        [Authorize(Policy = Permissions.Units.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var units = await _mediator.Send(new GetAllUnitsPagedQuery(pageNumber, pageSize, searchString));

            return Ok(units);
        }

        [Authorize(Policy = Permissions.Units.View)]
        [HttpGet("pagedInternal")]
        public async Task<IActionResult> GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            var units = await _mediator.Send(new GetAllUnitsPagedInternalQuery(pageNumber, pageSize, searchString, idInternalDepartment));

            return Ok(units);
        }

        [Authorize(Policy = Permissions.Units.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var unit = await _mediator.Send(new GetUnitByIdQuery() { Id = id });

            return Ok(unit);
        }

        [Authorize(Policy = Permissions.Units.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditUnitCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.Units.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteUnitCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.Units.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportUnitsQuery(searchString)));
        }
    }
}