﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCabManager.Application.Features.Drivers.Commands.AddEdit;
using NetCabManager.Application.Features.Drivers.Commands.Delete;
using NetCabManager.Application.Features.Drivers.Queries.Export;
using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Drivers.Queries.GetById;
using NetCabManager.Shared.Constants.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCabManager.Server.Controllers.v1.Catalog
{
    public class DriversController : BaseApiController<DriversController>
    {
        [Authorize(Policy = Permissions.Drivers.View)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var drivers = await _mediator.Send(new GetAllDriversQuery());

            return Ok(drivers);
        }

        [Authorize(Policy = Permissions.Drivers.View)]
        [HttpGet("paged")]
        public async Task<IActionResult> GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            var drivers = await _mediator.Send(new GetAllDriversPagedQuery(pageNumber, pageSize, searchString));

            return Ok(drivers);
        }

        [Authorize(Policy = Permissions.Drivers.View)]
        [HttpGet("pagedInternal")]
        public async Task<IActionResult> GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            var drivers = await _mediator.Send(new GetAllDriversPagedInternalQuery(pageNumber, pageSize, searchString, idInternalDepartment));

            return Ok(drivers);
        }

        [Authorize(Policy = Permissions.Drivers.View)]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var driver = await _mediator.Send(new GetDriverByIdQuery() { Id = id });

            return Ok(driver);
        }

        [Authorize(Policy = Permissions.Drivers.Create)]
        [HttpPost]
        public async Task<IActionResult> Post(AddEditDriverCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [Authorize(Policy = Permissions.Drivers.Delete)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _mediator.Send(new DeleteDriverCommand() { Id = id }));
        }

        [Authorize(Policy = Permissions.Drivers.Export)]
        [HttpGet("export")]
        public async Task<IActionResult> Export(string searchString = "")
        {
            return Ok(await _mediator.Send(new ExportDriversQuery(searchString)));
        }
    }
}