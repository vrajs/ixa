﻿using System.Linq;
using NetCabManager.Shared.Constants.Localization;
using NetCabManager.Shared.Settings;

namespace NetCabManager.Server.Settings
{
    public record ServerPreference : IPreference
    {
        public string LanguageCode { get; set; } = LocalizationConstants.SupportedLanguages.FirstOrDefault()?.Code ?? "en-US";

        //TODO - add server preferences
    }
}