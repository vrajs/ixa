﻿using NetCabManager.Shared.Managers;

namespace NetCabManager.Server.Managers.Preferences
{
    public interface IServerPreferenceManager : IPreferenceManager
    {
    }
}
