﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class GeneralRemark
    {
        public int IdGeneralRemark { get; set; }
        public string Remark { get; set; }
    }
}
