﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class HostSipAccount
    {
        public string HostAddress { get; set; }
        public string SipAccount { get; set; }
    }
}
