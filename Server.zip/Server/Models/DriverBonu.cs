﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverBonu
    {
        public int IdDriverBonus { get; set; }
        public int IdDriver { get; set; }
        public double BonusAmmount { get; set; }
        public DateTime Inserted { get; set; }
        public bool Deleted { get; set; }
    }
}
