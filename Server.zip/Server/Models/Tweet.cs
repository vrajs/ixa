﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Tweet
    {
        public int IdMessage { get; set; }
        public string IdTweet { get; set; }
        public string Message { get; set; }
        public string IdUser { get; set; }
        public short Status { get; set; }
        public DateTime? TweetDatetime { get; set; }
        public string ReplyTweetId { get; set; }
        public bool? IsDirectMessage { get; set; }
        public string DirectMessageRecepient { get; set; }
    }
}
