﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceResourcesInUse
    {
        public int IdFinanceResourceInUse { get; set; }
        public int IdFinanceProduct { get; set; }
        public int IdResourceUser { get; set; }
        public int IdUserType { get; set; }
        public DateTime Inserted { get; set; }
        public bool Deleted { get; set; }
        public DateTime? DeletedDt { get; set; }
        public string PhoneNumber { get; set; }
        public bool? Paid { get; set; }
    }
}
