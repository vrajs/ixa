﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PushNotificationQueue
    {
        public int IdPushNotificationQueue { get; set; }
        public int IdTarget { get; set; }
        public int UnitId { get; set; }
        public int IdAppuser { get; set; }
        public string MessageTitle { get; set; }
        public string MessageText { get; set; }
        public bool IsProcessed { get; set; }
        public DateTime Inserted { get; set; }
        public int Type { get; set; }
        public string Data { get; set; }
    }
}
