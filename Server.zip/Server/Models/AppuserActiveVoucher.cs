﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserActiveVoucher
    {
        public int IdAppUser { get; set; }
        public int IdVoucher { get; set; }
        public bool Applied { get; set; }
    }
}
