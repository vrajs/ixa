﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class RequestToTalk
    {
        public int IdRequestToTalk { get; set; }
        public int? IdUnit { get; set; }
        public int IdDriver { get; set; }
        public bool Handled { get; set; }
        public DateTime Inserted { get; set; }
    }
}
