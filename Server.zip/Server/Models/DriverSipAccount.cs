﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverSipAccount
    {
        public int IdDriverSipAccount { get; set; }
        public int IdDriver { get; set; }
        public string SipServer { get; set; }
        public string SipUsername { get; set; }
        public string SipPassword { get; set; }
    }
}
