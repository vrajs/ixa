﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Licitation
    {
        public int IdLicitation { get; set; }
        public int IdTarget { get; set; }
        public DateTime LicitationStart { get; set; }
        public DateTime LicitationEnd { get; set; }
        public bool? LicitationClosed { get; set; }
        public DateTime? ClosedDt { get; set; }
    }
}
