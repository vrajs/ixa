﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class So
    {
        public int IdSos { get; set; }
        public int IdUnit { get; set; }
        public int IdDriver { get; set; }
        public DateTime Inserted { get; set; }
        public bool Handled { get; set; }
        public bool UnitNotified { get; set; }
    }
}
