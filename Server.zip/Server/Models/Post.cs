﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Post
    {
        public int IdPost { get; set; }
        public string PostName { get; set; }
        public int IdCountry { get; set; }
    }
}
