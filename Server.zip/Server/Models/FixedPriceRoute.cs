﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FixedPriceRoute
    {
        public int IdFixedPriceRoute { get; set; }
        public string Location { get; set; }
        public int? Lat { get; set; }
        public int? Lon { get; set; }
        public decimal? Price { get; set; }
        public bool Deleted { get; set; }
    }
}
