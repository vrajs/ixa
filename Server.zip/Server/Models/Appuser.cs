﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Appuser
    {
        public Appuser()
        {
            AppuserSettings = new HashSet<AppuserSetting>();
            ViberMessages = new HashSet<ViberMessage>();
        }

        public int IdAppuser { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Salt { get; set; }
        public bool? Validated { get; set; }
        public string DeviceToken { get; set; }
        public string DeviceType { get; set; }
        public string Imei { get; set; }
        public int? ThirdPartyIdAppuser { get; set; }
        public int? ThirdPartyType { get; set; }
        public bool? IsDeleted { get; set; }
        public int? DefaultIdCustomLocation { get; set; }
        public int? DefaultDispatchType { get; set; }
        public int? IdCompany { get; set; }
        public string DevicePushToken { get; set; }
        public short? IdInternalDepartment { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public string LastUpdateType { get; set; }
        public string AuthId { get; set; }
        public DateTime? InsertedDate { get; set; }

        public virtual ICollection<AppuserSetting> AppuserSettings { get; set; }
        public virtual ICollection<ViberMessage> ViberMessages { get; set; }
    }
}
