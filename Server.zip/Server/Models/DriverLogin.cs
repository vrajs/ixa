﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverLogin
    {
        public int IdDriverLogin { get; set; }
        public int IdDriver { get; set; }
        public int IdUnit { get; set; }
        public DateTime Login { get; set; }
        public DateTime LastActivity { get; set; }
        public DateTime? Logout { get; set; }
        public int? LogoutType { get; set; }
        public byte ShiftType { get; set; }
        public int TotalDistance { get; set; }
        public int HiredDistance { get; set; }
        public int? IdVehicle { get; set; }
    }
}
