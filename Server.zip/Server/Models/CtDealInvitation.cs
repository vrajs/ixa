﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtDealInvitation
    {
        public int IdCtDealInvitation { get; set; }
        public int IdCtDeal { get; set; }
        public int IdCtUser { get; set; }
        public string Code { get; set; }
        public DateTime RequestedAt { get; set; }
        public bool Validated { get; set; }
        public int PersonCount { get; set; }
    }
}
