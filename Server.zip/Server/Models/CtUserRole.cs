﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtUserRole
    {
        public int IdCtUserRole { get; set; }
        public string Title { get; set; }
    }
}
