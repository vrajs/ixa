﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceDocumentType
    {
        public int IdFinanceDocumentType { get; set; }
        public string DocumentTypeTitle { get; set; }
    }
}
