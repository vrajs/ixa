﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TelephonyExternalLine
    {
        public int IdTelephonyExternalLines { get; set; }
        public string Title { get; set; }
        public string Code { get; set; }
        public int? IdAreaOfOperation { get; set; }
    }
}
