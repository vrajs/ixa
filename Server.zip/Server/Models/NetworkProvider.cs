﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class NetworkProvider
    {
        public int IdNetworkProvider { get; set; }
        public string NetworkProvider1 { get; set; }
    }
}
