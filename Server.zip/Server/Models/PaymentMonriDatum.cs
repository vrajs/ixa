﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentMonriDatum
    {
        public int PaymentMonriDataId { get; set; }
        public int IdTarget { get; set; }
        public int? IdAppuser { get; set; }
        public string MonriCardData { get; set; }
        public decimal? PaymentAmmount { get; set; }
        public bool InitiateTransaction { get; set; }
        public bool TransactionCompleted { get; set; }
        public short? TransactionStatus { get; set; }
        public string ReferenceNumber { get; set; }
    }
}
