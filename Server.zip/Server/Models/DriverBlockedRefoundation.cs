﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverBlockedRefoundation
    {
        public int IdDriverBlockRefoundation { get; set; }
        public int IdDriverBlocked { get; set; }
        public int? IdControllerDriver { get; set; }
        public int? IdUser { get; set; }
        public int? IdTarget { get; set; }
        public bool? RefoundationRequested { get; set; }
        public string RefoundationFor { get; set; }
        public DateTime? RefoundationExpires { get; set; }
        public string UnblockedBy { get; set; }
        public string UnblockedReason { get; set; }
        public int? IdDriverBlockType { get; set; }
    }
}
