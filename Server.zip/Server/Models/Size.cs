﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Size
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }
}
