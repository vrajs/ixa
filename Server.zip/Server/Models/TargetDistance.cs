﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetDistance
    {
        public int IdRecord { get; set; }
        public int? IdTarget { get; set; }
        public string UnitId { get; set; }
        public double? AirDistance { get; set; }
        public double? HereDistance { get; set; }
        public double? HereArrivalTime { get; set; }
        public double? OsmDistance { get; set; }
        public double? OsmArrivalTime { get; set; }
        public double? GDistance { get; set; }
        public double? GArrivalTime { get; set; }
        public int? MqDistance { get; set; }
        public int? MqArrivalTime { get; set; }
        public DateTime CalculationTime { get; set; }
        public int? RouteDistance { get; set; }
        public int? RouteArrivalTime { get; set; }
        public int? RouteProvider { get; set; }
        public string CurrentPath { get; set; }
        public DateTime? DeactivationTime { get; set; }
        public int? RouteUnoccupiedDistance { get; set; }
        public int? RouteUnoccupiedArrivalTime { get; set; }
    }
}
