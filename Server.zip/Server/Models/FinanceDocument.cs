﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceDocument
    {
        public int IdFinanceDocument { get; set; }
        public string Client { get; set; }
        public DateTime Inserted { get; set; }
        public int Year { get; set; }
        public int IdDocumentType { get; set; }
        public DateTime? PaidDt { get; set; }
        public string Issuer { get; set; }
        public bool BlockUnpaid { get; set; }
        public DateTime? InvoiceGeneratedDt { get; set; }
        public bool IsInvoiceGenerated { get; set; }
    }
}
