﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class RolePermissionTemplate
    {
        public int IdRole { get; set; }
        public bool? CallCenterStatistics { get; set; }
        public bool? DriverStatistics { get; set; }
        public bool? VehicleStatistics { get; set; }
        public bool? DriverStatisticsTm { get; set; }
        public bool? VehicleStatisticsTm { get; set; }
        public bool? AcceptedUsersStatistics { get; set; }
        public bool? UnitLogoffStatistics { get; set; }
        public bool? ManuallyAssignedTargetsStatistics { get; set; }
        public bool? DriverPredictionStatistics { get; set; }
        public bool? CompanyTripReport { get; set; }
        public bool? FuelRefillStatistics { get; set; }
        public bool? LogonStatistics { get; set; }
        public bool? AutodispatchStatistics { get; set; }
        public bool? CustomersList { get; set; }
        public bool? Drivers { get; set; }
        public bool? Units { get; set; }
        public bool? Clients { get; set; }
        public bool? CustomLocation { get; set; }
        public bool? Stand { get; set; }
        public bool? Zones { get; set; }
        public bool? Trip { get; set; }
        public bool? Shifts { get; set; }
        public bool? Salaries { get; set; }
        public bool? FuelPrices { get; set; }
        public bool? FuelRefillAdm { get; set; }
        public bool? Users { get; set; }
        public bool? ArchiveData { get; set; }
        public bool? Sms { get; set; }
        public bool? Vehicle { get; set; }
        public bool? Remarks { get; set; }
        public bool? MobileUsers { get; set; }
        public bool? Streets { get; set; }
        public bool? CallStatistics { get; set; }
        public bool? ViberSettings { get; set; }
        public bool? Targets { get; set; }
        public bool? CompanyOrder { get; set; }
        public bool? QuickSearch { get; set; }
        public bool? ChangeFiscalPassword { get; set; }
    }
}
