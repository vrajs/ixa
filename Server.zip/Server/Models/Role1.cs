﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Role1
    {
        public string Username { get; set; }
        public string Role { get; set; }
    }
}
