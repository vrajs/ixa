﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyLoyaltyCard
    {
        public int IdCompanyLoyaltyCard { get; set; }
        public int IdCompany { get; set; }
        public string LoyaltyCardId { get; set; }
        public DateTime Inserted { get; set; }
    }
}
