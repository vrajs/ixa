﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentMonriPanToken
    {
        public int TokenId { get; set; }
        public string Md { get; set; }
        public string PanToken { get; set; }
    }
}
