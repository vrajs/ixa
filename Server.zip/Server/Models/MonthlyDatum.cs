﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class MonthlyDatum
    {
        public int IdMonthlyReport { get; set; }
        public short? Year { get; set; }
        public short? Month { get; set; }
        public DateTime? SendDate { get; set; }
    }
}
