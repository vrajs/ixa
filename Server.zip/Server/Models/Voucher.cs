﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Voucher
    {
        public int IdVoucher { get; set; }
        public string Voucher1 { get; set; }
        public bool IsActive { get; set; }
        public double DiscountValue { get; set; }
        public int DiscountPercentage { get; set; }
        public short VoucherType { get; set; }
        public int? NumberOfRides { get; set; }
        public double? MaxDiscountValue { get; set; }
    }
}
