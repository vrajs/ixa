﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinancialCategory
    {
        public int IdFinancialCategory { get; set; }
        public string Name { get; set; }
        public bool Editable { get; set; }
        public bool Disabled { get; set; }
    }
}
