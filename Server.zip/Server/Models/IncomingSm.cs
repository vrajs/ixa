﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class IncomingSm
    {
        public int IdSms { get; set; }
        public string PhoneNumber { get; set; }
        public string SmsMessage { get; set; }
        public DateTime? Timestamp { get; set; }
        public bool? IsReply { get; set; }
        public short? Status { get; set; }
        public bool? Active { get; set; }
        public string SubscriberPhoneNumber { get; set; }
    }
}
