﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtUnit
    {
        public int IdCtUnit { get; set; }
        public string Imei { get; set; }
        public int? Status { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public int? IdDriver { get; set; }
        public DateTime DtUpdate { get; set; }
        public int PassengerDetectionMode { get; set; }
        public string TaxiId { get; set; }
    }
}
