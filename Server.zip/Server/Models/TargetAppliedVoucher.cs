﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetAppliedVoucher
    {
        public int IdTarget { get; set; }
        public string VoucherData { get; set; }
    }
}
