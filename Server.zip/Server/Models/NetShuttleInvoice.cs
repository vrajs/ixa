﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class NetShuttleInvoice
    {
        public int IdInvoice { get; set; }
        public string UnitId { get; set; }
        public decimal Fare { get; set; }
        public decimal HiredDistance { get; set; }
        public bool? SendToDriver { get; set; }
    }
}
