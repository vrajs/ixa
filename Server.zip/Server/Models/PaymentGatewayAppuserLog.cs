﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentGatewayAppuserLog
    {
        public int IdPaymentGatewayAppuserLog { get; set; }
        public int IdAppuser { get; set; }
        public int IdTarget { get; set; }
        public string PaymentType { get; set; }
        public string CardType { get; set; }
        public string CardMask { get; set; }
    }
}
