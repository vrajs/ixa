﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Salary
    {
        public int IdSalary { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public int Type { get; set; }
        public DateTime Created { get; set; }
    }
}
