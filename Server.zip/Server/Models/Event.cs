﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Event
    {
        public int IdEvent { get; set; }
        public int? IdDriver { get; set; }
        public int? IdTarget { get; set; }
        public int? IdEventType { get; set; }
        public string Event1 { get; set; }
        public DateTime? DtAdded { get; set; }
        public string UnitId { get; set; }
    }
}
