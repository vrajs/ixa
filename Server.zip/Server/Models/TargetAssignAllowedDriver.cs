﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetAssignAllowedDriver
    {
        public int IdTargetAssignAllowedDriver { get; set; }
        public int IdTarget { get; set; }
        public int IdDriver { get; set; }
    }
}
