﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyPassenger
    {
        public int IdCompanyPassenger { get; set; }
        public int IdCompany { get; set; }
        public string Passenger { get; set; }
        public string Telephone { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
