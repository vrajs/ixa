﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class EmployeeLogin
    {
        public int IdEmployeeLogin { get; set; }
        public int IdEmployee { get; set; }
        public DateTime ActivityStarted { get; set; }
        public DateTime? ActivityEnded { get; set; }
        public byte LoginType { get; set; }
        public byte ShiftType { get; set; }
        public string SipAccount { get; set; }
    }
}
