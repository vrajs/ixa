﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentMonriTransactionLog
    {
        public int TransactionLogId { get; set; }
        public int OrderNumber { get; set; }
        public DateTime TransactionDatetime { get; set; }
        public string TransactionResponseMessage { get; set; }
    }
}
