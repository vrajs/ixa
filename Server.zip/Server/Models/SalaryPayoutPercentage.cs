﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SalaryPayoutPercentage
    {
        public int IdSalaryPayoutPercentage { get; set; }
        public double FareSumFrom { get; set; }
        public double FareSumTo { get; set; }
        public double PayoutPercentage { get; set; }
    }
}
