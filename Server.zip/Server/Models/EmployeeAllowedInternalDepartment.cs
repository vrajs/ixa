﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class EmployeeAllowedInternalDepartment
    {
        public int IdEmployeeAllowedInternalDepartment { get; set; }
        public int IdUser { get; set; }
        public int IdInternalDepartment { get; set; }
    }
}
