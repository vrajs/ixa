﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ClientType
    {
        public int IdClientType { get; set; }
        public string ClientType1 { get; set; }
    }
}
