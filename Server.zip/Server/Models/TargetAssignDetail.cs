﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetAssignDetail
    {
        public int IdTargetAssignDetail { get; set; }
        public int? IdTarget { get; set; }
        public int? IdDriver { get; set; }
        public int? Status { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public decimal? DispatchType { get; set; }
        public int? IdStand { get; set; }
        public int? IdZone { get; set; }
        public DateTime? Assigned { get; set; }
        public int? IdLicitation { get; set; }
        public int? IdUnitSnapshot { get; set; }
    }
}
