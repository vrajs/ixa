﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class VehicleCompany
    {
        public int IdVehicle { get; set; }
        public int IdCompany { get; set; }
    }
}
