﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyNote
    {
        public int IdCompanyNote { get; set; }
        public int IdCompany { get; set; }
        public string Note { get; set; }
        public bool? IsDeleted { get; set; }
        public int? SortingNumber { get; set; }
    }
}
