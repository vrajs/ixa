﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Unit
    {
        public int IdUnit { get; set; }
        public string UnitId { get; set; }
        public string Imei { get; set; }
        public string Imsi { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public string OrientLat { get; set; }
        public string OrientLon { get; set; }
        public double? Speed { get; set; }
        public string DtUpdate { get; set; }
        public string DtIdle { get; set; }
        public double? Y { get; set; }
        public double? X { get; set; }
        public int? Status { get; set; }
        public DateTime? DtTask { get; set; }
        public int? SosPos { get; set; }
        public string Sos { get; set; }
        public int? IdUnittype { get; set; }
        public string DeviceId { get; set; }
        public string PhoneNumber { get; set; }
        public string Ip { get; set; }
        public DateTime? UnitUpdate { get; set; }
        public string UnitIdTmp { get; set; }
        public bool? Position { get; set; }
        public bool? Service { get; set; }
        public int ZoneIn { get; set; }
        public int? ZoneTo { get; set; }
        public DateTime? ZoneArrival { get; set; }
        public int StandIn { get; set; }
        public DateTime? StandArrival { get; set; }
        public int Taximeter { get; set; }
        public DateTime? DestinationArrival { get; set; }
        public DateTime? DtTaximeterFree { get; set; }
        public byte RequestedStatus { get; set; }
        public DateTime? LocationUpdate { get; set; }
        public byte ConnectionQuality { get; set; }
        public string DestinationAddress { get; set; }
        public double? DestinationLat { get; set; }
        public double? DestinationLon { get; set; }
        public int IdInternalDepartment { get; set; }
        public string DeviceSerialNumber { get; set; }
        public int? IdVehicle { get; set; }
        public int? IdDriver { get; set; }
        public string SimSerialNumber { get; set; }
        public string IdTracker { get; set; }
        public bool NotifyPending { get; set; }
        public int? CurrentTariff { get; set; }
        public int? Heading { get; set; }
    }
}
