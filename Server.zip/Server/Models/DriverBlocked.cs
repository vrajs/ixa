﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverBlocked
    {
        public int IdDriverBlocked { get; set; }
        public int? IdDriver { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public string Note { get; set; }
        public int? IdUserInsert { get; set; }
        public DateTime? DateDeleted { get; set; }
        public bool? Deleted { get; set; }
        public int? IdUserDelete { get; set; }
    }
}
