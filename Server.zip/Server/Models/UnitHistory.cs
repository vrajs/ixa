﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitHistory
    {
        public int IdMessage { get; set; }
        public string UnitId { get; set; }
        public string Imei { get; set; }
        public string Imsi { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public int? Speed { get; set; }
        public string Sos { get; set; }
        public DateTime? DtUpdate { get; set; }
        public DateTime? DtIdle { get; set; }
        public int? Status { get; set; }
        public bool? Position { get; set; }
        public int IdZone { get; set; }
        public DateTime ZoneArrival { get; set; }
        public int IdStand { get; set; }
        public DateTime StandArrival { get; set; }
        public int Taximeter { get; set; }
        public int? Heading { get; set; }
    }
}
