﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtUnitStatusUpdate
    {
        public int IdCtUnitStatusUpdate { get; set; }
        public string TaxiIdIdentification { get; set; }
        public int Status { get; set; }
        public DateTime Inserted { get; set; }
    }
}
