﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ServiceUptime
    {
        public string ServiceName { get; set; }
        public DateTime LastUpdateDt { get; set; }
    }
}
