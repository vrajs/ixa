﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class LicitationUnit
    {
        public int IdLicitationUnit { get; set; }
        public int IdLicitation { get; set; }
        public string UnitId { get; set; }
        public bool? Notified { get; set; }
        public bool? Applied { get; set; }
        public bool? EndNotified { get; set; }
        public short ArrivalTime { get; set; }
        public DateTime? AppliedDt { get; set; }
    }
}
