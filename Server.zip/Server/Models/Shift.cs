﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Shift
    {
        public int IdShift { get; set; }
        public string DeviceId { get; set; }
        public string UnitId { get; set; }
        public string TmShiftNumber { get; set; }
        public string TmCarNumber { get; set; }
        public string TmDriverNumber { get; set; }
        public DateTime? TmShiftStart { get; set; }
        public DateTime? TmShiftEnd { get; set; }
        public int? TmTrips { get; set; }
        public decimal? TmEarnAvg { get; set; }
        public decimal? TmDistanceTotal { get; set; }
        public decimal? TmDistanceHired { get; set; }
        public decimal? TmDistanceForhire { get; set; }
        public decimal? TmDistanceDaily { get; set; }
        public decimal? TmDistanceTariff1 { get; set; }
        public decimal? TmDistanceTariff2 { get; set; }
        public decimal? TmDistanceBlack { get; set; }
        public int? TmWaitingTimeMinutes { get; set; }
        public decimal? TmFareAmmount { get; set; }
        public decimal? TmExtraCharges { get; set; }
        public decimal? TmCreditCardAmmount { get; set; }
        public decimal? TmTaxAmmount { get; set; }
        public decimal? TmTipsAmmount { get; set; }
        public DateTime Inserted { get; set; }
        public decimal? CalculatedStartingDistanceTotal { get; set; }
        public decimal? CalculatedStartingDistanceHired { get; set; }
        public int? CalculatedStartingTrips { get; set; }
        public decimal? CalculatedStartingFareAmmount { get; set; }
        public int? IdTaximeter { get; set; }
        public int IdPartialSalary { get; set; }
        public int IdFullSalary { get; set; }
        public decimal FullSalaryPercentage { get; set; }
        public bool Confirmed { get; set; }
    }
}
