﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitProperty
    {
        public int IdUnit { get; set; }
        public int IdPropertie { get; set; }
    }
}
