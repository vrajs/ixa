﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyCredential
    {
        public int IdCompanyCredential { get; set; }
        public int IdCompany { get; set; }
        public string IssuedTo { get; set; }
        public string Code { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
