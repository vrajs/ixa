﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PredefinedCompanyTarget
    {
        public int IdPredefinedCompanyTargets { get; set; }
        public int IdCompany { get; set; }
        public string Title { get; set; }
        public string Address { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public string DestinationAddress { get; set; }
        public double? DestinationLat { get; set; }
        public double? DestinationLon { get; set; }
        public decimal? Price { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string Remark { get; set; }
        public int? IdPaymentType { get; set; }
        public int? NumberOfPassengers { get; set; }
        public int? IdServiceType { get; set; }
        public DateTime? DispatchTime { get; set; }
        public bool? VehicleType1 { get; set; }
        public bool? VehicleType2 { get; set; }
        public bool? VehicleType3 { get; set; }
        public bool? VehicleType4 { get; set; }
        public bool? VehicleType5 { get; set; }
        public bool? VehicleType6 { get; set; }
        public bool? VehicleType7 { get; set; }
        public bool? VehicleType8 { get; set; }
        public bool? VehicleType9 { get; set; }
        public bool? VehicleType10 { get; set; }
        public bool? VehicleType11 { get; set; }
        public bool? VehicleType12 { get; set; }
        public bool? VehicleType13 { get; set; }
        public bool? VehicleType14 { get; set; }
        public bool? VehicleType15 { get; set; }
        public bool? VehicleType16 { get; set; }
        public bool? VehicleType17 { get; set; }
        public bool? VehicleType18 { get; set; }
        public bool? VehicleType19 { get; set; }
        public bool? VehicleType20 { get; set; }
        public bool? UsesPredefinedTimes { get; set; }
        public int? ReminderMin { get; set; }
        public int? IdTariff { get; set; }
    }
}
