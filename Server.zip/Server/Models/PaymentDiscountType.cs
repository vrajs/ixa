﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentDiscountType
    {
        public int PaymentDiscountTypeId { get; set; }
        public short DiscountType { get; set; }
        public DateTime ActiveFromDatetime { get; set; }
        public DateTime ActiveToDatetime { get; set; }
        public int DiscountPercentage { get; set; }
        public decimal? DiscountAmount { get; set; }
        public int MinumumNumberOfRides { get; set; }
        public int? DiscountedRidesNumber { get; set; }
        public decimal? MaximumDiscountValue { get; set; }
    }
}
