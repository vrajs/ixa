﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Version
    {
        public string Version1 { get; set; }
    }
}
