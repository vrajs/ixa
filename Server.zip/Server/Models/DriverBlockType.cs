﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverBlockType
    {
        public int IdDriverBlockType { get; set; }
        public string Title { get; set; }
        public int? BlockTimespanHours { get; set; }
    }
}
