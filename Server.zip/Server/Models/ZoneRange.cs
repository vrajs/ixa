﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ZoneRange
    {
        public int IdZoneRange { get; set; }
        public int IdZone { get; set; }
        public int IdStreet { get; set; }
        public int? EvenMax { get; set; }
        public string EvenMaxLabel { get; set; }
        public int? OddMax { get; set; }
        public string OddMaxLabel { get; set; }
    }
}
