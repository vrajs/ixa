﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetCategory
    {
        public int Id { get; set; }
        public int CategoryNumber { get; set; }
        public string CategoryName { get; set; }
    }
}
