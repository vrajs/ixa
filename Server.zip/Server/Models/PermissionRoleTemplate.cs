﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PermissionRoleTemplate
    {
        public int IdPermissionRoleTemplate { get; set; }
        public int IdRole { get; set; }
        public int IdPermission { get; set; }
        public int PermissionValue { get; set; }
    }
}
