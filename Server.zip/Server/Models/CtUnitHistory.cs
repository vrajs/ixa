﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtUnitHistory
    {
        public int IdMessage { get; set; }
        public int IdDriver { get; set; }
        public string Imei { get; set; }
        public double Lat { get; set; }
        public double Lon { get; set; }
        public DateTime DtUpdate { get; set; }
        public int Taximeter { get; set; }
    }
}
