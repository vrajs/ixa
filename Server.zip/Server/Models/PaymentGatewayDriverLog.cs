﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentGatewayDriverLog
    {
        public int IdPaymentGatewayDriverLog { get; set; }
        public string UnitId { get; set; }
        public int IdTarget { get; set; }
        public decimal PaymentAmount { get; set; }
        public DateTime PaymentDt { get; set; }
        public string ResponseCode { get; set; }
    }
}
