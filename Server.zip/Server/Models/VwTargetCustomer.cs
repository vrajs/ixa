﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class VwTargetCustomer
    {
        public string UlIme { get; set; }
        public int? Hs { get; set; }
        public string Hd { get; set; }
        public int? NaMid { get; set; }
        public int? NaId { get; set; }
        public int? PtId { get; set; }
        public string NaIme { get; set; }
        public string Remarkname { get; set; }
        public int? HsMid { get; set; }
    }
}
