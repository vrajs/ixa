﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class StandLocationPolygon
    {
        public int IdStandLocationPolygon { get; set; }
        public int? IdStand { get; set; }
        public string Polygon { get; set; }
    }
}
