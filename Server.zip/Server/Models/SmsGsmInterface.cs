﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SmsGsmInterface
    {
        public int IdSmsGsmInterface { get; set; }
        public string Phone { get; set; }
        public string Message { get; set; }
        public bool IsSent { get; set; }
        public DateTime Inserted { get; set; }
        public string SenderImei { get; set; }
        public string SenderPhoneNumber { get; set; }
    }
}
