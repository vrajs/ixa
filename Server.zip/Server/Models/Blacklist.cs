﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Blacklist
    {
        public int IdBlacklist { get; set; }
        public string Phone { get; set; }
        public DateTime? DtCreate { get; set; }
        public bool? Isdeleted { get; set; }
    }
}
