﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class GeneratedReport
    {
        public int IdGeneratedReport { get; set; }
        public DateTime CreatedDate { get; set; }
        public short? GeneratedReportType { get; set; }
    }
}
