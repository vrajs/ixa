﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SalaryDeduction
    {
        public int IdSalaryDeduction { get; set; }
        public int IdDriver { get; set; }
        public double DeductionAmmount { get; set; }
        public DateTime DeductionAt { get; set; }
        public bool Deleted { get; set; }
    }
}
