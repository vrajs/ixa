﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetCancelReason
    {
        public int IdTargetCancelReason { get; set; }
        public int IdTarget { get; set; }
        public int IdCancelationReason { get; set; }
        public DateTime CancelationDatetime { get; set; }
    }
}
