﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetVehicleCategory
    {
        public int IdRecord { get; set; }
        public int? IdTarget { get; set; }
        public bool VehicleType1 { get; set; }
        public bool VehicleType2 { get; set; }
        public bool VehicleType3 { get; set; }
        public bool VehicleType4 { get; set; }
        public bool VehicleType5 { get; set; }
        public bool VehicleType6 { get; set; }
        public bool VehicleType7 { get; set; }
        public bool VehicleType8 { get; set; }
        public bool VehicleType9 { get; set; }
        public bool VehicleType10 { get; set; }
        public bool VehicleType11 { get; set; }
        public bool VehicleType12 { get; set; }
        public bool VehicleType13 { get; set; }
        public bool VehicleType14 { get; set; }
        public bool VehicleType15 { get; set; }
        public bool VehicleType16 { get; set; }
        public bool VehicleType17 { get; set; }
        public bool VehicleType18 { get; set; }
        public bool VehicleType19 { get; set; }
        public bool VehicleType20 { get; set; }
    }
}
