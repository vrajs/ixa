﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DiscountType
    {
        public int IdDiscountType { get; set; }
        public string Title { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
