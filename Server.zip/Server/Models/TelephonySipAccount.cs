﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TelephonySipAccount
    {
        public int IdTelephonySipAccount { get; set; }
        public string SipUsername { get; set; }
        public string SipPassword { get; set; }
        public int CallParkingRangeStart { get; set; }
        public int CallParkingRangeEnd { get; set; }
    }
}
