﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class StandLocation
    {
        public int IdStandLocation { get; set; }
        public int? IdStand { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
    }
}
