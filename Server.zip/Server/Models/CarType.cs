﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CarType
    {
        public int IdCarType { get; set; }
        public int? IdCar { get; set; }
        public string CarType1 { get; set; }
        public bool? Isdeleted { get; set; }
    }
}
