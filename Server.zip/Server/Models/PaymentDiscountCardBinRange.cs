﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentDiscountCardBinRange
    {
        public int Id { get; set; }
        public int IsoBin { get; set; }
        public int RangeFrom { get; set; }
        public int RangeTo { get; set; }
        public string ProductName { get; set; }
    }
}
