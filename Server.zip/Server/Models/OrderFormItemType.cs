﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class OrderFormItemType
    {
        public int IdOrderFormItemType { get; set; }
        public string Name { get; set; }
    }
}
