﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverBankAccount
    {
        public int IdDriverAccountNumber { get; set; }
        public int IdDriver { get; set; }
        public string AccountNumber { get; set; }
        public DateTime? Inserted { get; set; }
        public DateTime? Deleted { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
