﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Setting
    {
        public int IdSetting { get; set; }
        public string SettingKey { get; set; }
        public string SettingValue { get; set; }
        public string Comment { get; set; }
        public string DefaultValue { get; set; }
    }
}
