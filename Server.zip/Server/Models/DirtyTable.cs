﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DirtyTable
    {
        public int IdRecord { get; set; }
        public string TableName { get; set; }
        public bool? IsDirty { get; set; }
        public DateTime? DirtyDate { get; set; }
        public int? DirtySeconds { get; set; }
    }
}
