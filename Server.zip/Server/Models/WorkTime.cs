﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class WorkTime
    {
        public int IdWorkTime { get; set; }
        public int? IdDriver { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
    }
}
