﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetHandledRequest
    {
        public int IdTargetHandledRequest { get; set; }
        public int IdTarget { get; set; }
        public string UnitId { get; set; }
        public DateTime RequestDt { get; set; }
        public bool RequestProcessed { get; set; }
        public int? ProcessedBy { get; set; }
        public DateTime? ProcessedDt { get; set; }
        public bool? Approved { get; set; }
    }
}
