﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Unittype
    {
        public int IdUnittype { get; set; }
        public string Name { get; set; }
    }
}
