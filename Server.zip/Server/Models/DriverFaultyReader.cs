﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverFaultyReader
    {
        public int IdDriverFaultyReader { get; set; }
        public int IdDriver { get; set; }
        public int IdUserAdded { get; set; }
        public DateTime DtAdded { get; set; }
        public int? IdUserRemoved { get; set; }
        public DateTime? DtRemoved { get; set; }
    }
}
