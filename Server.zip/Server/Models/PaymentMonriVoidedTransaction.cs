﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentMonriVoidedTransaction
    {
        public int IdVoidedTransaction { get; set; }
        public int OrderNumber { get; set; }
        public int Amount { get; set; }
        public bool TransactionVoided { get; set; }
    }
}
