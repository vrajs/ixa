﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverPaymentDatum
    {
        public int IdDriverPaymentData { get; set; }
        public string IdUnit { get; set; }
        public string BankAccount { get; set; }
        public string CardNumber { get; set; }
        public short? DefaultPaymentType { get; set; }
        public string FullName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public bool IsDeleted { get; set; }
    }
}
