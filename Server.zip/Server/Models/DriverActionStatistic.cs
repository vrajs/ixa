﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverActionStatistic
    {
        public int IdDriverActionStatistic { get; set; }
        public int IdDriverAction { get; set; }
        public int IdDriver { get; set; }
        public DateTime DtAction { get; set; }
    }
}
