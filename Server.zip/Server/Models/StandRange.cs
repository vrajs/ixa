﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class StandRange
    {
        public int IdStandRange { get; set; }
        public int IdStand { get; set; }
        public int IdStreet { get; set; }
        public int? EvenMax { get; set; }
        public string EvenMaxLabel { get; set; }
        public int? OddMax { get; set; }
        public string OddMaxLabel { get; set; }
    }
}
