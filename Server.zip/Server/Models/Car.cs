﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Car
    {
        public int IdCar { get; set; }
        public string Car1 { get; set; }
        public bool? Isdeleted { get; set; }
    }
}
