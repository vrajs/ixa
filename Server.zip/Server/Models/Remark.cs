﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Remark
    {
        public int IdRemark { get; set; }
        public int IdHsMid { get; set; }
        public string Remarkname { get; set; }
    }
}
