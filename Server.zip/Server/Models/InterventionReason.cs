﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class InterventionReason
    {
        public int IdInterventionReason { get; set; }
        public short? ReasonValue { get; set; }
        public string ReasonDescription { get; set; }
    }
}
