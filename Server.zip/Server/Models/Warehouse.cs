﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Warehouse
    {
        public int IdWarehouse { get; set; }
        public string WarehouseName { get; set; }
        public string ConnectionString { get; set; }
    }
}
