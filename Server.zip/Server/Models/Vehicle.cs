﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Vehicle
    {
        public Vehicle()
        {
            VehicleShiftReports = new HashSet<VehicleShiftReport>();
        }

        public int IdVehicle { get; set; }
        public string RegistrationNumber { get; set; }
        public string IdCar { get; set; }
        public string IdCarType { get; set; }
        public int? IdColour { get; set; }
        public string EngineDisp { get; set; }
        public string EnginePower { get; set; }
        public int? YearOf { get; set; }
        public int? NumOfSeats { get; set; }
        public DateTime? RegstrationDate { get; set; }
        public DateTime? OverviewDate { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string Note { get; set; }
        public bool? Isdeleted { get; set; }
        public int? VehicleNumber { get; set; }
        public DateTime? RegistrationDateTo { get; set; }
        public string InsurancePolicy { get; set; }
        public string InsurancePolicyNumber { get; set; }
        public DateTime? MotExpirationDate { get; set; }
        public string PriceListNumber { get; set; }
        public string LicenseNumber { get; set; }
        public DateTime? LicenseExpirationDate { get; set; }
        public byte[] Picture { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public short? IdInternalDepartment { get; set; }

        public virtual ICollection<VehicleShiftReport> VehicleShiftReports { get; set; }
    }
}
