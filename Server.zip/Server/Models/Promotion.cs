﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Promotion
    {
        public int IdPromotion { get; set; }
        public string DefaultLocale { get; set; }
        public string Sr { get; set; }
        public string Sl { get; set; }
        public bool Active { get; set; }
    }
}
