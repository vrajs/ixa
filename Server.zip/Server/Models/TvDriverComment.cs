﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TvDriverComment
    {
        public int IdDriverComment { get; set; }
        public int IdDriver { get; set; }
        public string Comment { get; set; }
        public string Contact { get; set; }
    }
}
