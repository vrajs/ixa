﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class OrderFromCompany
    {
        public int IdRecord { get; set; }
        public int? IdTarget { get; set; }
        public int? OrderFromCompany1 { get; set; }
        public DateTime? Inserted { get; set; }
    }
}
