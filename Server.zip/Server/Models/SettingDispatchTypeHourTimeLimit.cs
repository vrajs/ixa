﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SettingDispatchTypeHourTimeLimit
    {
        public int IdSettingDispatchTypeHourTimeLimits { get; set; }
        public int DispatchType { get; set; }
        public int HourFrom { get; set; }
        public int HourTo { get; set; }
        public int DriverPickupMaximumMinutes { get; set; }
    }
}
