﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ActiveAuction
    {
        public int IdAuction { get; set; }
        public short StatusFlag { get; set; }
    }
}
