﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceUserType
    {
        public int IdFinanceUserType { get; set; }
        public string UserTypeTitle { get; set; }
    }
}
