﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentGatewayAppuserRequestLog
    {
        public int IdPaymentGatewayAppuserRequest { get; set; }
        public DateTime RequestDatetime { get; set; }
        public int IdAppuser { get; set; }
        public string Email { get; set; }
        public string DeviceCode { get; set; }
    }
}
