﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyPhone
    {
        public int IdCompanyPhone { get; set; }
        public int? IdCompany { get; set; }
        public string Phone { get; set; }
    }
}
