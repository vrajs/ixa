﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TvDriver
    {
        public int IdDriver { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Salt { get; set; }
        public string ImagePath { get; set; }
        public string Description { get; set; }
        public string DescriptionNl { get; set; }
        public string CabNumber { get; set; }
        public string District { get; set; }
        public int? IdCompany { get; set; }
    }
}
