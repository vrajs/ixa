﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ClientBillingCenter
    {
        public int IdClientBillingCenter { get; set; }
        public int IdClient { get; set; }
        public string BillingCenter { get; set; }
        public bool IsDeleted { get; set; }
    }
}
