﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Trip
    {
        public int IdTrip { get; set; }
        public string DeviceId { get; set; }
        public string UnitId { get; set; }
        public int? IdTarget { get; set; }
        public double? LatStart { get; set; }
        public double? LonStart { get; set; }
        public double? LatEnd { get; set; }
        public double? LonEnd { get; set; }
        public DateTime DtStart { get; set; }
        public DateTime? DtEnd { get; set; }
        public decimal? Fare { get; set; }
        public string ExpirationDate { get; set; }
        public string PaymentType { get; set; }
        public string AuthNo { get; set; }
        public string TripType { get; set; }
        public string TopSpeed { get; set; }
        public string CreditCardNo { get; set; }
        public decimal? FareExtra { get; set; }
        public string BatchNo { get; set; }
        public string HiredDistance { get; set; }
        public string DriverNo { get; set; }
        public string TotalDistance { get; set; }
        public string CarNumber { get; set; }
        public decimal? Tips { get; set; }
        public int? TripConsecutiveNumber { get; set; }
        public bool Isdeleted { get; set; }
        public int IdPartialSalary { get; set; }
        public int IdFullSalary { get; set; }
        public double FullSalaryPercentage { get; set; }
        public int TypeExtra { get; set; }
        public int? IdTaximeter { get; set; }
        public int? IdShift { get; set; }
        public string AddressStart { get; set; }
        public string AddressEnd { get; set; }
        public string Coupon { get; set; }
        public string TargetStreet { get; set; }
        public string TargetDestination { get; set; }
        public decimal? SoftwareTaximeterFare { get; set; }
    }
}
