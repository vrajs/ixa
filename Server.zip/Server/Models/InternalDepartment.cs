﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class InternalDepartment
    {
        public int IdInternalDepartment { get; set; }
        public string InternalDepartment1 { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? Deleted { get; set; }
    }
}
