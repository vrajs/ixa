﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetCancelTime
    {
        public int IdTargetCancelTime { get; set; }
        public int? TargetCancelTime1 { get; set; }
        public byte? HourFrom { get; set; }
        public byte? HourTo { get; set; }
    }
}
