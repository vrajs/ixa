﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserThirdPartyType
    {
        public int IdAppuserThirdPartyType { get; set; }
        public string Title { get; set; }
        public bool? Visible { get; set; }
    }
}
