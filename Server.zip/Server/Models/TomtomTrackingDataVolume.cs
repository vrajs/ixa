﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TomtomTrackingDataVolume
    {
        public int IdDataVolume { get; set; }
        public DateTime Date { get; set; }
        public int SentLocations { get; set; }
    }
}
