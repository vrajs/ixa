﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ViberMessage
    {
        public int IdViberMessage { get; set; }
        public int IdAppuser { get; set; }
        public string Type { get; set; }
        public string Text { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public DateTime Timestamp { get; set; }
        public bool? IsReply { get; set; }
        public short? Status { get; set; }
        public bool? Active { get; set; }

        public virtual Appuser IdAppuserNavigation { get; set; }
    }
}
