﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Denial
    {
        public int IdDenial { get; set; }
        public int? IdTarget { get; set; }
        public string UnitId { get; set; }
        public int? AddedBy { get; set; }
    }
}
