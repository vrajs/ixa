﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Resource
    {
        public int IdResource { get; set; }
        public string ResourceKey { get; set; }
        public string ResourceValue { get; set; }
        public string Note { get; set; }
    }
}
