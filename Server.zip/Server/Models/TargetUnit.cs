﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetUnit
    {
        public int? IdUnit { get; set; }
        public string UnitId { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public DateTime? DtUpdate { get; set; }
        public DateTime? DtIdle { get; set; }
        public int? Status { get; set; }
        public DateTime? DtTask { get; set; }
        public int? IdUnittype { get; set; }
        public string DeviceId { get; set; }
        public DateTime? UnitUpdate { get; set; }
        public bool? Position { get; set; }
    }
}
