﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitFuelRefill
    {
        public int IdUnitFuelRefill { get; set; }
        public int IdUnit { get; set; }
        public int IdDriver { get; set; }
        public int FuelType { get; set; }
        public decimal Amount { get; set; }
        public decimal Price { get; set; }
        public DateTime Inserted { get; set; }
        public decimal TotalDistance { get; set; }
    }
}
