﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class NoCustomerStatus
    {
        public int IdNoCustomerStatus { get; set; }
        public int IdDriver { get; set; }
        public int IdTarget { get; set; }
        public DateTime DtReceived { get; set; }
        public short NoCustomerType { get; set; }
        public DateTime DtValidTo { get; set; }
        public int IdStand { get; set; }
        public bool NoCustomerHandled { get; set; }
        public int? NoCustomerTarget { get; set; }
    }
}
