﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FuelType
    {
        public int IdFuelType { get; set; }
        public string Title { get; set; }
        public string UnitOfMeasure { get; set; }
        public decimal PricePerUnit { get; set; }
    }
}
