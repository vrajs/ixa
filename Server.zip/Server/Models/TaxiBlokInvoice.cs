﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TaxiBlokInvoice
    {
        public int InvoiceId { get; set; }
        public bool Paid { get; set; }
        public DateTime? PaidDate { get; set; }
        public decimal? PaidAmmount { get; set; }
        public int? PaidCount { get; set; }
        public int? CompanyId { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
