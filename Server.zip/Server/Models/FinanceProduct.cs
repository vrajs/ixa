﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceProduct
    {
        public int IdFinanceProduct { get; set; }
        public string Name { get; set; }
        public decimal? Price { get; set; }
        public DateTime? Inserted { get; set; }
        public int IdProductType { get; set; }
    }
}
