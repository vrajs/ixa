﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TvCompany
    {
        public int IdTvCompany { get; set; }
        public string Title { get; set; }
        public string LogoPath { get; set; }
    }
}
