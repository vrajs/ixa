﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Stand
    {
        public int IdStand { get; set; }
        public string Title { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
        public int? IdBackupStand { get; set; }
        public short OrderValue { get; set; }
    }
}
