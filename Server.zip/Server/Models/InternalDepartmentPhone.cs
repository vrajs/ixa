﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class InternalDepartmentPhone
    {
        public int IdInternalDepartmentPhone { get; set; }
        public int IdInternalDepartment { get; set; }
        public string PhoneExtension { get; set; }
    }
}
