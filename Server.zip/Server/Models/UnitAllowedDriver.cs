﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitAllowedDriver
    {
        public int IdUnitAllowedDriver { get; set; }
        public int IdUnit { get; set; }
        public int IdDriver { get; set; }
        public bool IsDeleted { get; set; }
    }
}
