﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DispatchType
    {
        public int IdDispatchType { get; set; }
        public byte DispatchType1 { get; set; }
        public string Title { get; set; }
        public int? DriverPickupMaximumMinutes { get; set; }
        public string TargetAcceptTimes { get; set; }
        public short? LicitationDistance { get; set; }
        public bool LicitationType { get; set; }
        public bool DriverMayOptOut { get; set; }
    }
}
