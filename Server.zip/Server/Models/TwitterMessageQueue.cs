﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TwitterMessageQueue
    {
        public int IdTwitterMessageQueue { get; set; }
        public int IdMessage { get; set; }
        public bool IsMessageProcessed { get; set; }
        public string IdTweet { get; set; }
        public string Message { get; set; }
        public bool IsDirectMessage { get; set; }
        public string ScreenName { get; set; }
    }
}
