﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverDispatchType
    {
        public int IdDriverDispatchType { get; set; }
        public int IdDriver { get; set; }
        public int IdDispatchType { get; set; }
        public bool OptedOut { get; set; }
    }
}
