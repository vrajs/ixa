﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyBillingCenter
    {
        public int IdCompanyBillingCenter { get; set; }
        public int IdCompany { get; set; }
        public string BillingCenter { get; set; }
        public bool IsDeleted { get; set; }
    }
}
