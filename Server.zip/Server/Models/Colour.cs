﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Colour
    {
        public int IdColour { get; set; }
        public string Colour1 { get; set; }
    }
}
