﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyBlock
    {
        public int IdCompanyBlock { get; set; }
        public int IdCompany { get; set; }
        public int BlockNumberFrom { get; set; }
        public int BlockNumberTo { get; set; }
        public DateTime Inserted { get; set; }
    }
}
