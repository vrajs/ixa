﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Permission
    {
        public int IdPermission { get; set; }
        public string PermissionKey { get; set; }
        public string PermissionDisplayText { get; set; }
    }
}
