﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyCustomLocation
    {
        public int IdCompanyCustomLocation { get; set; }
        public int IdCompany { get; set; }
        public int IdCustomLocation { get; set; }
        public bool IsDeleted { get; set; }
    }
}
