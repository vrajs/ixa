﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TariffSchedule
    {
        public int IdTariffSchedule { get; set; }
        public int IdTariff { get; set; }
        public string ActiveDayOfTheWeek { get; set; }
        public int? ActiveHourFrom { get; set; }
        public int? ActiveHourTo { get; set; }
    }
}
