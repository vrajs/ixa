﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserAssignedVoucher
    {
        public int IdAppUser { get; set; }
        public int IdVoucher { get; set; }
        public bool IsUsed { get; set; }
        public int UsageCount { get; set; }
    }
}
