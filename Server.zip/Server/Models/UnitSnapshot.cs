﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitSnapshot
    {
        public int IdUnitSnapshot { get; set; }
        public string Snapshot { get; set; }
        public DateTime Created { get; set; }
        public short? SnapshotType { get; set; }
    }
}
