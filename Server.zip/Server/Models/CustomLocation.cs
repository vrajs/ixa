﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CustomLocation
    {
        public int IdCustomLocation { get; set; }
        public string Title { get; set; }
        public int Lat { get; set; }
        public int Lon { get; set; }
        public int IdStand { get; set; }
        public int IdZone { get; set; }
        public byte? InsertType { get; set; }
        public bool? ConfirmedAccuracy { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public int? IdPost { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public DateTime? ExpiresAtDt { get; set; }
    }
}
