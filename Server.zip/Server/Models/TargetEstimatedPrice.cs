﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetEstimatedPrice
    {
        public int IdTarget { get; set; }
        public decimal? EstimatedPrice { get; set; }
    }
}
