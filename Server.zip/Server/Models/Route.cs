﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Route
    {
        public string Timestamp { get; set; }
        public float? Longitude { get; set; }
        public float? Latitude { get; set; }
    }
}
