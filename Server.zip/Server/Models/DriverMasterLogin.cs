﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverMasterLogin
    {
        public int IdDriverMasterLogin { get; set; }
        public int IdDriver { get; set; }
        public DateTime Assigned { get; set; }
        public DateTime? Deassigned { get; set; }
    }
}
