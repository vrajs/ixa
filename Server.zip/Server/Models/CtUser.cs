﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CtUser
    {
        public int IdCtUser { get; set; }
        public int IdCtUserRole { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public bool Deleted { get; set; }
    }
}
