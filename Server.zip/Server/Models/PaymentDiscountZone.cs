﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentDiscountZone
    {
        public int IdDiscountZone { get; set; }
        public string ZoneName { get; set; }
        public short ZoneType { get; set; }
        public string ZonePolygon { get; set; }
    }
}
