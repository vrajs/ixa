﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Street
    {
        public int IdStreet { get; set; }
        public string Title { get; set; }
        public string SecTitle { get; set; }
        public string District { get; set; }
        public string SecDistrict { get; set; }
        public string City { get; set; }
        public string SecCity { get; set; }
    }
}
