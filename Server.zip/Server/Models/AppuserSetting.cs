﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserSetting
    {
        public int IdAppuserSetting { get; set; }
        public int IdAppuser { get; set; }
        public int IdInternalDepartment { get; set; }
        public bool IsSuperadmin { get; set; }

        public virtual Appuser IdAppuserNavigation { get; set; }
    }
}
