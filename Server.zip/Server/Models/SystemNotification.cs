﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SystemNotification
    {
        public int IdSystemNotification { get; set; }
        public string NotificationText { get; set; }
        public DateTime AddedDatetime { get; set; }
    }
}
