﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetPayment
    {
        public int IdPayment { get; set; }
        public int? IdTarget { get; set; }
        public bool? IsPaid { get; set; }
    }
}
