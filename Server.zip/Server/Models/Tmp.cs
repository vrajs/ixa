﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Tmp
    {
        public int PaymentMonriDataId { get; set; }
        public string TransactionResponseMessage { get; set; }
    }
}
