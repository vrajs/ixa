﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Driver
    {
        public Driver()
        {
            ShiftReportDrivers = new HashSet<ShiftReportDriver>();
        }

        public int IdDriver { get; set; }
        public string IdUnit { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public bool Isdeleted { get; set; }
        public string Password { get; set; }
        public string Gsm { get; set; }
        public string RegistrationNumber { get; set; }
        public string Car { get; set; }
        public string Imei { get; set; }
        public string License { get; set; }
        public string Company { get; set; }
        public string Note { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string CompanyPhone { get; set; }
        public string HomePhone { get; set; }
        public int? IdCompany { get; set; }
        public string Address { get; set; }
        public int? IdPost { get; set; }
        public string CarType { get; set; }
        public string CarColor { get; set; }
        public string EngineDisp { get; set; }
        public string EnginePower { get; set; }
        public int? YearOf { get; set; }
        public int? NumOfSeats { get; set; }
        public DateTime? RegstrationDate { get; set; }
        public DateTime? OverviewDate { get; set; }
        public string PersonalId { get; set; }
        public int Master { get; set; }
        public int? ImportedDriverId { get; set; }
        public string ImportedCarId { get; set; }
        public string Email { get; set; }
        public DateTime? LicenseExpiration { get; set; }
        public byte[] Picture { get; set; }
        public short? IdInternalDepartment { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public int? IdNetworkProvider { get; set; }
        public bool? Bluetooth { get; set; }
        public bool? IsController { get; set; }
        public bool? PermanentDeleted { get; set; }

        public virtual ICollection<ShiftReportDriver> ShiftReportDrivers { get; set; }
    }
}
