﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinancePeriodicIssuing
    {
        public int IdFinancePeriodicIssuing { get; set; }
        public int Year { get; set; }
        public DateTime Inserted { get; set; }
        public string Issuer { get; set; }
        public string Item { get; set; }
        public int IdFinanceProduct { get; set; }
    }
}
