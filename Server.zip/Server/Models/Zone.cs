﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Zone
    {
        public int IdZone { get; set; }
        public string Title { get; set; }
        public int? AutodispatchDistanceLimit { get; set; }
        public int? DriverPickupMaximumMinutes { get; set; }
        public int? IdBackupZone1 { get; set; }
        public int? IdBackupZone2 { get; set; }
        public int? IdBackupZone3 { get; set; }
        public int? IdBackupZone4 { get; set; }
        public int? IdBackupZone5 { get; set; }
        public short OrderValue { get; set; }
        public short? IdInternalDepartment { get; set; }
        public string LatCenter { get; set; }
        public string LonCenter { get; set; }
    }
}
