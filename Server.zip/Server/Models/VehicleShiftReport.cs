﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class VehicleShiftReport
    {
        public int IdVehicleShiftReport { get; set; }
        public int IdVehicle { get; set; }
        public DateTime DtShiftStart { get; set; }
        public DateTime DtShiftEnd { get; set; }
        public double? TaximeterStartKm { get; set; }
        public double? TaximeterEndKm { get; set; }
        public double? TotalDistanceTravelled { get; set; }
        public double? TakenDistanceTravelled { get; set; }
        public double? MaxSpeed { get; set; }
        public double? TotalPaid { get; set; }
        public double? TotalPurchaseOrder { get; set; }
        public int? DoneJobsCount { get; set; }
        public int? StreetPickupCount { get; set; }
        public int? DispatchedJobsCount { get; set; }
        public int? AuctionsCount { get; set; }
        public int? RefusedJobsCount { get; set; }
        public int? CancelledJobsCount { get; set; }
        public int? PurchaseOrderCount { get; set; }
        public int? LateJobsCount { get; set; }

        public virtual Vehicle IdVehicleNavigation { get; set; }
    }
}
