﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitAppVersion
    {
        public int IdUnitAppVersion { get; set; }
        public int IdUnit { get; set; }
        public string AppVersion { get; set; }
    }
}
