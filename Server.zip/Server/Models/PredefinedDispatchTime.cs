﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PredefinedDispatchTime
    {
        public int IdRecord { get; set; }
        public int? IdCompany { get; set; }
        public string TimeValues { get; set; }
    }
}
