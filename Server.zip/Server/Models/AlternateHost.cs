﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AlternateHost
    {
        public int IdAlternateHost { get; set; }
        public string ConnectionUrl { get; set; }
        public string ConnectionName { get; set; }
        public double CenterLat { get; set; }
        public double CenterLon { get; set; }
        public int RadiusM { get; set; }
        public bool IsEnabled { get; set; }
        public string HostLogoImagePath { get; set; }
        public string OsrmBaseUrl { get; set; }
        public string DispatchCenterPhoneNumber { get; set; }
    }
}
