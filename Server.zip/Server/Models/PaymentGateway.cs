﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentGateway
    {
        public int IdPaymentGateway { get; set; }
        public int IdDriver { get; set; }
        public string GatewayCode { get; set; }
        public string BankAccount { get; set; }
    }
}
