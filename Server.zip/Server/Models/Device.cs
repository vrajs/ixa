﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Device
    {
        public int IdDevice { get; set; }
        public int? IdDriver { get; set; }
        public string SerialNumber { get; set; }
        public string Imei { get; set; }
        public string DeviceSim { get; set; }
        public DateTime? DateOfApplication { get; set; }
        public bool? AlternateDevice { get; set; }
        public DateTime? AddDate { get; set; }
    }
}
