﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitRequestDefinition
    {
        public short RequestType { get; set; }
        public string RequestText { get; set; }
        public string RequestNote { get; set; }
    }
}
