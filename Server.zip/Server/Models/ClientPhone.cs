﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ClientPhone
    {
        public int IdClientPhone { get; set; }
        public int? IdClient { get; set; }
        public string Phone { get; set; }
        public bool? IsBlack { get; set; }
    }
}
