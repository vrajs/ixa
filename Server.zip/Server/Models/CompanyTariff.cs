﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyTariff
    {
        public int IdTariff { get; set; }
        public int? IdCompany { get; set; }
        public string Tariff { get; set; }
        public decimal? PriceKm { get; set; }
        public decimal? StartFee { get; set; }
        public decimal? WaitTimeHour { get; set; }
        public bool IsDefault { get; set; }
    }
}
