﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PermissionUser
    {
        public int IdUserPermission { get; set; }
        public int IdUser { get; set; }
        public int IdPermission { get; set; }
        public int PermissionValue { get; set; }
    }
}
