﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetAppliedDiscount
    {
        public int IdTargetDiscount { get; set; }
        public int IdTarget { get; set; }
        public int PaymentDiscountTypeId { get; set; }
        public decimal DiscountedPrice { get; set; }
    }
}
