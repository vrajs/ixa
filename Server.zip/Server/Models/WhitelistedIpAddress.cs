﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class WhitelistedIpAddress
    {
        public string IpAddress { get; set; }
    }
}
