﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CancelationReason
    {
        public int IdCancelationReason { get; set; }
        public string CancelationReason1 { get; set; }
        public string CancelationReasonSl { get; set; }
        public string CancelationReasonSr { get; set; }
    }
}
