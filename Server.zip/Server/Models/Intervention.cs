﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Intervention
    {
        public int IdIntervention { get; set; }
        public int? IdTarget { get; set; }
        public string UnitId { get; set; }
        public bool? ReleaseUnit { get; set; }
        public bool? Processed { get; set; }
        public short? Reason { get; set; }
        public DateTime? DtRequested { get; set; }
    }
}
