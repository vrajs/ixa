﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TaxiCustomer
    {
        public int? Id { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Person { get; set; }
        public string Client { get; set; }
        public string Center { get; set; }
        public string TariffId { get; set; }
        public string PaymentMethodId { get; set; }
        public string Note { get; set; }
        public string CName { get; set; }
        public string CPlace { get; set; }
        public string COffices { get; set; }
        public string CIco { get; set; }
        public string CDic { get; set; }
        public string CUserId { get; set; }
    }
}
