﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Property
    {
        public int IdPropertie { get; set; }
        public string Propertie { get; set; }
        public int? Sort { get; set; }
        public bool? Deleted { get; set; }
    }
}
