﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class EmployeeShiftType
    {
        public int IdEmployeeShiftType { get; set; }
        public byte ShiftType { get; set; }
        public byte HourFrom { get; set; }
        public byte HourTo { get; set; }
        public byte EmployeeType { get; set; }
        public string Title { get; set; }
    }
}
