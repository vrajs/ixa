﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CallComport
    {
        public int IdCall { get; set; }
        public string ReceiverNumber { get; set; }
        public short? Ext { get; set; }
        public DateTime? Initiated { get; set; }
        public DateTime? Answered { get; set; }
        public DateTime? Ended { get; set; }
    }
}
