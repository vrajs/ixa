﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Role
    {
        public int IdRole { get; set; }
        public string RoleTitle { get; set; }
    }
}
