﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Archive
    {
        public int IdArchive { get; set; }
        public DateTime Requested { get; set; }
        public DateTime ArchiveBefore { get; set; }
        public DateTime? Started { get; set; }
        public DateTime? Finished { get; set; }
    }
}
