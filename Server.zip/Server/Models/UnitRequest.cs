﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitRequest
    {
        public int IdUnitRequest { get; set; }
        public int IdUnit { get; set; }
        public int IdDriver { get; set; }
        public int IdVehicle { get; set; }
        public short RequestType { get; set; }
        public DateTime RequestDt { get; set; }
        public short RequestStatus { get; set; }
    }
}
