﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ShuttleSchedule
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string StartLocation { get; set; }
        public string EndLocation { get; set; }
        public string Title { get; set; }
        public int? IdVehicle { get; set; }
        public int IdShuttleSchedule { get; set; }
        public int? IdShuttleScheduleRelation { get; set; }
        public string BorderColor { get; set; }
    }
}
