﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitLogoff
    {
        public int IdUnitLogoff { get; set; }
        public string UnitId { get; set; }
        public int Actor { get; set; }
        public string Reason { get; set; }
        public DateTime Inserted { get; set; }
        public int? IdDriver { get; set; }
    }
}
