﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PredefinedDriverMessage
    {
        public int IdPredefinedDriverMessage { get; set; }
        public string Message { get; set; }
        public int? IdMessageType { get; set; }
    }
}
