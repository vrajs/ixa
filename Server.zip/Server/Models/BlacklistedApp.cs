﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class BlacklistedApp
    {
        public int IdBlacklistedApp { get; set; }
        public string BlacklistedAppIdentifier { get; set; }
        public bool Blacklisted { get; set; }
    }
}
