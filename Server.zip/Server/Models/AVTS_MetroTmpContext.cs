﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace NetCabManager.Server.Models
{
    public partial class AVTS_MetroTmpContext : DbContext
    {
        public AVTS_MetroTmpContext()
        {
        }

        public AVTS_MetroTmpContext(DbContextOptions<AVTS_MetroTmpContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ActiveAuction> ActiveAuctions { get; set; }
        public virtual DbSet<AlternateHost> AlternateHosts { get; set; }
        public virtual DbSet<Appuser> Appusers { get; set; }
        public virtual DbSet<AppuserActiveVoucher> AppuserActiveVouchers { get; set; }
        public virtual DbSet<AppuserAssignedVoucher> AppuserAssignedVouchers { get; set; }
        public virtual DbSet<AppuserDiscountTargetCounter> AppuserDiscountTargetCounters { get; set; }
        public virtual DbSet<AppuserDriverRating> AppuserDriverRatings { get; set; }
        public virtual DbSet<AppuserSetting> AppuserSettings { get; set; }
        public virtual DbSet<AppuserShadow> AppuserShadows { get; set; }
        public virtual DbSet<AppuserThirdPartyType> AppuserThirdPartyTypes { get; set; }
        public virtual DbSet<Archive> Archives { get; set; }
        public virtual DbSet<AreaOfOperation> AreaOfOperations { get; set; }
        public virtual DbSet<Blacklist> Blacklists { get; set; }
        public virtual DbSet<BlacklistedApp> BlacklistedApps { get; set; }
        public virtual DbSet<Call> Calls { get; set; }
        public virtual DbSet<CallComport> CallComports { get; set; }
        public virtual DbSet<CancelationReason> CancelationReasons { get; set; }
        public virtual DbSet<Car> Cars { get; set; }
        public virtual DbSet<CarType> CarTypes { get; set; }
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<ClientBillingCenter> ClientBillingCenters { get; set; }
        public virtual DbSet<ClientPhone> ClientPhones { get; set; }
        public virtual DbSet<ClientType> ClientTypes { get; set; }
        public virtual DbSet<Colour> Colours { get; set; }
        public virtual DbSet<Company> Companies { get; set; }
        public virtual DbSet<CompanyAssignAllowedDriver> CompanyAssignAllowedDrivers { get; set; }
        public virtual DbSet<CompanyBilling> CompanyBillings { get; set; }
        public virtual DbSet<CompanyBillingCenter> CompanyBillingCenters { get; set; }
        public virtual DbSet<CompanyBlock> CompanyBlocks { get; set; }
        public virtual DbSet<CompanyCredential> CompanyCredentials { get; set; }
        public virtual DbSet<CompanyCustomLocation> CompanyCustomLocations { get; set; }
        public virtual DbSet<CompanyLoyaltyCard> CompanyLoyaltyCards { get; set; }
        public virtual DbSet<CompanyNote> CompanyNotes { get; set; }
        public virtual DbSet<CompanyPassenger> CompanyPassengers { get; set; }
        public virtual DbSet<CompanyPhone> CompanyPhones { get; set; }
        public virtual DbSet<CompanyTariff> CompanyTariffs { get; set; }
        public virtual DbSet<Coupon> Coupons { get; set; }
        public virtual DbSet<CtDealInvitation> CtDealInvitations { get; set; }
        public virtual DbSet<CtUnit> CtUnits { get; set; }
        public virtual DbSet<CtUnitHistory> CtUnitHistories { get; set; }
        public virtual DbSet<CtUnitStatusUpdate> CtUnitStatusUpdates { get; set; }
        public virtual DbSet<CtUser> CtUsers { get; set; }
        public virtual DbSet<CtUserBackend> CtUserBackends { get; set; }
        public virtual DbSet<CtUserRole> CtUserRoles { get; set; }
        public virtual DbSet<CustomLocation> CustomLocations { get; set; }
        public virtual DbSet<CustomLocationShadow> CustomLocationShadows { get; set; }
        public virtual DbSet<CustomerCancellType> CustomerCancellTypes { get; set; }
        public virtual DbSet<Denial> Denials { get; set; }
        public virtual DbSet<Device> Devices { get; set; }
        public virtual DbSet<DirtyTable> DirtyTables { get; set; }
        public virtual DbSet<DiscountType> DiscountTypes { get; set; }
        public virtual DbSet<DispatchType> DispatchTypes { get; set; }
        public virtual DbSet<DistancesType> DistancesTypes { get; set; }
        public virtual DbSet<Driver> Drivers { get; set; }
        public virtual DbSet<DriverAction> DriverActions { get; set; }
        public virtual DbSet<DriverActionStatistic> DriverActionStatistics { get; set; }
        public virtual DbSet<DriverBankAccount> DriverBankAccounts { get; set; }
        public virtual DbSet<DriverBlockType> DriverBlockTypes { get; set; }
        public virtual DbSet<DriverBlocked> DriverBlockeds { get; set; }
        public virtual DbSet<DriverBlockedRefoundation> DriverBlockedRefoundations { get; set; }
        public virtual DbSet<DriverBonu> DriverBonus { get; set; }
        public virtual DbSet<DriverCompanyAssignBlock> DriverCompanyAssignBlocks { get; set; }
        public virtual DbSet<DriverDispatchType> DriverDispatchTypes { get; set; }
        public virtual DbSet<DriverFaultyReader> DriverFaultyReaders { get; set; }
        public virtual DbSet<DriverField> DriverFields { get; set; }
        public virtual DbSet<DriverLogin> DriverLogins { get; set; }
        public virtual DbSet<DriverLogoutType> DriverLogoutTypes { get; set; }
        public virtual DbSet<DriverMasterLogin> DriverMasterLogins { get; set; }
        public virtual DbSet<DriverPause> DriverPauses { get; set; }
        public virtual DbSet<DriverPaymentDatum> DriverPaymentData { get; set; }
        public virtual DbSet<DriverShadow> DriverShadows { get; set; }
        public virtual DbSet<DriverSipAccount> DriverSipAccounts { get; set; }
        public virtual DbSet<EmployeeAllowedInternalDepartment> EmployeeAllowedInternalDepartments { get; set; }
        public virtual DbSet<EmployeeLogin> EmployeeLogins { get; set; }
        public virtual DbSet<EmployeeShiftType> EmployeeShiftTypes { get; set; }
        public virtual DbSet<Event> Events { get; set; }
        public virtual DbSet<EventType> EventTypes { get; set; }
        public virtual DbSet<FinanceDocument> FinanceDocuments { get; set; }
        public virtual DbSet<FinanceDocumentItem> FinanceDocumentItems { get; set; }
        public virtual DbSet<FinanceDocumentType> FinanceDocumentTypes { get; set; }
        public virtual DbSet<FinancePeriodicIssuing> FinancePeriodicIssuings { get; set; }
        public virtual DbSet<FinanceProduct> FinanceProducts { get; set; }
        public virtual DbSet<FinanceProductType> FinanceProductTypes { get; set; }
        public virtual DbSet<FinanceResourcesInUse> FinanceResourcesInUses { get; set; }
        public virtual DbSet<FinanceUserType> FinanceUserTypes { get; set; }
        public virtual DbSet<FinancialCategory> FinancialCategories { get; set; }
        public virtual DbSet<FinancialRecord> FinancialRecords { get; set; }
        public virtual DbSet<FixedPriceRoute> FixedPriceRoutes { get; set; }
        public virtual DbSet<FuelType> FuelTypes { get; set; }
        public virtual DbSet<GeneralRemark> GeneralRemarks { get; set; }
        public virtual DbSet<GeneratedReport> GeneratedReports { get; set; }
        public virtual DbSet<HostSipAccount> HostSipAccounts { get; set; }
        public virtual DbSet<IncomingSm> IncomingSms { get; set; }
        public virtual DbSet<InternalDepartment> InternalDepartments { get; set; }
        public virtual DbSet<InternalDepartmentPhone> InternalDepartmentPhones { get; set; }
        public virtual DbSet<Intervention> Interventions { get; set; }
        public virtual DbSet<InterventionReason> InterventionReasons { get; set; }
        public virtual DbSet<Licitation> Licitations { get; set; }
        public virtual DbSet<LicitationUnit> LicitationUnits { get; set; }
        public virtual DbSet<LocationServiceBlackList> LocationServiceBlackLists { get; set; }
        public virtual DbSet<LocationServiceCachedStreet> LocationServiceCachedStreets { get; set; }
        public virtual DbSet<LocationServiceRequest> LocationServiceRequests { get; set; }
        public virtual DbSet<ManualShift> ManualShifts { get; set; }
        public virtual DbSet<MonthlyDatum> MonthlyData { get; set; }
        public virtual DbSet<NetShuttleInvoice> NetShuttleInvoices { get; set; }
        public virtual DbSet<NetworkProvider> NetworkProviders { get; set; }
        public virtual DbSet<NoCustomerStatus> NoCustomerStatuses { get; set; }
        public virtual DbSet<OrderFormItem> OrderFormItems { get; set; }
        public virtual DbSet<OrderFormItemType> OrderFormItemTypes { get; set; }
        public virtual DbSet<OrderFromCompany> OrderFromCompanies { get; set; }
        public virtual DbSet<OrderType> OrderTypes { get; set; }
        public virtual DbSet<PaymentDiscountCardBinRange> PaymentDiscountCardBinRanges { get; set; }
        public virtual DbSet<PaymentDiscountType> PaymentDiscountTypes { get; set; }
        public virtual DbSet<PaymentDiscountZone> PaymentDiscountZones { get; set; }
        public virtual DbSet<PaymentGateway> PaymentGateways { get; set; }
        public virtual DbSet<PaymentGatewayAppuserLog> PaymentGatewayAppuserLogs { get; set; }
        public virtual DbSet<PaymentGatewayAppuserRequestLog> PaymentGatewayAppuserRequestLogs { get; set; }
        public virtual DbSet<PaymentGatewayDriverLog> PaymentGatewayDriverLogs { get; set; }
        public virtual DbSet<PaymentMonriDatum> PaymentMonriData { get; set; }
        public virtual DbSet<PaymentMonriPanToken> PaymentMonriPanTokens { get; set; }
        public virtual DbSet<PaymentMonriTransactionLog> PaymentMonriTransactionLogs { get; set; }
        public virtual DbSet<PaymentMonriVoidedTransaction> PaymentMonriVoidedTransactions { get; set; }
        public virtual DbSet<PaymentReceiptDatum> PaymentReceiptData { get; set; }
        public virtual DbSet<PaymentType> PaymentTypes { get; set; }
        public virtual DbSet<Permission> Permissions { get; set; }
        public virtual DbSet<PermissionRoleTemplate> PermissionRoleTemplates { get; set; }
        public virtual DbSet<PermissionUser> PermissionUsers { get; set; }
        public virtual DbSet<Post> Posts { get; set; }
        public virtual DbSet<PredefinedCompanyTarget> PredefinedCompanyTargets { get; set; }
        public virtual DbSet<PredefinedDispatchTime> PredefinedDispatchTimes { get; set; }
        public virtual DbSet<PredefinedDriverMessage> PredefinedDriverMessages { get; set; }
        public virtual DbSet<Promotion> Promotions { get; set; }
        public virtual DbSet<Property> Properties { get; set; }
        public virtual DbSet<PushNotificationQueue> PushNotificationQueues { get; set; }
        public virtual DbSet<QuickSearch> QuickSearches { get; set; }
        public virtual DbSet<Remark> Remarks { get; set; }
        public virtual DbSet<RequestToTalk> RequestToTalks { get; set; }
        public virtual DbSet<Resource> Resources { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Role1> Roles1 { get; set; }
        public virtual DbSet<RolePermissionTemplate> RolePermissionTemplates { get; set; }
        public virtual DbSet<Route> Routes { get; set; }
        public virtual DbSet<Salary> Salaries { get; set; }
        public virtual DbSet<SalaryDeduction> SalaryDeductions { get; set; }
        public virtual DbSet<SalaryPayoutPercentage> SalaryPayoutPercentages { get; set; }
        public virtual DbSet<ServiceType> ServiceTypes { get; set; }
        public virtual DbSet<ServiceUptime> ServiceUptimes { get; set; }
        public virtual DbSet<Setting> Settings { get; set; }
        public virtual DbSet<SettingAutodispatchLimitDayofweek> SettingAutodispatchLimitDayofweeks { get; set; }
        public virtual DbSet<SettingAutodispatchLimitTimeframe> SettingAutodispatchLimitTimeframes { get; set; }
        public virtual DbSet<SettingDispatchTypeHourTimeLimit> SettingDispatchTypeHourTimeLimits { get; set; }
        public virtual DbSet<SettingDriverApp> SettingDriverApps { get; set; }
        public virtual DbSet<SettingWordDocument> SettingWordDocuments { get; set; }
        public virtual DbSet<Shift> Shifts { get; set; }
        public virtual DbSet<ShiftReportDriver> ShiftReportDrivers { get; set; }
        public virtual DbSet<ShuttleSchedule> ShuttleSchedules { get; set; }
        public virtual DbSet<ShuttleScheduleRelation> ShuttleScheduleRelations { get; set; }
        public virtual DbSet<ShuttleScheduleTarget> ShuttleScheduleTargets { get; set; }
        public virtual DbSet<Size> Sizes { get; set; }
        public virtual DbSet<Sm> Sms { get; set; }
        public virtual DbSet<SmsGsmInterface> SmsGsmInterfaces { get; set; }
        public virtual DbSet<So> Sos { get; set; }
        public virtual DbSet<SoftwareTaximeterTargetDatum> SoftwareTaximeterTargetData { get; set; }
        public virtual DbSet<Stand> Stands { get; set; }
        public virtual DbSet<StandLocation> StandLocations { get; set; }
        public virtual DbSet<StandLocationPolygon> StandLocationPolygons { get; set; }
        public virtual DbSet<StandPolygon> StandPolygons { get; set; }
        public virtual DbSet<StandRange> StandRanges { get; set; }
        public virtual DbSet<StandUnitLogin> StandUnitLogins { get; set; }
        public virtual DbSet<StatsTargetDay> StatsTargetDays { get; set; }
        public virtual DbSet<StatsTargetMonth> StatsTargetMonths { get; set; }
        public virtual DbSet<StatsTargetQuarter> StatsTargetQuarters { get; set; }
        public virtual DbSet<StatsTargetWeek> StatsTargetWeeks { get; set; }
        public virtual DbSet<StatsTargetYear> StatsTargetYears { get; set; }
        public virtual DbSet<Street> Streets { get; set; }
        public virtual DbSet<SystemNotification> SystemNotifications { get; set; }
        public virtual DbSet<Target> Targets { get; set; }
        public virtual DbSet<TargetAppliedDiscount> TargetAppliedDiscounts { get; set; }
        public virtual DbSet<TargetAppliedVoucher> TargetAppliedVouchers { get; set; }
        public virtual DbSet<TargetAssignAllowedDriver> TargetAssignAllowedDrivers { get; set; }
        public virtual DbSet<TargetAssignDetail> TargetAssignDetails { get; set; }
        public virtual DbSet<TargetCancelReason> TargetCancelReasons { get; set; }
        public virtual DbSet<TargetCancelTime> TargetCancelTimes { get; set; }
        public virtual DbSet<TargetCategory> TargetCategories { get; set; }
        public virtual DbSet<TargetDistance> TargetDistances { get; set; }
        public virtual DbSet<TargetDriverAtLocationDetail> TargetDriverAtLocationDetails { get; set; }
        public virtual DbSet<TargetEstimatedPrice> TargetEstimatedPrices { get; set; }
        public virtual DbSet<TargetHandledRequest> TargetHandledRequests { get; set; }
        public virtual DbSet<TargetHistory> TargetHistories { get; set; }
        public virtual DbSet<TargetPayment> TargetPayments { get; set; }
        public virtual DbSet<TargetProperty> TargetProperties { get; set; }
        public virtual DbSet<TargetShadow> TargetShadows { get; set; }
        public virtual DbSet<TargetStatus> TargetStatuses { get; set; }
        public virtual DbSet<TargetStatus1> TargetStatuses1 { get; set; }
        public virtual DbSet<TargetUnit> TargetUnits { get; set; }
        public virtual DbSet<TargetVehicleCategoriesShadow> TargetVehicleCategoriesShadows { get; set; }
        public virtual DbSet<TargetVehicleCategory> TargetVehicleCategories { get; set; }
        public virtual DbSet<TargetVehicleCustomer> TargetVehicleCustomers { get; set; }
        public virtual DbSet<Tariff> Tariffs { get; set; }
        public virtual DbSet<TariffSchedule> TariffSchedules { get; set; }
        public virtual DbSet<TaxiBlok> TaxiBloks { get; set; }
        public virtual DbSet<TaxiBlokInvoice> TaxiBlokInvoices { get; set; }
        public virtual DbSet<TaxiCustomer> TaxiCustomers { get; set; }
        public virtual DbSet<Taximeter> Taximeters { get; set; }
        public virtual DbSet<TelephonyExternalLine> TelephonyExternalLines { get; set; }
        public virtual DbSet<TelephonyParkedCall> TelephonyParkedCalls { get; set; }
        public virtual DbSet<TelephonySipAccount> TelephonySipAccounts { get; set; }
        public virtual DbSet<Tmp> Tmps { get; set; }
        public virtual DbSet<TomtomTrackingDataVolume> TomtomTrackingDataVolumes { get; set; }
        public virtual DbSet<Tracker> Trackers { get; set; }
        public virtual DbSet<TrackerHistory> TrackerHistories { get; set; }
        public virtual DbSet<Trip> Trips { get; set; }
        public virtual DbSet<TvCompany> TvCompanies { get; set; }
        public virtual DbSet<TvDeal> TvDeals { get; set; }
        public virtual DbSet<TvDriver> TvDrivers { get; set; }
        public virtual DbSet<TvDriverComment> TvDriverComments { get; set; }
        public virtual DbSet<TvDriverRating> TvDriverRatings { get; set; }
        public virtual DbSet<Tweet> Tweets { get; set; }
        public virtual DbSet<TwitterMessageQueue> TwitterMessageQueues { get; set; }
        public virtual DbSet<Unit> Units { get; set; }
        public virtual DbSet<UnitAllowedDriver> UnitAllowedDrivers { get; set; }
        public virtual DbSet<UnitAppVersion> UnitAppVersions { get; set; }
        public virtual DbSet<UnitFuelRefill> UnitFuelRefills { get; set; }
        public virtual DbSet<UnitHistory> UnitHistories { get; set; }
        public virtual DbSet<UnitLogoff> UnitLogoffs { get; set; }
        public virtual DbSet<UnitProperty> UnitProperties { get; set; }
        public virtual DbSet<UnitRequest> UnitRequests { get; set; }
        public virtual DbSet<UnitRequestDefinition> UnitRequestDefinitions { get; set; }
        public virtual DbSet<UnitRequestedStatus> UnitRequestedStatuses { get; set; }
        public virtual DbSet<UnitSnapshot> UnitSnapshots { get; set; }
        public virtual DbSet<UnitStatus> UnitStatuses { get; set; }
        public virtual DbSet<Unittype> Unittypes { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<UsersLoginLog> UsersLoginLogs { get; set; }
        public virtual DbSet<Vehicle> Vehicles { get; set; }
        public virtual DbSet<VehicleCompany> VehicleCompanies { get; set; }
        public virtual DbSet<VehicleDistance> VehicleDistances { get; set; }
        public virtual DbSet<VehicleShiftReport> VehicleShiftReports { get; set; }
        public virtual DbSet<Version> Versions { get; set; }
        public virtual DbSet<ViberMessage> ViberMessages { get; set; }
        public virtual DbSet<Voucher> Vouchers { get; set; }
        public virtual DbSet<VwDriver> VwDrivers { get; set; }
        public virtual DbSet<VwTargetCustomer> VwTargetCustomers { get; set; }
        public virtual DbSet<Warehouse> Warehouses { get; set; }
        public virtual DbSet<WhitelistedIpAddress> WhitelistedIpAddresses { get; set; }
        public virtual DbSet<WorkTime> WorkTimes { get; set; }
        public virtual DbSet<Zone> Zones { get; set; }
        public virtual DbSet<ZonePolygon> ZonePolygons { get; set; }
        public virtual DbSet<ZoneRange> ZoneRanges { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=vps3.net-informatika.com,34262\\SqlServer03;User ID=NetCabUser;Password=Taxi_User_GG;Database=AVTS_MetroTmp;Trusted_Connection=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("Slovenian_CI_AS");

            modelBuilder.Entity<ActiveAuction>(entity =>
            {
                entity.HasKey(e => e.IdAuction);

                entity.ToTable("active_auction");

                entity.Property(e => e.IdAuction)
                    .ValueGeneratedNever()
                    .HasColumnName("id_auction");

                entity.Property(e => e.StatusFlag).HasColumnName("status_flag");
            });

            modelBuilder.Entity<AlternateHost>(entity =>
            {
                entity.HasKey(e => e.IdAlternateHost)
                    .HasName("PK__alternat__764BAF425832DCF6");

                entity.ToTable("alternate_hosts");

                entity.Property(e => e.IdAlternateHost).HasColumnName("id_alternate_host");

                entity.Property(e => e.CenterLat).HasColumnName("center_lat");

                entity.Property(e => e.CenterLon).HasColumnName("center_lon");

                entity.Property(e => e.ConnectionName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("connection_name");

                entity.Property(e => e.ConnectionUrl)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("connection_url");

                entity.Property(e => e.DispatchCenterPhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("dispatch_center_phone_number");

                entity.Property(e => e.HostLogoImagePath)
                    .HasMaxLength(500)
                    .HasColumnName("host_logo_image_path");

                entity.Property(e => e.IsEnabled).HasColumnName("is_enabled");

                entity.Property(e => e.OsrmBaseUrl)
                    .HasMaxLength(100)
                    .HasColumnName("osrm_base_url");

                entity.Property(e => e.RadiusM).HasColumnName("radius_m");
            });

            modelBuilder.Entity<Appuser>(entity =>
            {
                entity.HasKey(e => e.IdAppuser);

                entity.ToTable("appuser");

                entity.HasIndex(e => e.Imei, "NonClusteredIndex-20160829-102540");

                entity.HasIndex(e => new { e.Email, e.Password }, "NonClusteredIndex-20160901-105812");

                entity.HasIndex(e => new { e.Phone, e.AuthId }, "NonClusteredIndex-GetAppUserByPhoneAndAuthId");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.AuthId)
                    .HasMaxLength(256)
                    .HasColumnName("auth_id");

                entity.Property(e => e.DefaultDispatchType).HasColumnName("default_dispatch_type");

                entity.Property(e => e.DefaultIdCustomLocation).HasColumnName("default_id_custom_location");

                entity.Property(e => e.DevicePushToken).HasColumnName("device_push_token");

                entity.Property(e => e.DeviceToken)
                    .IsUnicode(false)
                    .HasColumnName("device_token");

                entity.Property(e => e.DeviceType)
                    .IsUnicode(false)
                    .HasColumnName("device_type");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.Imei)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.InsertedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.LastUpdateType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("last_update_type")
                    .IsFixedLength();

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Password)
                    .HasMaxLength(256)
                    .HasColumnName("password");

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone");

                entity.Property(e => e.Salt)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("salt");

                entity.Property(e => e.Surname)
                    .HasMaxLength(50)
                    .HasColumnName("surname");

                entity.Property(e => e.ThirdPartyIdAppuser).HasColumnName("third_party_id_appuser");

                entity.Property(e => e.ThirdPartyType).HasColumnName("third_party_type");

                entity.Property(e => e.Validated)
                    .HasColumnName("validated")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<AppuserActiveVoucher>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("appuser_active_vouchers");

                entity.Property(e => e.Applied).HasColumnName("applied");

                entity.Property(e => e.IdAppUser).HasColumnName("id_app_user");

                entity.Property(e => e.IdVoucher).HasColumnName("id_voucher");
            });

            modelBuilder.Entity<AppuserAssignedVoucher>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("appuser_assigned_voucher");

                entity.Property(e => e.IdAppUser).HasColumnName("id_app_user");

                entity.Property(e => e.IdVoucher).HasColumnName("id_voucher");

                entity.Property(e => e.IsUsed).HasColumnName("is_used");

                entity.Property(e => e.UsageCount).HasColumnName("usage_count");
            });

            modelBuilder.Entity<AppuserDiscountTargetCounter>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("appuser_discount_target_counter");

                entity.Property(e => e.DiscountTargetCountId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("discount_target_count_id");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.LastTargetCounted).HasColumnName("last_target_counted");

                entity.Property(e => e.RideCount).HasColumnName("ride_count");
            });

            modelBuilder.Entity<AppuserDriverRating>(entity =>
            {
                entity.HasKey(e => e.IdDriverRating);

                entity.ToTable("appuser_driver_rating");

                entity.HasIndex(e => e.IdTarget, "IX_appuser_driver_rating_id_target_845E2");

                entity.Property(e => e.IdDriverRating).HasColumnName("id_driver_rating");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdThirdPartyType).HasColumnName("id_third_party_type");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.Note)
                    .HasMaxLength(250)
                    .HasColumnName("note");

                entity.Property(e => e.Rating).HasColumnName("rating");
            });

            modelBuilder.Entity<AppuserSetting>(entity =>
            {
                entity.HasKey(e => e.IdAppuserSetting);

                entity.ToTable("appuser_setting");

                entity.Property(e => e.IdAppuserSetting).HasColumnName("id_appuser_setting");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IsSuperadmin).HasColumnName("is_superadmin");

                entity.HasOne(d => d.IdAppuserNavigation)
                    .WithMany(p => p.AppuserSettings)
                    .HasForeignKey(d => d.IdAppuser)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_appuser_setting_appuser");
            });

            modelBuilder.Entity<AppuserShadow>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("appuser_shadow");

                entity.Property(e => e.DefaultDispatchType).HasColumnName("default_dispatch_type");

                entity.Property(e => e.DefaultIdCustomLocation).HasColumnName("default_id_custom_location");

                entity.Property(e => e.DevicePushToken).HasColumnName("device_push_token");

                entity.Property(e => e.DeviceToken)
                    .IsUnicode(false)
                    .HasColumnName("device_token");

                entity.Property(e => e.DeviceType)
                    .IsUnicode(false)
                    .HasColumnName("device_type");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdAppuserShadow)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_appuser_shadow");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.Imei)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.LastUpdateType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("last_update_type")
                    .IsFixedLength();

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Password)
                    .HasMaxLength(256)
                    .HasColumnName("password");

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone");

                entity.Property(e => e.Salt)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("salt");

                entity.Property(e => e.Surname)
                    .HasMaxLength(50)
                    .HasColumnName("surname");

                entity.Property(e => e.ThirdPartyIdAppuser).HasColumnName("third_party_id_appuser");

                entity.Property(e => e.ThirdPartyType).HasColumnName("third_party_type");

                entity.Property(e => e.Validated).HasColumnName("validated");
            });

            modelBuilder.Entity<AppuserThirdPartyType>(entity =>
            {
                entity.HasKey(e => e.IdAppuserThirdPartyType);

                entity.ToTable("appuser_third_party_type");

                entity.Property(e => e.IdAppuserThirdPartyType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_appuser_third_party_type");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");

                entity.Property(e => e.Visible)
                    .IsRequired()
                    .HasColumnName("visible")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Archive>(entity =>
            {
                entity.HasKey(e => e.IdArchive);

                entity.ToTable("archive");

                entity.Property(e => e.IdArchive).HasColumnName("id_archive");

                entity.Property(e => e.ArchiveBefore)
                    .HasColumnType("datetime")
                    .HasColumnName("archive_before");

                entity.Property(e => e.Finished)
                    .HasColumnType("datetime")
                    .HasColumnName("finished");

                entity.Property(e => e.Requested)
                    .HasColumnType("datetime")
                    .HasColumnName("requested")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Started)
                    .HasColumnType("datetime")
                    .HasColumnName("started");
            });

            modelBuilder.Entity<AreaOfOperation>(entity =>
            {
                entity.HasKey(e => e.IdAreaOfOperation);

                entity.ToTable("area_of_operation");

                entity.Property(e => e.IdAreaOfOperation).HasColumnName("id_area_of_operation");

                entity.Property(e => e.AppendText)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("append_text");

                entity.Property(e => e.CenterLat).HasColumnName("center_lat");

                entity.Property(e => e.CenterLon).HasColumnName("center_lon");

                entity.Property(e => e.DefaultAreaOfOperation).HasColumnName("default_area_of_operation");

                entity.Property(e => e.StrictBoundsEnabled).HasColumnName("strict_bounds_enabled");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<Blacklist>(entity =>
            {
                entity.HasKey(e => e.IdBlacklist);

                entity.ToTable("blacklist");

                entity.Property(e => e.IdBlacklist).HasColumnName("id_blacklist");

                entity.Property(e => e.DtCreate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_create");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone");
            });

            modelBuilder.Entity<BlacklistedApp>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("blacklisted_apps");

                entity.Property(e => e.Blacklisted).HasColumnName("blacklisted");

                entity.Property(e => e.BlacklistedAppIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("blacklisted_app_identifier");

                entity.Property(e => e.IdBlacklistedApp)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_blacklisted_app");
            });

            modelBuilder.Entity<Call>(entity =>
            {
                entity.HasKey(e => e.IdCall);

                entity.ToTable("call");

                entity.HasIndex(e => e.UniqueId, "IX_call_unique_id");

                entity.HasIndex(e => e.Status, "NCI_CallQueue");

                entity.Property(e => e.IdCall).HasColumnName("id_call");

                entity.Property(e => e.Answered)
                    .HasColumnType("datetime")
                    .HasColumnName("answered");

                entity.Property(e => e.Ended)
                    .HasColumnType("datetime")
                    .HasColumnName("ended");

                entity.Property(e => e.Initiated)
                    .HasColumnType("datetime")
                    .HasColumnName("initiated")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InitiatorNumber)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("initiator_number");

                entity.Property(e => e.ReceiverNumber)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("receiver_number");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.UniqueId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("unique_id");
            });

            modelBuilder.Entity<CallComport>(entity =>
            {
                entity.HasKey(e => e.IdCall);

                entity.ToTable("call_comport");

                entity.Property(e => e.IdCall).HasColumnName("id_call");

                entity.Property(e => e.Answered)
                    .HasColumnType("datetime")
                    .HasColumnName("answered");

                entity.Property(e => e.Ended)
                    .HasColumnType("datetime")
                    .HasColumnName("ended");

                entity.Property(e => e.Ext).HasColumnName("ext");

                entity.Property(e => e.Initiated)
                    .HasColumnType("datetime")
                    .HasColumnName("initiated");

                entity.Property(e => e.ReceiverNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("receiver_number");
            });

            modelBuilder.Entity<CancelationReason>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("cancelation_reasons");

                entity.Property(e => e.CancelationReason1)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("cancelation_reason");

                entity.Property(e => e.CancelationReasonSl)
                    .HasMaxLength(250)
                    .HasColumnName("cancelation_reason_sl");

                entity.Property(e => e.CancelationReasonSr)
                    .HasMaxLength(250)
                    .HasColumnName("cancelation_reason_sr");

                entity.Property(e => e.IdCancelationReason).HasColumnName("id_cancelation_reason");
            });

            modelBuilder.Entity<Car>(entity =>
            {
                entity.HasKey(e => e.IdCar);

                entity.ToTable("cars");

                entity.Property(e => e.IdCar).HasColumnName("id_car");

                entity.Property(e => e.Car1)
                    .HasMaxLength(50)
                    .HasColumnName("car");

                entity.Property(e => e.Isdeleted)
                    .HasColumnName("isdeleted")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<CarType>(entity =>
            {
                entity.HasKey(e => e.IdCarType);

                entity.ToTable("car_type");

                entity.Property(e => e.IdCarType).HasColumnName("id_car_type");

                entity.Property(e => e.CarType1)
                    .HasMaxLength(100)
                    .HasColumnName("car_type");

                entity.Property(e => e.IdCar).HasColumnName("id_car");

                entity.Property(e => e.Isdeleted)
                    .HasColumnName("isdeleted")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.IdClient);

                entity.ToTable("client");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .HasColumnName("address");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.HandicapDiscount)
                    .HasColumnName("handicap_discount")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdClientType)
                    .HasColumnName("id_client_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdRecord)
                    .HasColumnName("id_record")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Name)
                    .HasMaxLength(250)
                    .HasColumnName("name");

                entity.Property(e => e.Note)
                    .HasMaxLength(250)
                    .HasColumnName("note");

                entity.Property(e => e.NumberOfCalls)
                    .HasColumnName("number_of_calls")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.RideCount)
                    .HasColumnName("ride_count")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TaxId)
                    .HasMaxLength(50)
                    .HasColumnName("tax_id");

                entity.Property(e => e.TimeOfLastCall)
                    .HasColumnType("datetime")
                    .HasColumnName("time_of_last_call")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ClientBillingCenter>(entity =>
            {
                entity.HasKey(e => e.IdClientBillingCenter);

                entity.ToTable("client_billing_center");

                entity.Property(e => e.IdClientBillingCenter).HasColumnName("id_client_billing_center");

                entity.Property(e => e.BillingCenter)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("billing_center");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<ClientPhone>(entity =>
            {
                entity.HasKey(e => e.IdClientPhone)
                    .HasName("PK_ClientPhone");

                entity.ToTable("client_phone");

                entity.HasIndex(e => e.Phone, "NonClusteredIndex-20161207-213612");

                entity.HasIndex(e => new { e.IdClient, e.Phone }, "UC_Phone")
                    .IsUnique();

                entity.Property(e => e.IdClientPhone).HasColumnName("id_client_phone");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.IsBlack)
                    .HasColumnName("isBlack")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone");
            });

            modelBuilder.Entity<ClientType>(entity =>
            {
                entity.HasKey(e => e.IdClientType);

                entity.ToTable("client_type");

                entity.Property(e => e.IdClientType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_client_type");

                entity.Property(e => e.ClientType1)
                    .HasMaxLength(50)
                    .HasColumnName("client_type");
            });

            modelBuilder.Entity<Colour>(entity =>
            {
                entity.HasKey(e => e.IdColour);

                entity.ToTable("colours");

                entity.Property(e => e.IdColour).HasColumnName("id_colour");

                entity.Property(e => e.Colour1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("colour");
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.HasKey(e => e.IdCompany);

                entity.ToTable("Company");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.Address)
                    .HasMaxLength(150)
                    .HasColumnName("address");

                entity.Property(e => e.BookingRemarks)
                    .HasColumnType("text")
                    .HasColumnName("booking_remarks");

                entity.Property(e => e.Comment)
                    .HasColumnType("text")
                    .HasColumnName("comment");

                entity.Property(e => e.ContractNumber)
                    .HasMaxLength(50)
                    .HasColumnName("contract_number");

                entity.Property(e => e.ContractText)
                    .HasMaxLength(150)
                    .HasColumnName("contract_text");

                entity.Property(e => e.CouponValue)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("coupon_value");

                entity.Property(e => e.DefaultType1).HasColumnName("default_type1");

                entity.Property(e => e.DefaultType10).HasColumnName("default_type10");

                entity.Property(e => e.DefaultType11).HasColumnName("default_type11");

                entity.Property(e => e.DefaultType12).HasColumnName("default_type12");

                entity.Property(e => e.DefaultType13).HasColumnName("default_type13");

                entity.Property(e => e.DefaultType14).HasColumnName("default_type14");

                entity.Property(e => e.DefaultType15).HasColumnName("default_type15");

                entity.Property(e => e.DefaultType16).HasColumnName("default_type16");

                entity.Property(e => e.DefaultType17).HasColumnName("default_type17");

                entity.Property(e => e.DefaultType18).HasColumnName("default_type18");

                entity.Property(e => e.DefaultType19).HasColumnName("default_type19");

                entity.Property(e => e.DefaultType2).HasColumnName("default_type2");

                entity.Property(e => e.DefaultType20).HasColumnName("default_type20");

                entity.Property(e => e.DefaultType3).HasColumnName("default_type3");

                entity.Property(e => e.DefaultType4).HasColumnName("default_type4");

                entity.Property(e => e.DefaultType5).HasColumnName("default_type5");

                entity.Property(e => e.DefaultType6).HasColumnName("default_type6");

                entity.Property(e => e.DefaultType7).HasColumnName("default_type7");

                entity.Property(e => e.DefaultType8).HasColumnName("default_type8");

                entity.Property(e => e.DefaultType9).HasColumnName("default_type9");

                entity.Property(e => e.DefaultVehicleType1).HasColumnName("default_vehicle_type1");

                entity.Property(e => e.DefaultVehicleType10).HasColumnName("default_vehicle_type10");

                entity.Property(e => e.DefaultVehicleType11).HasColumnName("default_vehicle_type11");

                entity.Property(e => e.DefaultVehicleType12).HasColumnName("default_vehicle_type12");

                entity.Property(e => e.DefaultVehicleType13).HasColumnName("default_vehicle_type13");

                entity.Property(e => e.DefaultVehicleType14).HasColumnName("default_vehicle_type14");

                entity.Property(e => e.DefaultVehicleType15).HasColumnName("default_vehicle_type15");

                entity.Property(e => e.DefaultVehicleType16).HasColumnName("default_vehicle_type16");

                entity.Property(e => e.DefaultVehicleType17).HasColumnName("default_vehicle_type17");

                entity.Property(e => e.DefaultVehicleType18).HasColumnName("default_vehicle_type18");

                entity.Property(e => e.DefaultVehicleType19).HasColumnName("default_vehicle_type19");

                entity.Property(e => e.DefaultVehicleType2).HasColumnName("default_vehicle_type2");

                entity.Property(e => e.DefaultVehicleType20).HasColumnName("default_vehicle_type20");

                entity.Property(e => e.DefaultVehicleType3).HasColumnName("default_vehicle_type3");

                entity.Property(e => e.DefaultVehicleType4).HasColumnName("default_vehicle_type4");

                entity.Property(e => e.DefaultVehicleType5).HasColumnName("default_vehicle_type5");

                entity.Property(e => e.DefaultVehicleType6).HasColumnName("default_vehicle_type6");

                entity.Property(e => e.DefaultVehicleType7).HasColumnName("default_vehicle_type7");

                entity.Property(e => e.DefaultVehicleType8).HasColumnName("default_vehicle_type8");

                entity.Property(e => e.DefaultVehicleType9).HasColumnName("default_vehicle_type9");

                entity.Property(e => e.DelayedPaymentDefault)
                    .IsRequired()
                    .HasColumnName("delayed_payment_default")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Deleted)
                    .HasColumnName("deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Discount)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("discount");

                entity.Property(e => e.Einvoice).HasColumnName("einvoice");

                entity.Property(e => e.Email)
                    .HasMaxLength(70)
                    .HasColumnName("email");

                entity.Property(e => e.Iban)
                    .HasMaxLength(50)
                    .HasColumnName("iban");

                entity.Property(e => e.IdCompanyBlock).HasColumnName("id_company_block");

                entity.Property(e => e.IdCompanySlip).HasColumnName("id_company_slip");

                entity.Property(e => e.IdPaymentTypeDefault).HasColumnName("id_payment_type_default");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdRecord)
                    .HasColumnName("id_record")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdTariffDefault).HasColumnName("id_tariff_default");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InternalCompany)
                    .HasColumnName("internal_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Name)
                    .HasMaxLength(150)
                    .HasColumnName("name");

                entity.Property(e => e.OutsourcingCompany)
                    .HasColumnName("outsourcing_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PassValidation)
                    .HasMaxLength(50)
                    .HasColumnName("pass_validation");

                entity.Property(e => e.PaymentDueDateText)
                    .HasMaxLength(150)
                    .HasColumnName("payment_due_date_text");

                entity.Property(e => e.Phone)
                    .HasMaxLength(20)
                    .HasColumnName("phone");

                entity.Property(e => e.Post)
                    .HasMaxLength(100)
                    .HasColumnName("post");

                entity.Property(e => e.RegisterNumber)
                    .HasMaxLength(50)
                    .HasColumnName("register_number");

                entity.Property(e => e.ShortName)
                    .HasMaxLength(150)
                    .HasColumnName("short_name");

                entity.Property(e => e.SignatureInvoice).HasColumnName("signature_invoice");

                entity.Property(e => e.TaxId)
                    .HasMaxLength(50)
                    .HasColumnName("tax_id");
            });

            modelBuilder.Entity<CompanyAssignAllowedDriver>(entity =>
            {
                entity.HasKey(e => e.IdCompanyAssignAllowedDriver)
                    .HasName("PK_company_assing_allowed_unit");

                entity.ToTable("company_assign_allowed_driver");

                entity.Property(e => e.IdCompanyAssignAllowedDriver).HasColumnName("id_company_assign_allowed_driver");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<CompanyBilling>(entity =>
            {
                entity.HasKey(e => e.IdCompanyBilling);

                entity.ToTable("company_billing");

                entity.Property(e => e.IdCompanyBilling).HasColumnName("id_company_billing");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 0)")
                    .HasColumnName("price");
            });

            modelBuilder.Entity<CompanyBillingCenter>(entity =>
            {
                entity.HasKey(e => e.IdCompanyBillingCenter);

                entity.ToTable("company_billing_center");

                entity.Property(e => e.IdCompanyBillingCenter).HasColumnName("id_company_billing_center");

                entity.Property(e => e.BillingCenter)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("billing_center");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<CompanyBlock>(entity =>
            {
                entity.HasKey(e => e.IdCompanyBlock);

                entity.ToTable("company_block");

                entity.Property(e => e.IdCompanyBlock).HasColumnName("id_company_block");

                entity.Property(e => e.BlockNumberFrom).HasColumnName("block_number_from");

                entity.Property(e => e.BlockNumberTo).HasColumnName("block_number_to");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");
            });

            modelBuilder.Entity<CompanyCredential>(entity =>
            {
                entity.HasKey(e => e.IdCompanyCredential);

                entity.ToTable("company_credential");

                entity.Property(e => e.IdCompanyCredential).HasColumnName("id_company_credential");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("code");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IssuedTo)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("issued_to");
            });

            modelBuilder.Entity<CompanyCustomLocation>(entity =>
            {
                entity.HasKey(e => e.IdCompanyCustomLocation);

                entity.ToTable("company_custom_locations");

                entity.Property(e => e.IdCompanyCustomLocation).HasColumnName("id_company_custom_location");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdCustomLocation).HasColumnName("id_custom_location");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<CompanyLoyaltyCard>(entity =>
            {
                entity.HasKey(e => e.IdCompanyLoyaltyCard);

                entity.ToTable("company_loyalty_card");

                entity.Property(e => e.IdCompanyLoyaltyCard).HasColumnName("id_company_loyalty_card");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.LoyaltyCardId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("loyalty_card_id");
            });

            modelBuilder.Entity<CompanyNote>(entity =>
            {
                entity.HasKey(e => e.IdCompanyNote)
                    .HasName("PK_company_note");

                entity.ToTable("company_notes");

                entity.Property(e => e.IdCompanyNote).HasColumnName("id_company_note");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Note)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("note");

                entity.Property(e => e.SortingNumber)
                    .HasColumnName("sorting_number")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<CompanyPassenger>(entity =>
            {
                entity.HasKey(e => e.IdCompanyPassenger)
                    .HasName("PK_company_passenger");

                entity.ToTable("company_passengers");

                entity.Property(e => e.IdCompanyPassenger).HasColumnName("id_company_passenger");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Passenger)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("passenger");

                entity.Property(e => e.Telephone)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("telephone");
            });

            modelBuilder.Entity<CompanyPhone>(entity =>
            {
                entity.HasKey(e => e.IdCompanyPhone);

                entity.ToTable("CompanyPhone");

                entity.Property(e => e.IdCompanyPhone).HasColumnName("id_company_phone");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.Phone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone");
            });

            modelBuilder.Entity<CompanyTariff>(entity =>
            {
                entity.HasKey(e => e.IdTariff);

                entity.ToTable("company_tariff");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IsDefault).HasColumnName("is_default");

                entity.Property(e => e.PriceKm)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price_km");

                entity.Property(e => e.StartFee)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("start_fee");

                entity.Property(e => e.Tariff)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("tariff")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.WaitTimeHour)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("wait_time_hour");
            });

            modelBuilder.Entity<Coupon>(entity =>
            {
                entity.HasKey(e => e.IdCoupon)
                    .HasName("PK_cupons");

                entity.ToTable("coupons");

                entity.Property(e => e.IdCoupon).HasColumnName("id_coupon");

                entity.Property(e => e.Coupon1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("coupon");

                entity.Property(e => e.CouponValue)
                    .HasColumnType("decimal(7, 2)")
                    .HasColumnName("coupon_value");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");
            });

            modelBuilder.Entity<CtDealInvitation>(entity =>
            {
                entity.HasKey(e => e.IdCtDealInvitation)
                    .HasName("PK_deal_invitation");

                entity.ToTable("ct_deal_invitation");

                entity.HasIndex(e => e.Code, "U_deal_invitation_code")
                    .IsUnique();

                entity.Property(e => e.IdCtDealInvitation).HasColumnName("id_ct_deal_invitation");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("code");

                entity.Property(e => e.IdCtDeal).HasColumnName("id_ct_deal");

                entity.Property(e => e.IdCtUser).HasColumnName("id_ct_user");

                entity.Property(e => e.PersonCount).HasColumnName("person_count");

                entity.Property(e => e.RequestedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("requested_at")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Validated).HasColumnName("validated");
            });

            modelBuilder.Entity<CtUnit>(entity =>
            {
                entity.HasKey(e => e.IdCtUnit);

                entity.ToTable("ct_unit");

                entity.Property(e => e.IdCtUnit).HasColumnName("id_ct_unit");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Imei)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.PassengerDetectionMode).HasColumnName("passenger_detection_mode");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.TaxiId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("taxi_id");
            });

            modelBuilder.Entity<CtUnitHistory>(entity =>
            {
                entity.HasKey(e => e.IdMessage);

                entity.ToTable("ct_unit_history");

                entity.Property(e => e.IdMessage).HasColumnName("id_message");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Imei)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Taximeter)
                    .HasColumnName("taximeter")
                    .HasDefaultValueSql("((-1))");
            });

            modelBuilder.Entity<CtUnitStatusUpdate>(entity =>
            {
                entity.HasKey(e => e.IdCtUnitStatusUpdate);

                entity.ToTable("ct_unit_status_update");

                entity.Property(e => e.IdCtUnitStatusUpdate).HasColumnName("id_ct_unit_status_update");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.TaxiIdIdentification)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("taxi_id_identification");
            });

            modelBuilder.Entity<CtUser>(entity =>
            {
                entity.HasKey(e => e.IdCtUser);

                entity.ToTable("ct_user");

                entity.Property(e => e.IdCtUser).HasColumnName("id_ct_user");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.IdCtUserRole).HasColumnName("id_ct_user_role");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Surname)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("surname");
            });

            modelBuilder.Entity<CtUserBackend>(entity =>
            {
                entity.HasKey(e => e.IdCtUserBackend);

                entity.ToTable("ct_user_backend");

                entity.Property(e => e.IdCtUserBackend).HasColumnName("id_ct_user_backend");

                entity.Property(e => e.IdCtUser).HasColumnName("id_ct_user");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.Salt)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("salt");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<CtUserRole>(entity =>
            {
                entity.HasKey(e => e.IdCtUserRole);

                entity.ToTable("ct_user_role");

                entity.Property(e => e.IdCtUserRole)
                    .ValueGeneratedNever()
                    .HasColumnName("id_ct_user_role");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<CustomLocation>(entity =>
            {
                entity.HasKey(e => e.IdCustomLocation);

                entity.ToTable("custom_location");

                entity.HasIndex(e => new { e.InsertType, e.ExpiresAtDt }, "IX_custom_location_insert_type_expires_at_dt_58298")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Lat, e.Lon }, "IX_custom_location_lat_lon_BB87C")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.Title, "IX_custom_location_title_EB1EB")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Lat, e.Lon }, "NCI_custom_location_distance_search")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.Title, "NonClusteredIndex-20150301-180127")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.InsertType, e.Title }, "NonClusteredIndex-GetCustomLocationList")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Title, e.Lat, e.Lon, e.InsertType }, "UC_custom_location")
                    .IsUnique()
                    .HasFillFactor(100);

                entity.Property(e => e.IdCustomLocation).HasColumnName("id_custom_location");

                entity.Property(e => e.ConfirmedAccuracy)
                    .HasColumnName("confirmed_accuracy")
                    .HasDefaultValueSql("('true')");

                entity.Property(e => e.ExpiresAtDt)
                    .HasColumnType("datetime")
                    .HasColumnName("expires_at_dt");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.InsertType)
                    .HasColumnName("insert_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Number)
                    .HasMaxLength(10)
                    .HasColumnName("number");

                entity.Property(e => e.Street)
                    .HasMaxLength(250)
                    .HasColumnName("street");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<CustomLocationShadow>(entity =>
            {
                entity.HasKey(e => e.IdCustomLocationShadow);

                entity.ToTable("custom_location_shadow");

                entity.Property(e => e.IdCustomLocationShadow).HasColumnName("id_custom_location_shadow");

                entity.Property(e => e.ConfirmedAccuracy)
                    .HasColumnName("confirmed_accuracy")
                    .HasDefaultValueSql("('true')");

                entity.Property(e => e.IdCustomLocation).HasColumnName("id_custom_location");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.InsertType)
                    .HasColumnName("insert_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Number)
                    .HasMaxLength(10)
                    .HasColumnName("number");

                entity.Property(e => e.Street)
                    .HasMaxLength(250)
                    .HasColumnName("street");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<CustomerCancellType>(entity =>
            {
                entity.HasKey(e => e.IdCustomerCancellType);

                entity.ToTable("customer_cancell_type");

                entity.Property(e => e.IdCustomerCancellType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_customer_cancell_type");

                entity.Property(e => e.CustomerCancellType1)
                    .HasMaxLength(150)
                    .HasColumnName("customer_cancell_type");
            });

            modelBuilder.Entity<Denial>(entity =>
            {
                entity.HasKey(e => e.IdDenial);

                entity.ToTable("denials");

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-20160119-195146");

                entity.Property(e => e.IdDenial).HasColumnName("id_denial");

                entity.Property(e => e.AddedBy)
                    .HasColumnName("added_by")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<Device>(entity =>
            {
                entity.HasKey(e => e.IdDevice);

                entity.ToTable("devices");

                entity.Property(e => e.IdDevice).HasColumnName("id_device");

                entity.Property(e => e.AddDate)
                    .HasColumnType("datetime")
                    .HasColumnName("add_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AlternateDevice).HasColumnName("alternate_device");

                entity.Property(e => e.DateOfApplication)
                    .HasColumnType("datetime")
                    .HasColumnName("date_of_application");

                entity.Property(e => e.DeviceSim)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("device_sim");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Imei)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.SerialNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("serial_number");
            });

            modelBuilder.Entity<DirtyTable>(entity =>
            {
                entity.HasKey(e => e.IdRecord);

                entity.ToTable("dirty_table");

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.DirtyDate)
                    .HasColumnType("datetime")
                    .HasColumnName("dirty_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DirtySeconds)
                    .HasColumnName("dirty_seconds")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IsDirty)
                    .HasColumnName("is_dirty")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TableName)
                    .HasMaxLength(50)
                    .HasColumnName("table_name");
            });

            modelBuilder.Entity<DiscountType>(entity =>
            {
                entity.HasKey(e => e.IdDiscountType);

                entity.ToTable("discount_type");

                entity.Property(e => e.IdDiscountType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_discount_type");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<DispatchType>(entity =>
            {
                entity.HasKey(e => e.IdDispatchType);

                entity.ToTable("dispatch_type");

                entity.Property(e => e.IdDispatchType).HasColumnName("id_dispatch_type");

                entity.Property(e => e.DispatchType1).HasColumnName("dispatch_type");

                entity.Property(e => e.DriverMayOptOut).HasColumnName("driver_may_opt_out");

                entity.Property(e => e.DriverPickupMaximumMinutes).HasColumnName("driver_pickup_maximum_minutes");

                entity.Property(e => e.LicitationDistance)
                    .HasColumnName("licitation_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LicitationType).HasColumnName("licitation_type");

                entity.Property(e => e.TargetAcceptTimes).HasColumnName("target_accept_times");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<DistancesType>(entity =>
            {
                entity.HasKey(e => e.IdDistancesType);

                entity.ToTable("distances_type");

                entity.Property(e => e.IdDistancesType).HasColumnName("id_distances_type");

                entity.Property(e => e.DistancesType1)
                    .HasMaxLength(10)
                    .HasColumnName("distances_type")
                    .IsFixedLength();
            });

            modelBuilder.Entity<Driver>(entity =>
            {
                entity.HasKey(e => e.IdDriver);

                entity.ToTable("driver");

                entity.HasIndex(e => e.Isdeleted, "IX_driver_isdeleted_81E3D");

                entity.HasIndex(e => new { e.IdUnit, e.Master }, "NonClusteredIndex-20151207-082026");

                entity.HasIndex(e => e.Password, "UC_Password")
                    .IsUnique();

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .HasColumnName("address");

                entity.Property(e => e.Bluetooth).HasColumnName("bluetooth");

                entity.Property(e => e.Car)
                    .HasMaxLength(50)
                    .HasColumnName("car");

                entity.Property(e => e.CarColor)
                    .HasMaxLength(50)
                    .HasColumnName("car_color");

                entity.Property(e => e.CarType)
                    .HasMaxLength(50)
                    .HasColumnName("car_type");

                entity.Property(e => e.Company)
                    .HasMaxLength(150)
                    .HasColumnName("company");

                entity.Property(e => e.CompanyPhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("company_phone");

                entity.Property(e => e.Email)
                    .HasMaxLength(150)
                    .HasColumnName("email");

                entity.Property(e => e.EngineDisp)
                    .HasMaxLength(50)
                    .HasColumnName("engine_disp");

                entity.Property(e => e.EnginePower)
                    .HasMaxLength(50)
                    .HasColumnName("engine_power");

                entity.Property(e => e.Gsm)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("gsm");

                entity.Property(e => e.HomePhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("home_phone");

                entity.Property(e => e.IdCompany)
                    .HasColumnName("id_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdInternalDepartment)
                    .HasColumnName("id_internal_department")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdNetworkProvider).HasColumnName("id_network_provider");

                entity.Property(e => e.IdPost)
                    .HasColumnName("id_post")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdUnit)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("id_unit");

                entity.Property(e => e.Imei)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.ImportedCarId)
                    .HasMaxLength(50)
                    .HasColumnName("imported_car_id");

                entity.Property(e => e.ImportedDriverId).HasColumnName("imported_driver_id");

                entity.Property(e => e.IsController)
                    .HasColumnName("is_controller")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateBy)
                    .HasColumnName("last_update_by")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(50)
                    .HasColumnName("lastname");

                entity.Property(e => e.License)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("license");

                entity.Property(e => e.LicenseExpiration)
                    .HasColumnType("datetime")
                    .HasColumnName("license_expiration");

                entity.Property(e => e.Master).HasColumnName("master");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Note).HasColumnName("note");

                entity.Property(e => e.NumOfSeats)
                    .HasColumnName("num_of_seats")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OverviewDate)
                    .HasColumnType("datetime")
                    .HasColumnName("overview_date");

                entity.Property(e => e.Password)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.PermanentDeleted)
                    .HasColumnName("permanent_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PersonalId)
                    .HasMaxLength(50)
                    .HasColumnName("personal_id");

                entity.Property(e => e.Picture).HasColumnName("picture");

                entity.Property(e => e.RegistrationNumber)
                    .HasMaxLength(50)
                    .HasColumnName("registration_number");

                entity.Property(e => e.RegstrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("regstration_date");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.YearOf)
                    .HasColumnName("year_of")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<DriverAction>(entity =>
            {
                entity.HasKey(e => e.IdDriverAction);

                entity.ToTable("driver_action");

                entity.Property(e => e.IdDriverAction).HasColumnName("id_driver_action");

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<DriverActionStatistic>(entity =>
            {
                entity.HasKey(e => e.IdDriverActionStatistic);

                entity.ToTable("driver_action_statistic");

                entity.Property(e => e.IdDriverActionStatistic).HasColumnName("id_driver_action_statistic");

                entity.Property(e => e.DtAction)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_action")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdDriverAction).HasColumnName("id_driver_action");
            });

            modelBuilder.Entity<DriverBankAccount>(entity =>
            {
                entity.HasKey(e => e.IdDriverAccountNumber)
                    .HasName("PK_driver_account");

                entity.ToTable("driver_bank_account");

                entity.Property(e => e.IdDriverAccountNumber).HasColumnName("id_driver_account_number");

                entity.Property(e => e.AccountNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("account_number");

                entity.Property(e => e.Deleted)
                    .HasColumnType("datetime")
                    .HasColumnName("deleted");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<DriverBlockType>(entity =>
            {
                entity.HasKey(e => e.IdDriverBlockType);

                entity.ToTable("driver_block_type");

                entity.Property(e => e.IdDriverBlockType).HasColumnName("id_driver_block_type");

                entity.Property(e => e.BlockTimespanHours).HasColumnName("block_timespan_hours");

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<DriverBlocked>(entity =>
            {
                entity.HasKey(e => e.IdDriverBlocked);

                entity.ToTable("driver_blocked");

                entity.HasIndex(e => new { e.Deleted, e.DateFrom, e.DateTo }, "IX_driver_blocked_deleted_date_from_date_to_3DD93");

                entity.Property(e => e.IdDriverBlocked).HasColumnName("id_driver_blocked");

                entity.Property(e => e.DateDeleted)
                    .HasColumnType("datetime")
                    .HasColumnName("date_deleted");

                entity.Property(e => e.DateFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("date_from");

                entity.Property(e => e.DateTo)
                    .HasColumnType("datetime")
                    .HasColumnName("date_to");

                entity.Property(e => e.Deleted)
                    .HasColumnName("deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUserDelete).HasColumnName("id_user_delete");

                entity.Property(e => e.IdUserInsert).HasColumnName("id_user_insert");

                entity.Property(e => e.Note)
                    .HasMaxLength(250)
                    .HasColumnName("note");
            });

            modelBuilder.Entity<DriverBlockedRefoundation>(entity =>
            {
                entity.HasKey(e => e.IdDriverBlockRefoundation);

                entity.ToTable("driver_blocked_refoundation");

                entity.Property(e => e.IdDriverBlockRefoundation).HasColumnName("id_driver_block_refoundation");

                entity.Property(e => e.IdControllerDriver).HasColumnName("id_controller_driver");

                entity.Property(e => e.IdDriverBlockType).HasColumnName("id_driver_block_type");

                entity.Property(e => e.IdDriverBlocked).HasColumnName("id_driver_blocked");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.RefoundationExpires)
                    .HasColumnType("datetime")
                    .HasColumnName("refoundation_expires");

                entity.Property(e => e.RefoundationFor)
                    .HasMaxLength(50)
                    .HasColumnName("refoundation_for");

                entity.Property(e => e.RefoundationRequested).HasColumnName("refoundation_requested");

                entity.Property(e => e.UnblockedBy)
                    .HasMaxLength(50)
                    .HasColumnName("unblocked_by");

                entity.Property(e => e.UnblockedReason)
                    .HasMaxLength(250)
                    .HasColumnName("unblocked_reason");
            });

            modelBuilder.Entity<DriverBonu>(entity =>
            {
                entity.HasKey(e => e.IdDriverBonus);

                entity.ToTable("driver_bonus");

                entity.Property(e => e.IdDriverBonus).HasColumnName("id_driver_bonus");

                entity.Property(e => e.BonusAmmount).HasColumnName("bonus_ammount");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");
            });

            modelBuilder.Entity<DriverCompanyAssignBlock>(entity =>
            {
                entity.HasKey(e => e.IdDriverCompanyAssignBlock);

                entity.ToTable("driver_company_assign_block");

                entity.Property(e => e.IdDriverCompanyAssignBlock).HasColumnName("id_driver_company_assign_block");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<DriverDispatchType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("driver_dispatch_type");

                entity.HasIndex(e => new { e.IdDriver, e.IdDispatchType }, "IX_driver_dispatch_type_id_driver_id_dispatch_type_46032");

                entity.Property(e => e.IdDispatchType).HasColumnName("id_dispatch_type");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdDriverDispatchType)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_driver_dispatch_type");

                entity.Property(e => e.OptedOut).HasColumnName("opted_out");
            });

            modelBuilder.Entity<DriverFaultyReader>(entity =>
            {
                entity.HasKey(e => e.IdDriverFaultyReader);

                entity.ToTable("driver_faulty_reader");

                entity.Property(e => e.IdDriverFaultyReader).HasColumnName("id_driver_faulty_reader");

                entity.Property(e => e.DtAdded)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_added")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DtRemoved)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_removed");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUserAdded).HasColumnName("id_user_added");

                entity.Property(e => e.IdUserRemoved).HasColumnName("id_user_removed");
            });

            modelBuilder.Entity<DriverField>(entity =>
            {
                entity.HasKey(e => e.IdDriver);

                entity.ToTable("driver_fields");

                entity.Property(e => e.IdDriver)
                    .ValueGeneratedNever()
                    .HasColumnName("id_driver");

                entity.Property(e => e.CarSerialNumber)
                    .HasMaxLength(20)
                    .HasColumnName("car_serial_number");

                entity.Property(e => e.DriverFrom)
                    .HasMaxLength(50)
                    .HasColumnName("driver_from");

                entity.Property(e => e.IdPersonalCard).HasColumnName("id_personal_card");

                entity.Property(e => e.ListType).HasColumnName("list_type");

                entity.Property(e => e.MemberFrom)
                    .HasColumnType("date")
                    .HasColumnName("member_from");

                entity.Property(e => e.MemberTo)
                    .HasColumnType("date")
                    .HasColumnName("member_to");

                entity.Property(e => e.Points)
                    .HasMaxLength(10)
                    .HasColumnName("points");

                entity.Property(e => e.RideCount).HasColumnName("ride_count");

                entity.Property(e => e.StatusType)
                    .HasMaxLength(20)
                    .HasColumnName("status_type");

                entity.Property(e => e.UniqueMasterCitizenNumber)
                    .HasMaxLength(20)
                    .HasColumnName("unique_master_citizen_number");
            });

            modelBuilder.Entity<DriverLogin>(entity =>
            {
                entity.HasKey(e => e.IdDriverLogin);

                entity.ToTable("driver_login");

                entity.HasIndex(e => e.IdUnit, "IX_driver_login_id_unit_3EC8F")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Login, e.LastActivity }, "IX_driver_login_login_last_activity_3F4A7");

                entity.HasIndex(e => new { e.IdDriver, e.LastActivity, e.ShiftType }, "NonClusteredIndex-20150605-160015")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.IdDriver, e.ShiftType }, "NonClusteredIndex-20160119-195009")
                    .HasFillFactor(100);

                entity.Property(e => e.IdDriverLogin).HasColumnName("id_driver_login");

                entity.Property(e => e.HiredDistance).HasColumnName("hired_distance");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.LastActivity)
                    .HasColumnType("datetime")
                    .HasColumnName("last_activity")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Login)
                    .HasColumnType("datetime")
                    .HasColumnName("login")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Logout)
                    .HasColumnType("datetime")
                    .HasColumnName("logout");

                entity.Property(e => e.LogoutType).HasColumnName("logout_type");

                entity.Property(e => e.ShiftType)
                    .HasColumnName("shift_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.TotalDistance).HasColumnName("total_distance");
            });

            modelBuilder.Entity<DriverLogoutType>(entity =>
            {
                entity.HasKey(e => e.IdDriverLogoutType);

                entity.ToTable("driver_logout_type");

                entity.Property(e => e.IdDriverLogoutType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_driver_logout_type");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasColumnName("title");
            });

            modelBuilder.Entity<DriverMasterLogin>(entity =>
            {
                entity.HasKey(e => e.IdDriverMasterLogin);

                entity.ToTable("driver_master_login");

                entity.Property(e => e.IdDriverMasterLogin).HasColumnName("id_driver_master_login");

                entity.Property(e => e.Assigned)
                    .HasColumnType("datetime")
                    .HasColumnName("assigned")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Deassigned)
                    .HasColumnType("datetime")
                    .HasColumnName("deassigned");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<DriverPause>(entity =>
            {
                entity.HasKey(e => e.IdDriverPause);

                entity.ToTable("driver_pause");

                entity.HasIndex(e => new { e.IdDriver, e.ShiftType }, "IX_driver_pause_id_driver_shift_type_44B70");

                entity.HasIndex(e => e.PauseEnd, "IX_driver_pause_pause_end_823EF");

                entity.HasIndex(e => new { e.IdUnit, e.PauseStart, e.PauseEnd }, "NonClusteredIndex-pause");

                entity.Property(e => e.IdDriverPause).HasColumnName("id_driver_pause");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.PauseEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("pause_end")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PauseStart)
                    .HasColumnType("datetime")
                    .HasColumnName("pause_start")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ShiftType).HasColumnName("shift_type");
            });

            modelBuilder.Entity<DriverPaymentDatum>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("driver_payment_data");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .HasColumnName("address");

                entity.Property(e => e.BankAccount)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("bank_account");

                entity.Property(e => e.CardNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("card_number");

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .HasColumnName("city");

                entity.Property(e => e.DefaultPaymentType).HasColumnName("default_payment_type");

                entity.Property(e => e.FullName)
                    .HasMaxLength(50)
                    .HasColumnName("full_name");

                entity.Property(e => e.IdDriverPaymentData)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_driver_payment_data");

                entity.Property(e => e.IdUnit)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("id_unit");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<DriverShadow>(entity =>
            {
                entity.HasKey(e => e.IdDriverShadow)
                    .HasName("PK_driver_shadow_1");

                entity.ToTable("driver_shadow");

                entity.HasIndex(e => e.IdDriver, "IX_driver_shadow_id_driver_06058")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.IdDriver, "IX_driver_shadow_id_driver_CE85C");

                entity.Property(e => e.IdDriverShadow).HasColumnName("id_driver_shadow");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .HasColumnName("address");

                entity.Property(e => e.Bluetooth)
                    .HasColumnName("bluetooth")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Car)
                    .HasMaxLength(50)
                    .HasColumnName("car");

                entity.Property(e => e.CarColor)
                    .HasMaxLength(50)
                    .HasColumnName("car_color");

                entity.Property(e => e.CarType)
                    .HasMaxLength(50)
                    .HasColumnName("car_type");

                entity.Property(e => e.ChangeType)
                    .HasMaxLength(50)
                    .HasColumnName("change_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Company)
                    .HasMaxLength(150)
                    .HasColumnName("company");

                entity.Property(e => e.CompanyPhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("company_phone");

                entity.Property(e => e.Email)
                    .HasMaxLength(150)
                    .HasColumnName("email");

                entity.Property(e => e.EngineDisp)
                    .HasMaxLength(50)
                    .HasColumnName("engine_disp");

                entity.Property(e => e.EnginePower)
                    .HasMaxLength(50)
                    .HasColumnName("engine_power");

                entity.Property(e => e.Gsm)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("gsm");

                entity.Property(e => e.HomePhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("home_phone");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdNetworkProvider)
                    .HasColumnName("id_network_provider")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdUnit)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("id_unit");

                entity.Property(e => e.Imei)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.ImportedCarId)
                    .HasMaxLength(50)
                    .HasColumnName("imported_car_id");

                entity.Property(e => e.ImportedDriverId).HasColumnName("imported_driver_id");

                entity.Property(e => e.IsController)
                    .HasColumnName("is_controller")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(50)
                    .HasColumnName("lastname");

                entity.Property(e => e.License)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("license");

                entity.Property(e => e.LicenseExpiration)
                    .HasColumnType("datetime")
                    .HasColumnName("license_expiration");

                entity.Property(e => e.Master).HasColumnName("master");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Note).HasColumnName("note");

                entity.Property(e => e.NumOfSeats).HasColumnName("num_of_seats");

                entity.Property(e => e.OverviewDate)
                    .HasColumnType("datetime")
                    .HasColumnName("overview_date");

                entity.Property(e => e.Password)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.PermanentDeleted)
                    .HasColumnName("permanent_deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PersonalId)
                    .HasMaxLength(50)
                    .HasColumnName("personal_id");

                entity.Property(e => e.Picture).HasColumnName("picture");

                entity.Property(e => e.RegistrationNumber)
                    .HasMaxLength(50)
                    .HasColumnName("registration_number");

                entity.Property(e => e.RegstrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("regstration_date");

                entity.Property(e => e.Type1).HasColumnName("type1");

                entity.Property(e => e.Type10).HasColumnName("type10");

                entity.Property(e => e.Type11).HasColumnName("type11");

                entity.Property(e => e.Type12).HasColumnName("type12");

                entity.Property(e => e.Type13).HasColumnName("type13");

                entity.Property(e => e.Type14).HasColumnName("type14");

                entity.Property(e => e.Type15).HasColumnName("type15");

                entity.Property(e => e.Type16).HasColumnName("type16");

                entity.Property(e => e.Type17).HasColumnName("type17");

                entity.Property(e => e.Type18).HasColumnName("type18");

                entity.Property(e => e.Type19).HasColumnName("type19");

                entity.Property(e => e.Type2).HasColumnName("type2");

                entity.Property(e => e.Type20).HasColumnName("type20");

                entity.Property(e => e.Type3).HasColumnName("type3");

                entity.Property(e => e.Type4).HasColumnName("type4");

                entity.Property(e => e.Type5).HasColumnName("type5");

                entity.Property(e => e.Type6).HasColumnName("type6");

                entity.Property(e => e.Type7).HasColumnName("type7");

                entity.Property(e => e.Type8).HasColumnName("type8");

                entity.Property(e => e.Type9).HasColumnName("type9");

                entity.Property(e => e.YearOf).HasColumnName("year_of");
            });

            modelBuilder.Entity<DriverSipAccount>(entity =>
            {
                entity.HasKey(e => e.IdDriverSipAccount);

                entity.ToTable("driver_sip_account");

                entity.Property(e => e.IdDriverSipAccount).HasColumnName("id_driver_sip_account");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.SipPassword)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("sip_password");

                entity.Property(e => e.SipServer)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("sip_server");

                entity.Property(e => e.SipUsername)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("sip_username");
            });

            modelBuilder.Entity<EmployeeAllowedInternalDepartment>(entity =>
            {
                entity.HasKey(e => e.IdEmployeeAllowedInternalDepartment);

                entity.ToTable("employee_allowed_internal_department");

                entity.Property(e => e.IdEmployeeAllowedInternalDepartment).HasColumnName("id_employee_allowed_internal_department");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdUser).HasColumnName("id_user");
            });

            modelBuilder.Entity<EmployeeLogin>(entity =>
            {
                entity.HasKey(e => e.IdEmployeeLogin);

                entity.ToTable("employee_login");

                entity.HasIndex(e => new { e.ActivityStarted, e.ActivityEnded }, "IX_employee_login_activity_started_activity_ended_C6E1C");

                entity.HasIndex(e => new { e.IdEmployee, e.ActivityStarted, e.ActivityEnded }, "IX_employee_login_id_employee_activity_started_activity_ended_ACF23")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.SipAccount, e.ActivityStarted, e.ActivityEnded }, "IX_employee_login_sip_account_activity_started_activity_ended_29BAA")
                    .HasFillFactor(100);

                entity.Property(e => e.IdEmployeeLogin).HasColumnName("id_employee_login");

                entity.Property(e => e.ActivityEnded)
                    .HasColumnType("datetime")
                    .HasColumnName("activity_ended");

                entity.Property(e => e.ActivityStarted)
                    .HasColumnType("datetime")
                    .HasColumnName("activity_started");

                entity.Property(e => e.IdEmployee).HasColumnName("id_employee");

                entity.Property(e => e.LoginType)
                    .HasColumnName("login_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ShiftType)
                    .HasColumnName("shift_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.SipAccount)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sip_account");
            });

            modelBuilder.Entity<EmployeeShiftType>(entity =>
            {
                entity.HasKey(e => e.IdEmployeeShiftType);

                entity.ToTable("employee_shift_type");

                entity.Property(e => e.IdEmployeeShiftType).HasColumnName("id_employee_shift_type");

                entity.Property(e => e.EmployeeType)
                    .HasColumnName("employee_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.HourFrom).HasColumnName("hour_from");

                entity.Property(e => e.HourTo).HasColumnName("hour_to");

                entity.Property(e => e.ShiftType).HasColumnName("shift_type");

                entity.Property(e => e.Title)
                    .HasMaxLength(150)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.IdEvent);

                entity.ToTable("events");

                entity.HasIndex(e => e.DtAdded, "IX_events_dt_added_382BF")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.IdEventType, "NonClusteredIndex-20160422-120737")
                    .HasFillFactor(100);

                entity.Property(e => e.IdEvent).HasColumnName("id_event");

                entity.Property(e => e.DtAdded)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_added")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Event1)
                    .HasMaxLength(150)
                    .HasColumnName("event");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdEventType).HasColumnName("id_event_type");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<EventType>(entity =>
            {
                entity.HasKey(e => e.IdEventType);

                entity.ToTable("event_type");

                entity.Property(e => e.IdEventType).HasColumnName("id_event_type");

                entity.Property(e => e.EventType1)
                    .HasMaxLength(150)
                    .HasColumnName("event_type");
            });

            modelBuilder.Entity<FinanceDocument>(entity =>
            {
                entity.HasKey(e => e.IdFinanceDocument);

                entity.ToTable("finance_document");

                entity.Property(e => e.IdFinanceDocument).HasColumnName("id_finance_document");

                entity.Property(e => e.BlockUnpaid).HasColumnName("block_unpaid");

                entity.Property(e => e.Client)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("client");

                entity.Property(e => e.IdDocumentType)
                    .HasColumnName("id_document_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InvoiceGeneratedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("invoice_generated_dt");

                entity.Property(e => e.IsInvoiceGenerated).HasColumnName("is_invoice_generated");

                entity.Property(e => e.Issuer)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("issuer");

                entity.Property(e => e.PaidDt)
                    .HasColumnType("datetime")
                    .HasColumnName("paid_dt");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<FinanceDocumentItem>(entity =>
            {
                entity.HasKey(e => e.IdFinanceDocumentItem);

                entity.ToTable("finance_document_item");

                entity.Property(e => e.IdFinanceDocumentItem).HasColumnName("id_finance_document_item");

                entity.Property(e => e.IdFinanceDocument).HasColumnName("id_finance_document");

                entity.Property(e => e.Item)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("item");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.Value)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("value");
            });

            modelBuilder.Entity<FinanceDocumentType>(entity =>
            {
                entity.HasKey(e => e.IdFinanceDocumentType);

                entity.ToTable("finance_document_type");

                entity.Property(e => e.IdFinanceDocumentType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_finance_document_type");

                entity.Property(e => e.DocumentTypeTitle)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("document_type_title");
            });

            modelBuilder.Entity<FinancePeriodicIssuing>(entity =>
            {
                entity.HasKey(e => e.IdFinancePeriodicIssuing)
                    .HasName("PK_finanece_periodic_issuing");

                entity.ToTable("finance_periodic_issuing");

                entity.Property(e => e.IdFinancePeriodicIssuing).HasColumnName("id_finance_periodic_issuing");

                entity.Property(e => e.IdFinanceProduct).HasColumnName("id_finance_product");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.Issuer)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("issuer");

                entity.Property(e => e.Item)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("item");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<FinanceProduct>(entity =>
            {
                entity.HasKey(e => e.IdFinanceProduct);

                entity.ToTable("finance_product");

                entity.Property(e => e.IdFinanceProduct).HasColumnName("id_finance_product");

                entity.Property(e => e.IdProductType).HasColumnName("id_product_type");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");
            });

            modelBuilder.Entity<FinanceProductType>(entity =>
            {
                entity.HasKey(e => e.IdFinanceProductType);

                entity.ToTable("finance_product_type");

                entity.Property(e => e.IdFinanceProductType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_finance_product_type");

                entity.Property(e => e.Note)
                    .HasMaxLength(250)
                    .HasColumnName("note");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<FinanceResourcesInUse>(entity =>
            {
                entity.HasKey(e => e.IdFinanceResourceInUse);

                entity.ToTable("finance_resources_in_use");

                entity.Property(e => e.IdFinanceResourceInUse).HasColumnName("id_finance_resource_in_use");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.DeletedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("deleted_dt");

                entity.Property(e => e.IdFinanceProduct).HasColumnName("id_finance_product");

                entity.Property(e => e.IdResourceUser).HasColumnName("id_resource_user");

                entity.Property(e => e.IdUserType)
                    .HasColumnName("id_user_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Paid)
                    .IsRequired()
                    .HasColumnName("paid")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("phone_number");
            });

            modelBuilder.Entity<FinanceUserType>(entity =>
            {
                entity.HasKey(e => e.IdFinanceUserType);

                entity.ToTable("finance_user_type");

                entity.Property(e => e.IdFinanceUserType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_finance_user_type");

                entity.Property(e => e.UserTypeTitle)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("user_type_title");
            });

            modelBuilder.Entity<FinancialCategory>(entity =>
            {
                entity.HasKey(e => e.IdFinancialCategory);

                entity.ToTable("financial_category");

                entity.Property(e => e.IdFinancialCategory).HasColumnName("id_financial_category");

                entity.Property(e => e.Disabled).HasColumnName("disabled");

                entity.Property(e => e.Editable).HasColumnName("editable");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<FinancialRecord>(entity =>
            {
                entity.HasKey(e => e.IdFinancialRecord);

                entity.ToTable("financial_record");

                entity.Property(e => e.IdFinancialRecord).HasColumnName("id_financial_record");

                entity.Property(e => e.Amount)
                    .HasColumnType("decimal(18, 4)")
                    .HasColumnName("amount");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.Description).HasColumnName("description");

                entity.Property(e => e.IdCategory).HasColumnName("id_category");

                entity.Property(e => e.IdShift).HasColumnName("id_shift");

                entity.Property(e => e.InsertedDate).HasColumnName("inserted_date");

                entity.Property(e => e.ModifiedDate).HasColumnName("modified_date");

                entity.Property(e => e.Type).HasColumnName("type");
            });

            modelBuilder.Entity<FixedPriceRoute>(entity =>
            {
                entity.HasKey(e => e.IdFixedPriceRoute)
                    .HasName("PK_Prearranged");

                entity.ToTable("fixed_price_route");

                entity.Property(e => e.IdFixedPriceRoute).HasColumnName("id_fixed_price_route");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Location)
                    .HasMaxLength(100)
                    .HasColumnName("location");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");
            });

            modelBuilder.Entity<FuelType>(entity =>
            {
                entity.HasKey(e => e.IdFuelType);

                entity.ToTable("fuel_type");

                entity.Property(e => e.IdFuelType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_fuel_type");

                entity.Property(e => e.PricePerUnit)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price_per_unit");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");

                entity.Property(e => e.UnitOfMeasure)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("unit_of_measure");
            });

            modelBuilder.Entity<GeneralRemark>(entity =>
            {
                entity.HasKey(e => e.IdGeneralRemark);

                entity.ToTable("general_remark");

                entity.Property(e => e.IdGeneralRemark).HasColumnName("id_general_remark");

                entity.Property(e => e.Remark)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("remark");
            });

            modelBuilder.Entity<GeneratedReport>(entity =>
            {
                entity.HasKey(e => e.IdGeneratedReport);

                entity.ToTable("generated_report");

                entity.Property(e => e.IdGeneratedReport).HasColumnName("id_generated_report");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("date")
                    .HasColumnName("created_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.GeneratedReportType).HasColumnName("generated_report_type");
            });

            modelBuilder.Entity<HostSipAccount>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("host_sip_accounts");

                entity.Property(e => e.HostAddress)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("host_address");

                entity.Property(e => e.SipAccount)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sip_account");
            });

            modelBuilder.Entity<IncomingSm>(entity =>
            {
                entity.HasKey(e => e.IdSms);

                entity.ToTable("incoming_sms");

                entity.Property(e => e.IdSms).HasColumnName("id_sms");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.IsReply).HasColumnName("is_reply");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("phone_number");

                entity.Property(e => e.SmsMessage)
                    .HasMaxLength(700)
                    .HasColumnName("sms_message");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.SubscriberPhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("subscriber_phone_number");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasColumnName("timestamp")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<InternalDepartment>(entity =>
            {
                entity.HasKey(e => e.IdInternalDepartment)
                    .HasName("PK_company_department");

                entity.ToTable("internal_department");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.Deleted)
                    .HasColumnType("datetime")
                    .HasColumnName("deleted");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InternalDepartment1)
                    .HasMaxLength(50)
                    .HasColumnName("internal_department");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("is_deleted")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<InternalDepartmentPhone>(entity =>
            {
                entity.HasKey(e => e.IdInternalDepartmentPhone);

                entity.ToTable("internal_department_phone");

                entity.Property(e => e.IdInternalDepartmentPhone).HasColumnName("id_internal_department_phone");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.PhoneExtension)
                    .HasMaxLength(50)
                    .HasColumnName("phone_extension");
            });

            modelBuilder.Entity<Intervention>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interventions");

                entity.HasIndex(e => e.IdTarget, "ClusteredIndex-20191118-084635")
                    .IsClustered();

                entity.Property(e => e.DtRequested)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_requested");

                entity.Property(e => e.IdIntervention)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_intervention");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.Processed).HasColumnName("processed");

                entity.Property(e => e.Reason).HasColumnName("reason");

                entity.Property(e => e.ReleaseUnit).HasColumnName("release_unit");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<InterventionReason>(entity =>
            {
                entity.HasKey(e => e.IdInterventionReason)
                    .HasName("PK__interven__4AA68AAD0E8D8708");

                entity.ToTable("intervention_reason");

                entity.Property(e => e.IdInterventionReason).HasColumnName("id_intervention_reason");

                entity.Property(e => e.ReasonDescription)
                    .HasMaxLength(250)
                    .HasColumnName("reason_description");

                entity.Property(e => e.ReasonValue).HasColumnName("reason_value");
            });

            modelBuilder.Entity<Licitation>(entity =>
            {
                entity.HasKey(e => e.IdLicitation);

                entity.ToTable("licitation");

                entity.HasIndex(e => new { e.LicitationClosed, e.IdLicitation }, "NonClusteredIndex-20150319-145020");

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-20191118-084708");

                entity.Property(e => e.IdLicitation).HasColumnName("id_licitation");

                entity.Property(e => e.ClosedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("closed_dt");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.LicitationClosed)
                    .IsRequired()
                    .HasColumnName("licitation_closed")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.LicitationEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("licitation_end");

                entity.Property(e => e.LicitationStart)
                    .HasColumnType("datetime")
                    .HasColumnName("licitation_start");
            });

            modelBuilder.Entity<LicitationUnit>(entity =>
            {
                entity.HasKey(e => e.IdLicitationUnit);

                entity.ToTable("licitation_unit");

                entity.HasIndex(e => e.IdLicitation, "IX_licitation_unit_id_licitation");

                entity.HasIndex(e => new { e.IdLicitation, e.Notified, e.EndNotified }, "IX_licitation_unit_id_licitation_notified_end_notified_3673D");

                entity.HasIndex(e => new { e.UnitId, e.IdLicitation, e.Notified, e.Applied, e.EndNotified }, "NonClusteredIndex-20150312-120710");

                entity.HasIndex(e => new { e.UnitId, e.Notified, e.EndNotified }, "NonClusteredIndex-20150319-140949");

                entity.HasIndex(e => new { e.UnitId, e.EndNotified }, "NonClusteredIndex-20171010-145054");

                entity.Property(e => e.IdLicitationUnit).HasColumnName("id_licitation_unit");

                entity.Property(e => e.Applied)
                    .IsRequired()
                    .HasColumnName("applied")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.AppliedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("applied_dt");

                entity.Property(e => e.ArrivalTime)
                    .HasColumnName("arrival_time")
                    .HasDefaultValueSql("((10000))");

                entity.Property(e => e.EndNotified)
                    .IsRequired()
                    .HasColumnName("end_notified")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.IdLicitation).HasColumnName("id_licitation");

                entity.Property(e => e.Notified)
                    .IsRequired()
                    .HasColumnName("notified")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<LocationServiceBlackList>(entity =>
            {
                entity.HasKey(e => e.IdLocationServiceBlackList);

                entity.ToTable("location_service_black_list");

                entity.Property(e => e.IdLocationServiceBlackList).HasColumnName("id_location_service_black_list");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Radius).HasColumnName("radius");
            });

            modelBuilder.Entity<LocationServiceCachedStreet>(entity =>
            {
                entity.HasKey(e => e.IdLocationServiceCachedStreet);

                entity.ToTable("location_service_cached_street");

                entity.Property(e => e.IdLocationServiceCachedStreet).HasColumnName("id_location_service_cached_street");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Radius).HasColumnName("radius");

                entity.Property(e => e.Street)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("street");
            });

            modelBuilder.Entity<LocationServiceRequest>(entity =>
            {
                entity.HasKey(e => e.IdLocationServiceRequest);

                entity.ToTable("location_service_request");

                entity.Property(e => e.IdLocationServiceRequest).HasColumnName("id_location_service_request");

                entity.Property(e => e.Request)
                    .HasColumnType("datetime")
                    .HasColumnName("request")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ServiceType).HasColumnName("service_type");

                entity.Property(e => e.Source).HasColumnName("source");

                entity.Property(e => e.Url)
                    .IsRequired()
                    .HasMaxLength(512)
                    .IsUnicode(false)
                    .HasColumnName("url");
            });

            modelBuilder.Entity<ManualShift>(entity =>
            {
                entity.HasKey(e => e.IdManualShift);

                entity.ToTable("manual_shifts");

                entity.Property(e => e.IdManualShift).HasColumnName("id_manual_shift");

                entity.Property(e => e.Amount)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("amount");

                entity.Property(e => e.Deleted)
                    .HasColumnType("datetime")
                    .HasColumnName("deleted");

                entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");

                entity.Property(e => e.IdEmployee).HasColumnName("id_employee");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<MonthlyDatum>(entity =>
            {
                entity.HasKey(e => e.IdMonthlyReport);

                entity.ToTable("monthly_data");

                entity.Property(e => e.IdMonthlyReport).HasColumnName("id_monthly_report");

                entity.Property(e => e.Month).HasColumnName("month");

                entity.Property(e => e.SendDate)
                    .HasColumnType("datetime")
                    .HasColumnName("send_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<NetShuttleInvoice>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("net_shuttle_invoice");

                entity.Property(e => e.Fare)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("fare");

                entity.Property(e => e.HiredDistance)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("hired_distance");

                entity.Property(e => e.IdInvoice)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_invoice");

                entity.Property(e => e.SendToDriver)
                    .IsRequired()
                    .HasColumnName("send_to_driver")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<NetworkProvider>(entity =>
            {
                entity.HasKey(e => e.IdNetworkProvider);

                entity.ToTable("network_providers");

                entity.Property(e => e.IdNetworkProvider).HasColumnName("id_network_provider");

                entity.Property(e => e.NetworkProvider1)
                    .HasMaxLength(50)
                    .HasColumnName("network_provider");
            });

            modelBuilder.Entity<NoCustomerStatus>(entity =>
            {
                entity.HasKey(e => e.IdNoCustomerStatus);

                entity.ToTable("no_customer_status");

                entity.HasIndex(e => e.DtReceived, "IX_no_customer_status_dt_received_2BC16");

                entity.HasIndex(e => new { e.IdDriver, e.IdStand, e.NoCustomerHandled }, "IX_no_customer_status_id_driver_id_stand_no_customer_handled_49522");

                entity.HasIndex(e => new { e.IdStand, e.DtValidTo }, "IX_no_customer_status_id_stand_dt_valid_to_0749C");

                entity.HasIndex(e => e.DtValidTo, "NonClusteredIndex-20211224-120304");

                entity.Property(e => e.IdNoCustomerStatus).HasColumnName("id_no_customer_status");

                entity.Property(e => e.DtReceived)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_received")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DtValidTo)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_valid_to");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.NoCustomerHandled).HasColumnName("no_customer_handled");

                entity.Property(e => e.NoCustomerTarget)
                    .HasColumnName("no_customer_target")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.NoCustomerType)
                    .HasColumnName("no_customer_type")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<OrderFormItem>(entity =>
            {
                entity.HasKey(e => e.IdOrderFormItem);

                entity.ToTable("order_form_item");

                entity.Property(e => e.IdOrderFormItem).HasColumnName("id_order_form_item");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdOrderFormItemType).HasColumnName("id_order_form_item_type");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.OrderFormItemValue)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("order_form_item_value");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");
            });

            modelBuilder.Entity<OrderFormItemType>(entity =>
            {
                entity.HasKey(e => e.IdOrderFormItemType);

                entity.ToTable("order_form_item_type");

                entity.Property(e => e.IdOrderFormItemType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_order_form_item_type");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<OrderFromCompany>(entity =>
            {
                entity.HasKey(e => e.IdRecord);

                entity.ToTable("order_from_company");

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.OrderFromCompany1).HasColumnName("order_from_company");
            });

            modelBuilder.Entity<OrderType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("order_type");

                entity.Property(e => e.IdOrderType).HasColumnName("idOrderType");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PaymentDiscountCardBinRange>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_discount_card_bin_ranges");

                entity.HasIndex(e => e.IsoBin, "NonClusteredIndex-GetPaymentCardNumberDataForIsoBin");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id");

                entity.Property(e => e.IsoBin).HasColumnName("iso_bin");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("product_name");

                entity.Property(e => e.RangeFrom).HasColumnName("range_from");

                entity.Property(e => e.RangeTo).HasColumnName("range_to");
            });

            modelBuilder.Entity<PaymentDiscountType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_discount_types");

                entity.Property(e => e.ActiveFromDatetime)
                    .HasPrecision(3)
                    .HasColumnName("active_from_datetime");

                entity.Property(e => e.ActiveToDatetime)
                    .HasPrecision(3)
                    .HasColumnName("active_to_datetime");

                entity.Property(e => e.DiscountAmount)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("discount_amount");

                entity.Property(e => e.DiscountPercentage).HasColumnName("discount_percentage");

                entity.Property(e => e.DiscountType).HasColumnName("discount_type");

                entity.Property(e => e.DiscountedRidesNumber).HasColumnName("discounted_rides_number");

                entity.Property(e => e.MaximumDiscountValue)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("maximum_discount_value");

                entity.Property(e => e.MinumumNumberOfRides).HasColumnName("minumum_number_of_rides");

                entity.Property(e => e.PaymentDiscountTypeId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("payment_discount_type_id");
            });

            modelBuilder.Entity<PaymentDiscountZone>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_discount_zones");

                entity.Property(e => e.IdDiscountZone)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_discount_zone");

                entity.Property(e => e.ZoneName)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("zone_name");

                entity.Property(e => e.ZonePolygon)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("zone_polygon");

                entity.Property(e => e.ZoneType).HasColumnName("zone_type");
            });

            modelBuilder.Entity<PaymentGateway>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_gateway");

                entity.Property(e => e.BankAccount)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("bank_account");

                entity.Property(e => e.GatewayCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("gateway_code");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdPaymentGateway)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_payment_gateway");
            });

            modelBuilder.Entity<PaymentGatewayAppuserLog>(entity =>
            {
                entity.HasKey(e => e.IdPaymentGatewayAppuserLog);

                entity.ToTable("payment_gateway_appuser_log");

                entity.HasIndex(e => e.IdAppuser, "IX_payment_gateway_appuser_log_id_appuser_6B2F3")
                    .HasFillFactor(100);

                entity.Property(e => e.IdPaymentGatewayAppuserLog).HasColumnName("id_payment_gateway_appuser_log");

                entity.Property(e => e.CardMask)
                    .HasMaxLength(4)
                    .HasColumnName("card_mask")
                    .IsFixedLength();

                entity.Property(e => e.CardType)
                    .HasMaxLength(30)
                    .HasColumnName("card_type")
                    .IsFixedLength();

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.PaymentType)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("payment_type")
                    .IsFixedLength();
            });

            modelBuilder.Entity<PaymentGatewayAppuserRequestLog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_gateway_appuser_request_log");

                entity.Property(e => e.DeviceCode)
                    .IsUnicode(false)
                    .HasColumnName("device_code");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdPaymentGatewayAppuserRequest)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_payment_gateway_appuser_request");

                entity.Property(e => e.RequestDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("request_datetime");
            });

            modelBuilder.Entity<PaymentGatewayDriverLog>(entity =>
            {
                entity.HasKey(e => e.IdPaymentGatewayDriverLog);

                entity.ToTable("payment_gateway_driver_log");

                entity.Property(e => e.IdPaymentGatewayDriverLog).HasColumnName("id_payment_gateway_driver_log");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.PaymentAmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("payment_amount");

                entity.Property(e => e.PaymentDt)
                    .HasColumnType("datetime")
                    .HasColumnName("payment_dt")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ResponseCode)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("response_code");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<PaymentMonriDatum>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_monri_data");

                entity.HasIndex(e => new { e.IdTarget, e.InitiateTransaction, e.TransactionCompleted }, "IX_payment_monri_data_id_target_initiate_transaction_transaction_completed_C6386");

                entity.HasIndex(e => e.PaymentMonriDataId, "NonClusteredIndex-20211231-144830");

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-GetMonriCardDataByTargetId");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.InitiateTransaction).HasColumnName("initiate_transaction");

                entity.Property(e => e.MonriCardData)
                    .HasMaxLength(500)
                    .HasColumnName("monri_card_data");

                entity.Property(e => e.PaymentAmmount)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("payment_ammount");

                entity.Property(e => e.PaymentMonriDataId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("payment_monri_data_id");

                entity.Property(e => e.ReferenceNumber)
                    .HasMaxLength(25)
                    .HasColumnName("reference_number");

                entity.Property(e => e.TransactionCompleted).HasColumnName("transaction_completed");

                entity.Property(e => e.TransactionStatus).HasColumnName("transaction_status");
            });

            modelBuilder.Entity<PaymentMonriPanToken>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_monri_pan_tokens");

                entity.Property(e => e.Md)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("md");

                entity.Property(e => e.PanToken)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("pan_token");

                entity.Property(e => e.TokenId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("token_id");
            });

            modelBuilder.Entity<PaymentMonriTransactionLog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_monri_transaction_log");

                entity.Property(e => e.OrderNumber).HasColumnName("order_number");

                entity.Property(e => e.TransactionDatetime)
                    .HasColumnName("transaction_datetime")
                    .HasDefaultValueSql("(sysdatetime())");

                entity.Property(e => e.TransactionLogId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("transaction_log_id");

                entity.Property(e => e.TransactionResponseMessage)
                    .HasMaxLength(1000)
                    .HasColumnName("transaction_response_message");
            });

            modelBuilder.Entity<PaymentMonriVoidedTransaction>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_monri_voided_transactions");

                entity.Property(e => e.Amount).HasColumnName("amount");

                entity.Property(e => e.IdVoidedTransaction)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_voided_transaction");

                entity.Property(e => e.OrderNumber).HasColumnName("order_number");

                entity.Property(e => e.TransactionVoided).HasColumnName("transaction_voided");
            });

            modelBuilder.Entity<PaymentReceiptDatum>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("payment_receipt_data");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id");

                entity.Property(e => e.ReceiptData)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("receipt_data");

                entity.Property(e => e.TargetId).HasColumnName("target_id");
            });

            modelBuilder.Entity<PaymentType>(entity =>
            {
                entity.HasKey(e => e.IdPaymentType)
                    .HasName("PK__payment___D764C19A52D92AFC");

                entity.ToTable("payment_type");

                entity.Property(e => e.IdPaymentType)
                    .ValueGeneratedNever()
                    .HasColumnName("id_payment_type");

                entity.Property(e => e.CallCenterOnly).HasColumnName("call_center_only");

                entity.Property(e => e.DefaultTaxRate)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("default_tax_rate");

                entity.Property(e => e.DefaultType1).HasColumnName("default_type1");

                entity.Property(e => e.DefaultType10).HasColumnName("default_type10");

                entity.Property(e => e.DefaultType11).HasColumnName("default_type11");

                entity.Property(e => e.DefaultType12).HasColumnName("default_type12");

                entity.Property(e => e.DefaultType13).HasColumnName("default_type13");

                entity.Property(e => e.DefaultType14).HasColumnName("default_type14");

                entity.Property(e => e.DefaultType15).HasColumnName("default_type15");

                entity.Property(e => e.DefaultType16).HasColumnName("default_type16");

                entity.Property(e => e.DefaultType17).HasColumnName("default_type17");

                entity.Property(e => e.DefaultType18).HasColumnName("default_type18");

                entity.Property(e => e.DefaultType19).HasColumnName("default_type19");

                entity.Property(e => e.DefaultType2).HasColumnName("default_type2");

                entity.Property(e => e.DefaultType20).HasColumnName("default_type20");

                entity.Property(e => e.DefaultType3).HasColumnName("default_type3");

                entity.Property(e => e.DefaultType4).HasColumnName("default_type4");

                entity.Property(e => e.DefaultType5).HasColumnName("default_type5");

                entity.Property(e => e.DefaultType6).HasColumnName("default_type6");

                entity.Property(e => e.DefaultType7).HasColumnName("default_type7");

                entity.Property(e => e.DefaultType8).HasColumnName("default_type8");

                entity.Property(e => e.DefaultType9).HasColumnName("default_type9");

                entity.Property(e => e.DefaultVehicleType1).HasColumnName("default_vehicle_type1");

                entity.Property(e => e.DefaultVehicleType10).HasColumnName("default_vehicle_type10");

                entity.Property(e => e.DefaultVehicleType11).HasColumnName("default_vehicle_type11");

                entity.Property(e => e.DefaultVehicleType12).HasColumnName("default_vehicle_type12");

                entity.Property(e => e.DefaultVehicleType13).HasColumnName("default_vehicle_type13");

                entity.Property(e => e.DefaultVehicleType14).HasColumnName("default_vehicle_type14");

                entity.Property(e => e.DefaultVehicleType15).HasColumnName("default_vehicle_type15");

                entity.Property(e => e.DefaultVehicleType16).HasColumnName("default_vehicle_type16");

                entity.Property(e => e.DefaultVehicleType17).HasColumnName("default_vehicle_type17");

                entity.Property(e => e.DefaultVehicleType18).HasColumnName("default_vehicle_type18");

                entity.Property(e => e.DefaultVehicleType19).HasColumnName("default_vehicle_type19");

                entity.Property(e => e.DefaultVehicleType2).HasColumnName("default_vehicle_type2");

                entity.Property(e => e.DefaultVehicleType20).HasColumnName("default_vehicle_type20");

                entity.Property(e => e.DefaultVehicleType3).HasColumnName("default_vehicle_type3");

                entity.Property(e => e.DefaultVehicleType4).HasColumnName("default_vehicle_type4");

                entity.Property(e => e.DefaultVehicleType5).HasColumnName("default_vehicle_type5");

                entity.Property(e => e.DefaultVehicleType6).HasColumnName("default_vehicle_type6");

                entity.Property(e => e.DefaultVehicleType7).HasColumnName("default_vehicle_type7");

                entity.Property(e => e.DefaultVehicleType8).HasColumnName("default_vehicle_type8");

                entity.Property(e => e.DefaultVehicleType9).HasColumnName("default_vehicle_type9");

                entity.Property(e => e.InvoicingOnly)
                    .HasColumnName("invoicing_only")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PaymentText)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("payment_text");
            });

            modelBuilder.Entity<Permission>(entity =>
            {
                entity.HasKey(e => e.IdPermission);

                entity.ToTable("permission");

                entity.Property(e => e.IdPermission).HasColumnName("id_permission");

                entity.Property(e => e.PermissionDisplayText)
                    .IsUnicode(false)
                    .HasColumnName("permission_display_text");

                entity.Property(e => e.PermissionKey)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("permission_key");
            });

            modelBuilder.Entity<PermissionRoleTemplate>(entity =>
            {
                entity.HasKey(e => e.IdPermissionRoleTemplate);

                entity.ToTable("permission_role_template");

                entity.Property(e => e.IdPermissionRoleTemplate).HasColumnName("id_permission_role_template");

                entity.Property(e => e.IdPermission).HasColumnName("id_permission");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.PermissionValue).HasColumnName("permission_value");
            });

            modelBuilder.Entity<PermissionUser>(entity =>
            {
                entity.HasKey(e => e.IdUserPermission);

                entity.ToTable("permission_user");

                entity.Property(e => e.IdUserPermission).HasColumnName("id_user_permission");

                entity.Property(e => e.IdPermission).HasColumnName("id_permission");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.PermissionValue).HasColumnName("permission_value");
            });

            modelBuilder.Entity<Post>(entity =>
            {
                entity.HasKey(e => new { e.IdPost, e.IdCountry });

                entity.ToTable("Post");

                entity.Property(e => e.IdCountry).HasDefaultValueSql("((705))");

                entity.Property(e => e.PostName).HasMaxLength(150);
            });

            modelBuilder.Entity<PredefinedCompanyTarget>(entity =>
            {
                entity.HasKey(e => e.IdPredefinedCompanyTargets);

                entity.ToTable("predefined_company_targets");

                entity.Property(e => e.IdPredefinedCompanyTargets).HasColumnName("id_predefined_company_targets");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasColumnName("address");

                entity.Property(e => e.DestinationAddress).HasColumnName("destination_address");

                entity.Property(e => e.DestinationLat).HasColumnName("destination_lat");

                entity.Property(e => e.DestinationLon).HasColumnName("destination_lon");

                entity.Property(e => e.DispatchTime)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatch_time");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdPaymentType).HasColumnName("id_payment_type");

                entity.Property(e => e.IdServiceType).HasColumnName("id_service_type");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.NumberOfPassengers).HasColumnName("number_of_passengers");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");

                entity.Property(e => e.Remark).HasColumnName("remark");

                entity.Property(e => e.ReminderMin)
                    .HasColumnName("reminder_min")
                    .HasDefaultValueSql("((60))");

                entity.Property(e => e.Title)
                    .HasMaxLength(100)
                    .HasColumnName("title");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UsesPredefinedTimes)
                    .HasColumnName("uses_predefined_times")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.VehicleType1)
                    .HasColumnName("vehicle_type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType10)
                    .HasColumnName("vehicle_type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType11)
                    .HasColumnName("vehicle_type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType12)
                    .HasColumnName("vehicle_type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType13)
                    .HasColumnName("vehicle_type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType14)
                    .HasColumnName("vehicle_type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType15)
                    .HasColumnName("vehicle_type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType16)
                    .HasColumnName("vehicle_type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType17)
                    .HasColumnName("vehicle_type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType18)
                    .HasColumnName("vehicle_type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType19)
                    .HasColumnName("vehicle_type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType2)
                    .HasColumnName("vehicle_type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType20)
                    .HasColumnName("vehicle_type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType3)
                    .HasColumnName("vehicle_type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType4)
                    .HasColumnName("vehicle_type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType5)
                    .HasColumnName("vehicle_type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType6)
                    .HasColumnName("vehicle_type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType7)
                    .HasColumnName("vehicle_type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType8)
                    .HasColumnName("vehicle_type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleType9)
                    .HasColumnName("vehicle_type9")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<PredefinedDispatchTime>(entity =>
            {
                entity.HasKey(e => e.IdRecord)
                    .HasName("PK_PredefinedTargetsDispatchTimes");

                entity.ToTable("predefined_dispatch_times");

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.TimeValues)
                    .IsUnicode(false)
                    .HasColumnName("time_values");
            });

            modelBuilder.Entity<PredefinedDriverMessage>(entity =>
            {
                entity.HasKey(e => e.IdPredefinedDriverMessage);

                entity.ToTable("predefined_driver_messages");

                entity.Property(e => e.IdPredefinedDriverMessage).HasColumnName("id_predefined_driver_message");

                entity.Property(e => e.IdMessageType)
                    .HasColumnName("id_message_type")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Message)
                    .IsRequired()
                    .HasColumnName("message");
            });

            modelBuilder.Entity<Promotion>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("promotions");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.DefaultLocale)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("default_locale");

                entity.Property(e => e.IdPromotion)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_promotion");

                entity.Property(e => e.Sl)
                    .HasMaxLength(500)
                    .HasColumnName("sl");

                entity.Property(e => e.Sr)
                    .HasMaxLength(500)
                    .HasColumnName("sr");
            });

            modelBuilder.Entity<Property>(entity =>
            {
                entity.HasKey(e => e.IdPropertie);

                entity.ToTable("properties");

                entity.Property(e => e.IdPropertie).HasColumnName("id_propertie");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.Propertie)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("propertie");

                entity.Property(e => e.Sort).HasColumnName("sort");
            });

            modelBuilder.Entity<PushNotificationQueue>(entity =>
            {
                entity.HasKey(e => e.IdPushNotificationQueue)
                    .HasName("PK__push_not__17906B8A6498B3DB");

                entity.ToTable("push_notification_queue");

                entity.Property(e => e.IdPushNotificationQueue).HasColumnName("id_push_notification_queue");

                entity.Property(e => e.Data)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("data")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsProcessed).HasColumnName("is_processed");

                entity.Property(e => e.MessageText)
                    .IsRequired()
                    .HasColumnName("message_text");

                entity.Property(e => e.MessageTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("message_title");

                entity.Property(e => e.Type).HasColumnName("type");

                entity.Property(e => e.UnitId).HasColumnName("unit_id");
            });

            modelBuilder.Entity<QuickSearch>(entity =>
            {
                entity.HasKey(e => e.IdQuickSearch);

                entity.ToTable("quick_search");

                entity.Property(e => e.IdQuickSearch).HasColumnName("id_quick_search");

                entity.Property(e => e.FullSearchText)
                    .IsRequired()
                    .HasColumnName("full_search_text");

                entity.Property(e => e.QuickSearchText)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("quick_search_text");
            });

            modelBuilder.Entity<Remark>(entity =>
            {
                entity.HasKey(e => e.IdRemark);

                entity.ToTable("remark");

                entity.Property(e => e.IdRemark).HasColumnName("id_remark");

                entity.Property(e => e.IdHsMid).HasColumnName("id_hs_mid");

                entity.Property(e => e.Remarkname)
                    .HasMaxLength(50)
                    .HasColumnName("remarkname");
            });

            modelBuilder.Entity<RequestToTalk>(entity =>
            {
                entity.HasKey(e => e.IdRequestToTalk);

                entity.ToTable("request_to_talk");

                entity.HasIndex(e => e.Handled, "IX_request_to_talk_handled");

                entity.Property(e => e.IdRequestToTalk).HasColumnName("id_request_to_talk");

                entity.Property(e => e.Handled).HasColumnName("handled");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.HasKey(e => e.IdResource)
                    .HasName("PK_Resource");

                entity.ToTable("resource");

                entity.Property(e => e.IdResource).HasColumnName("id_resource");

                entity.Property(e => e.Note)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("note");

                entity.Property(e => e.ResourceKey)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("resource_key");

                entity.Property(e => e.ResourceValue)
                    .IsUnicode(false)
                    .HasColumnName("resource_value");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.IdRole);

                entity.ToTable("role");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.RoleTitle)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("role_title");
            });

            modelBuilder.Entity<Role1>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("roles");

                entity.Property(e => e.Role)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("role");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<RolePermissionTemplate>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("role_permission_template");

                entity.Property(e => e.AcceptedUsersStatistics).HasColumnName("accepted_users_statistics");

                entity.Property(e => e.ArchiveData).HasColumnName("archive_data");

                entity.Property(e => e.AutodispatchStatistics).HasColumnName("autodispatch_statistics");

                entity.Property(e => e.CallCenterStatistics).HasColumnName("call_center_statistics");

                entity.Property(e => e.CallStatistics).HasColumnName("call_statistics");

                entity.Property(e => e.ChangeFiscalPassword).HasColumnName("change_fiscal_password");

                entity.Property(e => e.Clients).HasColumnName("clients");

                entity.Property(e => e.CompanyOrder).HasColumnName("company_order");

                entity.Property(e => e.CompanyTripReport).HasColumnName("company_trip_report");

                entity.Property(e => e.CustomLocation).HasColumnName("custom_location");

                entity.Property(e => e.CustomersList).HasColumnName("customers_list");

                entity.Property(e => e.DriverPredictionStatistics).HasColumnName("driver_prediction_statistics");

                entity.Property(e => e.DriverStatistics).HasColumnName("driver_statistics");

                entity.Property(e => e.DriverStatisticsTm).HasColumnName("driver_statistics_tm");

                entity.Property(e => e.Drivers).HasColumnName("drivers");

                entity.Property(e => e.FuelPrices).HasColumnName("fuel_prices");

                entity.Property(e => e.FuelRefillAdm).HasColumnName("fuel_refill_adm");

                entity.Property(e => e.FuelRefillStatistics).HasColumnName("fuel_refill_statistics");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.LogonStatistics).HasColumnName("logon_statistics");

                entity.Property(e => e.ManuallyAssignedTargetsStatistics).HasColumnName("manually_assigned_targets_statistics");

                entity.Property(e => e.MobileUsers).HasColumnName("mobile_users");

                entity.Property(e => e.QuickSearch).HasColumnName("quick_search");

                entity.Property(e => e.Remarks).HasColumnName("remarks");

                entity.Property(e => e.Salaries).HasColumnName("salaries");

                entity.Property(e => e.Shifts).HasColumnName("shifts");

                entity.Property(e => e.Sms).HasColumnName("sms");

                entity.Property(e => e.Stand).HasColumnName("stand");

                entity.Property(e => e.Streets).HasColumnName("streets");

                entity.Property(e => e.Targets).HasColumnName("targets");

                entity.Property(e => e.Trip).HasColumnName("trip");

                entity.Property(e => e.UnitLogoffStatistics).HasColumnName("unit_logoff_statistics");

                entity.Property(e => e.Units).HasColumnName("units");

                entity.Property(e => e.Users).HasColumnName("users");

                entity.Property(e => e.Vehicle).HasColumnName("vehicle");

                entity.Property(e => e.VehicleStatistics).HasColumnName("vehicle_statistics");

                entity.Property(e => e.VehicleStatisticsTm).HasColumnName("vehicle_statistics_tm");

                entity.Property(e => e.ViberSettings).HasColumnName("viber_settings");

                entity.Property(e => e.Zones).HasColumnName("zones");
            });

            modelBuilder.Entity<Route>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Route");

                entity.Property(e => e.Latitude).HasColumnName("Latitude ");

                entity.Property(e => e.Timestamp)
                    .HasMaxLength(16)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Salary>(entity =>
            {
                entity.HasKey(e => e.IdSalary);

                entity.ToTable("salary");

                entity.Property(e => e.IdSalary).HasColumnName("id_salary");

                entity.Property(e => e.Created)
                    .HasColumnType("datetime")
                    .HasColumnName("created")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.From)
                    .HasColumnType("datetime")
                    .HasColumnName("from");

                entity.Property(e => e.To)
                    .HasColumnType("datetime")
                    .HasColumnName("to");

                entity.Property(e => e.Type).HasColumnName("type");
            });

            modelBuilder.Entity<SalaryDeduction>(entity =>
            {
                entity.HasKey(e => e.IdSalaryDeduction);

                entity.ToTable("salary_deduction");

                entity.Property(e => e.IdSalaryDeduction).HasColumnName("id_salary_deduction");

                entity.Property(e => e.DeductionAmmount).HasColumnName("deduction_ammount");

                entity.Property(e => e.DeductionAt)
                    .HasColumnType("datetime")
                    .HasColumnName("deduction_at");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<SalaryPayoutPercentage>(entity =>
            {
                entity.HasKey(e => e.IdSalaryPayoutPercentage);

                entity.ToTable("salary_payout_percentage");

                entity.Property(e => e.IdSalaryPayoutPercentage).HasColumnName("id_salary_payout_percentage");

                entity.Property(e => e.FareSumFrom).HasColumnName("fare_sum_from");

                entity.Property(e => e.FareSumTo).HasColumnName("fare_sum_to");

                entity.Property(e => e.PayoutPercentage).HasColumnName("payout_percentage");
            });

            modelBuilder.Entity<ServiceType>(entity =>
            {
                entity.HasKey(e => e.IdServiceType);

                entity.ToTable("service_types");

                entity.Property(e => e.IdServiceType).HasColumnName("id_service_type");

                entity.Property(e => e.ServiceName)
                    .HasMaxLength(50)
                    .HasColumnName("service_name");

                entity.Property(e => e.Type1)
                    .HasColumnName("type_1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type_10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type_11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type_12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type_13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type_14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type_15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type_16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type_17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type_18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type_19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type_2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type_20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type_3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type_4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type_5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type_6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type_7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type_8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type_9")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<ServiceUptime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("service_uptime");

                entity.Property(e => e.LastUpdateDt)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update_dt")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ServiceName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("service_name");
            });

            modelBuilder.Entity<Setting>(entity =>
            {
                entity.HasKey(e => e.IdSetting);

                entity.ToTable("setting");

                entity.HasIndex(e => e.SettingKey, "NCI_setting_retrieval")
                    .HasFillFactor(100);

                entity.Property(e => e.IdSetting).HasColumnName("id_setting");

                entity.Property(e => e.Comment)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("comment");

                entity.Property(e => e.DefaultValue).HasColumnName("default_value");

                entity.Property(e => e.SettingKey)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("setting_key");

                entity.Property(e => e.SettingValue)
                    .IsRequired()
                    .HasColumnName("setting_value");
            });

            modelBuilder.Entity<SettingAutodispatchLimitDayofweek>(entity =>
            {
                entity.HasKey(e => e.IdSettingAutodispatchLimitDayofweek);

                entity.ToTable("setting_autodispatch_limit_dayofweek");

                entity.Property(e => e.IdSettingAutodispatchLimitDayofweek).HasColumnName("id_setting_autodispatch_limit_dayofweek");

                entity.Property(e => e.AuctionArrivalTimeLimit).HasColumnName("auction_arrival_time_limit");

                entity.Property(e => e.AuctionDistanceLimit).HasColumnName("auction_distance_limit");

                entity.Property(e => e.AutodispatchArrivalTimeLimit).HasColumnName("autodispatch_arrival_time_limit");

                entity.Property(e => e.AutodispatchDistanceLimit).HasColumnName("autodispatch_distance_limit");

                entity.Property(e => e.DaysOfWeek)
                    .HasColumnName("days_of_week")
                    .HasDefaultValueSql("((127))");

                entity.Property(e => e.HourFrom).HasColumnName("hour_from");

                entity.Property(e => e.HourTo).HasColumnName("hour_to");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");
            });

            modelBuilder.Entity<SettingAutodispatchLimitTimeframe>(entity =>
            {
                entity.HasKey(e => e.IdSettingAutodispatchLimitTimeframe);

                entity.ToTable("setting_autodispatch_limit_timeframe");

                entity.Property(e => e.IdSettingAutodispatchLimitTimeframe).HasColumnName("id_setting_autodispatch_limit_timeframe");

                entity.Property(e => e.AuctionArrivalTimeLimit).HasColumnName("auction_arrival_time_limit");

                entity.Property(e => e.AuctionDistanceLimit).HasColumnName("auction_distance_limit");

                entity.Property(e => e.AutodispatchArrivalTimeLimit).HasColumnName("autodispatch_arrival_time_limit");

                entity.Property(e => e.AutodispatchDistanceLimit).HasColumnName("autodispatch_distance_limit");

                entity.Property(e => e.HourFrom).HasColumnName("hour_from");

                entity.Property(e => e.HourTo).HasColumnName("hour_to");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");
            });

            modelBuilder.Entity<SettingDispatchTypeHourTimeLimit>(entity =>
            {
                entity.HasKey(e => e.IdSettingDispatchTypeHourTimeLimits);

                entity.ToTable("setting_dispatch_type_hour_time_limits");

                entity.Property(e => e.IdSettingDispatchTypeHourTimeLimits).HasColumnName("id_setting_dispatch_type_hour_time_limits");

                entity.Property(e => e.DispatchType).HasColumnName("dispatch_type");

                entity.Property(e => e.DriverPickupMaximumMinutes).HasColumnName("driver_pickup_maximum_minutes");

                entity.Property(e => e.HourFrom).HasColumnName("hour_from");

                entity.Property(e => e.HourTo).HasColumnName("hour_to");
            });

            modelBuilder.Entity<SettingDriverApp>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("setting_driver_app");

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("data_type");

                entity.Property(e => e.Note).HasColumnName("note");

                entity.Property(e => e.SettingKey)
                    .IsRequired()
                    .HasColumnName("setting_key");

                entity.Property(e => e.SettingValue).HasColumnName("setting_value");
            });

            modelBuilder.Entity<SettingWordDocument>(entity =>
            {
                entity.HasKey(e => e.IdDocument)
                    .HasName("PK__setting___D5F2A16F15A5FF8A");

                entity.ToTable("setting_word_documents");

                entity.Property(e => e.IdDocument).HasColumnName("id_document");

                entity.Property(e => e.Path).HasColumnName("path");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<Shift>(entity =>
            {
                entity.HasKey(e => e.IdShift);

                entity.ToTable("shift");

                entity.HasIndex(e => new { e.DeviceId, e.TmShiftNumber, e.TmCarNumber, e.TmDriverNumber, e.TmShiftStart, e.TmShiftEnd, e.TmTrips, e.TmWaitingTimeMinutes }, "NonClusteredIndex-20160427-154531");

                entity.Property(e => e.IdShift).HasColumnName("id_shift");

                entity.Property(e => e.CalculatedStartingDistanceHired)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("calculated_starting_distance_hired");

                entity.Property(e => e.CalculatedStartingDistanceTotal)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("calculated_starting_distance_total");

                entity.Property(e => e.CalculatedStartingFareAmmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("calculated_starting_fare_ammount");

                entity.Property(e => e.CalculatedStartingTrips).HasColumnName("calculated_starting_trips");

                entity.Property(e => e.Confirmed).HasColumnName("confirmed");

                entity.Property(e => e.DeviceId)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("device_id");

                entity.Property(e => e.FullSalaryPercentage)
                    .HasColumnType("decimal(8, 4)")
                    .HasColumnName("full_salary_percentage");

                entity.Property(e => e.IdFullSalary).HasColumnName("id_full_salary");

                entity.Property(e => e.IdPartialSalary).HasColumnName("id_partial_salary");

                entity.Property(e => e.IdTaximeter).HasColumnName("id_taximeter");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TmCarNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("tm_car_number");

                entity.Property(e => e.TmCreditCardAmmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("tm_credit_card_ammount");

                entity.Property(e => e.TmDistanceBlack)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_black");

                entity.Property(e => e.TmDistanceDaily)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_daily");

                entity.Property(e => e.TmDistanceForhire)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_forhire");

                entity.Property(e => e.TmDistanceHired)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_hired");

                entity.Property(e => e.TmDistanceTariff1)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_tariff1");

                entity.Property(e => e.TmDistanceTariff2)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_tariff2");

                entity.Property(e => e.TmDistanceTotal)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_distance_total");

                entity.Property(e => e.TmDriverNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("tm_driver_number");

                entity.Property(e => e.TmEarnAvg)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("tm_earn_avg");

                entity.Property(e => e.TmExtraCharges)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("tm_extra_charges");

                entity.Property(e => e.TmFareAmmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("tm_fare_ammount");

                entity.Property(e => e.TmShiftEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("tm_shift_end");

                entity.Property(e => e.TmShiftNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("tm_shift_number");

                entity.Property(e => e.TmShiftStart)
                    .HasColumnType("datetime")
                    .HasColumnName("tm_shift_start");

                entity.Property(e => e.TmTaxAmmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("tm_tax_ammount");

                entity.Property(e => e.TmTipsAmmount)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("tm_tips_ammount");

                entity.Property(e => e.TmTrips).HasColumnName("tm_trips");

                entity.Property(e => e.TmWaitingTimeMinutes).HasColumnName("tm_waiting_time_minutes");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<ShiftReportDriver>(entity =>
            {
                entity.HasKey(e => e.IdShiftReportDriver);

                entity.ToTable("shift_report_driver");

                entity.Property(e => e.IdShiftReportDriver).HasColumnName("id_shift_report_driver");

                entity.Property(e => e.AuctionsCount).HasColumnName("auctions_count");

                entity.Property(e => e.CancelledJobsCount).HasColumnName("cancelled_jobs_count");

                entity.Property(e => e.DispatchedJobsCount).HasColumnName("dispatched_jobs_count");

                entity.Property(e => e.DoneJobsCount).HasColumnName("done_jobs_count");

                entity.Property(e => e.DtShiftEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_shift_end");

                entity.Property(e => e.DtShiftStart)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_shift_start");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.LateJobsCount).HasColumnName("late_jobs_count");

                entity.Property(e => e.MaxSpeed).HasColumnName("max_speed");

                entity.Property(e => e.PurchaseOrderCount).HasColumnName("purchase_order_count");

                entity.Property(e => e.RefusedJobsCount).HasColumnName("refused_jobs_count");

                entity.Property(e => e.StreetPickupCount).HasColumnName("street_pickup_count");

                entity.Property(e => e.TakenDistanceTravelled).HasColumnName("taken_distance_travelled");

                entity.Property(e => e.TaximeterEndKm).HasColumnName("taximeter_end_km");

                entity.Property(e => e.TaximeterStartKm).HasColumnName("taximeter_start_km");

                entity.Property(e => e.TotalDistanceTravelled).HasColumnName("total_distance_travelled");

                entity.Property(e => e.TotalPaid).HasColumnName("total_paid");

                entity.Property(e => e.TotalPurchaseOrder).HasColumnName("total_purchase_order");

                entity.HasOne(d => d.IdDriverNavigation)
                    .WithMany(p => p.ShiftReportDrivers)
                    .HasForeignKey(d => d.IdDriver)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_id_driver_shift_report_driver");
            });

            modelBuilder.Entity<ShuttleSchedule>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("shuttle_schedule");

                entity.Property(e => e.BorderColor)
                    .HasMaxLength(250)
                    .HasColumnName("border_color");

                entity.Property(e => e.EndDate)
                    .HasColumnType("datetime")
                    .HasColumnName("end_date");

                entity.Property(e => e.EndLocation)
                    .HasMaxLength(250)
                    .HasColumnName("end_location");

                entity.Property(e => e.IdShuttleSchedule)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_shuttle_schedule");

                entity.Property(e => e.IdShuttleScheduleRelation).HasColumnName("id_shuttle_schedule_relation");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.StartDate)
                    .HasColumnType("datetime")
                    .HasColumnName("start_date");

                entity.Property(e => e.StartLocation)
                    .HasMaxLength(250)
                    .HasColumnName("start_location");

                entity.Property(e => e.Title)
                    .HasMaxLength(100)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<ShuttleScheduleRelation>(entity =>
            {
                entity.HasKey(e => e.IdShuttleScheduleRelation)
                    .HasName("PK__shuttle___990C50ED9D066622");

                entity.ToTable("shuttle_schedule_relation");

                entity.Property(e => e.IdShuttleScheduleRelation).HasColumnName("id_shuttle_schedule_relation");

                entity.Property(e => e.EndStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("end_street");

                entity.Property(e => e.Relation)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("relation");

                entity.Property(e => e.StartStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("start_street");
            });

            modelBuilder.Entity<ShuttleScheduleTarget>(entity =>
            {
                entity.HasKey(e => e.IdShuttleScheduleTargets)
                    .HasName("PK__shuttle___BFE77717943DD875");

                entity.ToTable("shuttle_schedule_targets");

                entity.Property(e => e.IdShuttleScheduleTargets).HasColumnName("id_shuttle_schedule_targets");

                entity.Property(e => e.IdShuttleSchedule).HasColumnName("id_shuttle_schedule");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");
            });

            modelBuilder.Entity<Size>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("sizes");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Value).HasColumnName("value");
            });

            modelBuilder.Entity<Sm>(entity =>
            {
                entity.HasKey(e => e.IdSms);

                entity.ToTable("sms");

                entity.HasIndex(e => e.SentDate, "IX_sms_sent_date_99DE5");

                entity.HasIndex(e => new { e.UnitId, e.IsSent }, "NonClusteredIndex-20150605-160108");

                entity.HasIndex(e => new { e.IsSent, e.SmsType }, "NonClusteredIndex-20171010-144845");

                entity.Property(e => e.IdSms).HasColumnName("id_sms");

                entity.Property(e => e.ClientId).HasColumnName("client_id");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");

                entity.Property(e => e.IsSent).HasColumnName("is_sent");

                entity.Property(e => e.Message).HasColumnName("message");

                entity.Property(e => e.Remark)
                    .HasMaxLength(50)
                    .HasColumnName("remark");

                entity.Property(e => e.SentDate)
                    .HasColumnType("datetime")
                    .HasColumnName("sent_date");

                entity.Property(e => e.SmsType)
                    .HasColumnName("sms_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<SmsGsmInterface>(entity =>
            {
                entity.HasKey(e => e.IdSmsGsmInterface);

                entity.ToTable("sms_gsm_interface");

                entity.Property(e => e.IdSmsGsmInterface).HasColumnName("id_sms_gsm_interface");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsSent).HasColumnName("is_sent");

                entity.Property(e => e.Message)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("message");

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("phone");

                entity.Property(e => e.SenderImei)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("sender_imei");

                entity.Property(e => e.SenderPhoneNumber)
                    .HasMaxLength(50)
                    .HasColumnName("sender_phone_number");
            });

            modelBuilder.Entity<So>(entity =>
            {
                entity.HasKey(e => e.IdSos);

                entity.ToTable("sos");

                entity.HasIndex(e => e.Handled, "NonClusteredIndex-20161208-204243");

                entity.Property(e => e.IdSos).HasColumnName("id_sos");

                entity.Property(e => e.Handled).HasColumnName("handled");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UnitNotified).HasColumnName("unit_notified");
            });

            modelBuilder.Entity<SoftwareTaximeterTargetDatum>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("software_taximeter_target_data");

                entity.HasIndex(e => e.TargetId, "NCI_TargetIdWithData-20220221");

                entity.Property(e => e.DistanceTraveled).HasColumnName("distance_traveled");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id");

                entity.Property(e => e.LastUpdated)
                    .HasColumnName("last_updated")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TargetId).HasColumnName("target_id");

                entity.Property(e => e.TariffId).HasColumnName("tariff_id");

                entity.Property(e => e.TaxiFare).HasColumnName("taxi_fare");

                entity.Property(e => e.WaitingTimeMilliseconds).HasColumnName("waiting_time_milliseconds");
            });

            modelBuilder.Entity<Stand>(entity =>
            {
                entity.HasKey(e => e.IdStand);

                entity.ToTable("stand");

                entity.HasIndex(e => e.IdStand, "NonClusteredIndex-GetCustomLocationList");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdBackupStand).HasColumnName("id_backup_stand");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.OrderValue).HasColumnName("order_value");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<StandLocation>(entity =>
            {
                entity.HasKey(e => e.IdStandLocation);

                entity.ToTable("stand_location");

                entity.HasIndex(e => e.IdStand, "NonClusteredIndex-20160907-124500");

                entity.Property(e => e.IdStandLocation).HasColumnName("id_stand_location");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");
            });

            modelBuilder.Entity<StandLocationPolygon>(entity =>
            {
                entity.HasKey(e => e.IdStandLocationPolygon);

                entity.ToTable("stand_location_polygon");

                entity.Property(e => e.IdStandLocationPolygon).HasColumnName("id_stand_location_polygon");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.Polygon)
                    .IsUnicode(false)
                    .HasColumnName("polygon");
            });

            modelBuilder.Entity<StandPolygon>(entity =>
            {
                entity.HasKey(e => e.IdStandPolygon);

                entity.ToTable("stand_polygon");

                entity.HasIndex(e => e.IdStand, "IX_stand_polygon_id_stand_8496C");

                entity.Property(e => e.IdStandPolygon).HasColumnName("id_stand_polygon");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.Polygon)
                    .IsUnicode(false)
                    .HasColumnName("polygon");
            });

            modelBuilder.Entity<StandRange>(entity =>
            {
                entity.HasKey(e => e.IdStandRange);

                entity.ToTable("stand_range");

                entity.Property(e => e.IdStandRange).HasColumnName("id_stand_range");

                entity.Property(e => e.EvenMax).HasColumnName("even_max");

                entity.Property(e => e.EvenMaxLabel)
                    .HasMaxLength(1)
                    .HasColumnName("even_max_label");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdStreet).HasColumnName("id_street");

                entity.Property(e => e.OddMax).HasColumnName("odd_max");

                entity.Property(e => e.OddMaxLabel)
                    .HasMaxLength(1)
                    .HasColumnName("odd_max_label");
            });

            modelBuilder.Entity<StandUnitLogin>(entity =>
            {
                entity.HasKey(e => e.IdStandUnitLogin);

                entity.ToTable("stand_unit_login");

                entity.Property(e => e.IdStandUnitLogin).HasColumnName("id_stand_unit_login");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<StatsTargetDay>(entity =>
            {
                entity.HasKey(e => e.IdStatsTargetDay)
                    .HasName("PK_STATS_TARGET_DAY");

                entity.ToTable("stats_target_day");

                entity.Property(e => e.IdStatsTargetDay).HasColumnName("id_stats_target_day");

                entity.Property(e => e.All).HasColumnName("all");

                entity.Property(e => e.AvgDispatchatTime)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("avg_dispatchat_time");

                entity.Property(e => e.CompanyOrders).HasColumnName("company_orders");

                entity.Property(e => e.CustomerApp).HasColumnName("customer_app");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.NoCustomer).HasColumnName("no_customer");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.Successful).HasColumnName("successful");

                entity.Property(e => e.TotalFare)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("total_fare");
            });

            modelBuilder.Entity<StatsTargetMonth>(entity =>
            {
                entity.HasKey(e => e.IdStatsTargetMonth)
                    .HasName("PK_STATS_TARGET_MONTH");

                entity.ToTable("stats_target_month");

                entity.Property(e => e.IdStatsTargetMonth).HasColumnName("id_stats_target_month");

                entity.Property(e => e.All).HasColumnName("all");

                entity.Property(e => e.AvgDispatchatTime)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("avg_dispatchat_time");

                entity.Property(e => e.CompanyOrders).HasColumnName("company_orders");

                entity.Property(e => e.CustomerApp).HasColumnName("customer_app");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.MonthNum).HasColumnName("month_num");

                entity.Property(e => e.NoCustomer).HasColumnName("no_customer");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.Successful).HasColumnName("successful");

                entity.Property(e => e.TotalFare)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("total_fare");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<StatsTargetQuarter>(entity =>
            {
                entity.HasKey(e => e.IdStatsTargetQuarter)
                    .HasName("PK_STATS_TARGET_QUARTER_ID");

                entity.ToTable("stats_target_quarter");

                entity.Property(e => e.IdStatsTargetQuarter).HasColumnName("id_stats_target_quarter");

                entity.Property(e => e.All).HasColumnName("all");

                entity.Property(e => e.AvgDispatchatTime)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("avg_dispatchat_time");

                entity.Property(e => e.CompanyOrders).HasColumnName("company_orders");

                entity.Property(e => e.CustomerApp).HasColumnName("customer_app");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.NoCustomer).HasColumnName("no_customer");

                entity.Property(e => e.QuarterNum).HasColumnName("quarter_num");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.Successful).HasColumnName("successful");

                entity.Property(e => e.TotalFare)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("total_fare");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<StatsTargetWeek>(entity =>
            {
                entity.HasKey(e => e.IdStatsTargetWeek)
                    .HasName("PK_STATS_TARGET_WEKK");

                entity.ToTable("stats_target_week");

                entity.Property(e => e.IdStatsTargetWeek).HasColumnName("id_stats_target_week");

                entity.Property(e => e.All).HasColumnName("all");

                entity.Property(e => e.AvgDispatchatTime)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("avg_dispatchat_time");

                entity.Property(e => e.CompanyOrders).HasColumnName("company_orders");

                entity.Property(e => e.CustomerApp).HasColumnName("customer_app");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.NoCustomer).HasColumnName("no_customer");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.Successful).HasColumnName("successful");

                entity.Property(e => e.TotalFare)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("total_fare");

                entity.Property(e => e.WeekNum).HasColumnName("week_num");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<StatsTargetYear>(entity =>
            {
                entity.HasKey(e => e.IdStatsTargetYear)
                    .HasName("PK_STATS_TARGET_YEAR_ID");

                entity.ToTable("stats_target_year");

                entity.Property(e => e.IdStatsTargetYear).HasColumnName("id_stats_target_year");

                entity.Property(e => e.All).HasColumnName("all");

                entity.Property(e => e.AvgDispatchatTime)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("avg_dispatchat_time");

                entity.Property(e => e.CompanyOrders).HasColumnName("company_orders");

                entity.Property(e => e.CustomerApp).HasColumnName("customer_app");

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.NoCustomer).HasColumnName("no_customer");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.Successful).HasColumnName("successful");

                entity.Property(e => e.TotalFare)
                    .HasColumnType("decimal(12, 3)")
                    .HasColumnName("total_fare");

                entity.Property(e => e.Year).HasColumnName("year");
            });

            modelBuilder.Entity<Street>(entity =>
            {
                entity.HasKey(e => e.IdStreet);

                entity.ToTable("street");

                entity.HasIndex(e => e.SecTitle, "IX_street_sec_title_5C4D3");

                entity.Property(e => e.IdStreet).HasColumnName("id_street");

                entity.Property(e => e.City)
                    .HasMaxLength(100)
                    .HasColumnName("city");

                entity.Property(e => e.District)
                    .HasMaxLength(100)
                    .HasColumnName("district");

                entity.Property(e => e.SecCity)
                    .HasMaxLength(100)
                    .HasColumnName("sec_city");

                entity.Property(e => e.SecDistrict)
                    .HasMaxLength(100)
                    .HasColumnName("sec_district");

                entity.Property(e => e.SecTitle)
                    .HasMaxLength(500)
                    .HasColumnName("sec_title");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<SystemNotification>(entity =>
            {
                entity.HasKey(e => e.IdSystemNotification);

                entity.ToTable("system_notification");

                entity.Property(e => e.IdSystemNotification).HasColumnName("id_system_notification");

                entity.Property(e => e.AddedDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("added_datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NotificationText)
                    .IsRequired()
                    .HasColumnName("notification_text");
            });

            modelBuilder.Entity<Target>(entity =>
            {
                entity.HasKey(e => e.IdTarget);

                entity.ToTable("target");

                entity.HasIndex(e => new { e.Phone, e.Lat, e.Lon }, "IX_NC_phone")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Isdeleted, e.AssignedIdDriver, e.Status }, "IX_target_isdeleted_assigned_id_driver_status_FBE62");

                entity.HasIndex(e => new { e.UnitId, e.DispatchType, e.Status, e.IdStand }, "IX_target_unit_id_dispatch_type_status_id_stand_5D680");

                entity.HasIndex(e => new { e.UnitId, e.IdStand, e.Status }, "NCI_AutodispatchRetrieval");

                entity.HasIndex(e => new { e.Isdeleted, e.StreetPickup, e.Inserted }, "NCI_statistics");

                entity.HasIndex(e => e.Status, "NCI_target_history_retrieval")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Status, e.UnitId, e.Isdeleted }, "NonClusteredIndex-20160111-140848")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Status, e.Isdeleted, e.PurchaseOrder, e.DelayedPayment }, "NonClusteredIndex-20160111-193113");

                entity.HasIndex(e => new { e.Isdeleted, e.Dispatchnow }, "NonClusteredIndex-20160111-193156");

                entity.HasIndex(e => new { e.UnitId, e.NotifyUnitPending }, "NonClusteredIndex-20160418-094016");

                entity.HasIndex(e => new { e.Status, e.Isdeleted, e.IdCompany, e.PurchaseOrder, e.DelayedPayment }, "NonClusteredIndex-20160427-154305");

                entity.HasIndex(e => e.IdClient, "NonClusteredIndex-20160829-102147")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.Isdeleted, e.Dispatchnow }, "NonClusteredIndex-isdeleted");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.AssignedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("assigned_at");

                entity.Property(e => e.AssignedIdDriver).HasColumnName("assigned_id_driver");

                entity.Property(e => e.AssignedIdUnit).HasColumnName("assigned_id_unit");

                entity.Property(e => e.AssignedIdVehicle).HasColumnName("assigned_id_vehicle");

                entity.Property(e => e.Autodispatch)
                    .HasColumnName("autodispatch")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Autodispatched)
                    .HasColumnName("autodispatched")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.BillingCenter)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.BillingCenter1)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("billing_center");

                entity.Property(e => e.CancellationReason)
                    .HasColumnName("cancellation_reason")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.CardNumber)
                    .HasMaxLength(30)
                    .HasColumnName("card_number");

                entity.Property(e => e.CompanyOrderNote)
                    .HasMaxLength(200)
                    .HasColumnName("company_order_note");

                entity.Property(e => e.CpuFinalDestinationTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_final_destination_time");

                entity.Property(e => e.CpuFirstTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_first_time");

                entity.Property(e => e.CpuPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_pickup_time");

                entity.Property(e => e.Customer)
                    .HasMaxLength(150)
                    .HasColumnName("customer");

                entity.Property(e => e.DelayedPayment)
                    .HasColumnName("delayed_payment")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Destination)
                    .HasMaxLength(250)
                    .HasColumnName("destination");

                entity.Property(e => e.DestinationLat).HasColumnName("destination_lat");

                entity.Property(e => e.DestinationLon).HasColumnName("destination_lon");

                entity.Property(e => e.DispatchSubtype).HasColumnName("dispatch_subtype");

                entity.Property(e => e.DispatchTriggered)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatch_triggered");

                entity.Property(e => e.DispatchType)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("dispatch_type");

                entity.Property(e => e.Dispatchat)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatchat");

                entity.Property(e => e.Dispatchnow).HasColumnName("dispatchnow");

                entity.Property(e => e.Distance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("distance");

                entity.Property(e => e.DriverAtLocation)
                    .HasColumnName("driver_at_location")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.DriverDelay).HasColumnName("driver_delay");

                entity.Property(e => e.DriverPickupMin)
                    .HasColumnName("driver_pickup_min")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DriverPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("driver_pickup_time");

                entity.Property(e => e.DropOffTime)
                    .HasColumnType("datetime")
                    .HasColumnName("drop_off_time");

                entity.Property(e => e.DtPreorder)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_preorder");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.GDistance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_distance");

                entity.Property(e => e.GTimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_time_of_arrival");

                entity.Property(e => e.HsMid).HasColumnName("hs_mid");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.IdCompany)
                    .HasColumnName("id_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdCompanyCredential).HasColumnName("id_company_credential");

                entity.Property(e => e.IdDispatcher).HasColumnName("id_dispatcher");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName("id_internal_department_used");

                entity.Property(e => e.IdOperator).HasColumnName("id_operator");

                entity.Property(e => e.IdPaymentType).HasColumnName("id_payment_type");

                entity.Property(e => e.IdServiceType)
                    .HasColumnName("id_service_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lbl)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("lbl");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.ManualAssignReason)
                    .HasMaxLength(200)
                    .HasColumnName("manual_assign_reason");

                entity.Property(e => e.NoCustomerRequest)
                    .HasColumnName("no_customer_request")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.NotifyUnitPending).HasColumnName("notify_unit_pending");

                entity.Property(e => e.Num)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("num");

                entity.Property(e => e.OrderByDriver)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("order_by_driver")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OrdererName)
                    .HasMaxLength(150)
                    .HasColumnName("orderer_name");

                entity.Property(e => e.OrdererNote)
                    .HasMaxLength(250)
                    .HasColumnName("orderer_note");

                entity.Property(e => e.OrientLat)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lat")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.OrientLon)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lon")
                    .HasDefaultValueSql("('E')");

                entity.Property(e => e.Paid).HasColumnName("paid");

                entity.Property(e => e.Passenger)
                    .HasMaxLength(150)
                    .HasColumnName("passenger");

                entity.Property(e => e.PassengerPhone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("passenger_phone");

                entity.Property(e => e.Phone)
                    .HasMaxLength(55)
                    .IsUnicode(false)
                    .HasColumnName("phone")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.PhoneLine)
                    .HasColumnName("phone_line")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Pickup)
                    .HasColumnType("datetime")
                    .HasColumnName("pickup");

                entity.Property(e => e.Preorder).HasColumnName("preorder");

                entity.Property(e => e.PrimaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("primary_distance_request_time");

                entity.Property(e => e.PurchaseOrder)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("purchase_order")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PurchaseQuantity)
                    .HasMaxLength(20)
                    .HasColumnName("purchase_quantity")
                    .HasDefaultValueSql("('1')");

                entity.Property(e => e.ReceiptedInvoices).HasColumnName("receipted_invoices");

                entity.Property(e => e.Remark)
                    .HasMaxLength(250)
                    .HasColumnName("remark");

                entity.Property(e => e.RemindAt)
                    .HasColumnType("datetime")
                    .HasColumnName("remind_at");

                entity.Property(e => e.RequesteTime)
                    .HasColumnType("datetime")
                    .HasColumnName("requeste_time");

                entity.Property(e => e.SecondaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("secondary_distance_request_time");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.Street).HasColumnName("street");

                entity.Property(e => e.StreetPickup)
                    .HasColumnName("street_pickup")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TaxiNumber)
                    .HasColumnName("taxi_number")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("time_of_arrival");

                entity.Property(e => e.TripRemark)
                    .HasMaxLength(250)
                    .HasColumnName("trip_remark");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TargetAppliedDiscount>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_applied_discount");

                entity.Property(e => e.DiscountedPrice)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("discounted_price");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTargetDiscount)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_target_discount");

                entity.Property(e => e.PaymentDiscountTypeId).HasColumnName("payment_discount_type_id");
            });

            modelBuilder.Entity<TargetAppliedVoucher>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_applied_voucher");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.VoucherData)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("voucher_data");
            });

            modelBuilder.Entity<TargetAssignAllowedDriver>(entity =>
            {
                entity.HasKey(e => e.IdTargetAssignAllowedDriver)
                    .HasName("PK_target_assign_allowed_unit");

                entity.ToTable("target_assign_allowed_driver");

                entity.Property(e => e.IdTargetAssignAllowedDriver).HasColumnName("id_target_assign_allowed_driver");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");
            });

            modelBuilder.Entity<TargetAssignDetail>(entity =>
            {
                entity.HasKey(e => e.IdTargetAssignDetail);

                entity.ToTable("target_assign_detail");

                entity.HasIndex(e => e.Assigned, "IX_target_assign_detail_assigned_42FCA")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-20191118-084752")
                    .HasFillFactor(100);

                entity.Property(e => e.IdTargetAssignDetail).HasColumnName("id_target_assign_detail");

                entity.Property(e => e.Assigned)
                    .HasColumnType("datetime")
                    .HasColumnName("assigned")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DispatchType)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("dispatch_type");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdLicitation)
                    .HasColumnName("id_licitation")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdUnitSnapshot).HasColumnName("id_unit_snapshot");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<TargetCancelReason>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_cancel_reason");

                entity.Property(e => e.CancelationDatetime)
                    .HasColumnName("cancelation_datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdCancelationReason).HasColumnName("id_cancelation_reason");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTargetCancelReason)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_target_cancel_reason");
            });

            modelBuilder.Entity<TargetCancelTime>(entity =>
            {
                entity.HasKey(e => e.IdTargetCancelTime)
                    .HasName("PK_target_cancell_time");

                entity.ToTable("target_cancel_time");

                entity.Property(e => e.IdTargetCancelTime).HasColumnName("id_target_cancel_time");

                entity.Property(e => e.HourFrom).HasColumnName("hour_from");

                entity.Property(e => e.HourTo).HasColumnName("hour_to");

                entity.Property(e => e.TargetCancelTime1).HasColumnName("target_cancel_time");
            });

            modelBuilder.Entity<TargetCategory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_categories");

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("category_name");

                entity.Property(e => e.CategoryNumber).HasColumnName("category_number");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id");
            });

            modelBuilder.Entity<TargetDistance>(entity =>
            {
                entity.HasKey(e => e.IdRecord);

                entity.ToTable("target_distance");

                entity.HasIndex(e => e.IdTarget, "IX_target_distance_id_target");

                entity.HasIndex(e => new { e.IdTarget, e.DeactivationTime }, "IX_target_distance_id_target_deactivation_time_1AC77");

                entity.HasIndex(e => e.UnitId, "IX_target_distance_unit_id");

                entity.HasIndex(e => e.CalculationTime, "NonClusteredIndex-20160425-220639");

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.AirDistance)
                    .HasColumnName("air_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CalculationTime)
                    .HasColumnType("datetime")
                    .HasColumnName("calculation_time")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CurrentPath)
                    .HasMaxLength(250)
                    .HasColumnName("current_path");

                entity.Property(e => e.DeactivationTime)
                    .HasColumnType("datetime")
                    .HasColumnName("deactivation_time");

                entity.Property(e => e.GArrivalTime)
                    .HasColumnName("g_arrival_time")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.GDistance)
                    .HasColumnName("g_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.HereArrivalTime)
                    .HasColumnName("here_arrival_time")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.HereDistance)
                    .HasColumnName("here_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.MqArrivalTime).HasColumnName("mq_arrival_time");

                entity.Property(e => e.MqDistance).HasColumnName("mq_distance");

                entity.Property(e => e.OsmArrivalTime)
                    .HasColumnName("osm_arrival_time")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OsmDistance)
                    .HasColumnName("osm_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.RouteArrivalTime).HasColumnName("route_arrival_time");

                entity.Property(e => e.RouteDistance).HasColumnName("route_distance");

                entity.Property(e => e.RouteProvider).HasColumnName("route_provider");

                entity.Property(e => e.RouteUnoccupiedArrivalTime).HasColumnName("route_unoccupied_arrival_time");

                entity.Property(e => e.RouteUnoccupiedDistance).HasColumnName("route_unoccupied_distance");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TargetDriverAtLocationDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_driver_at_location_details");

                entity.HasIndex(e => e.IdTarget, "IX_target_driver_at_location_details_id_target_F4EF3");

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-DriverAtLocationTimeByIdTarget");

                entity.Property(e => e.DriverAtLocationTime).HasColumnName("driver_at_location_time");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTargetDriverAtLocationDetails)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_target_driver_at_location_details");

                entity.Property(e => e.LocationLatitude).HasColumnName("location_latitude");

                entity.Property(e => e.LocationLongitude).HasColumnName("location_longitude");
            });

            modelBuilder.Entity<TargetEstimatedPrice>(entity =>
            {
                entity.HasKey(e => e.IdTarget);

                entity.ToTable("target_estimated_price");

                entity.Property(e => e.IdTarget)
                    .ValueGeneratedNever()
                    .HasColumnName("id_target");

                entity.Property(e => e.EstimatedPrice)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("estimated_price");
            });

            modelBuilder.Entity<TargetHandledRequest>(entity =>
            {
                entity.HasKey(e => e.IdTargetHandledRequest);

                entity.ToTable("target_handled_request");

                entity.Property(e => e.IdTargetHandledRequest).HasColumnName("id_target_handled_request");

                entity.Property(e => e.Approved).HasColumnName("approved");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.ProcessedBy).HasColumnName("processed_by");

                entity.Property(e => e.ProcessedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("processed_dt");

                entity.Property(e => e.RequestDt)
                    .HasColumnType("datetime")
                    .HasColumnName("request_dt");

                entity.Property(e => e.RequestProcessed).HasColumnName("request_processed");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TargetHistory>(entity =>
            {
                entity.HasKey(e => e.IdTarget)
                    .HasName("PK_target_his");

                entity.ToTable("target_history");

                entity.Property(e => e.IdTarget)
                    .ValueGeneratedNever()
                    .HasColumnName("id_target");

                entity.Property(e => e.AssignedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("assigned_at");

                entity.Property(e => e.AssignedIdDriver).HasColumnName("assigned_id_driver");

                entity.Property(e => e.AssignedIdUnit).HasColumnName("assigned_id_unit");

                entity.Property(e => e.AssignedIdVehicle).HasColumnName("assigned_id_vehicle");

                entity.Property(e => e.Autodispatch)
                    .HasColumnName("autodispatch")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Autodispatched)
                    .HasColumnName("autodispatched")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.BillingCenter)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.BillingCenter1)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("billing_center");

                entity.Property(e => e.CancellationReason)
                    .HasColumnName("cancellation_reason")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.CardNumber)
                    .HasMaxLength(30)
                    .HasColumnName("card_number");

                entity.Property(e => e.CompanyOrderNote)
                    .HasMaxLength(200)
                    .HasColumnName("company_order_note");

                entity.Property(e => e.CpuFinalDestinationTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_final_destination_time");

                entity.Property(e => e.CpuFirstTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_first_time");

                entity.Property(e => e.CpuPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_pickup_time");

                entity.Property(e => e.Customer)
                    .HasMaxLength(150)
                    .HasColumnName("customer");

                entity.Property(e => e.DelayedPayment)
                    .HasColumnName("delayed_payment")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Destination)
                    .HasMaxLength(250)
                    .HasColumnName("destination");

                entity.Property(e => e.DestinationLat).HasColumnName("destination_lat");

                entity.Property(e => e.DestinationLon).HasColumnName("destination_lon");

                entity.Property(e => e.DispatchSubtype).HasColumnName("dispatch_subtype");

                entity.Property(e => e.DispatchTriggered)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatch_triggered");

                entity.Property(e => e.DispatchType)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("dispatch_type");

                entity.Property(e => e.Dispatchat)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatchat");

                entity.Property(e => e.Dispatchnow).HasColumnName("dispatchnow");

                entity.Property(e => e.Distance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("distance");

                entity.Property(e => e.DriverAtLocation)
                    .HasColumnName("driver_at_location")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.DriverDelay).HasColumnName("driver_delay");

                entity.Property(e => e.DriverPickupMin)
                    .HasColumnName("driver_pickup_min")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DriverPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("driver_pickup_time");

                entity.Property(e => e.DropOffTime)
                    .HasColumnType("datetime")
                    .HasColumnName("drop_off_time");

                entity.Property(e => e.DtPreorder)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_preorder");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.GDistance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_distance");

                entity.Property(e => e.GTimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_time_of_arrival");

                entity.Property(e => e.HsMid).HasColumnName("hs_mid");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.IdCompany)
                    .HasColumnName("id_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdCompanyCredential).HasColumnName("id_company_credential");

                entity.Property(e => e.IdDispatcher).HasColumnName("id_dispatcher");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName("id_internal_department_used");

                entity.Property(e => e.IdOperator).HasColumnName("id_operator");

                entity.Property(e => e.IdPaymentType).HasColumnName("id_payment_type");

                entity.Property(e => e.IdServiceType).HasColumnName("id_service_type");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lbl)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("lbl");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.ManualAssignReason)
                    .HasMaxLength(200)
                    .HasColumnName("manual_assign_reason");

                entity.Property(e => e.NoCustomerRequest).HasColumnName("no_customer_request");

                entity.Property(e => e.NotifyUnitPending).HasColumnName("notify_unit_pending");

                entity.Property(e => e.Num)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("num");

                entity.Property(e => e.OrderByDriver)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("order_by_driver")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OrdererName)
                    .HasMaxLength(150)
                    .HasColumnName("orderer_name");

                entity.Property(e => e.OrdererNote)
                    .HasMaxLength(250)
                    .HasColumnName("orderer_note");

                entity.Property(e => e.OrientLat)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lat")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.OrientLon)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lon")
                    .HasDefaultValueSql("('E')");

                entity.Property(e => e.Paid).HasColumnName("paid");

                entity.Property(e => e.Passenger)
                    .HasMaxLength(150)
                    .HasColumnName("passenger");

                entity.Property(e => e.PassengerPhone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("passenger_phone");

                entity.Property(e => e.Phone)
                    .HasMaxLength(55)
                    .IsUnicode(false)
                    .HasColumnName("phone")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.PhoneLine)
                    .HasColumnName("phone_line")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Pickup)
                    .HasColumnType("datetime")
                    .HasColumnName("pickup");

                entity.Property(e => e.Preorder).HasColumnName("preorder");

                entity.Property(e => e.PrimaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("primary_distance_request_time");

                entity.Property(e => e.PurchaseOrder)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("purchase_order")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PurchaseQuantity)
                    .HasMaxLength(20)
                    .HasColumnName("purchase_quantity")
                    .HasDefaultValueSql("('1')");

                entity.Property(e => e.ReceiptedInvoices).HasColumnName("receipted_invoices");

                entity.Property(e => e.Remark)
                    .HasMaxLength(250)
                    .HasColumnName("remark");

                entity.Property(e => e.RemindAt)
                    .HasColumnType("datetime")
                    .HasColumnName("remind_at");

                entity.Property(e => e.RequesteTime)
                    .HasColumnType("datetime")
                    .HasColumnName("requeste_time");

                entity.Property(e => e.SecondaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("secondary_distance_request_time");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.Street).HasColumnName("street");

                entity.Property(e => e.StreetPickup).HasColumnName("street_pickup");

                entity.Property(e => e.TaxiNumber)
                    .HasColumnName("taxi_number")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("time_of_arrival");

                entity.Property(e => e.TripRemark)
                    .HasMaxLength(250)
                    .HasColumnName("trip_remark");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TargetPayment>(entity =>
            {
                entity.HasKey(e => e.IdPayment);

                entity.ToTable("target_payment");

                entity.Property(e => e.IdPayment).HasColumnName("id_payment");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IsPaid)
                    .HasColumnName("is_paid")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<TargetProperty>(entity =>
            {
                entity.HasKey(e => new { e.IdTarget, e.IdPropertie });

                entity.ToTable("target_properties");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdPropertie).HasColumnName("id_propertie");
            });

            modelBuilder.Entity<TargetShadow>(entity =>
            {
                entity.HasKey(e => e.IdTargetShadow);

                entity.ToTable("target_shadow");

                entity.HasIndex(e => e.IdTarget, "IX_target_shadow_id_target_C3712")
                    .HasFillFactor(100);

                entity.Property(e => e.IdTargetShadow).HasColumnName("id_target_shadow");

                entity.Property(e => e.AssignedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("assigned_at");

                entity.Property(e => e.Autodispatch)
                    .HasColumnName("autodispatch")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Autodispatched)
                    .HasColumnName("autodispatched")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.BillingCenter)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.BillingCenter1)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("billing_center");

                entity.Property(e => e.CancellationReason)
                    .HasColumnName("cancellation_reason")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.CompanyOrderNote)
                    .HasMaxLength(200)
                    .HasColumnName("company_order_note");

                entity.Property(e => e.CpuFirstTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_first_time");

                entity.Property(e => e.CpuPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("cpu_pickup_time");

                entity.Property(e => e.Customer)
                    .HasMaxLength(150)
                    .HasColumnName("customer");

                entity.Property(e => e.DelayedPayment)
                    .HasColumnName("delayed_payment")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Destination)
                    .HasMaxLength(250)
                    .HasColumnName("destination");

                entity.Property(e => e.DestinationLat).HasColumnName("destination_lat");

                entity.Property(e => e.DestinationLon).HasColumnName("destination_lon");

                entity.Property(e => e.DispatchSubtype).HasColumnName("dispatch_subtype");

                entity.Property(e => e.DispatchType)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("dispatch_type");

                entity.Property(e => e.Dispatchat)
                    .HasColumnType("datetime")
                    .HasColumnName("dispatchat");

                entity.Property(e => e.Dispatchnow).HasColumnName("dispatchnow");

                entity.Property(e => e.Distance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("distance");

                entity.Property(e => e.DriverAtLocation)
                    .HasColumnName("driver_at_location")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.DriverDelay).HasColumnName("driver_delay");

                entity.Property(e => e.DriverPickupMin)
                    .HasColumnName("driver_pickup_min")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DriverPickupTime)
                    .HasColumnType("datetime")
                    .HasColumnName("driver_pickup_time");

                entity.Property(e => e.DropOffTime)
                    .HasColumnType("datetime")
                    .HasColumnName("drop_off_time");

                entity.Property(e => e.DtPreorder)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_preorder");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.GDistance)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_distance");

                entity.Property(e => e.GTimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("g_time_of_arrival");

                entity.Property(e => e.HsMid).HasColumnName("hs_mid");

                entity.Property(e => e.IdClient).HasColumnName("id_client");

                entity.Property(e => e.IdCompany)
                    .HasColumnName("id_company")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdCompanyCredential).HasColumnName("id_company_credential");

                entity.Property(e => e.IdDispatcher).HasColumnName("id_dispatcher");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName("id_internal_department_used");

                entity.Property(e => e.IdOperator).HasColumnName("id_operator");

                entity.Property(e => e.IdPaymentType).HasColumnName("id_payment_type");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("last_update")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateBy).HasColumnName("last_update_by");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lbl)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("lbl");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.ManualAssignReason)
                    .HasMaxLength(200)
                    .HasColumnName("manual_assign_reason");

                entity.Property(e => e.NoCustomerRequest)
                    .HasColumnName("no_customer_request")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.NotifyUnitPending).HasColumnName("notify_unit_pending");

                entity.Property(e => e.Num)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("num");

                entity.Property(e => e.OrderByDriver)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("order_by_driver")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OrdererName)
                    .HasMaxLength(150)
                    .HasColumnName("orderer_name");

                entity.Property(e => e.OrdererNote)
                    .HasMaxLength(250)
                    .HasColumnName("orderer_note");

                entity.Property(e => e.OrientLat)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lat")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.OrientLon)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lon")
                    .HasDefaultValueSql("('E')");

                entity.Property(e => e.Paid).HasColumnName("paid");

                entity.Property(e => e.Passenger)
                    .HasMaxLength(150)
                    .HasColumnName("passenger");

                entity.Property(e => e.PassengerPhone)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("passenger_phone");

                entity.Property(e => e.Phone)
                    .HasMaxLength(55)
                    .IsUnicode(false)
                    .HasColumnName("phone")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.PhoneLine)
                    .HasColumnName("phone_line")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Pickup)
                    .HasColumnType("datetime")
                    .HasColumnName("pickup");

                entity.Property(e => e.Preorder).HasColumnName("preorder");

                entity.Property(e => e.PrimaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("primary_distance_request_time");

                entity.Property(e => e.PurchaseOrder)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("purchase_order")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PurchaseQuantity)
                    .HasMaxLength(20)
                    .HasColumnName("purchase_quantity")
                    .HasDefaultValueSql("('1')");

                entity.Property(e => e.ReceiptedInvoices).HasColumnName("receipted_invoices");

                entity.Property(e => e.Remark)
                    .HasMaxLength(250)
                    .HasColumnName("remark");

                entity.Property(e => e.RemindAt)
                    .HasColumnType("datetime")
                    .HasColumnName("remind_at");

                entity.Property(e => e.RequesteTime)
                    .HasColumnType("datetime")
                    .HasColumnName("requeste_time");

                entity.Property(e => e.SecondaryDistanceRequestTime)
                    .HasColumnType("datetime")
                    .HasColumnName("secondary_distance_request_time");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.Street).HasColumnName("street");

                entity.Property(e => e.StreetPickup)
                    .HasColumnName("street_pickup")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TaxiNumber)
                    .HasColumnName("taxi_number")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TimeOfArrival)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("time_of_arrival");

                entity.Property(e => e.TripRemark)
                    .HasMaxLength(250)
                    .HasColumnName("trip_remark");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TargetStatus>(entity =>
            {
                entity.HasKey(e => e.IdStatus);

                entity.ToTable("target_status");

                entity.Property(e => e.IdStatus).HasColumnName("id_status");

                entity.Property(e => e.ColourHex)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("colour_hex");

                entity.Property(e => e.Deleted)
                    .HasColumnName("deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Note)
                    .HasMaxLength(50)
                    .HasColumnName("note");

                entity.Property(e => e.Status)
                    .HasMaxLength(100)
                    .HasColumnName("status");

                entity.Property(e => e.StatusValue).HasColumnName("status_value");
            });

            modelBuilder.Entity<TargetStatus1>(entity =>
            {
                entity.HasKey(e => e.IdTargetStatus);

                entity.ToTable("TargetStatus");

                entity.Property(e => e.IdTargetStatus)
                    .ValueGeneratedNever()
                    .HasColumnName("id_target_status");

                entity.Property(e => e.Status)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("status");
            });

            modelBuilder.Entity<TargetUnit>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("target_units");

                entity.Property(e => e.DeviceId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("device_id");

                entity.Property(e => e.DtIdle)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_idle");

                entity.Property(e => e.DtTask)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_task");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IdUnittype).HasColumnName("id_unittype");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Position).HasColumnName("position");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");

                entity.Property(e => e.UnitUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("unit_update");
            });

            modelBuilder.Entity<TargetVehicleCategoriesShadow>(entity =>
            {
                entity.HasKey(e => e.IdTargetVehicleCategoriesShadow);

                entity.ToTable("target_vehicle_categories_shadow");

                entity.Property(e => e.IdTargetVehicleCategoriesShadow).HasColumnName("id_target_vehicle_categories_shadow");

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTargetShadow).HasColumnName("id_target_shadow");

                entity.Property(e => e.VehicleType1).HasColumnName("vehicle_type1");

                entity.Property(e => e.VehicleType10).HasColumnName("vehicle_type10");

                entity.Property(e => e.VehicleType11).HasColumnName("vehicle_type11");

                entity.Property(e => e.VehicleType12).HasColumnName("vehicle_type12");

                entity.Property(e => e.VehicleType13).HasColumnName("vehicle_type13");

                entity.Property(e => e.VehicleType14).HasColumnName("vehicle_type14");

                entity.Property(e => e.VehicleType15).HasColumnName("vehicle_type15");

                entity.Property(e => e.VehicleType16).HasColumnName("vehicle_type16");

                entity.Property(e => e.VehicleType17).HasColumnName("vehicle_type17");

                entity.Property(e => e.VehicleType18).HasColumnName("vehicle_type18");

                entity.Property(e => e.VehicleType19).HasColumnName("vehicle_type19");

                entity.Property(e => e.VehicleType2).HasColumnName("vehicle_type2");

                entity.Property(e => e.VehicleType20).HasColumnName("vehicle_type20");

                entity.Property(e => e.VehicleType3).HasColumnName("vehicle_type3");

                entity.Property(e => e.VehicleType4).HasColumnName("vehicle_type4");

                entity.Property(e => e.VehicleType5).HasColumnName("vehicle_type5");

                entity.Property(e => e.VehicleType6).HasColumnName("vehicle_type6");

                entity.Property(e => e.VehicleType7).HasColumnName("vehicle_type7");

                entity.Property(e => e.VehicleType8).HasColumnName("vehicle_type8");

                entity.Property(e => e.VehicleType9).HasColumnName("vehicle_type9");
            });

            modelBuilder.Entity<TargetVehicleCategory>(entity =>
            {
                entity.HasKey(e => e.IdRecord);

                entity.ToTable("target_vehicle_categories");

                entity.HasIndex(e => e.IdTarget, "NonClusteredIndex-20160829-101938")
                    .HasFillFactor(100);

                entity.Property(e => e.IdRecord).HasColumnName("id_record");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.VehicleType1).HasColumnName("vehicle_type1");

                entity.Property(e => e.VehicleType10).HasColumnName("vehicle_type10");

                entity.Property(e => e.VehicleType11).HasColumnName("vehicle_type11");

                entity.Property(e => e.VehicleType12).HasColumnName("vehicle_type12");

                entity.Property(e => e.VehicleType13).HasColumnName("vehicle_type13");

                entity.Property(e => e.VehicleType14).HasColumnName("vehicle_type14");

                entity.Property(e => e.VehicleType15).HasColumnName("vehicle_type15");

                entity.Property(e => e.VehicleType16).HasColumnName("vehicle_type16");

                entity.Property(e => e.VehicleType17).HasColumnName("vehicle_type17");

                entity.Property(e => e.VehicleType18).HasColumnName("vehicle_type18");

                entity.Property(e => e.VehicleType19).HasColumnName("vehicle_type19");

                entity.Property(e => e.VehicleType2).HasColumnName("vehicle_type2");

                entity.Property(e => e.VehicleType20).HasColumnName("vehicle_type20");

                entity.Property(e => e.VehicleType3).HasColumnName("vehicle_type3");

                entity.Property(e => e.VehicleType4).HasColumnName("vehicle_type4");

                entity.Property(e => e.VehicleType5).HasColumnName("vehicle_type5");

                entity.Property(e => e.VehicleType6).HasColumnName("vehicle_type6");

                entity.Property(e => e.VehicleType7).HasColumnName("vehicle_type7");

                entity.Property(e => e.VehicleType8).HasColumnName("vehicle_type8");

                entity.Property(e => e.VehicleType9).HasColumnName("vehicle_type9");
            });

            modelBuilder.Entity<TargetVehicleCustomer>(entity =>
            {
                entity.HasKey(e => e.IdTargetVehicleCustomer);

                entity.ToTable("target_vehicle_customer");

                entity.Property(e => e.IdTargetVehicleCustomer).HasColumnName("id_target_vehicle_customer");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.TargetCustomerNum).HasColumnName("target_customer_num");

                entity.Property(e => e.TargetKidsNum).HasColumnName("target_kids_num");
            });

            modelBuilder.Entity<Tariff>(entity =>
            {
                entity.HasKey(e => e.IdTariff);

                entity.ToTable("tariff");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");

                entity.Property(e => e.FlatPrice)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("flat_price");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.IsDefault).HasColumnName("is_default");

                entity.Property(e => e.IsFlat)
                    .IsRequired()
                    .HasColumnName("is_flat")
                    .HasDefaultValueSql("('false')");

                entity.Property(e => e.MasterTariff).HasColumnName("master_tariff");

                entity.Property(e => e.MinDistance)
                    .HasColumnName("min_distance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PriceEstimationPercentageMargin).HasColumnName("price_estimation_percentage_margin");

                entity.Property(e => e.PriceKm)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price_km");

                entity.Property(e => e.StartFee)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("start_fee");

                entity.Property(e => e.Tariff1)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("tariff")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.TariffCategories)
                    .HasMaxLength(50)
                    .HasColumnName("tariff_categories");

                entity.Property(e => e.TariffType).HasColumnName("tariff_type");

                entity.Property(e => e.WaitTimeHour)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("wait_time_hour");
            });

            modelBuilder.Entity<TariffSchedule>(entity =>
            {
                entity.HasKey(e => e.IdTariffSchedule);

                entity.ToTable("tariff_schedule");

                entity.Property(e => e.IdTariffSchedule).HasColumnName("id_tariff_schedule");

                entity.Property(e => e.ActiveDayOfTheWeek)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("active_day_of_the_week");

                entity.Property(e => e.ActiveHourFrom).HasColumnName("active_hour_from");

                entity.Property(e => e.ActiveHourTo).HasColumnName("active_hour_to");

                entity.Property(e => e.IdTariff).HasColumnName("id_tariff");
            });

            modelBuilder.Entity<TaxiBlok>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("taxi_blok");

                entity.Property(e => e.IdAppUser).HasColumnName("id_app_user");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTaxiBlok)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_taxi_blok");

                entity.Property(e => e.InvoiceId).HasColumnName("invoice_id");

                entity.Property(e => e.Paid).HasColumnName("paid");

                entity.Property(e => e.PaidDate)
                    .HasColumnType("datetime")
                    .HasColumnName("paid_date");
            });

            modelBuilder.Entity<TaxiBlokInvoice>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("taxi_blok_invoice");

                entity.Property(e => e.CompanyId).HasColumnName("company_id");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasColumnName("create_date");

                entity.Property(e => e.InvoiceId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("invoice_id");

                entity.Property(e => e.Paid).HasColumnName("paid");

                entity.Property(e => e.PaidAmmount)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("paid_ammount");

                entity.Property(e => e.PaidCount).HasColumnName("paid_count");

                entity.Property(e => e.PaidDate)
                    .HasColumnType("datetime")
                    .HasColumnName("paid_date");
            });

            modelBuilder.Entity<TaxiCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("taxi_customers");

                entity.Property(e => e.CDic)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("c_dic");

                entity.Property(e => e.CIco)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("c_ico");

                entity.Property(e => e.CName)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("c_name");

                entity.Property(e => e.COffices)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("c_offices");

                entity.Property(e => e.CPlace)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("c_place");

                entity.Property(e => e.CUserId)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("c_user_id");

                entity.Property(e => e.Center)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("center");

                entity.Property(e => e.Client)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("client");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Note)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("note");

                entity.Property(e => e.PaymentMethodId)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("payment_method_id");

                entity.Property(e => e.Person)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("person");

                entity.Property(e => e.Phone)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("phone");

                entity.Property(e => e.TariffId)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("tariff_id");
            });

            modelBuilder.Entity<Taximeter>(entity =>
            {
                entity.HasKey(e => e.IdTaximeter);

                entity.ToTable("taximeter");

                entity.Property(e => e.IdTaximeter).HasColumnName("id_taximeter");

                entity.Property(e => e.DistanceHired)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("distance_hired");

                entity.Property(e => e.DistanceTotal)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("distance_total");

                entity.Property(e => e.FareTotal)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("fare_total");

                entity.Property(e => e.TaximeterCode)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("taximeter_code");

                entity.Property(e => e.TripsTotal).HasColumnName("trips_total");
            });

            modelBuilder.Entity<TelephonyExternalLine>(entity =>
            {
                entity.HasKey(e => e.IdTelephonyExternalLines);

                entity.ToTable("telephony_external_line");

                entity.Property(e => e.IdTelephonyExternalLines).HasColumnName("id_telephony_external_lines");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("code");

                entity.Property(e => e.IdAreaOfOperation).HasColumnName("id_area_of_operation");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<TelephonyParkedCall>(entity =>
            {
                entity.HasKey(e => e.IdTelephonyParkedCall);

                entity.ToTable("telephony_parked_call");

                entity.Property(e => e.IdTelephonyParkedCall).HasColumnName("id_telephony_parked_call");

                entity.Property(e => e.ParkExtension)
                    .HasMaxLength(50)
                    .HasColumnName("park_extension");

                entity.Property(e => e.ParkedNumber)
                    .HasMaxLength(50)
                    .HasColumnName("parked_number");

                entity.Property(e => e.Parkee)
                    .HasMaxLength(50)
                    .HasColumnName("parkee");

                entity.Property(e => e.UniqueId)
                    .HasMaxLength(50)
                    .HasColumnName("unique_id");
            });

            modelBuilder.Entity<TelephonySipAccount>(entity =>
            {
                entity.HasKey(e => e.IdTelephonySipAccount);

                entity.ToTable("telephony_sip_account");

                entity.Property(e => e.IdTelephonySipAccount).HasColumnName("id_telephony_sip_account");

                entity.Property(e => e.CallParkingRangeEnd).HasColumnName("call_parking_range_end");

                entity.Property(e => e.CallParkingRangeStart).HasColumnName("call_parking_range_start");

                entity.Property(e => e.SipPassword)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("sip_password");

                entity.Property(e => e.SipUsername)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("sip_username");
            });

            modelBuilder.Entity<Tmp>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tmp");

                entity.Property(e => e.PaymentMonriDataId).HasColumnName("payment_monri_data_id");

                entity.Property(e => e.TransactionResponseMessage)
                    .HasMaxLength(1000)
                    .HasColumnName("transaction_response_message");
            });

            modelBuilder.Entity<TomtomTrackingDataVolume>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tomtom_tracking_data_volume");

                entity.Property(e => e.Date)
                    .HasColumnType("date")
                    .HasColumnName("date");

                entity.Property(e => e.IdDataVolume)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_data_volume");

                entity.Property(e => e.SentLocations).HasColumnName("sent_locations");
            });

            modelBuilder.Entity<Tracker>(entity =>
            {
                entity.ToTable("tracker");

                entity.Property(e => e.TrackerId).HasColumnName("tracker_id");

                entity.Property(e => e.Altitude).HasColumnName("altitude");

                entity.Property(e => e.Direction).HasColumnName("direction");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.Ignition).HasColumnName("ignition");

                entity.Property(e => e.Imei)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.LastUpdated)
                    .HasColumnType("datetime")
                    .HasColumnName("last_updated");

                entity.Property(e => e.Latitude).HasColumnName("latitude");

                entity.Property(e => e.Longitude).HasColumnName("longitude");

                entity.Property(e => e.Priority).HasColumnName("priority");

                entity.Property(e => e.Satellites).HasColumnName("satellites");

                entity.Property(e => e.SeatStatus)
                    .HasColumnName("seat_status")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Speed).HasColumnName("speed");

                entity.Property(e => e.Taximeter).HasColumnName("taximeter");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasColumnName("timestamp");
            });

            modelBuilder.Entity<TrackerHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tracker_history");

                entity.Property(e => e.Altitude).HasColumnName("altitude");

                entity.Property(e => e.Direction).HasColumnName("direction");

                entity.Property(e => e.Ignition).HasColumnName("ignition");

                entity.Property(e => e.Imei)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.Latitude).HasColumnName("latitude");

                entity.Property(e => e.Longitude).HasColumnName("longitude");

                entity.Property(e => e.Priority).HasColumnName("priority");

                entity.Property(e => e.Satellites).HasColumnName("satellites");

                entity.Property(e => e.SeatStatus).HasColumnName("seat_status");

                entity.Property(e => e.ServerTimestamp)
                    .HasColumnType("datetime")
                    .HasColumnName("server_timestamp");

                entity.Property(e => e.Speed).HasColumnName("speed");

                entity.Property(e => e.Taximeter).HasColumnName("taximeter");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasColumnName("timestamp");

                entity.Property(e => e.TrackerHistoryId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("tracker_history_id");

                entity.Property(e => e.TrackerId).HasColumnName("tracker_id");
            });

            modelBuilder.Entity<Trip>(entity =>
            {
                entity.HasKey(e => e.IdTrip);

                entity.ToTable("trip");

                entity.HasIndex(e => e.DeviceId, "IX_trip_device_id_8C760")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.DeviceId, e.IdShift }, "IX_trip_device_id_id_shift_CB564");

                entity.HasIndex(e => new { e.DeviceId, e.IdShift }, "IX_trip_device_id_id_shift_DB436")
                    .HasFillFactor(100);

                entity.HasIndex(e => e.Fare, "IX_trip_fare_A1245");

                entity.HasIndex(e => e.IdTarget, "IX_trip_id_target");

                entity.HasIndex(e => new { e.DeviceId, e.DtEnd }, "NonClusteredIndex-20160119-195228")
                    .HasFillFactor(100);

                entity.HasIndex(e => new { e.DtEnd, e.Isdeleted }, "NonClusteredIndex-20160425-220449");

                entity.HasIndex(e => new { e.DeviceId, e.TripConsecutiveNumber }, "NonClusteredIndex-trip_conse");

                entity.Property(e => e.IdTrip).HasColumnName("id_trip");

                entity.Property(e => e.AddressEnd)
                    .HasMaxLength(500)
                    .HasColumnName("address_end");

                entity.Property(e => e.AddressStart)
                    .HasMaxLength(500)
                    .HasColumnName("address_start");

                entity.Property(e => e.AuthNo)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("auth_no");

                entity.Property(e => e.BatchNo)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("batch_no");

                entity.Property(e => e.CarNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("car_number");

                entity.Property(e => e.Coupon)
                    .HasMaxLength(30)
                    .HasColumnName("coupon");

                entity.Property(e => e.CreditCardNo)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("credit_card_no");

                entity.Property(e => e.DeviceId)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("device_id");

                entity.Property(e => e.DriverNo)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("driver_no");

                entity.Property(e => e.DtEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_end");

                entity.Property(e => e.DtStart)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_start")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ExpirationDate)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("expiration_date");

                entity.Property(e => e.Fare)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("fare");

                entity.Property(e => e.FareExtra)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("fare_extra");

                entity.Property(e => e.FullSalaryPercentage).HasColumnName("full_salary_percentage");

                entity.Property(e => e.HiredDistance)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("hired_distance");

                entity.Property(e => e.IdFullSalary).HasColumnName("id_full_salary");

                entity.Property(e => e.IdPartialSalary).HasColumnName("id_partial_salary");

                entity.Property(e => e.IdShift).HasColumnName("id_shift");

                entity.Property(e => e.IdTarget).HasColumnName("id_target");

                entity.Property(e => e.IdTaximeter).HasColumnName("id_taximeter");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.LatEnd).HasColumnName("lat_end");

                entity.Property(e => e.LatStart).HasColumnName("lat_start");

                entity.Property(e => e.LonEnd).HasColumnName("lon_end");

                entity.Property(e => e.LonStart).HasColumnName("lon_start");

                entity.Property(e => e.PaymentType)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("payment_type");

                entity.Property(e => e.SoftwareTaximeterFare)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("software_taximeter_fare");

                entity.Property(e => e.TargetDestination)
                    .HasMaxLength(500)
                    .HasColumnName("target_destination");

                entity.Property(e => e.TargetStreet)
                    .HasMaxLength(500)
                    .HasColumnName("target_street");

                entity.Property(e => e.Tips)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("tips");

                entity.Property(e => e.TopSpeed)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("top_speed");

                entity.Property(e => e.TotalDistance)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("total_distance");

                entity.Property(e => e.TripConsecutiveNumber).HasColumnName("trip_consecutive_number");

                entity.Property(e => e.TripType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("trip_type");

                entity.Property(e => e.TypeExtra).HasColumnName("type_extra");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<TvCompany>(entity =>
            {
                entity.HasKey(e => e.IdTvCompany);

                entity.ToTable("tv_company");

                entity.Property(e => e.IdTvCompany).HasColumnName("id_tv_company");

                entity.Property(e => e.LogoPath)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("logo_path");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<TvDeal>(entity =>
            {
                entity.HasKey(e => e.IdTvDeal);

                entity.ToTable("tv_deal");

                entity.Property(e => e.IdTvDeal).HasColumnName("id_tv_deal");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnType("text")
                    .HasColumnName("description");

                entity.Property(e => e.DescriptionNl)
                    .HasColumnType("text")
                    .HasColumnName("description_nl");

                entity.Property(e => e.Discount)
                    .HasColumnType("decimal(6, 2)")
                    .HasColumnName("discount");

                entity.Property(e => e.ImagePath)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("image_path");

                entity.Property(e => e.Link)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("link")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.OpeningHours)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("opening_hours")
                    .HasDefaultValueSql("('')")
                    .UseCollation("Latin1_General_CI_AS");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("price");

                entity.Property(e => e.ProviderContact)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("provider_contact");

                entity.Property(e => e.ProviderName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("provider_name");

                entity.Property(e => e.ProviderPost)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("provider_post")
                    .HasDefaultValueSql("('')")
                    .UseCollation("Latin1_General_CI_AS");

                entity.Property(e => e.ProviderStreet)
                    .IsRequired()
                    .HasMaxLength(300)
                    .HasColumnName("provider_street")
                    .HasDefaultValueSql("('')")
                    .UseCollation("Latin1_General_CI_AS");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("title");

                entity.Property(e => e.TitleNl)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("title_nl");
            });

            modelBuilder.Entity<TvDriver>(entity =>
            {
                entity.HasKey(e => e.IdDriver);

                entity.ToTable("tv_driver");

                entity.Property(e => e.IdDriver)
                    .ValueGeneratedNever()
                    .HasColumnName("id_driver");

                entity.Property(e => e.CabNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("cab_number")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("description")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.DescriptionNl)
                    .IsRequired()
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("description_nl")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.District)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("district")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.ImagePath)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("image_path")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.Salt)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("salt");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<TvDriverComment>(entity =>
            {
                entity.HasKey(e => e.IdDriverComment);

                entity.ToTable("tv_driver_comment");

                entity.Property(e => e.IdDriverComment).HasColumnName("id_driver_comment");

                entity.Property(e => e.Comment)
                    .IsRequired()
                    .HasColumnType("text")
                    .HasColumnName("comment");

                entity.Property(e => e.Contact)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("contact");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<TvDriverRating>(entity =>
            {
                entity.HasKey(e => e.IdDriverRating);

                entity.ToTable("tv_driver_rating");

                entity.Property(e => e.IdDriverRating).HasColumnName("id_driver_rating");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.Rating)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("rating");
            });

            modelBuilder.Entity<Tweet>(entity =>
            {
                entity.HasKey(e => e.IdMessage);

                entity.ToTable("tweets");

                entity.HasIndex(e => e.Status, "NonClusteredIndex-20160829-101758");

                entity.HasIndex(e => e.ReplyTweetId, "NonClusteredIndex-20160901-104945");

                entity.HasIndex(e => e.IdTweet, "uc_id_tweet")
                    .IsUnique();

                entity.Property(e => e.IdMessage).HasColumnName("id_message");

                entity.Property(e => e.DirectMessageRecepient)
                    .HasMaxLength(50)
                    .HasColumnName("direct_message_recepient");

                entity.Property(e => e.IdTweet)
                    .IsRequired()
                    .HasMaxLength(25)
                    .HasColumnName("id_tweet");

                entity.Property(e => e.IdUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("id_user");

                entity.Property(e => e.IsDirectMessage)
                    .HasColumnName("is_direct_message")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Message)
                    .IsRequired()
                    .HasMaxLength(140)
                    .HasColumnName("message");

                entity.Property(e => e.ReplyTweetId)
                    .HasMaxLength(25)
                    .HasColumnName("reply_tweet_id");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.TweetDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("tweet_datetime");
            });

            modelBuilder.Entity<TwitterMessageQueue>(entity =>
            {
                entity.HasKey(e => e.IdTwitterMessageQueue);

                entity.ToTable("twitter_message_queue");

                entity.Property(e => e.IdTwitterMessageQueue).HasColumnName("id_twitter_message_queue");

                entity.Property(e => e.IdMessage).HasColumnName("id_message");

                entity.Property(e => e.IdTweet)
                    .HasMaxLength(25)
                    .HasColumnName("id_tweet");

                entity.Property(e => e.IsDirectMessage).HasColumnName("is_direct_message");

                entity.Property(e => e.IsMessageProcessed).HasColumnName("is_message_processed");

                entity.Property(e => e.Message)
                    .IsRequired()
                    .HasMaxLength(140)
                    .HasColumnName("message");

                entity.Property(e => e.ScreenName)
                    .HasMaxLength(50)
                    .HasColumnName("screen_name");
            });

            modelBuilder.Entity<Unit>(entity =>
            {
                entity.HasKey(e => e.IdUnit);

                entity.ToTable("unit");

                entity.HasIndex(e => e.DeviceId, "IX_unit_device_id");

                entity.HasIndex(e => new { e.Position, e.UnitId, e.Status }, "IX_unit_position_unit_id_status_EA934");

                entity.HasIndex(e => new { e.Status, e.DtTask }, "IX_unit_status_dt_task_8BC86");

                entity.HasIndex(e => new { e.Status, e.IdDriver, e.DtTask }, "IX_unit_status_id_driver_dt_task_5F14C");

                entity.HasIndex(e => new { e.Status, e.ZoneIn }, "IX_unit_status_zone_in_7888F");

                entity.HasIndex(e => e.UnitId, "IX_unit_unit_id");

                entity.HasIndex(e => e.UnitId, "IX_unit_unit_id_2112C");

                entity.HasIndex(e => new { e.UnitId, e.Position }, "IX_unit_unit_id_position_2679B");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.ConnectionQuality)
                    .HasColumnName("connection_quality")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.CurrentTariff).HasColumnName("current_tariff");

                entity.Property(e => e.DestinationAddress).HasColumnName("destination_address");

                entity.Property(e => e.DestinationArrival)
                    .HasColumnType("datetime")
                    .HasColumnName("destination_arrival")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DestinationLat).HasColumnName("destination_lat");

                entity.Property(e => e.DestinationLon).HasColumnName("destination_lon");

                entity.Property(e => e.DeviceId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("device_id");

                entity.Property(e => e.DeviceSerialNumber)
                    .HasMaxLength(15)
                    .HasColumnName("device_serial_number");

                entity.Property(e => e.DtIdle)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("dt_idle")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DtTask)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_task")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DtTaximeterFree)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_taximeter_free");

                entity.Property(e => e.DtUpdate)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("dt_update")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Heading)
                    .HasColumnName("heading")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdDriver)
                    .HasColumnName("id_driver")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdTracker)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("id_tracker");

                entity.Property(e => e.IdUnittype)
                    .HasColumnName("id_unittype")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IdVehicle)
                    .HasColumnName("id_vehicle")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Imei)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.Imsi)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imsi");

                entity.Property(e => e.Ip)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("ip");

                entity.Property(e => e.Lat)
                    .HasColumnName("lat")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LocationUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("location_update");

                entity.Property(e => e.Lon)
                    .HasColumnName("lon")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.NotifyPending).HasColumnName("notify_pending");

                entity.Property(e => e.OrientLat)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lat")
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.OrientLon)
                    .HasMaxLength(1)
                    .HasColumnName("orient_lon")
                    .HasDefaultValueSql("('E')");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phone_number");

                entity.Property(e => e.Position)
                    .HasColumnName("position")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.RequestedStatus).HasColumnName("requested_status");

                entity.Property(e => e.Service)
                    .HasColumnName("service")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.SimSerialNumber)
                    .HasMaxLength(50)
                    .HasColumnName("sim_serial_number");

                entity.Property(e => e.Sos)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sos");

                entity.Property(e => e.SosPos)
                    .HasColumnName("sos_Pos")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Speed)
                    .HasColumnName("speed")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.StandArrival)
                    .HasColumnType("datetime")
                    .HasColumnName("stand_arrival")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.StandIn).HasColumnName("stand_in");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.Taximeter)
                    .HasColumnName("taximeter")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");

                entity.Property(e => e.UnitIdTmp)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("unit_id_tmp");

                entity.Property(e => e.UnitUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("unit_update")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.X)
                    .HasColumnName("x")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Y)
                    .HasColumnName("y")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ZoneArrival)
                    .HasColumnType("datetime")
                    .HasColumnName("zone_arrival")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ZoneIn).HasColumnName("zone_in");

                entity.Property(e => e.ZoneTo)
                    .HasColumnName("zone_to")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<UnitAllowedDriver>(entity =>
            {
                entity.HasKey(e => e.IdUnitAllowedDriver);

                entity.ToTable("unit_allowed_driver");

                entity.Property(e => e.IdUnitAllowedDriver).HasColumnName("id_unit_allowed_driver");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            });

            modelBuilder.Entity<UnitAppVersion>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("unit_app_version");

                entity.Property(e => e.AppVersion)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("app_version");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IdUnitAppVersion)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_unit_app_version");
            });

            modelBuilder.Entity<UnitFuelRefill>(entity =>
            {
                entity.HasKey(e => e.IdUnitFuelRefill)
                    .HasName("PK__unit_fue__C1217AE72C7E77EA");

                entity.ToTable("unit_fuel_refill");

                entity.Property(e => e.IdUnitFuelRefill).HasColumnName("id_unit_fuel_refill");

                entity.Property(e => e.Amount)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("amount");

                entity.Property(e => e.FuelType).HasColumnName("fuel_type");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Price)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("price");

                entity.Property(e => e.TotalDistance)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("total_distance");
            });

            modelBuilder.Entity<UnitHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("unit_history");

                entity.HasIndex(e => e.DtUpdate, "IXClustered_unit_history_dt_update")
                    .IsClustered()
                    .HasFillFactor(90);

                entity.HasIndex(e => e.IdMessage, "IX_unit_history_id_message_73118")
                    .HasFillFactor(100);

                entity.Property(e => e.DtIdle)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_idle");

                entity.Property(e => e.DtUpdate)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_update");

                entity.Property(e => e.Heading).HasColumnName("heading");

                entity.Property(e => e.IdMessage)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_message");

                entity.Property(e => e.IdStand).HasColumnName("id_stand");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Imei)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.Imsi)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("imsi");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Position).HasColumnName("position");

                entity.Property(e => e.Sos)
                    .HasMaxLength(1)
                    .HasColumnName("sos");

                entity.Property(e => e.Speed).HasColumnName("speed");

                entity.Property(e => e.StandArrival)
                    .HasColumnType("datetime")
                    .HasColumnName("stand_arrival")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.Taximeter)
                    .HasColumnName("taximeter")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.UnitId)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");

                entity.Property(e => e.ZoneArrival)
                    .HasColumnType("datetime")
                    .HasColumnName("zone_arrival")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<UnitLogoff>(entity =>
            {
                entity.HasKey(e => e.IdUnitLogoff);

                entity.ToTable("unit_logoff");

                entity.Property(e => e.IdUnitLogoff).HasColumnName("id_unit_logoff");

                entity.Property(e => e.Actor).HasColumnName("actor");

                entity.Property(e => e.IdDriver)
                    .HasColumnName("id_driver")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Reason)
                    .HasMaxLength(300)
                    .HasColumnName("reason");

                entity.Property(e => e.UnitId)
                    .IsRequired()
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("unit_id");
            });

            modelBuilder.Entity<UnitProperty>(entity =>
            {
                entity.HasKey(e => new { e.IdUnit, e.IdPropertie });

                entity.ToTable("unit_properties");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IdPropertie).HasColumnName("id_propertie");
            });

            modelBuilder.Entity<UnitRequest>(entity =>
            {
                entity.HasKey(e => e.IdUnitRequest);

                entity.ToTable("unit_request");

                entity.Property(e => e.IdUnitRequest).HasColumnName("id_unit_request");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdUnit).HasColumnName("id_unit");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.RequestDt)
                    .HasColumnType("datetime")
                    .HasColumnName("request_dt")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RequestStatus).HasColumnName("request_status");

                entity.Property(e => e.RequestType).HasColumnName("request_type");
            });

            modelBuilder.Entity<UnitRequestDefinition>(entity =>
            {
                entity.HasKey(e => e.RequestType);

                entity.ToTable("unit_request_definition");

                entity.Property(e => e.RequestType)
                    .ValueGeneratedNever()
                    .HasColumnName("request_type");

                entity.Property(e => e.RequestNote)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("request_note");

                entity.Property(e => e.RequestText)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("request_text");
            });

            modelBuilder.Entity<UnitRequestedStatus>(entity =>
            {
                entity.HasKey(e => e.IdRequestedStatus);

                entity.ToTable("unit_requested_status");

                entity.Property(e => e.IdRequestedStatus).HasColumnName("id_requested_status");

                entity.Property(e => e.ColourHex)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("colour_hex");

                entity.Property(e => e.Status)
                    .HasMaxLength(100)
                    .HasColumnName("status");

                entity.Property(e => e.StatusValue).HasColumnName("status_value");
            });

            modelBuilder.Entity<UnitSnapshot>(entity =>
            {
                entity.HasKey(e => e.IdUnitSnapshot);

                entity.ToTable("unit_snapshot");

                entity.HasIndex(e => e.Created, "IX_unit_snapshot_created_3194E");

                entity.Property(e => e.IdUnitSnapshot).HasColumnName("id_unit_snapshot");

                entity.Property(e => e.Created)
                    .HasColumnType("datetime")
                    .HasColumnName("created")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Snapshot)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("snapshot");

                entity.Property(e => e.SnapshotType).HasColumnName("snapshot_type");
            });

            modelBuilder.Entity<UnitStatus>(entity =>
            {
                entity.HasKey(e => e.IdStatus);

                entity.ToTable("unit_status");

                entity.Property(e => e.IdStatus).HasColumnName("id_status");

                entity.Property(e => e.ColourHex)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("colour_hex");

                entity.Property(e => e.Deleted)
                    .HasColumnName("deleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Note)
                    .HasMaxLength(50)
                    .HasColumnName("note");

                entity.Property(e => e.Status)
                    .HasMaxLength(100)
                    .HasColumnName("status");

                entity.Property(e => e.StatusValue).HasColumnName("status_value");
            });

            modelBuilder.Entity<Unittype>(entity =>
            {
                entity.HasKey(e => e.IdUnittype);

                entity.ToTable("unittype");

                entity.Property(e => e.IdUnittype)
                    .ValueGeneratedNever()
                    .HasColumnName("id_unittype");

                entity.Property(e => e.Name)
                    .HasMaxLength(10)
                    .HasColumnName("name")
                    .IsFixedLength();
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.IdUser);

                entity.ToTable("users");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.MustPickInternalDepartment)
                    .HasColumnName("must_pick_internal_department")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .HasColumnName("name");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("password");

                entity.Property(e => e.Surname)
                    .HasMaxLength(100)
                    .HasColumnName("surname");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<UsersLoginLog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("users_login_log");

                entity.Property(e => e.IdLog)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id_log");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.IpAddress)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ip_address");

                entity.Property(e => e.LoginDatetime)
                    .HasColumnType("datetime")
                    .HasColumnName("login_datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("password");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<Vehicle>(entity =>
            {
                entity.HasKey(e => e.IdVehicle)
                    .HasName("PK_vehicles");

                entity.ToTable("vehicle");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.EngineDisp)
                    .HasMaxLength(50)
                    .HasColumnName("engine_disp");

                entity.Property(e => e.EnginePower)
                    .HasMaxLength(50)
                    .HasColumnName("engine_power");

                entity.Property(e => e.IdCar)
                    .HasMaxLength(50)
                    .HasColumnName("id_car")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdCarType)
                    .HasMaxLength(50)
                    .HasColumnName("id_car_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdColour)
                    .HasColumnName("id_colour")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdInternalDepartment)
                    .HasColumnName("id_internal_department")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.InsurancePolicy)
                    .HasMaxLength(150)
                    .HasColumnName("insurance_policy");

                entity.Property(e => e.InsurancePolicyNumber)
                    .HasMaxLength(150)
                    .HasColumnName("insurance_policy_number");

                entity.Property(e => e.Isdeleted)
                    .HasColumnName("isdeleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LicenseExpirationDate)
                    .HasColumnType("date")
                    .HasColumnName("license_expiration_date");

                entity.Property(e => e.LicenseNumber)
                    .HasMaxLength(150)
                    .HasColumnName("license_number");

                entity.Property(e => e.MotExpirationDate)
                    .HasColumnType("date")
                    .HasColumnName("mot_expiration_date");

                entity.Property(e => e.Note)
                    .HasColumnType("text")
                    .HasColumnName("note");

                entity.Property(e => e.NumOfSeats)
                    .HasColumnName("num_of_seats")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.OverviewDate)
                    .HasColumnType("date")
                    .HasColumnName("overview_date");

                entity.Property(e => e.Picture).HasColumnName("picture");

                entity.Property(e => e.PriceListNumber)
                    .HasMaxLength(150)
                    .HasColumnName("price_list_number");

                entity.Property(e => e.RegistrationDateTo)
                    .HasColumnType("date")
                    .HasColumnName("registration_date_to");

                entity.Property(e => e.RegistrationNumber)
                    .HasMaxLength(50)
                    .HasColumnName("registration_number");

                entity.Property(e => e.RegstrationDate)
                    .HasColumnType("date")
                    .HasColumnName("regstration_date");

                entity.Property(e => e.Type1)
                    .HasColumnName("type1")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type10)
                    .HasColumnName("type10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type11)
                    .HasColumnName("type11")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type12)
                    .HasColumnName("type12")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type13)
                    .HasColumnName("type13")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type14)
                    .HasColumnName("type14")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type15)
                    .HasColumnName("type15")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type16)
                    .HasColumnName("type16")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type17)
                    .HasColumnName("type17")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type18)
                    .HasColumnName("type18")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type19)
                    .HasColumnName("type19")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type2)
                    .HasColumnName("type2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type20)
                    .HasColumnName("type20")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type3)
                    .HasColumnName("type3")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type4)
                    .HasColumnName("type4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type5)
                    .HasColumnName("type5")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type6)
                    .HasColumnName("type6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type7)
                    .HasColumnName("type7")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type8)
                    .HasColumnName("type8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Type9)
                    .HasColumnName("type9")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.VehicleMake).HasColumnName("vehicle_make");

                entity.Property(e => e.VehicleModel).HasColumnName("vehicle_model");

                entity.Property(e => e.VehicleNumber).HasColumnName("vehicle_number");

                entity.Property(e => e.YearOf)
                    .HasColumnName("year_of")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<VehicleCompany>(entity =>
            {
                entity.HasKey(e => new { e.IdVehicle, e.IdCompany });

                entity.ToTable("vehicle_company");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");
            });

            modelBuilder.Entity<VehicleDistance>(entity =>
            {
                entity.HasKey(e => e.IdVehicleDistances);

                entity.ToTable("vehicle_distances");

                entity.Property(e => e.IdVehicleDistances).HasColumnName("id_vehicle_distances");

                entity.Property(e => e.Distance).HasColumnName("distance");

                entity.Property(e => e.IdDistancesType)
                    .HasColumnName("id_distances_type")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.Inserted)
                    .HasColumnType("datetime")
                    .HasColumnName("inserted")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Isdeleted)
                    .HasColumnName("isdeleted")
                    .HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<VehicleShiftReport>(entity =>
            {
                entity.HasKey(e => e.IdVehicleShiftReport);

                entity.ToTable("vehicle_shift_report");

                entity.Property(e => e.IdVehicleShiftReport).HasColumnName("id_vehicle_shift_report");

                entity.Property(e => e.AuctionsCount).HasColumnName("auctions_count");

                entity.Property(e => e.CancelledJobsCount).HasColumnName("cancelled_jobs_count");

                entity.Property(e => e.DispatchedJobsCount).HasColumnName("dispatched_jobs_count");

                entity.Property(e => e.DoneJobsCount).HasColumnName("done_jobs_count");

                entity.Property(e => e.DtShiftEnd)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_shift_end");

                entity.Property(e => e.DtShiftStart)
                    .HasColumnType("datetime")
                    .HasColumnName("dt_shift_start");

                entity.Property(e => e.IdVehicle).HasColumnName("id_vehicle");

                entity.Property(e => e.LateJobsCount).HasColumnName("late_jobs_count");

                entity.Property(e => e.MaxSpeed).HasColumnName("max_speed");

                entity.Property(e => e.PurchaseOrderCount).HasColumnName("purchase_order_count");

                entity.Property(e => e.RefusedJobsCount).HasColumnName("refused_jobs_count");

                entity.Property(e => e.StreetPickupCount).HasColumnName("street_pickup_count");

                entity.Property(e => e.TakenDistanceTravelled).HasColumnName("taken_distance_travelled");

                entity.Property(e => e.TaximeterEndKm).HasColumnName("taximeter_end_km");

                entity.Property(e => e.TaximeterStartKm).HasColumnName("taximeter_start_km");

                entity.Property(e => e.TotalDistanceTravelled).HasColumnName("total_distance_travelled");

                entity.Property(e => e.TotalPaid).HasColumnName("total_paid");

                entity.Property(e => e.TotalPurchaseOrder).HasColumnName("total_purchase_order");

                entity.HasOne(d => d.IdVehicleNavigation)
                    .WithMany(p => p.VehicleShiftReports)
                    .HasForeignKey(d => d.IdVehicle)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_vehicle_shift_report_vehicle");
            });

            modelBuilder.Entity<Version>(entity =>
            {
                entity.HasKey(e => e.Version1);

                entity.ToTable("version");

                entity.Property(e => e.Version1)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("version");
            });

            modelBuilder.Entity<ViberMessage>(entity =>
            {
                entity.HasKey(e => e.IdViberMessage);

                entity.ToTable("viber_message");

                entity.Property(e => e.IdViberMessage).HasColumnName("id_viber_message");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.IdAppuser).HasColumnName("id_appuser");

                entity.Property(e => e.IsReply).HasColumnName("is_reply");

                entity.Property(e => e.Lat).HasColumnName("lat");

                entity.Property(e => e.Lon).HasColumnName("lon");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.Text).HasColumnName("text");

                entity.Property(e => e.Timestamp)
                    .HasColumnType("datetime")
                    .HasColumnName("timestamp")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("type");

                entity.HasOne(d => d.IdAppuserNavigation)
                    .WithMany(p => p.ViberMessages)
                    .HasForeignKey(d => d.IdAppuser)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_viber_message_appuser");
            });

            modelBuilder.Entity<Voucher>(entity =>
            {
                entity.HasKey(e => e.IdVoucher);

                entity.ToTable("vouchers");

                entity.Property(e => e.IdVoucher).HasColumnName("id_voucher");

                entity.Property(e => e.DiscountPercentage).HasColumnName("discount_percentage");

                entity.Property(e => e.DiscountValue).HasColumnName("discount_value");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.MaxDiscountValue).HasColumnName("max_discount_value");

                entity.Property(e => e.NumberOfRides)
                    .HasColumnName("number_of_rides")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Voucher1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("voucher");

                entity.Property(e => e.VoucherType)
                    .HasColumnName("voucher_type")
                    .HasDefaultValueSql("((-1))");
            });

            modelBuilder.Entity<VwDriver>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_driver");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .HasColumnName("address");

                entity.Property(e => e.Bluetooth).HasColumnName("bluetooth");

                entity.Property(e => e.Car)
                    .HasMaxLength(50)
                    .HasColumnName("car");

                entity.Property(e => e.CarColor)
                    .HasMaxLength(50)
                    .HasColumnName("car_color");

                entity.Property(e => e.CarType)
                    .HasMaxLength(50)
                    .HasColumnName("car_type");

                entity.Property(e => e.Company)
                    .HasMaxLength(150)
                    .HasColumnName("company");

                entity.Property(e => e.CompanyPhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("company_phone");

                entity.Property(e => e.DriverCode)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("driver_code");

                entity.Property(e => e.DriverDisplay)
                    .HasMaxLength(147)
                    .HasColumnName("driver_display");

                entity.Property(e => e.Email)
                    .HasMaxLength(150)
                    .HasColumnName("email");

                entity.Property(e => e.EngineDisp)
                    .HasMaxLength(50)
                    .HasColumnName("engine_disp");

                entity.Property(e => e.EnginePower)
                    .HasMaxLength(50)
                    .HasColumnName("engine_power");

                entity.Property(e => e.Gsm)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("gsm");

                entity.Property(e => e.HomePhone)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("home_phone");

                entity.Property(e => e.IdCompany).HasColumnName("id_company");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");

                entity.Property(e => e.IdInternalDepartment).HasColumnName("id_internal_department");

                entity.Property(e => e.IdPost).HasColumnName("id_post");

                entity.Property(e => e.IdUnit)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("id_unit");

                entity.Property(e => e.Imei)
                    .IsUnicode(false)
                    .HasColumnName("imei");

                entity.Property(e => e.ImportedCarId)
                    .HasMaxLength(50)
                    .HasColumnName("imported_car_id");

                entity.Property(e => e.ImportedDriverId).HasColumnName("imported_driver_id");

                entity.Property(e => e.Isdeleted).HasColumnName("isdeleted");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(50)
                    .HasColumnName("lastname");

                entity.Property(e => e.License)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("license");

                entity.Property(e => e.LicenseExpiration)
                    .HasColumnType("datetime")
                    .HasColumnName("license_expiration");

                entity.Property(e => e.Master).HasColumnName("master");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Note).HasColumnName("note");

                entity.Property(e => e.NumOfSeats).HasColumnName("num_of_seats");

                entity.Property(e => e.OverviewDate)
                    .HasColumnType("datetime")
                    .HasColumnName("overview_date");

                entity.Property(e => e.Password)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.PersonalId)
                    .HasMaxLength(50)
                    .HasColumnName("personal_id");

                entity.Property(e => e.Picture).HasColumnName("picture");

                entity.Property(e => e.RegistrationNumber)
                    .HasMaxLength(50)
                    .HasColumnName("registration_number");

                entity.Property(e => e.RegstrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("regstration_date");

                entity.Property(e => e.Type1).HasColumnName("type1");

                entity.Property(e => e.Type10).HasColumnName("type10");

                entity.Property(e => e.Type11).HasColumnName("type11");

                entity.Property(e => e.Type12).HasColumnName("type12");

                entity.Property(e => e.Type13).HasColumnName("type13");

                entity.Property(e => e.Type14).HasColumnName("type14");

                entity.Property(e => e.Type15).HasColumnName("type15");

                entity.Property(e => e.Type16).HasColumnName("type16");

                entity.Property(e => e.Type17).HasColumnName("type17");

                entity.Property(e => e.Type18).HasColumnName("type18");

                entity.Property(e => e.Type19).HasColumnName("type19");

                entity.Property(e => e.Type2).HasColumnName("type2");

                entity.Property(e => e.Type20).HasColumnName("type20");

                entity.Property(e => e.Type3).HasColumnName("type3");

                entity.Property(e => e.Type4).HasColumnName("type4");

                entity.Property(e => e.Type5).HasColumnName("type5");

                entity.Property(e => e.Type6).HasColumnName("type6");

                entity.Property(e => e.Type7).HasColumnName("type7");

                entity.Property(e => e.Type8).HasColumnName("type8");

                entity.Property(e => e.Type9).HasColumnName("type9");

                entity.Property(e => e.YearOf).HasColumnName("year_of");
            });

            modelBuilder.Entity<VwTargetCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_TargetCustomer");

                entity.Property(e => e.Hd)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("hd");

                entity.Property(e => e.Hs).HasColumnName("hs");

                entity.Property(e => e.HsMid).HasColumnName("hs_mid");

                entity.Property(e => e.NaId).HasColumnName("na_id");

                entity.Property(e => e.NaIme)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("na_ime");

                entity.Property(e => e.NaMid).HasColumnName("na_mid");

                entity.Property(e => e.PtId).HasColumnName("pt_id");

                entity.Property(e => e.Remarkname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("remarkname");

                entity.Property(e => e.UlIme)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("ul_ime");
            });

            modelBuilder.Entity<Warehouse>(entity =>
            {
                entity.HasKey(e => e.IdWarehouse);

                entity.ToTable("warehouse");

                entity.Property(e => e.IdWarehouse).HasColumnName("id_warehouse");

                entity.Property(e => e.ConnectionString).HasColumnName("connection_string");

                entity.Property(e => e.WarehouseName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("warehouse_name");
            });

            modelBuilder.Entity<WhitelistedIpAddress>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("whitelisted_ip_addresses");

                entity.Property(e => e.IpAddress)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ip_address");
            });

            modelBuilder.Entity<WorkTime>(entity =>
            {
                entity.HasKey(e => e.IdWorkTime);

                entity.ToTable("work_time");

                entity.Property(e => e.IdWorkTime).HasColumnName("id_work_time");

                entity.Property(e => e.DateFrom)
                    .HasColumnType("datetime")
                    .HasColumnName("date_from");

                entity.Property(e => e.DateTo)
                    .HasColumnType("datetime")
                    .HasColumnName("date_to");

                entity.Property(e => e.IdDriver).HasColumnName("id_driver");
            });

            modelBuilder.Entity<Zone>(entity =>
            {
                entity.HasKey(e => e.IdZone);

                entity.ToTable("zone");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.AutodispatchDistanceLimit).HasColumnName("autodispatch_distance_limit");

                entity.Property(e => e.DriverPickupMaximumMinutes).HasColumnName("driver_pickup_maximum_minutes");

                entity.Property(e => e.IdBackupZone1).HasColumnName("id_backup_zone_1");

                entity.Property(e => e.IdBackupZone2).HasColumnName("id_backup_zone_2");

                entity.Property(e => e.IdBackupZone3).HasColumnName("id_backup_zone_3");

                entity.Property(e => e.IdBackupZone4).HasColumnName("id_backup_zone_4");

                entity.Property(e => e.IdBackupZone5).HasColumnName("id_backup_zone_5");

                entity.Property(e => e.IdInternalDepartment)
                    .HasColumnName("id_internal_department")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LatCenter).HasColumnName("lat_center");

                entity.Property(e => e.LonCenter).HasColumnName("lon_center");

                entity.Property(e => e.OrderValue).HasColumnName("order_value");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<ZonePolygon>(entity =>
            {
                entity.HasKey(e => e.IdZonePolygon);

                entity.ToTable("zone_polygon");

                entity.Property(e => e.IdZonePolygon).HasColumnName("id_zone_polygon");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.Polygon)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("polygon");
            });

            modelBuilder.Entity<ZoneRange>(entity =>
            {
                entity.HasKey(e => e.IdZoneRange);

                entity.ToTable("zone_range");

                entity.Property(e => e.IdZoneRange).HasColumnName("id_zone_range");

                entity.Property(e => e.EvenMax).HasColumnName("even_max");

                entity.Property(e => e.EvenMaxLabel)
                    .HasMaxLength(1)
                    .HasColumnName("even_max_label");

                entity.Property(e => e.IdStreet).HasColumnName("id_street");

                entity.Property(e => e.IdZone).HasColumnName("id_zone");

                entity.Property(e => e.OddMax).HasColumnName("odd_max");

                entity.Property(e => e.OddMaxLabel)
                    .HasMaxLength(1)
                    .HasColumnName("odd_max_label");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
