﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SettingAutodispatchLimitDayofweek
    {
        public int IdSettingAutodispatchLimitDayofweek { get; set; }
        public int DaysOfWeek { get; set; }
        public int HourFrom { get; set; }
        public int HourTo { get; set; }
        public int? AutodispatchDistanceLimit { get; set; }
        public int AutodispatchArrivalTimeLimit { get; set; }
        public int? IdStand { get; set; }
        public int? AuctionDistanceLimit { get; set; }
        public int? AuctionArrivalTimeLimit { get; set; }
    }
}
