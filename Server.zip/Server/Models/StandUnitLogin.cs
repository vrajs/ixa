﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class StandUnitLogin
    {
        public int IdStandUnitLogin { get; set; }
        public int IdUnit { get; set; }
        public int IdStand { get; set; }
        public DateTime Inserted { get; set; }
    }
}
