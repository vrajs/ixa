﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CustomerCancellType
    {
        public int IdCustomerCancellType { get; set; }
        public string CustomerCancellType1 { get; set; }
    }
}
