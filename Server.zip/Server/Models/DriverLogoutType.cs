﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverLogoutType
    {
        public int IdDriverLogoutType { get; set; }
        public string Title { get; set; }
    }
}
