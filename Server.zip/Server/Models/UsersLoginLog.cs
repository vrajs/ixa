﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UsersLoginLog
    {
        public int IdLog { get; set; }
        public int IdUser { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string IpAddress { get; set; }
        public DateTime LoginDatetime { get; set; }
    }
}
