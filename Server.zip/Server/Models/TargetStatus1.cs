﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetStatus1
    {
        public int IdTargetStatus { get; set; }
        public string Status { get; set; }
    }
}
