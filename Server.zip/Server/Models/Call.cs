﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Call
    {
        public int IdCall { get; set; }
        public string UniqueId { get; set; }
        public string InitiatorNumber { get; set; }
        public string ReceiverNumber { get; set; }
        public byte Status { get; set; }
        public DateTime? Initiated { get; set; }
        public DateTime? Answered { get; set; }
        public DateTime? Ended { get; set; }
    }
}
