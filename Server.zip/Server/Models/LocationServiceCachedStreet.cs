﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class LocationServiceCachedStreet
    {
        public int IdLocationServiceCachedStreet { get; set; }
        public string Street { get; set; }
        public int? Lat { get; set; }
        public int? Lon { get; set; }
        public int? Radius { get; set; }
    }
}
