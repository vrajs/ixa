﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class PaymentReceiptDatum
    {
        public int Id { get; set; }
        public int TargetId { get; set; }
        public string ReceiptData { get; set; }
    }
}
