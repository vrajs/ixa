﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetStatus
    {
        public int IdStatus { get; set; }
        public int? StatusValue { get; set; }
        public string Status { get; set; }
        public bool? Deleted { get; set; }
        public string ColourHex { get; set; }
        public string Note { get; set; }
    }
}
