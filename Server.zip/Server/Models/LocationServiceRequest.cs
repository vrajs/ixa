﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class LocationServiceRequest
    {
        public int IdLocationServiceRequest { get; set; }
        public byte ServiceType { get; set; }
        public byte Source { get; set; }
        public DateTime Request { get; set; }
        public string Url { get; set; }
    }
}
