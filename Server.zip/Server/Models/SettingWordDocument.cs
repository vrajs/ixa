﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SettingWordDocument
    {
        public int IdDocument { get; set; }
        public string Title { get; set; }
        public string Path { get; set; }
    }
}
