﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TelephonyParkedCall
    {
        public int IdTelephonyParkedCall { get; set; }
        public string ParkExtension { get; set; }
        public string UniqueId { get; set; }
        public string Parkee { get; set; }
        public string ParkedNumber { get; set; }
    }
}
