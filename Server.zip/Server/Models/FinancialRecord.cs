﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinancialRecord
    {
        public int IdFinancialRecord { get; set; }
        public int Type { get; set; }
        public int? IdCategory { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public int? IdShift { get; set; }
        public DateTime InsertedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool Deleted { get; set; }
    }
}
