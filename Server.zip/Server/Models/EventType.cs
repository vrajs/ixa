﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class EventType
    {
        public int IdEventType { get; set; }
        public string EventType1 { get; set; }
    }
}
