﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TrackerHistory
    {
        public int TrackerHistoryId { get; set; }
        public int TrackerId { get; set; }
        public string Imei { get; set; }
        public DateTime? Timestamp { get; set; }
        public byte? Priority { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public double? Altitude { get; set; }
        public short? Direction { get; set; }
        public byte? Satellites { get; set; }
        public short? Speed { get; set; }
        public byte? Ignition { get; set; }
        public byte? Taximeter { get; set; }
        public byte? SeatStatus { get; set; }
        public DateTime? ServerTimestamp { get; set; }
    }
}
