﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ShuttleScheduleTarget
    {
        public int IdShuttleScheduleTargets { get; set; }
        public int? IdShuttleSchedule { get; set; }
        public int? IdTarget { get; set; }
    }
}
