﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ManualShift
    {
        public int IdManualShift { get; set; }
        public int? IdEmployee { get; set; }
        public DateTime? Inserted { get; set; }
        public decimal? Amount { get; set; }
        public bool? IsDeleted { get; set; }
        public int? DeletedBy { get; set; }
        public DateTime? Deleted { get; set; }
    }
}
