﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class OrderFormItem
    {
        public int IdOrderFormItem { get; set; }
        public int IdOrderFormItemType { get; set; }
        public string OrderFormItemValue { get; set; }
        public decimal Price { get; set; }
        public int IdDriver { get; set; }
        public int IdCompany { get; set; }
        public DateTime Inserted { get; set; }
    }
}
