﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverField
    {
        public int IdDriver { get; set; }
        public string ListType { get; set; }
        public string StatusType { get; set; }
        public string UniqueMasterCitizenNumber { get; set; }
        public string IdPersonalCard { get; set; }
        public DateTime? MemberFrom { get; set; }
        public DateTime? MemberTo { get; set; }
        public string CarSerialNumber { get; set; }
        public string Points { get; set; }
        public string DriverFrom { get; set; }
        public int? RideCount { get; set; }
    }
}
