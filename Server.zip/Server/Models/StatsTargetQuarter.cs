﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class StatsTargetQuarter
    {
        public int IdStatsTargetQuarter { get; set; }
        public int? All { get; set; }
        public int? Deleted { get; set; }
        public int? NoCustomer { get; set; }
        public int? Successful { get; set; }
        public int? StreetPickup { get; set; }
        public int? CustomerApp { get; set; }
        public int? CompanyOrders { get; set; }
        public decimal? AvgDispatchatTime { get; set; }
        public decimal? TotalFare { get; set; }
        public int? QuarterNum { get; set; }
        public int? Year { get; set; }
    }
}
