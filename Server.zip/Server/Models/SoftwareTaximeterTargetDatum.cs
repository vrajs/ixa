﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class SoftwareTaximeterTargetDatum
    {
        public int Id { get; set; }
        public int TargetId { get; set; }
        public double TaxiFare { get; set; }
        public int DistanceTraveled { get; set; }
        public long WaitingTimeMilliseconds { get; set; }
        public int TariffId { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}
