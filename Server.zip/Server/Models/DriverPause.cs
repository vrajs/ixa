﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverPause
    {
        public int IdDriverPause { get; set; }
        public int IdDriver { get; set; }
        public int IdUnit { get; set; }
        public DateTime PauseStart { get; set; }
        public DateTime PauseEnd { get; set; }
        public byte? ShiftType { get; set; }
    }
}
