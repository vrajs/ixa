﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetVehicleCustomer
    {
        public int IdTargetVehicleCustomer { get; set; }
        public int IdTarget { get; set; }
        public int IdVehicle { get; set; }
        public int TargetCustomerNum { get; set; }
        public int? TargetKidsNum { get; set; }
    }
}
