﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyAssignAllowedDriver
    {
        public int IdCompanyAssignAllowedDriver { get; set; }
        public int IdCompany { get; set; }
        public int IdDriver { get; set; }
    }
}
