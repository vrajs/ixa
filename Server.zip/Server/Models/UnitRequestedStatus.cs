﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class UnitRequestedStatus
    {
        public int IdRequestedStatus { get; set; }
        public int? StatusValue { get; set; }
        public string Status { get; set; }
        public string ColourHex { get; set; }
    }
}
