﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class LocationServiceBlackList
    {
        public int IdLocationServiceBlackList { get; set; }
        public int Lat { get; set; }
        public int Lon { get; set; }
        public int Radius { get; set; }
    }
}
