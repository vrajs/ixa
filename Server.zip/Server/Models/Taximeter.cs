﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Taximeter
    {
        public int IdTaximeter { get; set; }
        public string TaximeterCode { get; set; }
        public decimal? DistanceTotal { get; set; }
        public decimal? DistanceHired { get; set; }
        public decimal? FareTotal { get; set; }
        public int? TripsTotal { get; set; }
    }
}
