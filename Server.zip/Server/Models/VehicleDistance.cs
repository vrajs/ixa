﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class VehicleDistance
    {
        public int IdVehicleDistances { get; set; }
        public int? IdVehicle { get; set; }
        public int? Distance { get; set; }
        public int? IdDistancesType { get; set; }
        public int? IdDriver { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? Isdeleted { get; set; }
    }
}
