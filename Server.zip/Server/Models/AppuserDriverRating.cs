﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserDriverRating
    {
        public int IdDriverRating { get; set; }
        public int IdAppuser { get; set; }
        public int IdDriver { get; set; }
        public int IdTarget { get; set; }
        public int IdVehicle { get; set; }
        public int Rating { get; set; }
        public string Note { get; set; }
        public int? IdThirdPartyType { get; set; }
    }
}
