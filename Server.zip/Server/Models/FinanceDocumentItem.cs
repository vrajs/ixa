﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class FinanceDocumentItem
    {
        public int IdFinanceDocumentItem { get; set; }
        public int IdFinanceDocument { get; set; }
        public string Item { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Value { get; set; }
    }
}
