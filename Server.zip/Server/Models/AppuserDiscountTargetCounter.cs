﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AppuserDiscountTargetCounter
    {
        public int DiscountTargetCountId { get; set; }
        public int IdAppuser { get; set; }
        public int RideCount { get; set; }
        public int LastTargetCounted { get; set; }
    }
}
