﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Tariff
    {
        public int IdTariff { get; set; }
        public string Tariff1 { get; set; }
        public decimal? PriceKm { get; set; }
        public decimal? StartFee { get; set; }
        public decimal? WaitTimeHour { get; set; }
        public bool IsDefault { get; set; }
        public int? IdZone { get; set; }
        public decimal FlatPrice { get; set; }
        public bool? IsFlat { get; set; }
        public bool? MasterTariff { get; set; }
        public int? TariffType { get; set; }
        public string TariffCategories { get; set; }
        public int? PriceEstimationPercentageMargin { get; set; }
        public int? MinDistance { get; set; }
    }
}
