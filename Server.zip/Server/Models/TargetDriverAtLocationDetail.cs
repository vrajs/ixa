﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetDriverAtLocationDetail
    {
        public int IdTargetDriverAtLocationDetails { get; set; }
        public int IdTarget { get; set; }
        public DateTime DriverAtLocationTime { get; set; }
        public double LocationLatitude { get; set; }
        public double LocationLongitude { get; set; }
    }
}
