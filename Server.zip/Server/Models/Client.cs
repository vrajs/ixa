﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Client
    {
        public int IdClient { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int IdPost { get; set; }
        public string Note { get; set; }
        public string TaxId { get; set; }
        public bool Deleted { get; set; }
        public int? IdRecord { get; set; }
        public int IdCompany { get; set; }
        public int? IdClientType { get; set; }
        public bool? HandicapDiscount { get; set; }
        public int? NumberOfCalls { get; set; }
        public int? RideCount { get; set; }
        public DateTime? TimeOfLastCall { get; set; }
    }
}
