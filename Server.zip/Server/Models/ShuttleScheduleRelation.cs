﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ShuttleScheduleRelation
    {
        public int IdShuttleScheduleRelation { get; set; }
        public string Relation { get; set; }
        public string StartStreet { get; set; }
        public string EndStreet { get; set; }
    }
}
