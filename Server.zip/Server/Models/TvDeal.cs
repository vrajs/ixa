﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TvDeal
    {
        public int IdTvDeal { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public string ProviderName { get; set; }
        public string ProviderContact { get; set; }
        public string ImagePath { get; set; }
        public string Link { get; set; }
        public string ProviderStreet { get; set; }
        public string ProviderPost { get; set; }
        public string OpeningHours { get; set; }
        public string DescriptionNl { get; set; }
        public string TitleNl { get; set; }
    }
}
