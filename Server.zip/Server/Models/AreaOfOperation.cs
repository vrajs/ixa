﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class AreaOfOperation
    {
        public int IdAreaOfOperation { get; set; }
        public string Title { get; set; }
        public double CenterLat { get; set; }
        public double CenterLon { get; set; }
        public string AppendText { get; set; }
        public bool DefaultAreaOfOperation { get; set; }
        public bool StrictBoundsEnabled { get; set; }
    }
}
