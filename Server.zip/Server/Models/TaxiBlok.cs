﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TaxiBlok
    {
        public int IdTaxiBlok { get; set; }
        public int IdTarget { get; set; }
        public int IdAppUser { get; set; }
        public bool Paid { get; set; }
        public DateTime? PaidDate { get; set; }
        public int? InvoiceId { get; set; }
    }
}
