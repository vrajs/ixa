﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Coupon
    {
        public int IdCoupon { get; set; }
        public int IdTarget { get; set; }
        public string Coupon1 { get; set; }
        public decimal CouponValue { get; set; }
    }
}
