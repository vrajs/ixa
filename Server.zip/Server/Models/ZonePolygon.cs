﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class ZonePolygon
    {
        public int IdZonePolygon { get; set; }
        public int IdZone { get; set; }
        public string Polygon { get; set; }
    }
}
