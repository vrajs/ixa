﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DriverAction
    {
        public int IdDriverAction { get; set; }
        public string Title { get; set; }
    }
}
