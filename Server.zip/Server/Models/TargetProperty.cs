﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class TargetProperty
    {
        public int IdTarget { get; set; }
        public int IdPropertie { get; set; }
    }
}
