﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class QuickSearch
    {
        public int IdQuickSearch { get; set; }
        public string QuickSearchText { get; set; }
        public string FullSearchText { get; set; }
    }
}
