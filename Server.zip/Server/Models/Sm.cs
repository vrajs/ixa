﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class Sm
    {
        public int IdSms { get; set; }
        public string UnitId { get; set; }
        public string Message { get; set; }
        public string Remark { get; set; }
        public DateTime? SentDate { get; set; }
        public bool? IsSent { get; set; }
        public bool IsDeleted { get; set; }
        public int? SmsType { get; set; }
        public int? ClientId { get; set; }
        public int? IdTarget { get; set; }
    }
}
