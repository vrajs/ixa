﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class CompanyBilling
    {
        public int IdCompanyBilling { get; set; }
        public int? IdCompany { get; set; }
        public decimal? Price { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
