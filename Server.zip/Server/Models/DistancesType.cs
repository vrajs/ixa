﻿using System;
using System.Collections.Generic;

namespace NetCabManager.Server.Models
{
    public partial class DistancesType
    {
        public int IdDistancesType { get; set; }
        public string DistancesType1 { get; set; }
    }
}
