﻿using System.Text.Json;
using NetCabManager.Application.Interfaces.Serialization.Options;

namespace NetCabManager.Application.Serialization.Options
{
    public class SystemTextJsonOptions : IJsonSerializerOptions
    {
        public JsonSerializerOptions JsonSerializerOptions { get; } = new();
    }
}