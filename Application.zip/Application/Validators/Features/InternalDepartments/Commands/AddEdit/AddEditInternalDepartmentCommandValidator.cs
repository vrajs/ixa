﻿namespace NetCabManager.Application.Validators.Features.InternalDepartments.Commands.AddEdit
{
    using FluentValidation;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit;

    public class AddEditInternalDepartmentCommandValidator : AbstractValidator<AddEditInternalDepartmentCommand>
    {
        public AddEditInternalDepartmentCommandValidator(IStringLocalizer<AddEditInternalDepartmentCommandValidator> localizer)
        {
            RuleFor(i => i.Internal_Department).MaximumLength(50).WithMessage(i => localizer["Internal Department can contain 50 characters max"]);
        }
    }
}