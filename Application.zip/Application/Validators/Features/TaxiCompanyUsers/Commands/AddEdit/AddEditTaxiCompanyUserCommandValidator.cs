﻿namespace NetCabManager.Application.Validators.Features.TaxiCompanyUsers.Commands.AddEdit
{
    using FluentValidation;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit;

    public class AddEditTaxiCompanyUserCommandValidator : AbstractValidator<AddEditTaxiCompanyUserCommand>
    {
        public AddEditTaxiCompanyUserCommandValidator(IStringLocalizer<AddEditTaxiCompanyUserCommandValidator> localizer)
        {
            RuleFor(u => u.Name).MaximumLength(100).WithMessage(u => localizer["Name can contain 100 characters max"]);
            RuleFor(u => u.Surname).MaximumLength(100).WithMessage(u => localizer["Surname can contain 100 characters max"]);
            RuleFor(u => u.Username).NotNull().WithMessage(u => localizer["Username is required"])
                                    .MaximumLength(50).WithMessage(u => localizer["Username can contain 50 characters max"]);
            RuleFor(u => u.Password).NotNull().WithMessage(u => localizer["Password is required"])
                                    .MaximumLength(50).WithMessage(u => localizer["Password can contain 50 characters max"]);
            RuleFor(u => u.IdRole).NotNull().WithMessage(u => localizer["Id Role is required"])
                                  .GreaterThan(0).WithMessage(u => localizer["Id Role cannot be less or equal to 0"]);
        }
    }
}