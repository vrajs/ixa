﻿using FluentValidation;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Validators.Features.PartnerCompanies.Commands.AddEdit
{
    public class AddEditPartnerCompanyCommandValidator : AbstractValidator<AddEditPartnerCompanyCommand>
    {
        public AddEditPartnerCompanyCommandValidator(IStringLocalizer<AddEditPartnerCompanyCommandValidator> localizer)
        {
            RuleFor(p => p.Name).MaximumLength(150).WithMessage(p => localizer["Name can contain 150 characters max"]);
            RuleFor(p => p.Address).MaximumLength(150).WithMessage(p => localizer["Address can contain 150 characters max"]);
            RuleFor(p => p.IdPost).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Id Post must be greater or equal 0"]);
            RuleFor(p => p.TaxId).MaximumLength(50).WithMessage(p => localizer["Tax Id can contain 50 characters max"]);
            RuleFor(p => p.IdRecord).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Id Record must be greater or equal 0"]);
            RuleFor(p => p.Post).MaximumLength(100).WithMessage(p => localizer["Post can contain 100 characters max"]);
            RuleFor(p => p.Phone).MaximumLength(20).WithMessage(p => localizer["Phone can contain 20 characters max"])
                                 .Matches("^[0-9+/-]*$").WithMessage(p => localizer["Phone can contain only numbers and characters \"+\", \"/\", \"-\""]);
            RuleFor(p => p.IdTariffDefault).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Id Tariff Default must be greater or equal 0"]);
            RuleFor(p => p.ShortName).MaximumLength(150).WithMessage(p => localizer["Short Name can contain 150 characters max"]);
            RuleFor(p => p.ContractNumber).MaximumLength(50).WithMessage(p => localizer["Contract Number can contain 50 characters max"]);
            RuleFor(p => p.CouponValue).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Coupon Value must be greater or equal 0"]);
            RuleFor(p => p.ContractText).MaximumLength(150).WithMessage(p => localizer["Contract Text can contain 150 characters max"]);
            RuleFor(p => p.PaymentDueDateText).MaximumLength(150).WithMessage(p => localizer["Payment Due Date Text can contain 150 characters max"]);
            RuleFor(p => p.IBAN).MaximumLength(50).WithMessage(p => localizer["IBAN can contain 50 characters max"]);
            RuleFor(p => p.RegisterNumber).MaximumLength(50).WithMessage(p => localizer["Register Number can contain 50 characters max"]);
            RuleFor(p => p.Discount).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Discount must be greater or equal 0"]);
            RuleFor(p => p.PassValidation).MaximumLength(50).WithMessage(p => localizer["Pass Validation can contain 50 characters max"]);
            RuleFor(p => p.IdCompanyBlock).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Id Company Block must be greater or equal 0"]);
            RuleFor(p => p.IdCompanySlip).GreaterThanOrEqualTo(0).WithMessage(p => localizer["Id Company Slip must be greater or equal 0"]);
        }
    }
}