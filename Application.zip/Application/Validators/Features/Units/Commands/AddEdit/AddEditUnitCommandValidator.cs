﻿using FluentValidation;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.Units.Commands.AddEdit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Validators.Features.Units.Commands.AddEdit
{
    public class AddEditUnitCommandValidator : AbstractValidator<AddEditUnitCommand>
    {
        public AddEditUnitCommandValidator(IStringLocalizer<AddEditUnitCommandValidator> localizer)
        {
            RuleFor(u => u.UnitId).MaximumLength(45).WithMessage(u => localizer["Unit Id can contain 45 characters max"]);
            RuleFor(u => u.IMEI).NotEmpty().WithMessage(u => localizer["IMEI is required and must be unique!"])
                                .MaximumLength(45).WithMessage(u => localizer["IMEI can contain 45 characters max"]);
            RuleFor(u => u.IMSI).MaximumLength(45).WithMessage(u => localizer["IMSI can contain 45 characters max"]);
            RuleFor(u => u.OrientLatitude).MaximumLength(1).WithMessage(u => localizer["Orient Latitude can contain 1 character max"]);
            RuleFor(u => u.OrientLongitude).MaximumLength(1).WithMessage(u => localizer["Orient Longitude can contain 1 character max"]);
            RuleFor(u => u.DateTimeUpdate).MaximumLength(45).WithMessage(u => localizer["Datetime Update can contain 45 character max"]);
            RuleFor(u => u.DateTimeIdle).MaximumLength(45).WithMessage(u => localizer["Datetime Idle can contain 45 character max"]);
            RuleFor(u => u.SOS).MaximumLength(50).WithMessage(u => localizer["SOS can contain 50 character max"]);
            RuleFor(u => u.DeviceId).MaximumLength(30).WithMessage(u => localizer["Device Id can contain 30 character max"]);
            RuleFor(u => u.PhoneNumber).MaximumLength(50).WithMessage(u => localizer["Phone Number can contain 50 character max"]);
            RuleFor(u => u.IP).MaximumLength(50).WithMessage(u => localizer["IP can contain 50 character max"]);
            RuleFor(u => u.UnitIdTmp).MaximumLength(50).WithMessage(u => localizer["Unit Id Temp can contain 50 character max"]);     
            RuleFor(u => u.ZoneIn).NotNull().WithMessage(u => localizer["Zone In is required"])
                                  .GreaterThanOrEqualTo(0).WithMessage(u => localizer["Zone In cannot be less than 0"]);
            RuleFor(u => u.StandIn).NotNull().WithMessage(u => localizer["Stand In is required"])
                                   .GreaterThanOrEqualTo(0).WithMessage(u => localizer["Stand In cannot be less than 0"]);
            RuleFor(u => u.TaxiMeter).NotNull().WithMessage(u => localizer["Taximeter is required"]);
            RuleFor(u => u.RequestedStatus).NotNull().WithMessage(u => localizer["Requested Status is required"]);
            RuleFor(u => u.ConnectionQuality).NotNull().WithMessage(u => localizer["Connection Quality is required"]);
            RuleFor(u => u.IdInternalDepartment).NotNull().GreaterThanOrEqualTo(0).WithMessage(u => localizer["Id Internal Department is required"]);
            RuleFor(u => u.DeviceSerialNumber).MaximumLength(15).WithMessage(u => localizer["Device Serial Number can contain 15 characters max"]);
            RuleFor(u => u.SIMSerialNumber).MaximumLength(50).WithMessage(u => localizer["SIM Serial Number can contain 50 characters max"]);
            RuleFor(u => u.IdTracker).MaximumLength(30).WithMessage(u => localizer["Id Tracker can contain 30 characters max"]);
        }
    }
}