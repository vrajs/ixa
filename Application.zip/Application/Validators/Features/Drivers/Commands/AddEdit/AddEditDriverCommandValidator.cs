﻿using FluentValidation;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.Drivers.Commands.AddEdit;

namespace NetCabManager.Application.Validators.Features.Drivers.Commands.AddEdit
{
    public class AddEditDriverCommandValidator : AbstractValidator<AddEditDriverCommand>
    {
        public AddEditDriverCommandValidator(IStringLocalizer<AddEditDriverCommandValidator> localizer)
        {
            RuleFor(d => d.IdUnit).NotEmpty().WithMessage(d => localizer["Id Unit is required and must be unique!"])
                                  .MaximumLength(45).WithMessage(d => localizer["Id Unit can contain 45 characters max!"]);
            RuleFor(d => d.Name).MaximumLength(50).WithMessage(d => localizer["Name can contain 50 characters max!"]);
            RuleFor(d => d.Lastname).MaximumLength(50).WithMessage(d => localizer["Lastname can contain 50 characters max!"]);
            RuleFor(d => d.IsDeleted).NotNull();
            RuleFor(d => d.Password).NotEmpty().WithMessage(d => localizer["Password is required and must be unique!"])
                                    .MinimumLength(4).WithMessage(d => localizer["Password must contains at least 4 characters!"])
                                    .MaximumLength(10).WithMessage(d => localizer["Password can contains max 10 characters!"]);
            RuleFor(d => d.GSM).MaximumLength(50).WithMessage(d => localizer["GSM can contain 50 characters max!"]);
            RuleFor(d => d.RegistrationNumber).MaximumLength(50).WithMessage(d => localizer["Registration Number can contain 50 characters max!"]);
            RuleFor(d => d.Car).MaximumLength(50).WithMessage(d => localizer["Car can contain 50 characters max!"]);
            RuleFor(d => d.License).MaximumLength(50).WithMessage(d => localizer["Licence can contain 50 characters max!"]);
            RuleFor(d => d.Company).MaximumLength(150).WithMessage(d => localizer["Company can contain 150 characters max!"]);
            RuleFor(d => d.CompanyPhone).MaximumLength(50).WithMessage(d => localizer["Company Phone can contain 50 characters max!"]);
            RuleFor(d => d.HomePhone).MaximumLength(50).WithMessage(d => localizer["Home Phone can contain 50 characters max!"]);
            RuleFor(d => d.Address).MaximumLength(50).WithMessage(d => localizer["Address can contain 50 characters max!"]);
            RuleFor(d => d.CarType).MaximumLength(50).WithMessage(d => localizer["Car Type can contain 50 characters max!"]);
            RuleFor(d => d.CarColor).MaximumLength(50).WithMessage(d => localizer["Car Color can contain 50 characters max!"]);
            RuleFor(d => d.EngineDisplacement).MaximumLength(50).WithMessage(d => localizer["Engine Displacement can contain 50 characters max!"]);
            RuleFor(d => d.EnginePower).MaximumLength(50).WithMessage(d => localizer["Engine Power can contain 50 characters max!"]);
            RuleFor(d => d.PersonalId).MaximumLength(50).WithMessage(d => localizer["Personal Id can contain 50 characters max!"]);
            RuleFor(d => d.Master).NotNull().WithMessage("Master cannot be NULL")
                                  .GreaterThanOrEqualTo(0).WithMessage(d => localizer["Master must be 0 or greater!"]);
            RuleFor(d => d.ImportedCarId).MaximumLength(50).WithMessage(d => localizer["Imported Car Id can contain 50 characters max!"]);
            RuleFor(d => d.Email).MaximumLength(150).WithMessage(d => localizer["Email can contain 150 characters max!"])
                                 .EmailAddress().WithMessage(d => localizer["Email needs to contain \"@\" character!"]);
        }
    }
}