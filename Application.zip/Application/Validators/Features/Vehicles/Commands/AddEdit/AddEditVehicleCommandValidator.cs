﻿using FluentValidation;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.Vehicles.Commands.AddEdit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Validators.Features.Vehicles.Commands.AddEdit
{
    public class AddEditVehicleCommandValidator : AbstractValidator<AddEditVehicleCommand>
    {
        public AddEditVehicleCommandValidator(IStringLocalizer<AddEditVehicleCommandValidator> localizer)
        {
            RuleFor(v => v.RegistrationNumber).MaximumLength(50).WithMessage(v => localizer["Registration Number can contain 50 characters max"]);
            RuleFor(v => v.IdCar).MaximumLength(50).WithMessage(v => localizer["Id Car can contain 50 characters max"]);
            RuleFor(v => v.IdCarType).MaximumLength(50).WithMessage(v => localizer["Id Car Type can contain 50 characters max"]);
            RuleFor(v => v.EngineDisplacement).MaximumLength(50).WithMessage(v => localizer["Engine Displacement can contain 50 characters max"]);
            RuleFor(v => v.EnginePower).MaximumLength(50).WithMessage(v => localizer["Engine Power can contain 50 characters max"]);
            RuleFor(v => v.InsurancePolicy).MaximumLength(150).WithMessage(v => localizer["Insurance Policy can contain 150 characters max"]);
            RuleFor(v => v.InsurancePolicyNumber).MaximumLength(150).WithMessage(v => localizer["Insurance Policy Number can contain 150 characters max"]);
            RuleFor(v => v.PriceListNumber).MaximumLength(150).WithMessage(v => localizer["Price List Number can contain 150 characters max"]);
            RuleFor(v => v.LicenseNumber).MaximumLength(150).WithMessage(v => localizer["License Number can contain 150 characters max"]);
        }
    }
}