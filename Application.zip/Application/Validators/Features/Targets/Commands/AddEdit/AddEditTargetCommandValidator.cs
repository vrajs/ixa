﻿using FluentValidation;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.Targets.Commands.AddEdit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Validators.Features.Targets.Commands.AddEdit
{
    public class AddEditTargetCommandValidator : AbstractValidator<AddEditTargetCommand>
    {
        public AddEditTargetCommandValidator(IStringLocalizer<AddEditTargetCommandValidator> localizer)
        {
            RuleFor(t => t.Phone).MaximumLength(55).WithMessage(t => localizer["Phone can contain 55 characters max"])
                                 .Matches("^[0-9+/-]*$").WithMessage(t => localizer["Phone can contain only numbers and characters \"+\", \"/\", \"-\""]);
            RuleFor(t => t.Number).MaximumLength(15).WithMessage(t => localizer["Number can contain 15 characters max"]);
            RuleFor(t => t.Lbl).MaximumLength(10).WithMessage(t => localizer["Lbl can contain 10 characters max"]);
            RuleFor(t => t.Status).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Status must be greater or equal 0"]);
            RuleFor(t => t.UnitId).MaximumLength(45).WithMessage(t => localizer["Unit Id can contain 45 characters max"]);
            RuleFor(t => t.Remark).MaximumLength(250).WithMessage(t => localizer["Remark can contain 250 characters max"]);
            RuleFor(t => t.IdClient).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Client must be greater or equal 0"]);
            RuleFor(t => t.IdRecord).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Record must be greater or equal 0"]);
            RuleFor(t => t.IdOperator).NotNull().WithMessage(t => localizer["Id Operator is required"])
                                      .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Operator must be greater or equal 0"]);
            RuleFor(t => t.IdDispatcher).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Dispatcher must be greater or equal 0"]);
            RuleFor(t => t.IdPartnerCompany).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Partner Company must be greater or equal 0"]);
            RuleFor(t => t.TaxiNumber).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Taxi Number must be greater or equal 0"]);
            RuleFor(t => t.Latitude).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Latitude must be greater or equal 0"]);
            RuleFor(t => t.Longitude).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Longitude must be greater or equal 0"]);
            RuleFor(t => t.OrientLatitude).MaximumLength(1).WithMessage(t => localizer["Orient Latitude can contain only one capital letter"])
                                          .Matches("[A-Z]").WithMessage(t => localizer["Orient Latitude can contain only one capital letter"]);
            RuleFor(t => t.OrientLongitude).MaximumLength(1).WithMessage(t => localizer["Orient Longitude can contain only one capital letter"])
                                           .Matches("[A-Z]").WithMessage(t => localizer["Orient Longitude can contain only one capital letter"]);
            RuleFor(t => t.Destination).MaximumLength(250).WithMessage(t => localizer["Destination can contain 250 characters max"]);
            RuleFor(t => t.Customer).MaximumLength(150).WithMessage(t => localizer["Customer can contain 150 characters max"]);
            RuleFor(t => t.IdStand).NotNull().WithMessage(t => localizer["Id Stand is required"])
                                   .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Stand must be greater or equal 0"]);
            RuleFor(t => t.IdZone).NotNull().WithMessage(t => localizer["Id Zone is required"])
                                  .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Zone must be greater or equal 0"]);
            RuleFor(t => t.Distance).MaximumLength(50).WithMessage(t => localizer["Distance can contain 50 characters max"]);
            RuleFor(t => t.TimeOfArrival).MaximumLength(50).WithMessage(t => localizer["Time Of Arrival can contain 50 characters max"]);
            RuleFor(t => t.IdCompanyCredential).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Company Credential must be greater or equal 0"]);
            RuleFor(t => t.Gdistance).MaximumLength(50).WithMessage(t => localizer["G Distance can contain 50 characters max"]);
            RuleFor(t => t.GtimeOfArrival).MaximumLength(50).WithMessage(t => localizer["G Time Of Arrival can contain 50 characters max"]);
            RuleFor(t => t.PhoneLine).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Phone Line must be greater or equal 0"]);
            RuleFor(t => t.ManualAssignReason).MaximumLength(200).WithMessage(t => localizer["Manual Assign Reason can contain 200 characters max"]);
            RuleFor(t => t.CompanyOrderNote).MaximumLength(200).WithMessage(t => localizer["Company Order Note can contain 200 characters max"]);
            RuleFor(t => t.DispatchType).NotNull().WithMessage(t => localizer["Dispatch Type is required"])
                                        .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Dispatch Type must be greater or equal 0"]);
            RuleFor(t => t.CancellationReason).NotNull().WithMessage(t => localizer["Cancellation Reason is required"]);
            RuleFor(t => t.DriverDelay).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Driver Delay must be greater or equal 0"]);
            RuleFor(t => t.OrderByDriver).MaximumLength(45).WithMessage(t => localizer["Order By Driver can contain 45 characters max"]);
            RuleFor(t => t.DriverPickupMin).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Driver Pickup Min must be greater or equal 0"]);
            RuleFor(t => t.BillingCenter).NotNull().WithMessage(t => localizer["Billing Center is required"])
                                         .MaximumLength(150).WithMessage(t => localizer["Billing Center can contain 150 characters max"]);
            RuleFor(t => t.Billingcenterr).MaximumLength(150).WithMessage(t => localizer["billing center can contain 150 characters max"]);
            RuleFor(t => t.OrdererName).MaximumLength(150).WithMessage(t => localizer["Orderer Name can contain 150 characters max"]);
            RuleFor(t => t.OrdererNote).MaximumLength(250).WithMessage(t => localizer["Orderer Note can contain 250 characters max"]);
            RuleFor(t => t.DestinationLatitude).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Destination Latitude must be greater or equal 0"]);
            RuleFor(t => t.DestinationLongitude).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Destination Longitude must be greater or equal 0"]);
            RuleFor(t => t.DispatchSubtype).NotNull().WithMessage(t => localizer["Dispatch Subtype is required"])
                                           .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Dispatch Subtype must be greater or equal 0"]);
            RuleFor(t => t.Passenger).MaximumLength(150).WithMessage(t => localizer["Passenger can contain 150 characters max"]);
            RuleFor(t => t.IdTariff).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Tariff must be greater or equal 0"]);
            RuleFor(t => t.IdInternalDepartment).NotNull().WithMessage(t => localizer["Id Internal Department is required"])
                                                .GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Internal Department must be greater or equal 0"]);
            RuleFor(t => t.IdInternalDepartmentUsed).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Internal Department Used must be greater or equal 0"]);
            RuleFor(t => t.PurchaseQuantity).MaximumLength(20).WithMessage(t => localizer["Purchase Quantity can contain 20 characters max"]);
            RuleFor(t => t.TripRemark).MaximumLength(250).WithMessage(t => localizer["Trip Remark can contain 250 characters max"]);
            RuleFor(t => t.LastUpdateBy).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Last Update By must be greater or equal 0"]);
            RuleFor(t => t.AssignedIdDriver).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Assigned Id Driver must be greater or equal 0"]);
            RuleFor(t => t.AssignedIdUnit).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Assigned Id Unit must be greater or equal 0"]);
            RuleFor(t => t.AssignedIdVehicle).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Assigned Id Vehicle must be greater or equal 0"]);
            RuleFor(t => t.IdServiceType).GreaterThanOrEqualTo(0).WithMessage(t => localizer["Id Service Type must be greater or equal 0"]);
            RuleFor(t => t.PassengerPhone).MaximumLength(20).WithMessage(t => localizer["Passenger Phone can contain 20 characters max"])
                                          .Matches("^[0-9+/-]*$").WithMessage(t => localizer["Passenger Phone can contain only numbers and characters \"+\", \"/\", \"-\""]);
            RuleFor(t => t.CardNumber).MaximumLength(30).WithMessage(t => localizer["Card Number can contain 30 characters max"])
                                      .Matches("^[0-9-]*$").WithMessage(t => localizer["Card Number can contain only numbers and character \"-\""]);
        }
    }
}