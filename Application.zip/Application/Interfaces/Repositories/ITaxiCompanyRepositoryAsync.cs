﻿namespace NetCabManager.Application.Interfaces.Repositories
{
    using NetCabManager.Application.Responses.Identity;
    using NetCabManager.Domain.Contracts;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    public interface ITaxiCompanyRepositoryAsync<T, in TId> where T : class, IEntity<TId>
    {
        IQueryable<T> Entities { get; }
        Task<T> GetByIdAsync(TId id);
        Task<List<T>> GetAllAsync();
        Task<List<T>> GetPagedResponseAsync(int pageNumber, int pageSize);
        Task<T> AddAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys);
        Task<int> UpdateAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys);
        Task<int> DeleteAsync(T entity, CancellationToken cancellationToken, params string[] cacheKeys);
    }
}