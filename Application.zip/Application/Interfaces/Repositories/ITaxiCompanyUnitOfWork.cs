﻿using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Interfaces.Repositories
{
    public interface ITaxiCompanyUnitOfWork<TId> : IDisposable
    {
        ITaxiCompanyRepositoryAsync<TEntity, TId> Repository<TEntity>() where TEntity : AuditableEntityTaxiCompany<TId>;
        //Task<int> Commit(CancellationToken cancellationToken);
        //Task<int> CommitAndRemoveCache(CancellationToken cancellationToken, params string[] cacheKeys);
        Task Rollback();
    }
}