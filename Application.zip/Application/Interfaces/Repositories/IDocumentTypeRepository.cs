﻿namespace NetCabManager.Application.Interfaces.Repositories
{
    public interface IDocumentTypeRepository
    {
    }
}