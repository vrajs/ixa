﻿using NetCabManager.Application.Features;
using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NetCabManager.Application.Interfaces.Repositories
{
    public interface ICompanyRepository
    {
        Task<Result<List<GetAllCompaniesResponse>>> GetAllCompaniesAsync();
    }
}