﻿namespace NetCabManager.Application.Interfaces.Common
{
    public interface IScopedService
    {
    }
}