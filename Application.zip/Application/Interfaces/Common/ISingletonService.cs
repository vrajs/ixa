﻿namespace NetCabManager.Application.Interfaces.Common
{
    public interface ISingletonService
    {
    }
}