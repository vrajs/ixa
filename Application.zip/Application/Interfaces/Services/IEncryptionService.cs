﻿namespace NetCabManager.Application.Interfaces.Services
{
    public interface IEncryptionService 
    {
        string Decrypt(string cipherText);
        string Encrypt(string input);
    }
}