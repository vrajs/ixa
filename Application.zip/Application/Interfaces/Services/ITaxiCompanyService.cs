﻿namespace NetCabManager.Application.Interfaces.Services
{
    using NetCabManager.Application.Features;
    using NetCabManager.Application.Features.Companies.Queries.GetAll;
    using NetCabManager.Application.Responses.Identity;
    using NetCabManager.Shared.TaxiCompany.Context;
    using System.Threading.Tasks;

    public interface ITaxiCompanyService
    {
        UserResponse User { get; set; }
        GetAllCompaniesResponse Company { get; set; }
        string ConnectionString { get; set; }

        Task GetCurrentUser(string userId);
        Task GetCurrentUserCompany(UserResponse user);
        string CreateConnectionString(GetAllCompaniesResponse Company);
        TaxiCompanyContext CreateDbContext(string connectionString);
    }
}