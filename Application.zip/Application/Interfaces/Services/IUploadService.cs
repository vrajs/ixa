﻿using NetCabManager.Application.Requests;

namespace NetCabManager.Application.Interfaces.Services
{
    public interface IUploadService
    {
        string UploadAsync(UploadRequest request);
    }
}