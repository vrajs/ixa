﻿using System.Collections.Generic;
using System.Threading.Tasks;
using NetCabManager.Application.Interfaces.Common;
using NetCabManager.Application.Requests.Identity;
using NetCabManager.Application.Responses.Identity;
using NetCabManager.Shared.Wrapper;

namespace NetCabManager.Application.Interfaces.Services.Identity
{
    public interface IRoleClaimService : IService
    {
        Task<Result<List<RoleClaimResponse>>> GetAllAsync();

        Task<int> GetCountAsync();

        Task<Result<RoleClaimResponse>> GetByIdAsync(int id);

        Task<Result<List<RoleClaimResponse>>> GetAllByRoleIdAsync(string roleId);

        Task<Result<string>> SaveAsync(RoleClaimRequest request);

        Task<Result<string>> DeleteAsync(int id);
    }
}