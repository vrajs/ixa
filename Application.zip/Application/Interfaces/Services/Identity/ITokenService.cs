﻿using NetCabManager.Application.Interfaces.Common;
using NetCabManager.Application.Requests.Identity;
using NetCabManager.Application.Responses.Identity;
using NetCabManager.Shared.Wrapper;
using System.Threading.Tasks;

namespace NetCabManager.Application.Interfaces.Services.Identity
{
    public interface ITokenService : IService
    {
        Task<Result<TokenResponse>> LoginAsync(TokenRequest model);

        Task<Result<TokenResponse>> GetRefreshTokenAsync(RefreshTokenRequest model);
    }
}