﻿using NetCabManager.Application.Requests.Mail;
using System.Threading.Tasks;

namespace NetCabManager.Application.Interfaces.Services
{
    public interface IMailService
    {
        Task SendAsync(MailRequest request);
    }
}