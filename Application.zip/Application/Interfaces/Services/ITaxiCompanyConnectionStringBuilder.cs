﻿namespace NetCabManager.Application.Interfaces.Services
{
    using NetCabManager.Application.Features;
    using NetCabManager.Application.Features.Companies.Queries.GetAll;

    public interface ITaxiCompanyConnectionStringBuilder
    {
        string CreateConnectionString(GetAllCompaniesResponse Company);
    }
}