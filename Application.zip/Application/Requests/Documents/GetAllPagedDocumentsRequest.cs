﻿using System;

namespace NetCabManager.Application.Requests.Documents
{
    public class GetAllPagedDocumentsRequest : PagedRequest
    {
        public string SearchString { get; set; }
        public int IdInternalDepartment { get; set; }
        public int RadioValue { get; set; }
        public int? Month { get; set; }
        public string DriverName { get; set; }
        public string DriverId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}