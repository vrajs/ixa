﻿namespace NetCabManager.Application.Requests.Identity
{
    public class ToggleUserStatusRequest
    {
        public string CompanyIdentification { get; set; }
        public int? InternalDepartmentId { get; set; }
        public int? PartnerCompanyId { get; set; }
        public bool ActivateUser { get; set; }
        public string UserId { get; set; }
    }
}