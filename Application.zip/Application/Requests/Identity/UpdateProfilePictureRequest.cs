﻿namespace NetCabManager.Application.Requests.Identity
{
    public class UpdateProfilePictureRequest : UploadRequest
    {
    }
}