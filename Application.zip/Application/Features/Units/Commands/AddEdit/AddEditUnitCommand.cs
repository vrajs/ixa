﻿namespace NetCabManager.Application.Features.Units.Commands.AddEdit
{
    using AutoMapper;
    using MediatR;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public enum UnitStatus
    {
        Pause = -1,
        Free = 0,
        TargetPending = 1,
        AtLocation = 2,
        DrivingCustomer = 3,
        DrivingFixedPriceRoute = 18,
        WaitingFixedPriceRoute = 19
    }

    public class AddEditUnitCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string UnitId { get; set; }
        public string IMEI { get; set; }
        public string IMSI { get; set; }
        //[RegularExpression(pattern: @"^(\-?([0-8]?[0-9](\.[0-9]{1,6})?|90(.[0]{1,6})))$", ErrorMessage = "Latitude value must be between -90 and 90")]
        public double? Latitude { get; set; }
        //[RegularExpression(pattern: @"^(\-?([1]?[0-7]?[0-9](\.[0-9]{1,6})?|180((.[0]{1,6})?)))$", ErrorMessage = "Longitude value must be between -180 and 180")]
        public double? Longitude { get; set; }
        public string OrientLatitude { get; set; }
        public string OrientLongitude { get; set; }
        public double? Speed { get; set; }
        public string DateTimeUpdate { get; set; }
        public string DateTimeIdle { get; set; }
        public double? Y { get; set; }
        public double? X { get; set; }
        public int? Status { get; set; }
        public DateTime? DateTimeTask { get; set; }
        public int? SOSPos { get; set; }
        public string SOS { get; set; }
        public int? IdUnitType { get; set; }
        public string DeviceId { get; set; }
        public string PhoneNumber { get; set; }
        public string IP { get; set; }
        public DateTime? UnitUpdate { get; set; }
        public string UnitIdTmp { get; set; }
        public bool? Position { get; set; }
        public bool? Service { get; set; }
        public int ZoneIn { get; set; }
        public int? ZoneTo { get; set; }
        public DateTime? ZoneArrival { get; set; }
        public int StandIn { get; set; }
        public DateTime? StandArrival { get; set; }
        public int TaxiMeter { get; set; }
        public DateTime? DestinationArrival { get; set; }
        public DateTime? DateTimeTaximeterFree { get; set; }
        public byte RequestedStatus { get; set; }
        public DateTime? LocationUpdate { get; set; }
        public byte ConnectionQuality { get; set; }
        public string DestinationAddress { get; set; }
        public double? DestinationLatitude { get; set; }
        public double? DestinationLongitude { get; set; }
        public int IdInternalDepartment { get; set; }
        public string DeviceSerialNumber { get; set; }
        public int? IdVehicle { get; set; }
        public int? IdDriver { get; set; }
        public string SIMSerialNumber { get; set; }
        public string IdTracker { get; set; }
        public bool NotifyPending { get; set; }
        public int? CurrentTariff { get; set; }
        public int? Heading { get; set; }
    }

    internal class AddEditUnitCommandHandler : IRequestHandler<AddEditUnitCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditUnitCommand> _localizer;

        public AddEditUnitCommandHandler(IMapper mapper,
                                         ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                         IStringLocalizer<AddEditUnitCommand> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditUnitCommand command, CancellationToken cancellationToken)
        {
            if (await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().Entities.Where(u => u.Id != command.Id)
                .AnyAsync(u => u.IMEI == command.IMEI, cancellationToken))
            {
                return await Result<int>.FailAsync(_localizer["IMEI already exists."]);
            }

            if (await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().Entities.Where(u => u.Id != command.Id)
                .AnyAsync(u => u.DeviceId == command.DeviceId, cancellationToken))
            {
                return await Result<int>.FailAsync(_localizer["Device Id already exists."]);
            }

            if (command.Id == 0)
            {
                var unitMapped = _mapper.Map<Domain.Entities.Catalog.Unit>(command);

                await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().AddAsync(unitMapped,
                                                                                                 cancellationToken,
                                                                                                 ApplicationConstants.Cache.GetAllUnitsCacheKey);

                return await Result<int>.SuccessAsync(unitMapped.Id, _localizer["Unit Saved."]);
            }
            else
            {
                var unit = await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().GetByIdAsync(command.Id);

                if (unit != null)
                {
                    unit.UnitId = command.UnitId ?? unit.UnitId;
                    unit.IMEI = command.IMEI ?? unit.IMEI;
                    unit.IMSI = command.IMSI ?? unit.IMSI;
                    unit.Latitude = command.Latitude ?? unit.Latitude;
                    unit.Longitude = command.Longitude ?? unit.Longitude;
                    unit.OrientLatitude = command.OrientLatitude ?? unit.OrientLatitude;
                    unit.OrientLongitude = command.OrientLongitude ?? unit.OrientLongitude;
                    unit.Speed = command.Speed ?? unit.Speed;
                    unit.DateTimeUpdate = command.DateTimeUpdate ?? unit.DateTimeUpdate;
                    unit.DateTimeIdle = command.DateTimeIdle ?? unit.DateTimeIdle;
                    unit.Y = command.Y ?? unit.Y;
                    unit.X = command.X ?? unit.X;
                    unit.Status = command.Status ?? unit.Status;
                    unit.DateTimeTask = command.DateTimeTask ?? unit.DateTimeTask;
                    unit.SOSPos = command.SOSPos ?? unit.SOSPos;
                    unit.SOS = command.SOS ?? unit.SOS;
                    unit.IdUnitType = command.IdUnitType ?? unit.IdUnitType;
                    unit.DeviceId = command.DeviceId ?? unit.DeviceId;
                    unit.PhoneNumber = command.PhoneNumber ?? unit.PhoneNumber;
                    unit.IP = command.IP ?? unit.IP;
                    unit.UnitUpdate = command.UnitUpdate ?? unit.UnitUpdate;
                    unit.UnitIdTmp = command.UnitIdTmp ?? unit.UnitIdTmp;
                    unit.Position = command.Position ?? unit.Position;
                    unit.Service = command.Service ?? unit.Service;
                    unit.ZoneIn = (command.ZoneIn < 0) ? unit.ZoneIn : command.ZoneIn;
                    unit.ZoneTo = command.ZoneTo ?? unit.ZoneTo;
                    unit.ZoneArrival = command.ZoneArrival ?? unit.ZoneArrival;
                    unit.StandIn = (command.StandIn < 0) ? unit.StandIn : command.StandIn;
                    unit.StandArrival = command.StandArrival ?? unit.StandArrival;
                    unit.TaxiMeter = (command.TaxiMeter < 0) ? unit.TaxiMeter : command.TaxiMeter;
                    unit.DestinationArrival = command.DestinationArrival ?? unit.DestinationArrival;
                    unit.DateTimeTaximeterFree = command.DateTimeTaximeterFree ?? unit.DateTimeTaximeterFree;
                    unit.RequestedStatus = (command.RequestedStatus < 0) ? unit.RequestedStatus : command.RequestedStatus;
                    unit.LocationUpdate = command.LocationUpdate ?? unit.LocationUpdate;
                    unit.ConnectionQuality = (command.ConnectionQuality < 0) ? unit.ConnectionQuality : command.ConnectionQuality;
                    unit.DestinationAddress = command.DestinationAddress ?? unit.DestinationAddress;
                    unit.DestinationLatitude = command.DestinationLatitude ?? unit.DestinationLatitude;
                    unit.DestinationLongitude = command.DestinationLongitude ?? unit.DestinationLongitude;
                    unit.IdInternalDepartment = (command.IdInternalDepartment < 0) ? unit.IdInternalDepartment : command.IdInternalDepartment;
                    unit.DeviceSerialNumber = command.DeviceSerialNumber ?? unit.DeviceSerialNumber;
                    unit.IdVehicle = command.IdVehicle ?? unit.IdVehicle;
                    unit.IdDriver = command.IdDriver ?? unit.IdDriver;
                    unit.SIMSerialNumber = command.SIMSerialNumber ?? unit.SIMSerialNumber;
                    unit.IdTracker = command.IdTracker ?? unit.IdTracker;
                    unit.NotifyPending = command.NotifyPending;
                    unit.CurrentTariff = command.CurrentTariff ?? unit.CurrentTariff;
                    unit.Heading = command.Heading ?? unit.Heading;

                    await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().UpdateAsync(unit,
                                                                                                        cancellationToken,
                                                                                                        ApplicationConstants.Cache.GetAllUnitsCacheKey);

                    return await Result<int>.SuccessAsync(unit.Id, _localizer["Unit Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Unit Not Found!"]);
                }
            }
        }
    }
}