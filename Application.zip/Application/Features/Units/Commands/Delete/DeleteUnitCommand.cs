﻿namespace NetCabManager.Application.Features.Units.Commands.Delete
{
    using MediatR;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class DeleteUnitCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteUnitCommandHandler : IRequestHandler<DeleteUnitCommand, Result<int>>
    {
        private readonly IStringLocalizer<DeleteUnitCommand> _localizer;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public DeleteUnitCommandHandler(IStringLocalizer<DeleteUnitCommand> localizer,
                                        ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _localizer = localizer;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<int>> Handle(DeleteUnitCommand command, CancellationToken cancellationToken)
        {
            var unit = await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().GetByIdAsync(command.Id);

            if (unit != null)
            {
                await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().DeleteAsync(unit, 
                                                                                                    cancellationToken, 
                                                                                                    ApplicationConstants.Cache.GetAllUnitsCacheKey);

                return await Result<int>.SuccessAsync(unit.Id, _localizer["Unit Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Unit Not Found!"]);
            }
        }
    }
}