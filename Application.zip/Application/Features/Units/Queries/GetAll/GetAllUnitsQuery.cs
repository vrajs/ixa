﻿namespace NetCabManager.Application.Features.Units.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllUnitsQuery : IRequest<Result<List<GetAllUnitsResponse>>>
    {
        public GetAllUnitsQuery()
        {
        }
    }

    internal class GetAllUnitsQueryHandler : IRequestHandler<GetAllUnitsQuery, Result<List<GetAllUnitsResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllUnitsQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllUnitsResponse>>> Handle(GetAllUnitsQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllUnitsCacheKey);

            Task<List<Domain.Entities.Catalog.Unit>> GetAllUnits() => _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().GetAllAsync();

            var unitList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllUnitsCacheKey, GetAllUnits);

            var mappedUnits = _mapper.Map<List<GetAllUnitsResponse>>(unitList);

            return await Result<List<GetAllUnitsResponse>>.SuccessAsync(mappedUnits);
        }
    }
}