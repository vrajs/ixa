﻿namespace NetCabManager.Application.Features.Units.Queries.GetAll
{
    using System;

    public enum UnitStatus
    {
        Pause = -1,
        Free = 0,
        TargetPending = 1,
        AtLocation = 2,
        DrivingCustomer = 3,
        DrivingFixedPriceRoute = 18,
        WaitingFixedPriceRoute = 19
    }

    public class GetAllUnitsResponse
    {
        public int Id { get; set; }
        public string UnitId { get; set; }
        public string IMEI { get; set; }
        public string IMSI { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public string OrientLatitude { get; set; }
        public string OrientLongitude { get; set; }
        public double? Speed { get; set; }
        public string DateTimeUpdate { get; set; }
        public string DateTimeIdle { get; set; }
        public double? Y { get; set; }
        public double? X { get; set; }
        public int? Status { get; set; }
        public DateTime? DateTimeTask { get; set; }
        public int? SOSPos { get; set; }
        public string SOS { get; set; }
        public int? IdUnitType { get; set; }
        public string DeviceId { get; set; }
        public string PhoneNumber { get; set; }
        public string IP { get; set; }
        public DateTime? UnitUpdate { get; set; }
        public string UnitIdTmp { get; set; }
        public bool? Position { get; set; }
        public bool? Service { get; set; }
        public int ZoneIn { get; set; }
        public int? ZoneTo { get; set; }
        public DateTime? ZoneArrival { get; set; }
        public int StandIn { get; set; }
        public DateTime? StandArrival { get; set; }
        public int TaxiMeter { get; set; }
        public DateTime? DestinationArrival { get; set; }
        public DateTime? DateTimeTaximeterFree { get; set; }
        public byte RequestedStatus { get; set; }
        public DateTime? LocationUpdate { get; set; }
        public byte ConnectionQuality { get; set; }
        public string DestinationAddress { get; set; }
        public double? DestinationLatitude { get; set; }
        public double? DestinationLongitude { get; set; }
        public int IdInternalDepartment { get; set; }
        public string DeviceSerialNumber { get; set; }
        public int? IdVehicle { get; set; }
        public int? IdDriver { get; set; }
        public string SIMSerialNumber { get; set; }
        public string IdTracker { get; set; }
        public bool NotifyPending { get; set; }
        public int? CurrentTariff { get; set; }
        public int? Heading { get; set; }
    }
}