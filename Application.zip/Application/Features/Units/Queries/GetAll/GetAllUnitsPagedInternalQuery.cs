﻿namespace NetCabManager.Application.Features.Units.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllUnitsPagedInternalQuery : IRequest<PaginatedResult<GetAllUnitsResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }
        public int IdInternalDepartment { get; set; }

        public GetAllUnitsPagedInternalQuery(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            IdInternalDepartment = idInternalDepartment;
        }
    }

    internal class GetAllUnitsPagedInternalQueryHandler : IRequestHandler<GetAllUnitsPagedInternalQuery, PaginatedResult<GetAllUnitsResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllUnitsPagedInternalQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllUnitsResponse>> Handle(GetAllUnitsPagedInternalQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<Domain.Entities.Catalog.Unit, GetAllUnitsResponse>> expression = e => new GetAllUnitsResponse
            {
                Id = e.Id,
                UnitId = e.UnitId,
                IMEI = e.IMEI,
                IMSI = e.IMSI,
                Latitude = e.Latitude,
                Longitude = e.Longitude,
                OrientLatitude = e.OrientLatitude,
                OrientLongitude = e.OrientLongitude,
                Speed = e.Speed,
                DateTimeUpdate = e.DateTimeUpdate,
                DateTimeIdle = e.DateTimeIdle,
                Y = e.Y,
                X = e.X,
                Status = e.Status,
                DateTimeTask = e.DateTimeTask,
                SOSPos = e.SOSPos,
                SOS = e.SOS,
                IdUnitType = e.IdUnitType,
                DeviceId = e.DeviceId,
                PhoneNumber = e.PhoneNumber,
                IP = e.IP,
                UnitUpdate = e.UnitUpdate,
                UnitIdTmp = e.UnitIdTmp,
                Position = e.Position,
                Service = e.Service,
                ZoneIn = e.ZoneIn,
                ZoneTo = e.ZoneTo,
                ZoneArrival = e.ZoneArrival,
                StandIn = e.StandIn,
                StandArrival = e.StandArrival,
                TaxiMeter = e.TaxiMeter,
                DestinationArrival = e.DestinationArrival,
                DateTimeTaximeterFree = e.DateTimeTaximeterFree,
                RequestedStatus = e.RequestedStatus,
                LocationUpdate = e.LocationUpdate,
                ConnectionQuality = e.ConnectionQuality,
                DestinationAddress = e.DestinationAddress,
                DestinationLatitude = e.DestinationLatitude,
                DestinationLongitude = e.DestinationLongitude,
                IdInternalDepartment = e.IdInternalDepartment,
                DeviceSerialNumber = e.DeviceSerialNumber,
                IdVehicle = e.IdVehicle,
                IdDriver = e.IdDriver,
                SIMSerialNumber = e.SIMSerialNumber,
                IdTracker = e.IdTracker,
                NotifyPending = e.NotifyPending,
                CurrentTariff = e.CurrentTariff,
                Heading = e.Heading
            };

            var unitsSpec = new UnitFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().Entities
               .Where(u => u.IdInternalDepartment == request.IdInternalDepartment)
               .Specify(unitsSpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}