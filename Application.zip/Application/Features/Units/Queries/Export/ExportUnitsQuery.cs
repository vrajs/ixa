﻿namespace NetCabManager.Application.Features.Units.Queries.Export
{
    using MediatR;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Interfaces.Services;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Application.Specifications.Catalog;

    public class ExportUnitsQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportUnitsQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportUnitsQueryHandler : IRequestHandler<ExportUnitsQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportUnitsQueryHandler> _localizer;

        public ExportUnitsQueryHandler(IExcelService excelService,
                                       ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, 
                                       IStringLocalizer<ExportUnitsQueryHandler> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportUnitsQuery request, CancellationToken cancellationToken)
        {
            var unitFilterSpec = new UnitFilterSpecification(request.SearchString);

            var units = await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().Entities
                .Specify(unitFilterSpec)
                .ToListAsync(cancellationToken);

            var data = await _excelService.ExportAsync(data: units, mappers: new Dictionary<string, Func<Domain.Entities.Catalog.Unit, object>>
            {
                { _localizer["Id"], item => item.Id },
                { _localizer["UnitId"], item => item.UnitId },
                { _localizer["IMEI"], item => item.IMEI },
                { _localizer["IMSI"], item => item.IMSI },
                { _localizer["Latitude"], item => item.Latitude },
                { _localizer["Longitude"], item => item.Longitude },
                { _localizer["OrientLatitude"], item => item.OrientLatitude },
                { _localizer["OrientLongitude"], item => item.OrientLongitude },
                { _localizer["Speed"], item => item.Speed },
                { _localizer["DateTimeUpdate"], item => item.DateTimeUpdate },
                { _localizer["DateTimeIdle"], item => item.DateTimeIdle },
                { _localizer["Y"], item => item.Y },
                { _localizer["X"], item => item.X },
                { _localizer["Status"], item => item.Status },
                { _localizer["DateTimeTask"], item => item.DateTimeTask },
                { _localizer["SOSPos"], item => item.SOSPos },
                { _localizer["SOS"], item => item.SOS },
                { _localizer["IdUnitType"], item => item.IdUnitType },
                { _localizer["DeviceId"], item => item.DeviceId },
                { _localizer["PhoneNumber"], item => item.PhoneNumber },
                { _localizer["IP"], item => item.IP },
                { _localizer["UnitUpdate"], item => item.UnitUpdate },
                { _localizer["UnitIdTmp"], item => item.UnitIdTmp },
                { _localizer["Position"], item => item.Position },
                { _localizer["Service"], item => item.Service },
                { _localizer["ZoneIn"], item => item.ZoneIn },
                { _localizer["ZoneTo"], item => item.ZoneTo },
                { _localizer["ZoneArrival"], item => item.ZoneArrival },
                { _localizer["StandIn"], item => item.StandIn },
                { _localizer["StandArrival"], item => item.StandArrival },
                { _localizer["TaxiMeter"], item => item.TaxiMeter },
                { _localizer["DestinationArrival"], item => item.DestinationArrival },
                { _localizer["DateTimeTaximeterFree"], item => item.DateTimeTaximeterFree },
                { _localizer["RequestedStatus"], item => item.RequestedStatus},
                { _localizer["LocationUpdate"], item => item.LocationUpdate },
                { _localizer["ConnectionQuality"], item => item.ConnectionQuality },
                { _localizer["DestinationAddress"], item => item.DestinationAddress },
                { _localizer["DestinationLatitude"], item => item.DestinationLatitude },
                { _localizer["DestinationLongitude"], item => item.DestinationLongitude },
                { _localizer["IdInternalDepartment"], item => item.IdInternalDepartment },
                { _localizer["DeviceSerialNumber"], item => item.DeviceSerialNumber },
                { _localizer["IdVehicle"], item => item.IdVehicle },
                { _localizer["IdDriver"], item => item.IdDriver },
                { _localizer["SIMSerialNumber"], item => item.SIMSerialNumber },
                { _localizer["IdTracker"], item => item.IdTracker },
                { _localizer["NotifyPending"], item => item.NotifyPending },
                { _localizer["CurrentTariff"], item => item.CurrentTariff },
                { _localizer["Heading"], item => item.Heading }
            }, sheetName: "Units");

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}