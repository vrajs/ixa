﻿namespace NetCabManager.Application.Features.Units.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.Units.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetUnitByIdQuery : IRequest<Result<GetAllUnitsResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetUnitByIdQueryHandler : IRequestHandler<GetUnitByIdQuery, Result<GetAllUnitsResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetUnitByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllUnitsResponse>> Handle(GetUnitByIdQuery query, CancellationToken cancellationToken)
        {
            var unit = await _taxiCompanyUnitOfWork.Repository<Domain.Entities.Catalog.Unit>().GetByIdAsync(query.Id);

            var mappedUnit = _mapper.Map<GetAllUnitsResponse>(unit);

            return await Result<GetAllUnitsResponse>.SuccessAsync(mappedUnit);
        }
    }
}