﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Invoices.Commands.Delete
{
    public class DeleteInvoiceCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteInvoiceCommandHandler : IRequestHandler<DeleteInvoiceCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeleteInvoiceCommandHandler> _localizer;

        public DeleteInvoiceCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                      IStringLocalizer<DeleteInvoiceCommandHandler> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeleteInvoiceCommand command, CancellationToken cancellationToken)
        {
            var invoice = await _taxiCompanyUnitOfWork.Repository<Invoice>().GetByIdAsync(command.Id);

            if (invoice != null)
            {
                await _taxiCompanyUnitOfWork.Repository<Invoice>().DeleteAsync(invoice,
                                                                                          cancellationToken,
                                                                                          ApplicationConstants.Cache.GetAllInvoicesCacheKey);

                return await Result<int>.SuccessAsync(invoice.Id, _localizer["Invoice Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Invoice Not Found!"]);
            }
        }
    }
}
