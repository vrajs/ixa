﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Invoices.Commands.AddEdit
{
    public class AddEditInvoiceCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public string DriverName { get; set; }
        public string Address { get; set; }
        public double? Price { get; set; }
        public string PaymentMethod { get; set; }
        public string CompanyIdentification { get; set; }
    }
    internal class AddEditInvoiceCommandHandler : IRequestHandler<AddEditInvoiceCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditInvoiceCommandHandler> _localizer;

        public AddEditInvoiceCommandHandler(IMapper mapper,
                                                       ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                       IStringLocalizer<AddEditInvoiceCommandHandler> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditInvoiceCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var mappedInvoices = _mapper.Map<Invoice>(command);

                await _taxiCompanyUnitOfWork.Repository<Invoice>().AddAsync(mappedInvoices,
                                                                                       cancellationToken,
                                                                                       ApplicationConstants.Cache.GetAllInvoicesCacheKey);

                return await Result<int>.SuccessAsync(mappedInvoices.Id, _localizer["Invoice Saved."]);
            }
            else
            {
                var invoice = await _taxiCompanyUnitOfWork.Repository<Invoice>().GetByIdAsync(command.Id);

                if (invoice != null)
                {
                    invoice.Id = (invoice.Id <= 0) ? invoice.Id : command.Id;
                    invoice.InvoiceDate = command.InvoiceDate;
                    invoice.Price = (int?)command.Price;
                    invoice.Address = command.Address;
                    invoice.DriverName = command.DriverName;
                    invoice.PaymentMethod = command.PaymentMethod;
                    invoice.CompanyIdentification = command.CompanyIdentification;

                    await _taxiCompanyUnitOfWork.Repository<Invoice>().UpdateAsync(invoice,
                                                                                              cancellationToken,
                                                                                              ApplicationConstants.Cache.GetAllInvoicesCacheKey);

                    return await Result<int>.SuccessAsync(invoice.Id, _localizer["Invoice Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Invoice Not Found!"]);
                }
            }
        }
    }
}
