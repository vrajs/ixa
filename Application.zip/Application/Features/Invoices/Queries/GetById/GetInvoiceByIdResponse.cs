﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Invoices.Queries.GetById
{
    public class GetInvoiceByIdResponse
    {
        public int Id { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public string DriverName { get; set; }
        public string Address { get; set; }
        public double? Price { get; set; }
        public string PaymentMethod { get; set; }
        public string CompanyIdentification { get; set; }
    }
}
