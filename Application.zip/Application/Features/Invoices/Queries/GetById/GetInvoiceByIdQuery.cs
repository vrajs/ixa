﻿using AutoMapper;
using MediatR;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Invoices.Queries.GetById
{
    public class GetInvoiceByIdQuery : IRequest<Result<GetAllInvoiceResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetInvoiceByIdQueryHandler : IRequestHandler<GetInvoiceByIdQuery, Result<GetAllInvoiceResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetInvoiceByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllInvoiceResponse>> Handle(GetInvoiceByIdQuery query, CancellationToken cancellationToken)
        {
            var invoice = await _taxiCompanyUnitOfWork.Repository<Invoice>().GetByIdAsync(query.Id);

            var mappedInvoice = _mapper.Map<GetAllInvoiceResponse>(invoice);

            return await Result<GetAllInvoiceResponse>.SuccessAsync(mappedInvoice);
        }
    }
}
