﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using System.Data.SqlClient;
using System.Data;
using AutoMapper;
using System.Globalization;

namespace NetCabManager.Application.Features.Invoices.Queries.Export
{
    public class ExportInvoiceQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportInvoiceQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportInvoiceQueryHandler : IRequestHandler<ExportInvoiceQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportInvoiceQueryHandler> _localizer;
        private readonly IMapper _mapper;
        public ExportInvoiceQueryHandler(IExcelService excelService,
                                                     ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                     IStringLocalizer<ExportInvoiceQueryHandler> localizer,IMapper mapper)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
            _mapper= mapper;    
        }

        public async Task<Result<string>> Handle(ExportInvoiceQuery request, CancellationToken canncelationToken)
        {
            var invoiceFilterSpec = new InvoiceFilterSpecification(request.SearchString);

           
            
            try
            {


                //return new PaginatedResult<GetAllInvoiceResponse>(aa);
                SqlConnection connection = new SqlConnection("Data Source = vps3.net-informatika.com,34262\\SqlServer03; Initial Catalog = AVTS_MetroTmp; Uid = NetCabUser; Pwd = Taxi_User_GG");

                SqlCommand command = new SqlCommand("InvoicingDriverRidesInMonth", connection);
                command.Parameters.Add("@month", SqlDbType.Int).Value = 2;
                command.Parameters.Add("@paymentType", SqlDbType.Int).Value = null;
                command.Parameters.Add("@IdDriver", SqlDbType.Int).Value = null;
                command.Parameters.Add("@pageSize", SqlDbType.Int).Value = null;
                command.Parameters.Add("@pageNumber", SqlDbType.Int).Value = null;

                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());


                //List<GetAllInvoiceResponse> TestList = new List<GetAllInvoiceResponse>();
                List<GetAllInvoiceResponse> aa = new List<GetAllInvoiceResponse>();
                foreach (DataRow row in dt.Rows)
                {
                    GetAllInvoiceResponse test = new GetAllInvoiceResponse();
                    test.DriverName = row["Driver"].ToString();
                    test.Address = row["street"].ToString();
                    test.Id = int.Parse(row["id_target"].ToString());
                    string s = row["dispatchat"].ToString();
                    s = s.Replace(".", "-").Substring(0, s.Length - 6);
                    test.InvoiceDate = Convert.ToDateTime(DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture));
                    test.PaymentMethod = row["paymentType"].ToString();
                    test.Price = double.Parse(row["Price"].ToString());
                    aa.Add(test);
                }
                var mappedInvoiceList = _mapper.Map<List<Invoice>>(aa);
                var data = await _excelService.ExportAsync(mappedInvoiceList, mappers: new Dictionary<string, Func<Invoice, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["Invoice Date"], c => c.InvoiceDate },
                { _localizer["Price"], c => c.Price },
                { _localizer["Address"], c => c.Address },
                { _localizer["DriverName"], c => c.DriverName },
                //{ _localizer["CompanyIdentification"], c => c.CompanyIdentification },
                { _localizer["PaymentMethod"], c => c.PaymentMethod }
            }, sheetName: _localizer["Invoices"]);

                return await Result<string>.SuccessAsync(data: data);
            }
            catch (Exception e)
            {
                throw;
            }
            //var invoices = await _taxiCompanyUnitOfWork.Repository<Invoice>().Entities
            //                                                      .Specify(invoiceFilterSpec).ToListAsync(canncelationToken);
           
        }
    }
}
