﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Wrapper;
using MediatR;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AutoMapper;
using System.Globalization;

namespace NetCabManager.Application.Features.Invoices.Queries.GetAll
{
    public class GetAllInvoicePagedQuery : IRequest<Result<List<GetAllInvoiceResponse>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }

        public string Month { get; set; }
        public string DriverName { get; set; }
        public GetAllInvoicePagedQuery(int pageNumber, int pageSize, string searchString, string month, string driverName)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            Month = month;
            DriverName = driverName;
        }
    }

    internal class GetAllInvoicePagedQueryHandler : IRequestHandler<GetAllInvoicePagedQuery, Result<List<GetAllInvoiceResponse>>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IMapper _mapper;
        public GetAllInvoicePagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IMapper mapper)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<List<GetAllInvoiceResponse>>> Handle(GetAllInvoicePagedQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<Invoice, GetAllInvoiceResponse>> expression = e => new GetAllInvoiceResponse
            {
                Id = e.Id,
                InvoiceDate = e.InvoiceDate,
                Price = e.Price,
                Address = e.Address,
                DriverName = e.DriverName,
                PaymentMethod = e.PaymentMethod,
                CompanyIdentification = e.CompanyIdentification
            };
            List<GetAllInvoiceResponse> aa = new List<GetAllInvoiceResponse>();
            try
            {
                if (request.PageSize == 0)
                {
                    request.PageSize = 1;
                }
                SqlConnection connection = new SqlConnection("Data Source = vps3.net-informatika.com,34262\\SqlServer03; Initial Catalog = AVTS_MetroTmp; Uid = NetCabUser; Pwd = Taxi_User_GG");

                SqlCommand command = new SqlCommand("InvoicingDriverRidesInMonth", connection);
                command.Parameters.Add("@month", SqlDbType.Int).Value = request.Month == "0" ? 1 : int.Parse(request.Month);
                command.Parameters.Add("@paymentType", SqlDbType.Int).Value = null;
                command.Parameters.Add("@IdDriver", SqlDbType.Int).Value = null;
                command.Parameters.Add("@pageSize", SqlDbType.Int).Value = request.PageSize == 0 ? null : request.PageSize;
                command.Parameters.Add("@pageNumber", SqlDbType.Int).Value = request.PageNumber == 0 ? null : request.PageNumber;
                command.Parameters.Add("@paymentMethod", SqlDbType.VarChar).Value = request.SearchString == null ? null : request.SearchString;
                command.Parameters.Add("@driverName", SqlDbType.VarChar).Value = request.DriverName == null ? null : request.DriverName;

                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    var test = new GetAllInvoiceResponse();
                    test.DriverName = row["Driver"].ToString();
                    test.Address = row["street"].ToString();
                    test.Id = int.Parse(row["id_target"].ToString());
                    string s = row["dispatchat"].ToString();
                    s = s.Replace(".", "-").Substring(0, s.Length - 6);
                    test.InvoiceDate = Convert.ToDateTime(DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture));
                    test.PaymentMethod = row["paymentType"].ToString();
                    test.Price = double.Parse(row["Price"].ToString());
                    aa.Add(test);
                }
            }
            catch (Exception e)
            {

                throw;
            }
            var invoiceSpec = new InvoiceFilterSpecification(request.SearchString);

            //var data = await _taxiCompanyUnitOfWork.Repository<Invoice>().Entities
            //   .Specify(invoiceSpec)
            //   .Select(expression)
            //   .ToPaginatedListAsync(request.PageNumber, request.PageSize);
            var mappedInvoiceList = _mapper.Map<List<GetAllInvoiceResponse>>(aa);
            return await Result<List<GetAllInvoiceResponse>>.SuccessAsync(mappedInvoiceList);
        }
    }
}
