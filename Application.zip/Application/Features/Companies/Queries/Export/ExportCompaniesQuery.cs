﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NetCabManager.Shared.Wrapper;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Extensions;

namespace NetCabManager.Application.Features.Companies.Queries.Export
{
    public class ExportCompaniesQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportCompaniesQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportCompaniesQueryHandler : IRequestHandler<ExportCompaniesQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IStringLocalizer<ExportCompaniesQueryHandler> _localizer;

        public ExportCompaniesQueryHandler(IExcelService excelService, 
                                           IUnitOfWork<string> unitOfWork, 
                                           IStringLocalizer<ExportCompaniesQueryHandler> localizer)
        {
            _excelService = excelService;
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportCompaniesQuery request, CancellationToken canncelationToken)
        {
            var companyFilterSpec = new CompanyFilterSpecification(request.SearchString);

            var companies = await _unitOfWork.Repository<Company>().Entities.Specify((NetCabManager.Application.Specifications.Base.ISpecification<Company>)companyFilterSpec).ToListAsync(canncelationToken);

            var data = await _excelService.ExportAsync(companies, mappers: new Dictionary<string, Func<Company, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["Can Issue Update"], c => c.CanIssueUpdate },
                { _localizer["Sql Server Ip"], c => c.SqlServerIp },
                { _localizer["Sql Instance Name"], c => c.SqlInstanceName },
                { _localizer["Sql Instance Port"], c => c.SqlInstancePort },
                { _localizer["Sql Database Name"], c => c.SqlDatabaseName },
                { _localizer["Sql Server Username"], c => c.SqlServerUsername },
                { _localizer["Sql Server Password"], c => c.SqlServerPassword },
                { _localizer["Company Title"], c => c.CompanyTitle },
                { _localizer["Note"], c => c.Note },
                { _localizer["Update Parameter Id"], c => c.UpdateParameterId },
                { _localizer["Unit Server Host"], c => c.UnitServerHost },
                { _localizer["Unit Server Port"], c => c.UnitServerPort },
                { _localizer["Web Service Host"], c => c.WebServiceHost },
                { _localizer["Primary Color"], c => c.PrimaryColor }
            }, sheetName: _localizer["Companies"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}