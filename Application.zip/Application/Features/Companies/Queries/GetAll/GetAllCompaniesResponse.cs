﻿namespace NetCabManager.Application.Features.Companies.Queries.GetAll
{
    using System.Drawing;

    public class GetAllCompaniesResponse
    {
        public string Id { get; set; }
        public bool CanIssueUpdate { get; set; }
        public string SqlServerIp { get; set; }
        public string SqlInstanceName { get; set; }
        public int SqlInstancePort { get; set; }
        public string SqlDatabaseName { get; set; }
        public string SqlServerUsername { get; set; }
        public string SqlServerPassword { get; set; }
        public string SqlServerPasswordDecrypted { get; set; }
        public string CompanyTitle { get; set; }
        public string Note { get; set; }
        public int? UpdateParameterId { get; set; }
        public string UnitServerHost { get; set; }
        public int UnitServerPort { get; set; }
        public string WebServiceHost { get;  set; }
        public string PrimaryColor { get; set; } = ColorTranslator.FromHtml("#000000").ToString();
        public int CompanyCounter { get; set; }
        public string ConnectionString { get; set; }
        // public ServiceStatus ServiceStatus { get; set; }
        // public DriverApplicationSetting DriverApplicationSetting { get; set; }
        // public List<JobStatisticDaily> JobStatisticDailies { get; set; }
    }
}