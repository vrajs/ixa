﻿using AutoMapper;
using NetCabManager.Application.Features;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using LazyCache;
using MediatR;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Domain.Entities.Catalog;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Companies.Queries.GetAll
{
    public class GetAllCompaniesQuery : IRequest<Result<List<GetAllCompaniesResponse>>>
    {
        public GetAllCompaniesQuery()
        {
        }
    }

    internal class GetAllCompaniesCachedQueryHandler : IRequestHandler<GetAllCompaniesQuery, Result<List<GetAllCompaniesResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IAppCache _appCache;
        private readonly IEncryptionService _encryptionService;

        public GetAllCompaniesCachedQueryHandler(IMapper mapper, 
                                                 IUnitOfWork<string> unitOfWork, 
                                                 IAppCache appCache,
                                                 IEncryptionService encryptionService)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _appCache = appCache;
            _encryptionService = encryptionService;
        }

        public async Task<Result<List<GetAllCompaniesResponse>>> Handle(GetAllCompaniesQuery request, CancellationToken cancellationToken)
        {
            Task<List<Company>> GetAllCompanies() => _unitOfWork.Repository<Company>().GetAllAsync();

            var companyList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllCompaniesCacheKey, GetAllCompanies);

            var mappedCompanies = _mapper.Map<List<GetAllCompaniesResponse>>(companyList);

            //mappedCompanies.ForEach(Company =>
            //{
            //    Company.SqlServerPasswordDecrypted = _encryptionService.Decrypt(Company.SqlServerPassword);
            //});

            return await Result<List<GetAllCompaniesResponse>>.SuccessAsync(mappedCompanies);
        }
    }
}