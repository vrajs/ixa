﻿using Microsoft.AspNetCore.DataProtection;
using NetCabManager.Application.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Companies.Queries.GetById
{
    public class GetCompanyByIdResponse
    {
        public string Id { get; set; }
        public bool CanIssueUpdate { get; set; }
        public string SqlServerIp { get; set; }
        public string SqlInstanceName { get; set; }
        public int SqlInstancePort { get; set; }
        public string SqlDatabaseName { get; set; }
        public string SqlServerUsername { get; set; }
        public string SqlServerPassword { get; set; }        
        public string SqlServerPasswordDecrypted { get; set; }
        public string CompanyTitle { get; set; }
        public string Note { get; set; }
        public int? UpdateParameterId { get; set; }
        public string UnitServerHost { get; set; }
        public int UnitServerPort { get; set; }
        public string WebServiceHost { get; private set; }
        public string PrimaryColor { get; set; }
        public int CompanyCounter { get; set; }
        // public ServiceStatus ServiceStatus { get; set; }
        // public DriverApplicationSetting DriverApplicationSetting { get; set; }
        // public List<JobStatisticDaily> JobStatisticDailies { get; set; }
    }
}