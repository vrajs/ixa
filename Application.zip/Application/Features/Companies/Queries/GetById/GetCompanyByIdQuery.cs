﻿using AutoMapper;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Wrapper;
using MediatR;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Features.Companies.Queries.GetById;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Domain.Entities.Catalog;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Companies.Queries.GetById
{
    public class GetCompanyByIdQuery : IRequest<Result<GetCompanyByIdResponse>>
    {
        public string Id { get; set; }
    }

    internal class GetCompanyByIdQueryHandler : IRequestHandler<GetCompanyByIdQuery, Result<GetCompanyByIdResponse>>
    {
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IStringLocalizer<GetCompanyByIdQueryHandler> _localizer;
        private readonly IDataProtector _dataProtector;
        private readonly IEncryptionService _encryptionService;

        public GetCompanyByIdQueryHandler(IUnitOfWork<string> unitOfWork,
                                          IMapper mapper,
                                          IStringLocalizer<GetCompanyByIdQueryHandler> localizer,
                                          IDataProtectionProvider dataProtectionProvider,
                                          IEncryptionService encryptionService)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _localizer = localizer;
            _encryptionService = encryptionService;
            _dataProtector = dataProtectionProvider.CreateProtector(typeof(Company).FullName);
        }

        public async Task<Result<GetCompanyByIdResponse>> Handle(GetCompanyByIdQuery query, CancellationToken cancellationToken)
        {
            var Company = await _unitOfWork.Repository<Company>().GetByIdAsync(query.Id);

            if (Company != null)
            {
                //try
                //{
                //    _dataProtector.Unprotect(Company.SqlServerPassword);
                //}
                //catch
                //{
                //    //string not encrypted
                //    Company.SqlServerPassword = _dataProtector.Protect(Company.SqlServerPassword);
                //}

                var mappedCompany = _mapper.Map<GetCompanyByIdResponse>(Company);

                //mappedCompany.SqlServerPasswordDecrypted = _encryptionService.Decrypt(mappedCompany.SqlServerPassword);

                return await Result<GetCompanyByIdResponse>.SuccessAsync(mappedCompany);
            }
            else
            {
                return await Result<GetCompanyByIdResponse>.FailAsync(_localizer["Company Not Found!"]);
            }
        }
    }
}