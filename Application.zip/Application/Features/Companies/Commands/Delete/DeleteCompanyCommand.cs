﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Domain.Entities.Catalog;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Companies.Commands.Delete
{
    public class DeleteCompanyCommand : IRequest<Result<string>>
    {
        public string Id { get; set; }
    }

    internal class DeleteCompanyCommandHandler : IRequestHandler<DeleteCompanyCommand, Result<string>>
    {
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IStringLocalizer<DeleteCompanyCommandHandler> _localizer;

        public DeleteCompanyCommandHandler(IUnitOfWork<string> unitOfWork, IStringLocalizer<DeleteCompanyCommandHandler> localizer)
        {
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(DeleteCompanyCommand command, CancellationToken cancellationToken)
        {
            var Company = await _unitOfWork.Repository<Company>().GetByIdAsync(command.Id);

            if (Company != null)
            {
                await _unitOfWork.Repository<Company>().DeleteAsync(Company);
                
                await _unitOfWork.CommitAndRemoveCache(cancellationToken, ApplicationConstants.Cache.GetAllCompaniesCacheKey);
                
                return await Result<string>.SuccessAsync(Company.Id, _localizer["Company Deleted."]);
            }
            else
            {
                return await Result<string>.FailAsync(_localizer["Company Not Found!"]);
            }
        }
    }
}