﻿using AutoMapper;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using MediatR;
//using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Domain.Entities.Catalog;
using System.Threading;
using System.Threading.Tasks;
using NetCabManager.Domain.Entities.Catalog;

namespace NetCabManager.Application.Features.Companies.Commands.AddEdit
{
    public partial class AddEditCompanyCommand : IRequest<Result<string>>
    {
        public string Id { get; set; }
        public bool CanIssueUpdate { get; set; }
        public string SqlServerIp { get; set; }
        public string SqlInstanceName { get; set; }
        public int SqlInstancePort { get; set; }
        public string SqlDatabaseName { get; set; }
        public string SqlServerUsername { get; set; }
        public string SqlServerPassword { get; set; }
        public string CompanyTitle { get; set; }
        public string Note { get; set; }
        public int? UpdateParameterId { get; set; }
        public string UnitServerHost { get; set; }
        public int UnitServerPort { get; set; }
        public string WebServiceHost { get; set; }
        public string PrimaryColor { get; set; }
        public int CompanyCounter { get; set; }

        // public ServiceStatus ServiceStatus { get; set; }

        // public DriverApplicationSetting DriverApplicationSetting { get; set; }

        // public List<JobStatisticDaily> JobStatisticDailies { get; set; }
    }

    internal class AddEditCompanyCommandHandler : IRequestHandler<AddEditCompanyCommand, Result<string>>
    {
        private readonly IMapper _mapper;
        private readonly IStringLocalizer<AddEditCompanyCommandHandler> _localizer;
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IEncryptionService _encryptionService;
        private readonly IDataProtector _dataProtector;

        public AddEditCompanyCommandHandler(IMapper mapper, 
                                            IStringLocalizer<AddEditCompanyCommandHandler> stringLocalizer, 
                                            IUnitOfWork<string> unitOfWork,
                                            IEncryptionService encryptionService,
                                            IDataProtectionProvider dataProtectionProvider)
        {
            _mapper = mapper;
            _localizer = stringLocalizer;
            _unitOfWork = unitOfWork;
            _encryptionService = encryptionService;
            _dataProtector = dataProtectionProvider.CreateProtector(typeof(Company).FullName);
        }

        public async Task<Result<string>> Handle(AddEditCompanyCommand companyCommand, CancellationToken cancelationToken)
        {
            if (companyCommand.CompanyCounter == 0)
            {
                var companyMaped = _mapper.Map<Company>(companyCommand);

                //if (!string.IsNullOrEmpty(companyMaped.SqlServerPassword))
                //{
                //    companyMaped.SqlServerPassword = _encryptionService.Encrypt(companyMaped.SqlServerPassword);
                //}
                
                await _unitOfWork.Repository<Company>().AddAsync(companyMaped);
                
                await _unitOfWork.CommitAndRemoveCache(cancelationToken, ApplicationConstants.Cache.GetAllCompaniesCacheKey);

                return await Result<string>.SuccessAsync(companyMaped.Id, _localizer["Company Saved."]);
            }
            else
            {
                var Company = await _unitOfWork.Repository<Company>().GetByIdAsync(companyCommand.Id);

                if (Company != null)
                {
                    Company.Id = companyCommand.Id ?? Company.Id;
                    Company.CanIssueUpdate = companyCommand.CanIssueUpdate;
                    Company.SqlServerIp = companyCommand.SqlServerIp ?? Company.SqlServerIp;
                    Company.SqlInstanceName = companyCommand.SqlInstanceName ?? Company.SqlInstanceName;
                    Company.SqlInstancePort = (companyCommand.SqlInstancePort <= 0) ? Company.SqlInstancePort : companyCommand.SqlInstancePort;
                    Company.SqlDatabaseName = companyCommand.SqlDatabaseName ?? Company.SqlDatabaseName;
                    Company.SqlServerUsername = companyCommand.SqlServerUsername ?? Company.SqlServerUsername;
                    //Company.SqlServerPassword = _encryptionService.Encrypt(companyCommand.SqlServerPassword);
                    Company.SqlServerPassword = companyCommand.SqlServerPassword;
                    Company.CompanyTitle = companyCommand.CompanyTitle ?? Company.CompanyTitle;
                    Company.Note = companyCommand.Note ?? Company.Note;
                    Company.UpdateParameterId = (companyCommand.UpdateParameterId < 0) ? Company.UpdateParameterId : companyCommand.UpdateParameterId;
                    Company.UnitServerHost = companyCommand.UnitServerHost ?? Company.UnitServerHost;
                    Company.UnitServerPort = (companyCommand.UnitServerPort < 0) ? Company.UnitServerPort : companyCommand.UnitServerPort;
                    Company.WebServiceHost = companyCommand.WebServiceHost ?? Company.WebServiceHost;
                    Company.PrimaryColor = companyCommand.PrimaryColor ?? Company.PrimaryColor;
                    Company.CompanyCounter = companyCommand.CompanyCounter;

                    await _unitOfWork.Repository<Company>().UpdateAsync(Company);

                    await _unitOfWork.CommitAndRemoveCache(cancelationToken, ApplicationConstants.Cache.GetAllCompaniesCacheKey);

                    return await Result<string>.SuccessAsync(Company.Id, _localizer["Company Updated."]);
                }
                else
                {
                    return await Result<string>.FailAsync(_localizer["Company Not Found!"]);
                }
            }
        }
    }
}