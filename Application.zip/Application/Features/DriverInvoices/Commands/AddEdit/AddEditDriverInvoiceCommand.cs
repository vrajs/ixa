﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.DriverInvoices.Commands.AddEdit
{
    public class AddEditDriverInvoiceCommand : IRequest<Result<int>>
    {
        public int DriverId { get; set; }
        public int? UnitId { get; set; }
        public string DriverName { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }

        public int? Num { get; set; }
        public double? DriverPrice { get; set; }
        public double? DriverShare { get; set; }
        public int? CardNum { get; set; }
        public double? CardSum { get; set; }
        public double? PaymentToDriver { get; set; }
        public double? PaymentOfDriver { get; set; }
        public double? DriverCommission { get; set; }
        public double? NetCabCommission { get; set; }
        public string CompanyIdentification { get; set; }
    }
    internal class AddEditDriverInvoiceCommandHandler : IRequestHandler<AddEditDriverInvoiceCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditDriverInvoiceCommandHandler> _localizer;

        public AddEditDriverInvoiceCommandHandler(IMapper mapper,
                                                       ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                       IStringLocalizer<AddEditDriverInvoiceCommandHandler> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditDriverInvoiceCommand command, CancellationToken cancellationToken)
        {
            if (command.DriverId == 0)
            {
                var mappedInvoices = _mapper.Map<DriverInvoice>(command);

                await _taxiCompanyUnitOfWork.Repository<DriverInvoice>().AddAsync(mappedInvoices,
                                                                                       cancellationToken,
                                                                                       ApplicationConstants.Cache.GetAllDriverInvoicesCacheKey);

                return await Result<int>.SuccessAsync(mappedInvoices.Id, _localizer["Driver Invoice Saved."]);
            }
            else
            {
                var invoice = await _taxiCompanyUnitOfWork.Repository<DriverInvoice>().GetByIdAsync(command.DriverId);

                if (invoice != null)
                {
                    invoice.DriverId = (invoice.DriverId <= 0) ? invoice.DriverId : command.DriverId;
                    invoice.UnitId = (invoice.UnitId <= 0) ? invoice.UnitId : command.UnitId;
                    invoice.DriverName = command.DriverName;
                    invoice.DateFrom = command.DateFrom;
                    invoice.DateTo = command.DateTo;
                    invoice.Num = command.Num;
                    invoice.DriverPrice = command.DriverPrice;
                    invoice.DriverShare = command.DriverShare;
                    invoice.CardNum = command.CardNum;
                    invoice.CardSum = command.CardSum;
                    invoice.PaymentToDriver = command.PaymentToDriver;
                    invoice.PaymentOfDriver = command.PaymentOfDriver;
                    invoice.DriverCommission = command.DriverCommission;
                    invoice.NetCabCommission = command.NetCabCommission;
                    invoice.CompanyIdentification = command.CompanyIdentification;

                    await _taxiCompanyUnitOfWork.Repository<DriverInvoice>().UpdateAsync(invoice,
                                                                                              cancellationToken,
                                                                                              ApplicationConstants.Cache.GetAllDriverInvoicesCacheKey);

                    return await Result<int>.SuccessAsync(invoice.Id, _localizer["Drvier Invoice Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Driver Invoice Not Found!"]);
                }
            }
        }
    }
}
