﻿using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Responses.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.DriverInvoices.Queries.GetAll
{
    public class GetAllRidesResponse
    {
        public int? TargetId { get; set; }
      
        public string DriverName { get; set; }
        public DateTime? DispatchDate { get; set; }
        public string Street { get; set; }
        public string Destination { get; set; }
        public string PaymentType { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public int CustomerId { get; set; }
        public string TaxiCompanyName { get; set; }
        public string TaxiCompanyAddress { get; set; }
        public double? PriceWithOutVat { get; set; }
        public double? Vat { get; set; }
        public double? PriceTotal { get; set; }
    }
}
