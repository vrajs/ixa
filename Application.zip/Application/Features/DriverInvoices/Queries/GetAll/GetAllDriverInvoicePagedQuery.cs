﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Wrapper;
using MediatR;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AutoMapper;
using System.Globalization;

namespace NetCabManager.Application.Features.DriverInvoices.Queries.GetAll
{
    public class GetAllDriverInvoicePagedQuery : IRequest<Result<List<GetAllDriverInvoiceResponse>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }
        public int? Month { get; set; }
        public int? driverId { get; set; }
        public string DriverName { get; set; }
        public GetAllDriverInvoicePagedQuery(int pageNumber, int pageSize, string searchString, int? month, string driverName)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            Month = month;
            DriverName = driverName;
        }
    }

    internal class GetAllDriverInvoicePagedQueryHandler : IRequestHandler<GetAllDriverInvoicePagedQuery, Result<List<GetAllDriverInvoiceResponse>>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IMapper _mapper;
        public GetAllDriverInvoicePagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IMapper mapper)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<List<GetAllDriverInvoiceResponse>>> Handle(GetAllDriverInvoicePagedQuery request, CancellationToken cancellationToken)
        {
            //Expression<Func<DriverInvoice, GetAllDriverInvoiceResponse>> expression = e => new GetAllDriverInvoiceResponse
            //{
            //    Id = e.Id,
            //    InvoiceDate = e.InvoiceDate,
            //    Price = e.Price,
            //    Address = e.Address,
            //    DriverName = e.DriverName,
            //    PaymentMethod = e.PaymentMethod,
            //    CompanyIdentification = e.CompanyIdentification
            //};
            List<GetAllDriverInvoiceResponse> aa = new List<GetAllDriverInvoiceResponse>();
            try
            {
                if (request.PageSize == 0)
                {
                    request.PageSize = 1;
                }
                SqlConnection connection = new SqlConnection("Data Source = vps3.net-informatika.com,34262\\SqlServer03; Initial Catalog = AVTS_MetroTmp; Uid = NetCabUser; Pwd = Taxi_User_GG");

                SqlCommand command = new SqlCommand("InvoicingDriverCommissionInMonth", connection);
                command.Parameters.Add("@month", SqlDbType.Int).Value = request.SearchString == null ? 1 : int.Parse(request.SearchString);
                command.Parameters.Add("@pageSize", SqlDbType.Int).Value = request.PageSize == 0 ? null : request.PageSize;
                command.Parameters.Add("@pageNumber", SqlDbType.Int).Value = request.PageNumber == 0 ? null : request.PageNumber;
                command.Parameters.Add("@driverName", SqlDbType.VarChar).Value = request.DriverName == null ? null : request.DriverName;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    GetAllDriverInvoiceResponse test = new GetAllDriverInvoiceResponse();
                    test.DriverId = int.Parse(row["id_driver"].ToString());
                    test.UnitId = int.Parse(row["unit_id"].ToString());
                    test.DriverName = row["driverName"].ToString();
                    string s = row["DateFrom"].ToString();
                    s = s.Replace(".", "-");
                    test.DateFrom = Convert.ToDateTime(DateTime.ParseExact(s, "dd-MM-yy", CultureInfo.InvariantCulture));
                    string s2 = row["DateTo"].ToString();
                    s2 = s2.Replace(".", "-");
                    test.DateTo = Convert.ToDateTime(DateTime.ParseExact(s2, "dd-MM-yy", CultureInfo.InvariantCulture));
                    test.Num = int.Parse(row["num"].ToString());
                    test.DriverPrice = double.Parse(row["driverPrice"].ToString());
                    test.DriverShare = double.Parse(row["driverShare"].ToString());
                    test.CardNum = int.Parse(row["CardNum"].ToString());
                    test.CardSum = double.Parse(row["CardSum"].ToString());
                    test.PaymentToDriver = double.Parse(row["PaymenToTheDriver"].ToString());
                    test.PaymentOfDriver = double.Parse(row["PaymenOfTheDriverToCompany"].ToString());
                    test.DriverCommission = double.Parse(row["driverCommission"].ToString());
                    test.NetCabCommission = double.Parse(row["NetCabCommission"].ToString());
                    aa.Add(test);
                }
            }
            catch (Exception e)
            {

                throw;
            }
            var invoiceSpec = new InvoiceFilterSpecification(request.SearchString);

            //var data = await _taxiCompanyUnitOfWork.Repository<Invoice>().Entities
            //   .Specify(invoiceSpec)
            //   .Select(expression)
            //   .ToPaginatedListAsync(request.PageNumber, request.PageSize);
            var mappedInvoiceList = _mapper.Map<List<GetAllDriverInvoiceResponse>>(aa);
            return await Result<List<GetAllDriverInvoiceResponse>>.SuccessAsync(mappedInvoiceList);
        }
    }
}
