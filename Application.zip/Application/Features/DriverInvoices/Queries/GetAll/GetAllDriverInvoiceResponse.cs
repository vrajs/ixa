﻿using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Responses.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.DriverInvoices.Queries.GetAll
{
    public class GetAllDriverInvoiceResponse
    {
        public int DriverId { get; set; }
        public int? UnitId { get; set; }
        public string DriverName { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }

        public int? Num { get; set; }
        public double? DriverPrice { get; set; }
        public double? DriverShare { get; set; }
        public int? CardNum { get; set; }
        public double? CardSum { get; set; }
        public double? PaymentToDriver { get; set; }
        public double? PaymentOfDriver { get; set; }
        public double? DriverCommission { get; set; }
        public double? NetCabCommission { get; set; }
        public string CompanyIdentification { get; set; }
    }
}
