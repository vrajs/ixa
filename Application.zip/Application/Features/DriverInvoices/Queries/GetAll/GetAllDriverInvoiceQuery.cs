﻿//using AutoMapper;
//using LazyCache;
//using MediatR;
//using NetCabManager.Application.Interfaces.Repositories;
//using NetCabManager.Domain.Entities.Catalog;
//using NetCabManager.Shared.Constants.Application;
//using NetCabManager.Shared.Wrapper;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace NetCabManager.Application.Features.Invoices.Queries.GetAll
//{
//    public class GetAllInvoiceQuery : IRequest<Result<List<GetAllInvoiceResponse>>>
//    {
//        public GetAllInvoiceQuery()
//        {
//        }
//    }

//    internal class GetAllInvoiceQueryHandler : IRequestHandler<GetAllInvoiceQuery, Result<List<GetAllInvoiceResponse>>>
//    {
//        private readonly IMapper _mapper;
//        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
//        private readonly IAppCache _appCache;

//        public GetAllInvoiceQueryHandler(IMapper mapper,
//                                                     ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
//                                                     IAppCache appCache)
//        {
//            _mapper = mapper;
//            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
//            _appCache = appCache;
//        }

//        public async Task<Result<List<GetAllInvoiceResponse>>> Handle(GetAllInvoiceQuery query, CancellationToken cancellationToken)
//        {
//            _appCache.Remove(ApplicationConstants.Cache.GetAllInvoicesCacheKey);

//            Task<List<Invoice>> GetAllInvoices() => _taxiCompanyUnitOfWork.Repository<Invoice>().GetAllAsync();

//            var invoiceList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllInvoicesCacheKey, GetAllInvoices);

//            var mappedInvoiceList = _mapper.Map<List<GetAllInvoiceResponse>>(invoiceList);

//            return await Result<List<GetAllInvoiceResponse>>.SuccessAsync(mappedInvoiceList);
//        }
//    }
//}
