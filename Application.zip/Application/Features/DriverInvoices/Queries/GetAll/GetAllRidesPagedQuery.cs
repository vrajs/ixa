﻿using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Shared.Wrapper;
using MediatR;
using NetCabManager.Application.Specifications.Catalog;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AutoMapper;
using System.Globalization;

namespace NetCabManager.Application.Features.DriverInvoices.Queries.GetAll
{
    public class GetAllRidesPagedQuery : IRequest<Result<List<GetAllRidesResponse>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }
        public int? Month { get; set; }
        public int DriverId { get; set; }
        public string DriverName { get; set; }
        public GetAllRidesPagedQuery(int pageNumber, int pageSize, string searchString, int driverId)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            DriverId = driverId;
        }
    }

    internal class GetAllRidesPagedQueryHandler : IRequestHandler<GetAllRidesPagedQuery, Result<List<GetAllRidesResponse>>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IMapper _mapper;
        public GetAllRidesPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IMapper mapper)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<List<GetAllRidesResponse>>> Handle(GetAllRidesPagedQuery request, CancellationToken cancellationToken)
        {
            List<GetAllRidesResponse> aa = new List<GetAllRidesResponse>();
            try
            {
                if (request.PageSize == 0)
                {
                    request.PageSize = 1;
                }
                SqlConnection connection = new SqlConnection("Data Source = vps3.net-informatika.com,34262\\SqlServer03; Initial Catalog = AVTS_MetroTmp; Uid = NetCabUser; Pwd = Taxi_User_GG");

                SqlCommand command = new SqlCommand("InvoicingDriverDetailedRidesInMonth", connection);
                command.Parameters.Add("@month", SqlDbType.Int).Value = request.SearchString == null ? 1 : int.Parse(request.SearchString);
                command.Parameters.Add("@paymentType", SqlDbType.VarChar).Value = null;
                command.Parameters.Add("@IdDriver", SqlDbType.Int).Value = request.DriverId;
                command.Parameters.Add("@pageNumber", SqlDbType.Int).Value = request.PageNumber == 0 ? null : request.PageNumber;
                command.Parameters.Add("@pageSize", SqlDbType.Int).Value = request.PageSize == 0 ? null : request.PageSize;

                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    GetAllRidesResponse test = new GetAllRidesResponse();
                    test.TargetId = int.Parse(row["id_target"].ToString());
                    test.DriverName = row["Driver"].ToString();
                    string s = row["dispatchat"].ToString();
                    s = s.Replace(".", "-").Substring(0, s.Length - 6);
                    test.DispatchDate = Convert.ToDateTime(DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture));
                    test.Street = row["street"].ToString();
                    test.Destination = row["destination"].ToString();
                    test.PaymentType = row["paymentType"].ToString();
                    test.CustomerName = row["CustomerName"].ToString();
                    test.CustomerId = int.Parse(row["CustomerId"].ToString());
                    test.TaxiCompanyName = row["TaxiCompanyName"].ToString();
                    test.TaxiCompanyAddress = row["TaxiCompanyAddress"].ToString();
                    test.PriceWithOutVat = double.Parse(row["priceWithOutVat"].ToString());
                    test.Vat = double.Parse(row["vat"].ToString());
                    test.PriceTotal = double.Parse(row["Price total"].ToString());
                    aa.Add(test);
                }
            }
            catch (Exception e)
            {

                throw;
            }

            var mappedRideList = _mapper.Map<List<GetAllRidesResponse>>(aa);
            return await Result<List<GetAllRidesResponse>>.SuccessAsync(mappedRideList);
        }
    }
}
