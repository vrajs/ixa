﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AutoMapper;
using System.Globalization;
using NetCabManager.Application.Features.DriverInvoices.Queries.GetAll;

namespace NetCabManager.Application.Features.DriverInvoices.Queries.Export
{
    public class ExportDriverInvoiceQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportDriverInvoiceQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportDriverInvoiceQueryHandler : IRequestHandler<ExportDriverInvoiceQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportDriverInvoiceQueryHandler> _localizer;
        private readonly IMapper _mapper;
        public ExportDriverInvoiceQueryHandler(IExcelService excelService,
                                                     ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                     IStringLocalizer<ExportDriverInvoiceQueryHandler> localizer, IMapper mapper)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
            _mapper = mapper;
        }

        public async Task<Result<string>> Handle(ExportDriverInvoiceQuery request, CancellationToken canncelationToken)
        {
            var invoiceFilterSpec = new InvoiceFilterSpecification(request.SearchString);

            try
            {
                SqlConnection connection = new SqlConnection("Data Source = vps3.net-informatika.com,34262\\SqlServer03; Initial Catalog = AVTS_MetroTmp; Uid = NetCabUser; Pwd = Taxi_User_GG");

                SqlCommand command = new SqlCommand("InvoicingDriverCommissionInMonth", connection);
                command.Parameters.Add("@month", SqlDbType.Int).Value = 1;
                

                command.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                DataTable dt = new DataTable();
                dt.Load(command.ExecuteReader());

                List<GetAllDriverInvoiceResponse> aa = new List<GetAllDriverInvoiceResponse>();
                foreach (DataRow row in dt.Rows)
                {
                    GetAllDriverInvoiceResponse test = new GetAllDriverInvoiceResponse();
                    test.DriverId = int.Parse(row["id_driver"].ToString());
                    test.UnitId = int.Parse(row["unit_id"].ToString());
                    test.DriverName = row["driverName"].ToString();
                    string s = row["DateFrom"].ToString();
                    s = s.Replace(".", "-");
                    test.DateFrom = Convert.ToDateTime(DateTime.ParseExact(s, "dd-MM-yy", CultureInfo.InvariantCulture));
                    string s2 = row["DateTo"].ToString();
                    s2 = s2.Replace(".", "-");
                    test.DateTo = Convert.ToDateTime(DateTime.ParseExact(s2, "dd-MM-yy", CultureInfo.InvariantCulture));
                    test.Num = int.Parse(row["num"].ToString());
                    test.DriverPrice = double.Parse(row["driverPrice"].ToString());
                    test.DriverShare = double.Parse(row["driverShare"].ToString());
                    test.CardNum = int.Parse(row["CardNum"].ToString());
                    test.CardSum = double.Parse(row["CardSum"].ToString());
                    test.PaymentToDriver = double.Parse(row["PaymenToTheDriver"].ToString());
                    test.PaymentOfDriver = double.Parse(row["PaymenOfTheDriverToCompany"].ToString());
                    test.DriverCommission = double.Parse(row["driverCommission"].ToString());
                    test.NetCabCommission = double.Parse(row["NetCabCommission"].ToString());
                    aa.Add(test);
                }
                var mappedInvoiceList = _mapper.Map<List<DriverInvoice>>(aa);
                var data = await _excelService.ExportAsync(mappedInvoiceList, mappers: new Dictionary<string, Func<DriverInvoice, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["DriverName"], c => c.DriverName },
                { _localizer["DateFrom"], c => c.DateFrom },
                { _localizer["DateTo"], c => c.DateTo },
                { _localizer["Num"], c => c.Num },
                { _localizer["DriverPrice"], c => c.DriverPrice },
                { _localizer["DriverShare"], c => c.DriverShare },
                { _localizer["CardNum"], c => c.CardNum },
                { _localizer["CardSum"], c => c.CardSum },
                { _localizer["PaymentToDriver"], c => c.PaymentToDriver },
                { _localizer["PaymentOfDriver"], c => c.PaymentOfDriver },
                { _localizer["DriverCommission"], c => c.DriverCommission },
                { _localizer["NetCabCommission"], c => c.NetCabCommission },
            }, sheetName: _localizer["Driver Invoices"]);

                return await Result<string>.SuccessAsync(data: data);
            }
            catch (Exception e)
            {
                throw;
            }
            //var invoices = await _taxiCompanyUnitOfWork.Repository<Invoice>().Entities
            //                                                      .Specify(invoiceFilterSpec).ToListAsync(canncelationToken);

        }
    }
}
