﻿namespace NetCabManager.Application.Features.TaxiCompanyUsers.Commands.Delete
{
    using MediatR;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class DeleteTaxiCompanyUserCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteTaxiCompanyUserCommandHandler : IRequestHandler<DeleteTaxiCompanyUserCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeleteTaxiCompanyUserCommandHandler> _localizer;

        public DeleteTaxiCompanyUserCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, 
                                                   IStringLocalizer<DeleteTaxiCompanyUserCommandHandler> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeleteTaxiCompanyUserCommand command, CancellationToken cancellationToken)
        {
            var taxiCompanyUser = await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().GetByIdAsync(command.Id);

            if (taxiCompanyUser != null)
            {
                await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().DeleteAsync(taxiCompanyUser,
                                                                                       cancellationToken,
                                                                                       ApplicationConstants.Cache.GetAllTaxiCompanyUsersCacheKey);

                return await Result<int>.SuccessAsync(taxiCompanyUser.Id, _localizer["Company User Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Company User Not Found!"]);
            }
        }
    }
}