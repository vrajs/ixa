﻿namespace NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit
{
    using AutoMapper;
    using MediatR;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class AddEditTaxiCompanyUserCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int IdRole { get; set; }
        public bool IsDeleted { get; set; }
        public bool? MustPickInternalDepartment { get; set; }
    }

    internal class AddEditTaxiCompanyUserCommandHandler : IRequestHandler<AddEditTaxiCompanyUserCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly IStringLocalizer<AddEditTaxiCompanyUserCommandHandler> _localizer;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public AddEditTaxiCompanyUserCommandHandler(IMapper mapper,
                                                    IStringLocalizer<AddEditTaxiCompanyUserCommandHandler> localizer,
                                                    ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _localizer = localizer;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<int>> Handle(AddEditTaxiCompanyUserCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var mappedTaxiCompanyUser = _mapper.Map<TaxiCompanyUser>(command);

                await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().AddAsync(mappedTaxiCompanyUser,
                                                                                    cancellationToken,
                                                                                    ApplicationConstants.Cache.GetAllTaxiCompanyUsersCacheKey);

                return await Result<int>.SuccessAsync(mappedTaxiCompanyUser.Id, _localizer["Company User Saved."]);
            }
            else
            {
                var taxiCompanyUser = await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().GetByIdAsync(command.Id);

                if (taxiCompanyUser != null)
                {
                    taxiCompanyUser.Id = command.Id;
                    taxiCompanyUser.Name = command.Name ?? taxiCompanyUser.Name;
                    taxiCompanyUser.Surname = command.Surname ?? taxiCompanyUser.Surname;
                    taxiCompanyUser.Username = command.Username ?? taxiCompanyUser.Username;
                    taxiCompanyUser.Password = command.Password ?? taxiCompanyUser.Password;
                    taxiCompanyUser.IdRole = command.IdRole;
                    taxiCompanyUser.IsDeleted = command.IsDeleted;
                    taxiCompanyUser.MustPickInternalDepartment = command.MustPickInternalDepartment ?? taxiCompanyUser.MustPickInternalDepartment;

                    await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().UpdateAsync(taxiCompanyUser,
                                                                                           cancellationToken,
                                                                                           ApplicationConstants.Cache.GetAllTaxiCompanyUsersCacheKey);

                    return await Result<int>.SuccessAsync(taxiCompanyUser.Id, _localizer["Company User Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Company User Not Found!"]);
                }
            }
        }
    }
}