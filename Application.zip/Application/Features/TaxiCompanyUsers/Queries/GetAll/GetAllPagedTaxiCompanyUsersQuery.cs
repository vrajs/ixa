﻿namespace NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.TaxiCompany;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllPagedTaxiCompanyUsersQuery : IRequest<PaginatedResult<GetAllTaxiCompanyUsersResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }

        public GetAllPagedTaxiCompanyUsersQuery(int pageNumber, int pageSize, string searchString)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
        }
    }

    internal class GetAllPagedTaxiCompanyUsersQueryHandler : IRequestHandler<GetAllPagedTaxiCompanyUsersQuery, PaginatedResult<GetAllTaxiCompanyUsersResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllPagedTaxiCompanyUsersQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllTaxiCompanyUsersResponse>> Handle(GetAllPagedTaxiCompanyUsersQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<TaxiCompanyUser, GetAllTaxiCompanyUsersResponse>> expression = e => new GetAllTaxiCompanyUsersResponse
            {
                Id = e.Id,
                Name = e.Name,
                Surname = e.Surname,
                Username = e.Username,
                Password = e.Password,
                IdRole = e.IdRole,
                IsDeleted = e.IsDeleted,
                MustPickInternalDepartment = e.MustPickInternalDepartment
            };

            var taxiCompanyUserSpec = new TaxiCompanyUserFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().Entities
               .Specify(taxiCompanyUserSpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}