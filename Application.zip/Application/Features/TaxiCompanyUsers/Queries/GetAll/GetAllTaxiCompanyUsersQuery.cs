﻿namespace NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllTaxiCompanyUsersQuery : IRequest<Result<List<GetAllTaxiCompanyUsersResponse>>>
    {
        public GetAllTaxiCompanyUsersQuery()
        {
        }
    }

    internal class GetAllTaxiCompanyUsersQueryHandler : IRequestHandler<GetAllTaxiCompanyUsersQuery, Result<List<GetAllTaxiCompanyUsersResponse>>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IMapper _mapper;
        private readonly IAppCache _appCache;

        public GetAllTaxiCompanyUsersQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, 
                                                  IMapper mapper,
                                                  IAppCache appCache)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _mapper = mapper;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllTaxiCompanyUsersResponse>>> Handle(GetAllTaxiCompanyUsersQuery request, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllTaxiCompanyUsersCacheKey);

            Task<List<TaxiCompanyUser>> GetAllTaxiCompanyUsers() => _taxiCompanyUnitOfWork.Repository<TaxiCompanyUser>().GetAllAsync();

            var userList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllTaxiCompanyUsersCacheKey, GetAllTaxiCompanyUsers);

            var mappedUsers = _mapper.Map<List<GetAllTaxiCompanyUsersResponse>>(userList);

            return await Result<List<GetAllTaxiCompanyUsersResponse>>.SuccessAsync(mappedUsers);
        }
    }
}