﻿using AutoMapper;
using LazyCache;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.NetCabToFleets.Commands.AddEdit
{
    public class AddEditNetCabToFleetCommand : IRequest<Result<string>>
    {
        public int Id { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public int? Price { get; set; }

        public string CompanyIdentification { get; set; }
        public string UserId { get; set; }
    }

    internal class AddEditNetCabToFleetCommandHandler : IRequestHandler<AddEditNetCabToFleetCommand, Result<string>>
    {
        private readonly IMapper _mapper;
        private readonly IStringLocalizer<AddEditNetCabToFleetCommandHandler> _localizer;
        private readonly IUnitOfWork<string> _unitOfWork;
        public AddEditNetCabToFleetCommandHandler(IMapper mapper,
                                                       IUnitOfWork<string> unitOfWork,
                                                       IStringLocalizer<AddEditNetCabToFleetCommandHandler> localizer)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(AddEditNetCabToFleetCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var mappedFleets = _mapper.Map<NetCabToFleet>(command);

                await _unitOfWork.Repository<NetCabToFleet>().AddAsync(mappedFleets);

                return await Result<string>.SuccessAsync(mappedFleets.Id, _localizer["Fleet Saved."]);
            }
            else
            {
                var fleet = await _unitOfWork.Repository<NetCabToFleet>().GetByIdAsync(command.Id.ToString());

                if (fleet != null)
                {
                    fleet.Id = command.Id.ToString();
                    fleet.DateFrom = command.DateFrom;
                    fleet.DateTo = command.DateTo;
                    fleet.Price = command.Price;
                    fleet.CompanyIdentification = command.CompanyIdentification;
                    fleet.UserId = command.UserId;

                    await _unitOfWork.Repository<NetCabToFleet>().UpdateAsync(fleet);

                    return await Result<string>.SuccessAsync(fleet.Id, _localizer["Fleet Updated."]);
                }
                else
                {
                    return await Result<string>.FailAsync(_localizer["Fleet Not Found!"]);
                }
            }
        }
    }
}