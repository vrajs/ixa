﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.NetCabToFleets.Commands.Delete
{
    public class DeleteNetCabToFleetCommand : IRequest<Result<string>>
    {
        public string Id { get; set; }
    }

    internal class DeleteNetCabToFleetCommandHandler : IRequestHandler<DeleteNetCabToFleetCommand, Result<string>>
    {
        private readonly IStringLocalizer<DeleteNetCabToFleetCommandHandler> _localizer;
        private readonly IUnitOfWork<string> _unitOfWork;
        public DeleteNetCabToFleetCommandHandler(IUnitOfWork<string> unitOfWork,
                                                      IStringLocalizer<DeleteNetCabToFleetCommandHandler> localizer)
        {
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(DeleteNetCabToFleetCommand command, CancellationToken cancellationToken)
        {
            var fleet = await _unitOfWork.Repository<NetCabToFleet>().GetByIdAsync(command.Id);

            if (fleet != null)
            {
                await _unitOfWork.Repository<NetCabToFleet>().DeleteAsync(fleet);

                return await Result<string>.SuccessAsync(fleet.Id, _localizer["Fleet Deleted."]);
            }
            else
            {
                return await Result<string>.FailAsync(_localizer["Fleet Not Found!"]);
            }
        }
    }
}