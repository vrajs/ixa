﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.NetCabToFleets.Queries.Export
{
    public class ExportNetCabToFleetsQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportNetCabToFleetsQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportNetCabToFleetsQueryHandler : IRequestHandler<ExportNetCabToFleetsQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly IStringLocalizer<ExportNetCabToFleetsQueryHandler> _localizer;
        private readonly IUnitOfWork<string> _unitOfWork;
        public ExportNetCabToFleetsQueryHandler(IExcelService excelService,
                                                     IUnitOfWork<string> unitOfWork,
                                                     IStringLocalizer<ExportNetCabToFleetsQueryHandler> localizer)
        {
            _excelService = excelService;
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportNetCabToFleetsQuery request, CancellationToken canncelationToken)
        {
            var netCabToFleetFilterSpec = new NetCabToFleetFilterSpecification(request.SearchString);

            var netcabToFleets = await _unitOfWork.Repository<NetCabToFleet>().Entities
                                                                  .Specify(netCabToFleetFilterSpec).ToListAsync(canncelationToken);

            var data = await _excelService.ExportAsync(netcabToFleets, mappers: new Dictionary<string, Func<NetCabToFleet, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["Invoice Date"], c => c.InvoiceDate },
                { _localizer["Date From"], c => c.DateFrom },
                { _localizer["Date To"], c => c.DateTo },
                { _localizer["Price"], c => c.Price },
                { _localizer["CompanyIdentification"], c => c.CompanyIdentification },
                { _localizer["UserId"], c => c.UserId }
            }, sheetName: _localizer["NetCab_ToFleet"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}