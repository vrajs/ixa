﻿namespace NetCabManager.Application.Features.NetCabToFleets.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
    
    using Microsoft.Extensions.Localization;

    public class GetNetCabFleetByIdQuery : IRequest<Result<GetNetCabFleetByIdResponse>>
    {
        public string Id { get; set; }
    }

    internal class GetNetCabFleetByIdQueryHandler : IRequestHandler<GetNetCabFleetByIdQuery, Result<GetNetCabFleetByIdResponse>>
    {
        private readonly IMapper _mapper;
        
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IStringLocalizer<GetNetCabFleetByIdQueryHandler> _localizer;
        public GetNetCabFleetByIdQueryHandler(IMapper mapper, IUnitOfWork<string> unitOfWork, IStringLocalizer<GetNetCabFleetByIdQueryHandler> localizer)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<GetNetCabFleetByIdResponse>> Handle(GetNetCabFleetByIdQuery query, CancellationToken cancellationToken)
        {
            var netcabfleet = await _unitOfWork.Repository<NetCabToFleet>().GetByIdAsync(query.Id);

            if (netcabfleet != null)
            {
                var mappedNetCabFleet = _mapper.Map<GetNetCabFleetByIdResponse>(netcabfleet);

                return await Result<GetNetCabFleetByIdResponse>.SuccessAsync(mappedNetCabFleet);
            }
            else
            {
                return await Result<GetNetCabFleetByIdResponse>.FailAsync(_localizer["NetCab Fleet Not Found!"]);
            }
        }
    }
}