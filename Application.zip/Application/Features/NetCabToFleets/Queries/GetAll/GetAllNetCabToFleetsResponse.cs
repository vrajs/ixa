﻿using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Targets.Queries.GetAll;
using NetCabManager.Application.Features.Units.Queries.GetAll;
using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
using NetCabManager.Application.Responses.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll
{
    public class GetAllNetCabToFleetsResponse
    {
        public string Id { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public int? Price { get; set; }

        public string CompanyIdentification { get; set; }
        public string UserId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
    }
}