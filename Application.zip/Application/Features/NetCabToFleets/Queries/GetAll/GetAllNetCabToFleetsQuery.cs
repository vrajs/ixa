﻿namespace NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    
    public class GetAllNetCabToFleetsQuery : IRequest<Result<List<GetAllNetCabToFleetsResponse>>>
    {
        public GetAllNetCabToFleetsQuery()
        {
        }
    }

    internal class GetAllNetCabToFleetsQueryHandler : IRequestHandler<GetAllNetCabToFleetsQuery, Result<List<GetAllNetCabToFleetsResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork<string> _unitOfWork;
        private readonly IAppCache _appCache;

        public GetAllNetCabToFleetsQueryHandler(IMapper mapper,
                                                      IUnitOfWork<string> unitOfWork,
                                                     IAppCache appCache)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllNetCabToFleetsResponse>>> Handle(GetAllNetCabToFleetsQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllNetCabFleetCachekey);
            Task<List<NetCabToFleet>> GetAllNetCabFleet() => _unitOfWork.Repository<NetCabToFleet>().GetAllAsync();

            var netcabfleetList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllNetCabFleetCachekey, GetAllNetCabFleet);

            var mappedNetCabFleet = _mapper.Map<List<GetAllNetCabToFleetsResponse>>(netcabfleetList);

            return await Result<List<GetAllNetCabToFleetsResponse>>.SuccessAsync(mappedNetCabFleet);
        }
    }
}