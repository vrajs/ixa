﻿//namespace NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll
//{
//    using MediatR;
//    using NetCabManager.Application.Extensions;
//    using NetCabManager.Application.Interfaces.Repositories;
//    using NetCabManager.Application.Specifications.Catalog;
//    using NetCabManager.Domain.Entities.Catalog;
//    using NetCabManager.Shared.Wrapper;
//    using System;
//    using System.Linq;
//    using System.Linq.Expressions;
//    using System.Threading;
//    using System.Threading.Tasks;
//    using NetCabManager.Domain.Entities.Catalog;
//    using NetCabManager.Application.Specifications.Catalog;

//    public class GetAllNetCabToFleetsPagedQuery : IRequest<PaginatedResult<GetAllNetCabToFleetsResponse>>
//    {
//        public int PageNumber { get; set; }
//        public int PageSize { get; set; }
//        public string SearchString { get; set; }

//        public GetAllNetCabToFleetsPagedQuery(int pageNumber, int pageSize, string searchString)
//        {
//            PageNumber = pageNumber;
//            PageSize = pageSize;
//            SearchString = searchString;
//        }
//    }

//    internal class GetAllNetCabToFleetsPagedQueryHandler : IRequestHandler<GetAllNetCabToFleetsPagedQuery, PaginatedResult<GetAllNetCabToFleetsResponse>>
//    {
//        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

//        public GetAllNetCabToFleetsPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
//        {
//            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
//        }

//        public async Task<PaginatedResult<GetAllNetCabToFleetsResponse>> Handle(GetAllNetCabToFleetsPagedQuery request, CancellationToken cancellationToken)
//        {
//            Expression<Func<NetCabToFleet, GetAllNetCabToFleetsResponse>> expression = e => new GetAllNetCabToFleetsResponse
//            {
//                Id = e.Id,
//                DateFrom = e.DateFrom,
//                DateTo= e.DateTo,
//                Price = e.Price,
//                CompanyIdentification = e.CompanyIdentification,
//                UserId = e.UserId
//            };

//            var netCabToFleetFilterSpec = new NetCabToFleetFilterSpecification(request.SearchString);

//            var data = await _taxiCompanyUnitOfWork.Repository<NetCabToFleet>().Entities
//               .Specify(netCabToFleetFilterSpec)
//               .Select(expression)
//               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

//            return data;
//        }
//    }
//}