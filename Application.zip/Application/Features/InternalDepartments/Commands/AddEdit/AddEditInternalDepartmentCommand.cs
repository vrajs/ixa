﻿using AutoMapper;
using LazyCache;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit
{
    public class AddEditInternalDepartmentCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string Internal_Department { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? Deleted { get; set; }
    }

    internal class AddEditInternalDepartmentCommandHandler : IRequestHandler<AddEditInternalDepartmentCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditInternalDepartmentCommandHandler> _localizer;

        public AddEditInternalDepartmentCommandHandler(IMapper mapper,
                                                       ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                       IStringLocalizer<AddEditInternalDepartmentCommandHandler> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditInternalDepartmentCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var mappedInternalDepartments = _mapper.Map<InternalDepartment>(command);

                await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().AddAsync(mappedInternalDepartments, 
                                                                                       cancellationToken, 
                                                                                       ApplicationConstants.Cache.GetAllInternalDepartmentsCacheKey);

                return await Result<int>.SuccessAsync(mappedInternalDepartments.Id, _localizer["Internal Department Saved."]);
            }
            else
            {
                var internalDepartment = await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().GetByIdAsync(command.Id);

                if (internalDepartment != null)
                {
                    internalDepartment.Id = (internalDepartment.Id <= 0) ? internalDepartment.Id : command.Id;
                    internalDepartment.Internal_Department = command.Internal_Department;
                    internalDepartment.Inserted = command.Inserted;
                    internalDepartment.IsDeleted = command.IsDeleted;
                    internalDepartment.Deleted = command.Deleted;

                    await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().UpdateAsync(internalDepartment, 
                                                                                              cancellationToken, 
                                                                                              ApplicationConstants.Cache.GetAllInternalDepartmentsCacheKey);

                    return await Result<int>.SuccessAsync(internalDepartment.Id, _localizer["Internal Department Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Internal Department Not Found!"]);
                }
            }
        }
    }
}