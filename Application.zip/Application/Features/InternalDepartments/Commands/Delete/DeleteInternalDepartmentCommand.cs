﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.InternalDepartments.Commands.Delete
{
    public class DeleteInternalDepartmentCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteInternalDepartmentCommandHandler : IRequestHandler<DeleteInternalDepartmentCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeleteInternalDepartmentCommandHandler> _localizer;

        public DeleteInternalDepartmentCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                      IStringLocalizer<DeleteInternalDepartmentCommandHandler> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeleteInternalDepartmentCommand command, CancellationToken cancellationToken)
        {
            var internalDepartment = await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().GetByIdAsync(command.Id);

            if (internalDepartment != null)
            {
                await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().DeleteAsync(internalDepartment, 
                                                                                          cancellationToken, 
                                                                                          ApplicationConstants.Cache.GetAllInternalDepartmentsCacheKey);

                return await Result<int>.SuccessAsync(internalDepartment.Id, _localizer["Internal Department Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Internal Department Not Found!"]);
            }
        }
    }
}