﻿namespace NetCabManager.Application.Features.InternalDepartments.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.InternalDepartments.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetInternalDepartmentByIdQuery : IRequest<Result<GetAllInternalDepartmentsResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetInternalDepartmentByIdQueryHandler : IRequestHandler<GetInternalDepartmentByIdQuery, Result<GetAllInternalDepartmentsResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetInternalDepartmentByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllInternalDepartmentsResponse>> Handle(GetInternalDepartmentByIdQuery query, CancellationToken cancellationToken)
        {
            var internalDepartment = await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().GetByIdAsync(query.Id);

            var mappedInternalDepartment = _mapper.Map<GetAllInternalDepartmentsResponse>(internalDepartment);

            return await Result<GetAllInternalDepartmentsResponse>.SuccessAsync(mappedInternalDepartment);
        }
    }
}