﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.InternalDepartments.Queries.Export
{
    public class ExportInternalDepartmentsQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportInternalDepartmentsQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportInternalDepartmentsQueryHandler : IRequestHandler<ExportInternalDepartmentsQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportInternalDepartmentsQueryHandler> _localizer;

        public ExportInternalDepartmentsQueryHandler(IExcelService excelService,
                                                     ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                     IStringLocalizer<ExportInternalDepartmentsQueryHandler> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportInternalDepartmentsQuery request, CancellationToken canncelationToken)
        {
            var internalDepartmentFilterSpec = new InternalDepartmentFilterSpecification(request.SearchString);

            var internalDepartments = await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().Entities
                                                                  .Specify(internalDepartmentFilterSpec).ToListAsync(canncelationToken);

            var data = await _excelService.ExportAsync(internalDepartments, mappers: new Dictionary<string, Func<InternalDepartment, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["Internal Department"], c => c.Internal_Department },
                { _localizer["Inserted"], c => c.Inserted },
                { _localizer["Is Deleted"], c => c.IsDeleted },
                { _localizer["Deleted"], c => c.Deleted }
            }, sheetName: _localizer["Internal_Departments"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}