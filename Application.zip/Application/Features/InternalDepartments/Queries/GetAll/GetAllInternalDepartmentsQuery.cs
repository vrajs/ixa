﻿namespace NetCabManager.Application.Features.InternalDepartments.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllInternalDepartmentsQuery : IRequest<Result<List<GetAllInternalDepartmentsResponse>>>
    {
        public GetAllInternalDepartmentsQuery()
        {
        }
    }

    internal class GetAllInternalDepartmentsQueryHandler : IRequestHandler<GetAllInternalDepartmentsQuery, Result<List<GetAllInternalDepartmentsResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllInternalDepartmentsQueryHandler(IMapper mapper,
                                                     ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                     IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllInternalDepartmentsResponse>>> Handle(GetAllInternalDepartmentsQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllInternalDepartmentsCacheKey);

            Task<List<InternalDepartment>> GetAllInternalDepartments() => _taxiCompanyUnitOfWork.Repository<InternalDepartment>().GetAllAsync();

            var internalDepartmentList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllInternalDepartmentsCacheKey, GetAllInternalDepartments);

            var mappedInternalDepartmentList = _mapper.Map<List<GetAllInternalDepartmentsResponse>>(internalDepartmentList);

            return await Result<List<GetAllInternalDepartmentsResponse>>.SuccessAsync(mappedInternalDepartmentList);
        }
    }
}