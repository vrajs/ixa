﻿using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Targets.Queries.GetAll;
using NetCabManager.Application.Features.Units.Queries.GetAll;
using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
using NetCabManager.Application.Responses.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.InternalDepartments.Queries.GetAll
{
    public class GetAllInternalDepartmentsResponse
    {
        public int Id { get; set; }
        public string Internal_Department { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? Deleted { get; set; }
        public virtual ICollection<GetAllDriversResponse> Drivers { get; set; }
        public virtual ICollection<GetAllVehiclesResponse> Vehicles { get; set; }
        public virtual ICollection<GetAllUnitsResponse> Units { get; set; }
        public virtual ICollection<GetAllTargetsResponse> Targets { get; set; }
        public virtual ICollection<UserResponse> Users { get; set; }
    }
}