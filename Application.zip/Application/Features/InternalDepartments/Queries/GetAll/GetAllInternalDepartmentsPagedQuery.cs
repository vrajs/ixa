﻿namespace NetCabManager.Application.Features.InternalDepartments.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Application.Specifications.Catalog;

    public class GetAllInternalDepartmentsPagedQuery : IRequest<PaginatedResult<GetAllInternalDepartmentsResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }

        public GetAllInternalDepartmentsPagedQuery(int pageNumber, int pageSize, string searchString)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
        }
    }

    internal class GetAllInternalDepartmentsPagedQueryHandler : IRequestHandler<GetAllInternalDepartmentsPagedQuery, PaginatedResult<GetAllInternalDepartmentsResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllInternalDepartmentsPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllInternalDepartmentsResponse>> Handle(GetAllInternalDepartmentsPagedQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<InternalDepartment, GetAllInternalDepartmentsResponse>> expression = e => new GetAllInternalDepartmentsResponse
            {
                Id = e.Id,
                Internal_Department = e.Internal_Department,
                Inserted = e.Inserted,
                IsDeleted = e.IsDeleted,
                Deleted = e.Deleted
            };

            var internalDepartmentsSpec = new InternalDepartmentFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<InternalDepartment>().Entities
               .Specify(internalDepartmentsSpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}