﻿namespace NetCabManager.Application.Features.Targets.Commands.AddEdit
{
    using AutoMapper;
    using MediatR;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    //public enum TargetStatus
    //{
    //    NewCustomer = 0,
    //    AssigningCustomer = 1,
    //    DrivingToCustomer = 2,
    //    DrivingCustomer = 3,
    //    Finished = 4,
    //    NoCustomer = 5,
    //    Cancelled = 6,
    //    Unprocessed = 7,
    //    Deleted = 8,
    //    Licitation = 11,
    //    AtLocation = 12,
    //    Reserved = 13,
    //    NoCustomerRequest = 14,
    //    LateDriver = 15,
    //    Mobile = 16,
    //    Preorder = 17
    //}

    public class AddEditTargetCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public string Lbl { get; set; }
        public int? Status { get; set; }
        public string UnitId { get; set; }
        public DateTime? AssignedAt { get; set; }
        public string Remark { get; set; }
        public DateTime? DatetimeUpdate { get; set; }
        public int? IdClient { get; set; }
        public bool? IsDeleted { get; set; }
        public int? IdRecord { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? Preorder { get; set; }
        public DateTime? Dispatchat { get; set; }
        public DateTime? RemindAt { get; set; }
        public bool? DispatchNow { get; set; }
        public int IdOperator { get; set; }
        public int? IdDispatcher { get; set; }
        public int? IdPartnerCompany { get; set; }
        public decimal? PurchaseOrder { get; set; }
        public int? HsMid { get; set; }
        public int? TaxiNumber { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public string OrientLatitude { get; set; }
        public string OrientLongitude { get; set; }
        public bool? AutoDispatch { get; set; }
        public bool? AutoDispatched { get; set; }
        public DateTime? DatetimePreorder { get; set; }
        public string Destination { get; set; }
        public string Customer { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public int IdStand { get; set; }
        public int IdZone { get; set; }
        public string Distance { get; set; }
        public string TimeOfArrival { get; set; }
        public int? IdCompanyCredential { get; set; }
        public string Gdistance { get; set; }
        public string GtimeOfArrival { get; set; }
        public int? PhoneLine { get; set; }
        public DateTime? RequestedTime { get; set; }
        public string ManualAssignReason { get; set; }
        public string CompanyOrderNote { get; set; }
        public bool Paid { get; set; }
        public decimal DispatchType { get; set; }
        public int CancellationReason { get; set; }
        public DateTime? CpuPickupTime { get; set; }
        public DateTime? DriverPickupTime { get; set; }
        public int? DriverDelay { get; set; }
        public string OrderByDriver { get; set; }
        public bool? DelayedPayment { get; set; }
        public DateTime? Pickup { get; set; }
        public DateTime? DropOffTime { get; set; }
        public DateTime? CpuFirstTime { get; set; }
        public int? DriverPickupMin { get; set; }
        public bool? DriverAtLocation { get; set; }
        public string BillingCenter { get; set; }
        public string Billingcenterr { get; set; }
        public string OrdererName { get; set; }
        public string OrdererNote { get; set; }
        public double? DestinationLatitude { get; set; }
        public double? DestinationLongitude { get; set; }
        public int DispatchSubtype { get; set; }
        public string Passenger { get; set; }
        public int? IdTariff { get; set; }
        public int? IdPaymentType { get; set; }
        public int IdInternalDepartment { get; set; }
        public DateTime? PrimaryDistanceRequestTime { get; set; }
        public DateTime? SecondaryDistanceRequestTime { get; set; }
        public int? IdInternalDepartmentUsed { get; set; }
        public string PurchaseQuantity { get; set; }
        public bool ReceiptedInvoices { get; set; }
        public string TripRemark { get; set; }
        public bool? NoCustomerRequest { get; set; }
        public bool NotifyUnitPending { get; set; }
        public bool? StreetPickup { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public int? AssignedIdDriver { get; set; }
        public int? AssignedIdUnit { get; set; }
        public int? AssignedIdVehicle { get; set; }
        public int? IdServiceType { get; set; }
        public string PassengerPhone { get; set; }
        public DateTime? DispatchTriggered { get; set; }
        public DateTime? CpuFinalDestinationTime { get; set; }
        public string CardNumber { get; set; }
    }

    internal class AddEditTargetCommandHandler : IRequestHandler<AddEditTargetCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditTargetCommand> _localizer;

        public AddEditTargetCommandHandler(IMapper mapper,
                                           ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                           IStringLocalizer<AddEditTargetCommand> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditTargetCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var mappedTarget = _mapper.Map<TargetHistory>(command);

                await _taxiCompanyUnitOfWork.Repository<TargetHistory>().AddAsync(mappedTarget, 
                                                                           cancellationToken,
                                                                           ApplicationConstants.Cache.GetAllTargetsCacheKey);

                return await Result<int>.SuccessAsync(mappedTarget.Id, _localizer["Target Saved."]);
            }
            else
            {
                var target = await _taxiCompanyUnitOfWork.Repository<TargetHistory>().GetByIdAsync(command.Id);

                if (target != null)
                {
                    target.Phone = command.Phone ?? target.Phone;
                    target.Street = command.Street ?? target.Street;
                    target.Number = command.Number ?? target.Number;
                    target.Lbl = command.Lbl ?? target.Lbl;
                    target.Status = command.Status ?? target.Status;
                    target.UnitId = command.UnitId ?? target.UnitId;
                    target.AssignedAt = command.AssignedAt ?? target.AssignedAt;
                    target.Remark = command.Remark ?? target.Remark;
                    target.DatetimeUpdate = command.DatetimeUpdate ?? target.DatetimeUpdate;
                    target.IdClient = command.IdClient ?? target.IdClient;
                    target.IsDeleted = command.IsDeleted ?? target.IsDeleted;
                    target.IdRecord = command.IdRecord ?? target.IdRecord;
                    target.Inserted = command.Inserted ?? target.Inserted;
                    target.Preorder = command.Preorder ?? target.Preorder;
                    target.Dispatchat = command.Dispatchat ?? target.Dispatchat;
                    target.RemindAt = command.RemindAt ?? target.RemindAt;
                    target.DispatchNow = command.DispatchNow ?? target.DispatchNow;
                    target.IdOperator = (command.IdOperator < 0) ? target.IdOperator : command.IdOperator;
                    target.IdDispatcher = command.IdDispatcher ?? target.IdDispatcher;
                    target.IdPartnerCompany = (command.IdPartnerCompany < 0) ? target.IdPartnerCompany : command.IdPartnerCompany;
                    target.PurchaseOrder = command.PurchaseOrder ?? target.PurchaseOrder;
                    target.HsMid = command.HsMid ?? target.HsMid;
                    target.TaxiNumber = command.TaxiNumber ?? target.TaxiNumber;
                    target.Latitude = command.Latitude ?? target.Latitude;
                    target.Longitude = command.Longitude ?? target.Longitude;
                    target.OrientLatitude = command.OrientLatitude ?? target.OrientLatitude;
                    target.OrientLongitude = command.OrientLongitude ?? target.OrientLongitude;
                    target.AutoDispatch = command.AutoDispatch ?? target.AutoDispatch;
                    target.AutoDispatched = command.AutoDispatched ?? target.AutoDispatched;
                    target.DatetimePreorder = command.DatetimePreorder ?? target.DatetimePreorder;
                    target.Destination = command.Destination ?? target.Destination;
                    target.Customer = command.Customer ?? target.Customer;
                    target.Type1 = command.Type1 ?? target.Type1;
                    target.Type2 = command.Type2 ?? target.Type2;
                    target.Type3 = command.Type3 ?? target.Type3;
                    target.Type4 = command.Type4 ?? target.Type4;
                    target.Type5 = command.Type5 ?? target.Type5;
                    target.Type6 = command.Type6 ?? target.Type6;
                    target.Type7 = command.Type7 ?? target.Type7;
                    target.Type8 = command.Type8 ?? target.Type8;
                    target.Type9 = command.Type9 ?? target.Type9;
                    target.Type10 = command.Type10 ?? target.Type10;
                    target.Type11 = command.Type11 ?? target.Type11;
                    target.Type12 = command.Type12 ?? target.Type12;
                    target.Type13 = command.Type13 ?? target.Type13;
                    target.Type14 = command.Type14 ?? target.Type14;
                    target.Type15 = command.Type15 ?? target.Type15;
                    target.Type16 = command.Type16 ?? target.Type16;
                    target.Type17 = command.Type17 ?? target.Type17;
                    target.Type18 = command.Type18 ?? target.Type18;
                    target.Type19 = command.Type19 ?? target.Type19;
                    target.Type20 = command.Type20 ?? target.Type20;
                    target.IdStand = (command.IdStand < 0) ? target.IdStand : command.IdStand;
                    target.IdZone = (command.IdZone < 0) ? target.IdZone : command.IdZone;
                    target.Distance = command.Distance ?? target.Distance;
                    target.TimeOfArrival = command.TimeOfArrival ?? target.TimeOfArrival;
                    target.IdCompanyCredential = command.IdCompanyCredential ?? target.IdCompanyCredential;
                    target.Gdistance = command.Gdistance ?? target.Gdistance;
                    target.GtimeOfArrival = command.GtimeOfArrival ?? target.GtimeOfArrival;
                    target.PhoneLine = command.PhoneLine ?? target.PhoneLine;
                    target.RequestedTime = command.RequestedTime ?? target.RequestedTime;
                    target.ManualAssignReason = command.ManualAssignReason ?? target.ManualAssignReason;
                    target.CompanyOrderNote = command.CompanyOrderNote ?? target.CompanyOrderNote;
                    target.Paid = command.Paid;
                    target.DispatchType = command.DispatchType;
                    target.CancellationReason = command.CancellationReason;
                    target.CpuPickupTime = command.CpuPickupTime ?? target.CpuPickupTime;
                    target.DriverPickupTime = command.DriverPickupTime ?? target.DriverPickupTime;
                    target.DriverDelay = command.DriverDelay ?? target.DriverDelay;
                    target.OrderByDriver = command.OrderByDriver ?? target.OrderByDriver;
                    target.DelayedPayment = command.DelayedPayment ?? target.DelayedPayment;
                    target.Pickup = command.Pickup ?? target.Pickup;
                    target.DropOffTime = command.DropOffTime ?? target.DropOffTime;
                    target.CpuFirstTime = command.CpuFirstTime ?? target.CpuFirstTime;
                    target.DriverPickupMin = command.DriverPickupMin ?? target.DriverPickupMin;
                    target.DriverAtLocation = command.DriverAtLocation ?? target.DriverAtLocation;
                    target.BillingCenter = command.BillingCenter ?? target.BillingCenter;
                    target.Billingcenterr = command.Billingcenterr ?? target.Billingcenterr;
                    target.OrdererName = command.OrdererName ?? target.OrdererName;
                    target.OrdererNote = command.OrdererNote ?? target.OrdererNote;
                    target.DestinationLatitude = command.DestinationLatitude ?? target.DestinationLatitude;
                    target.DestinationLongitude = command.DestinationLongitude ?? target.DestinationLongitude;
                    target.DispatchSubtype = command.DispatchSubtype;
                    target.Passenger = command.Passenger ?? target.Passenger;
                    target.IdTariff = command.IdTariff ?? target.IdTariff;
                    target.IdPaymentType = command.IdPaymentType ?? target.IdPaymentType;
                    target.IdInternalDepartment = (command.IdInternalDepartment < 0) ? target.IdInternalDepartment : command.IdInternalDepartment;
                    target.PrimaryDistanceRequestTime = command.PrimaryDistanceRequestTime ?? target.PrimaryDistanceRequestTime;
                    target.SecondaryDistanceRequestTime = command.SecondaryDistanceRequestTime ?? target.SecondaryDistanceRequestTime;
                    target.IdInternalDepartmentUsed = command.IdInternalDepartmentUsed ?? target.IdInternalDepartmentUsed;
                    target.PurchaseQuantity = command.PurchaseQuantity ?? target.PurchaseQuantity;
                    target.ReceiptedInvoices = command.ReceiptedInvoices;
                    target.TripRemark = command.TripRemark ?? target.TripRemark;
                    target.NoCustomerRequest = command.NoCustomerRequest ?? target.NoCustomerRequest;
                    target.NotifyUnitPending = command.NotifyUnitPending;
                    target.StreetPickup = command.StreetPickup ?? target.StreetPickup;
                    target.LastUpdate = command.LastUpdate ?? target.LastUpdate;
                    target.LastUpdateBy = command.LastUpdateBy ?? target.LastUpdateBy;
                    target.AssignedIdDriver = command.AssignedIdDriver ?? target.AssignedIdDriver;
                    target.AssignedIdUnit = command.AssignedIdUnit ?? target.AssignedIdUnit;
                    target.AssignedIdVehicle = command.AssignedIdVehicle ?? target.AssignedIdVehicle;
                    target.IdServiceType = command.IdServiceType ?? target.IdServiceType;
                    target.PassengerPhone = command.PassengerPhone ?? target.PassengerPhone;
                    target.DispatchTriggered = command.DispatchTriggered ?? target.DispatchTriggered;
                    target.CpuFinalDestinationTime = command.CpuFinalDestinationTime ?? target.CpuFinalDestinationTime;
                    target.CardNumber = command.CardNumber ?? target.CardNumber;

                    await _taxiCompanyUnitOfWork.Repository<TargetHistory>().UpdateAsync(target,
                                                                                  cancellationToken,
                                                                                  ApplicationConstants.Cache.GetAllTargetsCacheKey);

                    return await Result<int>.SuccessAsync(target.Id, _localizer["Target Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Target Not Found!"]);
                }
            }
        }
    }
}