﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Targets.Queries.Export
{
    public class ExportTargetsQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportTargetsQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportTargetsQueryHandler : IRequestHandler<ExportTargetsQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportTargetsQueryHandler> _localizer;

        public ExportTargetsQueryHandler(IExcelService excelService,
                                         ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                         IStringLocalizer<ExportTargetsQueryHandler> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportTargetsQuery query, CancellationToken cancellationToken)
        {
            var targetFilterSpec = new TargetFilterSpecification(query.SearchString);

            var targets = await _taxiCompanyUnitOfWork.Repository<TargetHistory>().Entities
                .Specify(targetFilterSpec)
                .ToListAsync(cancellationToken);

            var data = await _excelService.ExportAsync(targets, new Dictionary<string, Func<TargetHistory, object>>
            {
                { _localizer["Id"], item => item.Id },
                { _localizer["Phone"], item => item.Phone },
                { _localizer["Street"], item => item.Street },
                { _localizer["Number"], item => item.Number },
                { _localizer["Lbl"], item => item.Lbl },
                { _localizer["Status"], item => item.Status },
                { _localizer["UnitId"], item => item.UnitId },
                { _localizer["AssignedAt"], item => item.AssignedAt },
                { _localizer["Remark"], item => item.Remark },
                { _localizer["DatetimeUpdate"], item => item.DatetimeUpdate },
                { _localizer["IdClient"], item => item.IdClient },
                { _localizer["IsDeleted"], item => item.IsDeleted },
                { _localizer["IdRecord"], item => item.IdRecord },
                { _localizer["Inserted"], item => item.Inserted },
                { _localizer["Preorder"], item => item.Preorder },
                { _localizer["Dispatchat"], item => item.Dispatchat },
                { _localizer["RemindAt"], item => item.RemindAt },
                { _localizer["DispatchNow"], item => item.DispatchNow },
                { _localizer["IdOperator"], item => item.IdOperator },
                { _localizer["IdDispatcher"], item => item.IdDispatcher },
                { _localizer["IdCompany"], item => item.IdPartnerCompany },
                { _localizer["PurchaseOrder"], item => item.PurchaseOrder },
                { _localizer["HsMid"], item => item.HsMid },
                { _localizer["TaxiNumber"], item => item.TaxiNumber },
                { _localizer["Latitude"], item => item.Latitude },
                { _localizer["Longitude"], item => item.Longitude },
                { _localizer["OrientLatitude"], item => item.OrientLatitude },
                { _localizer["OrientLongitude"], item => item.OrientLongitude },
                { _localizer["AutoDispatch"], item => item.AutoDispatch },
                { _localizer["AutoDispatched"], item => item.AutoDispatched },
                { _localizer["DatetimePreorder"], item => item.DatetimePreorder },
                { _localizer["Destination"], item => item.Destination },
                { _localizer["Customer"], item => item.Customer },
                { _localizer["Type1"], item => item.Type1 },
                { _localizer["Type2"], item => item.Type2 },
                { _localizer["Type3"], item => item.Type3 },
                { _localizer["Type4"], item => item.Type4 },
                { _localizer["Type5"], item => item.Type5 },
                { _localizer["Type6"], item => item.Type6 },
                { _localizer["Type7"], item => item.Type7 },
                { _localizer["Type8"], item => item.Type8 },
                { _localizer["Type9"], item => item.Type9 },
                { _localizer["Type10"], item => item.Type10 },
                { _localizer["Type11"], item => item.Type11 },
                { _localizer["Type12"], item => item.Type12 },
                { _localizer["Type13"], item => item.Type13 },
                { _localizer["Type14"], item => item.Type14 },
                { _localizer["Type15"], item => item.Type15 },
                { _localizer["Type16"], item => item.Type16 },
                { _localizer["Type17"], item => item.Type17 },
                { _localizer["Type18"], item => item.Type18 },
                { _localizer["Type19"], item => item.Type19 },
                { _localizer["Type20"], item => item.Type20 },
                { _localizer["IdStand"], item => item.IdStand },
                { _localizer["IdZone"], item => item.IdZone },
                { _localizer["Distance"], item => item.Distance },
                { _localizer["TimeOfArrival"], item => item.TimeOfArrival },
                { _localizer["IdCompanyCredential"], item => item.IdCompanyCredential },
                { _localizer["Gdistance"], item => item.Gdistance },
                { _localizer["GtimeOfArrival"], item => item.GtimeOfArrival },
                { _localizer["PhoneLine"], item => item.PhoneLine },
                { _localizer["RequestedTime"], item => item.RequestedTime },
                { _localizer["ManualAssignReason"], item => item.ManualAssignReason },
                { _localizer["CompanyOrderNote"], item => item.CompanyOrderNote },
                { _localizer["Paid"], item => item.Paid },
                { _localizer["DispatchType"], item => item.DispatchType },
                { _localizer["CancellationReason"], item => item.CancellationReason },
                { _localizer["CpuPickupTime"], item => item.CpuPickupTime },
                { _localizer["DriverPickupTime"], item => item.DriverPickupTime },
                { _localizer["DriverDelay"], item => item.DriverDelay },
                { _localizer["OrderByDriver"], item => item.OrderByDriver },
                { _localizer["DelayedPayment"], item => item.DelayedPayment },
                { _localizer["Pickup"], item => item.Pickup },
                { _localizer["DropOffTime"], item => item.DropOffTime },
                { _localizer["CpuFirstTime"], item => item.CpuFirstTime },
                { _localizer["DriverPickupMin"], item => item.DriverPickupMin },
                { _localizer["DriverAtLocation"], item => item.DriverAtLocation },
                { _localizer["BillingCenter"], item => item.BillingCenter },
                { _localizer["Billing_Center"], item => item.Billingcenterr },
                { _localizer["OrdererName"], item => item.OrdererName },
                { _localizer["OrdererNote"], item => item.OrdererNote },
                { _localizer["DestinationLatitude"], item => item.DestinationLatitude },
                { _localizer["DestinationLongitude"], item => item.DestinationLongitude },
                { _localizer["DispatchSubtype"], item => item.DispatchSubtype },
                { _localizer["Passenger"], item => item.Passenger },
                { _localizer["IdTariff"], item => item.IdTariff },
                { _localizer["IdPaymentType"], item => item.IdPaymentType },
                { _localizer["IdInternalDepartment"], item => item.IdInternalDepartment },
                { _localizer["PrimaryDistanceRequestTime"], item => item.PrimaryDistanceRequestTime },
                { _localizer["SecondaryDistanceRequestTime"], item => item.SecondaryDistanceRequestTime },
                { _localizer["IdInternalDepartmentUsed"], item => item.IdInternalDepartmentUsed },
                { _localizer["PurchaseQuantity"], item => item.PurchaseQuantity },
                { _localizer["ReceiptedInvoices"], item => item.ReceiptedInvoices },
                { _localizer["TripRemark"], item => item.TripRemark },
                { _localizer["NoCustomerRequest"], item => item.NoCustomerRequest },
                { _localizer["NotifyUnitPending"], item => item.NotifyUnitPending },
                { _localizer["StreetPickup"], item => item.StreetPickup },
                { _localizer["LastUpdate"], item => item.LastUpdate },
                { _localizer["LastUpdateBy"], item => item.LastUpdateBy },
                { _localizer["AssignedIdDriver"], item => item.AssignedIdDriver },
                { _localizer["AssignedIdUnit"], item => item.AssignedIdUnit },
                { _localizer["AssignedIdVehicle"], item => item.AssignedIdVehicle },
                { _localizer["IdServiceType"], item => item.IdServiceType },
                { _localizer["PassengerPhone"], item => item.PassengerPhone },
                { _localizer["DispatchTriggered"], item => item.DispatchTriggered },
                { _localizer["CpuFinalDestinationTime"], item => item.CpuFinalDestinationTime },
                { _localizer["CardNumber"], item => item.CardNumber }
            }, sheetName: _localizer["Targets"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}