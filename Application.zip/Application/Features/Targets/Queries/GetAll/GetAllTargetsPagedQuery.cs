﻿namespace NetCabManager.Application.Features.Targets.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Application.Specifications.Catalog;

    public class GetAllTargetsPagedQuery : IRequest<PaginatedResult<GetAllTargetsResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }
        public int RadioValue { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public GetAllTargetsPagedQuery(int pageNumber, int pageSize, string searchString, int radioValue, DateTime startDate, DateTime endDate)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            RadioValue = radioValue;
            StartDate = startDate;
            EndDate = endDate;
        }
    }

    internal class GetAllTargetsPagedQueryHandler : IRequestHandler<GetAllTargetsPagedQuery, PaginatedResult<GetAllTargetsResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllTargetsPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllTargetsResponse>> Handle(GetAllTargetsPagedQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<TargetHistory, GetAllTargetsResponse>> expression = e => new GetAllTargetsResponse
            {
                Id = e.Id,
                Phone = e.Phone,
                Street = e.Street,
                Number = e.Number,
                Lbl = e.Lbl,
                Status = e.Status,
                UnitId = e.UnitId,
                AssignedAt = e.AssignedAt,
                Remark = e.Remark,
                DatetimeUpdate = e.DatetimeUpdate,
                IdClient = e.IdClient,
                IsDeleted = e.IsDeleted,
                IdRecord = e.IdRecord,
                Inserted = e.Inserted,
                Preorder = e.Preorder,
                Dispatchat = e.Dispatchat,
                RemindAt = e.RemindAt,
                DispatchNow = e.DispatchNow,
                IdOperator = e.IdOperator,
                IdDispatcher = e.IdDispatcher,
                IdPartnerCompany = e.IdPartnerCompany,
                PurchaseOrder = e.PurchaseOrder,
                HsMid = e.HsMid,
                TaxiNumber = e.TaxiNumber,
                Latitude = e.Latitude,
                Longitude = e.Longitude,
                OrientLatitude = e.OrientLatitude,
                OrientLongitude = e.OrientLongitude,
                AutoDispatch = e.AutoDispatch,
                AutoDispatched = e.AutoDispatched,
                DatetimePreorder = e.DatetimePreorder,
                Destination = e.Destination,
                Customer = e.Customer,
                Type1 = e.Type1,
                Type2 = e.Type2,
                Type3 = e.Type3,
                Type4 = e.Type4,
                Type5 = e.Type5,
                Type6 = e.Type6,
                Type7 = e.Type7,
                Type8 = e.Type8,
                Type9 = e.Type9,
                Type10 = e.Type10,
                Type11 = e.Type11,
                Type12 = e.Type12,
                Type13 = e.Type13,
                Type14 = e.Type14,
                Type15 = e.Type15,
                Type16 = e.Type16,
                Type17 = e.Type17,
                Type18 = e.Type18,
                Type19 = e.Type19,
                Type20 = e.Type20,
                IdStand = e.IdStand,
                IdZone = e.IdZone,
                Distance = e.Distance,
                TimeOfArrival = e.TimeOfArrival,
                IdCompanyCredential = e.IdCompanyCredential,
                Gdistance = e.Gdistance,
                GtimeOfArrival = e.GtimeOfArrival,
                PhoneLine = e.PhoneLine,
                RequestedTime = e.RequestedTime,
                ManualAssignReason = e.ManualAssignReason,
                CompanyOrderNote = e.CompanyOrderNote,
                Paid = e.Paid,
                DispatchType = e.DispatchType,
                CancellationReason = e.CancellationReason,
                CpuPickupTime = e.CpuPickupTime,
                DriverPickupTime = e.DriverPickupTime,
                DriverDelay = e.DriverDelay,
                OrderByDriver = e.OrderByDriver,
                DelayedPayment = e.DelayedPayment,
                Pickup = e.Pickup,
                DropOffTime = e.DropOffTime,
                CpuFirstTime = e.CpuFirstTime,
                DriverPickupMin = e.DriverPickupMin,
                DriverAtLocation = e.DriverAtLocation,
                BillingCenter = e.BillingCenter,
                Billingcenterr = e.Billingcenterr,
                OrdererName = e.OrdererName,
                OrdererNote = e.OrdererNote,
                DestinationLatitude = e.DestinationLatitude,
                DestinationLongitude = e.DestinationLongitude,
                DispatchSubtype = e.DispatchSubtype,
                Passenger = e.Passenger,
                IdTariff = e.IdTariff,
                IdPaymentType = e.IdPaymentType,
                IdInternalDepartment = e.IdInternalDepartment,
                PrimaryDistanceRequestTime = e.PrimaryDistanceRequestTime,
                SecondaryDistanceRequestTime = e.SecondaryDistanceRequestTime,
                IdInternalDepartmentUsed = e.IdInternalDepartmentUsed,
                PurchaseQuantity = e.PurchaseQuantity,
                ReceiptedInvoices = e.ReceiptedInvoices,
                TripRemark = e.TripRemark,
                NoCustomerRequest = e.NoCustomerRequest,
                NotifyUnitPending = e.NotifyUnitPending,
                StreetPickup = e.StreetPickup,
                LastUpdate = e.LastUpdate,
                LastUpdateBy = e.LastUpdateBy,
                AssignedIdDriver = e.AssignedIdDriver,
                AssignedIdUnit = e.AssignedIdUnit,
                AssignedIdVehicle = e.AssignedIdVehicle,
                IdServiceType = e.IdServiceType,
                PassengerPhone = e.PassengerPhone,
                DispatchTriggered = e.DispatchTriggered,
                CpuFinalDestinationTime = e.CpuFinalDestinationTime,
                CardNumber = e.CardNumber
            };

            var targetsSpec = new TargetFilterSpecification(request.SearchString);

            if (request.RadioValue == 1)
            {
                var data = await _taxiCompanyUnitOfWork.Repository<TargetHistory>().Entities
                .Where(t => t.Inserted >= request.StartDate && t.Inserted <= request.EndDate)
                .Specify(targetsSpec)
                .Select(expression)
                .ToPaginatedListAsync(request.PageNumber, request.PageSize);

                return data;
            }
            else
            {
                var data = await _taxiCompanyUnitOfWork.Repository<TargetHistory>().Entities
                .Where(t => t.Dispatchat >= request.StartDate && t.Dispatchat <= request.EndDate)
                .Specify(targetsSpec)
                .Select(expression)
                .ToPaginatedListAsync(request.PageNumber, request.PageSize);

                return data;
            }
        }
    }
}