﻿namespace NetCabManager.Application.Features.Targets.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllTargetsQuery : IRequest<Result<List<GetAllTargetsResponse>>>
    {
        public GetAllTargetsQuery()
        {
        }
    }

    internal class GetAllTargetsQueryHandler : IRequestHandler<GetAllTargetsQuery, Result<List<GetAllTargetsResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllTargetsQueryHandler(IMapper mapper,
                                         ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                         IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllTargetsResponse>>> Handle(GetAllTargetsQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllTargetsCacheKey);

            Task<List<TargetHistory>> getAllTargets() => _taxiCompanyUnitOfWork.Repository<TargetHistory>().GetAllAsync();

            var targetList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllTargetsCacheKey, getAllTargets);

            var mappedTargets = _mapper.Map<List<GetAllTargetsResponse>>(targetList);

            return await Result<List<GetAllTargetsResponse>>.SuccessAsync(mappedTargets);
        }
    }
}