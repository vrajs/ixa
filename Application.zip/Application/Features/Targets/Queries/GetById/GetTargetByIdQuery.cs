﻿namespace NetCabManager.Application.Features.Targets.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.Targets.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetTargetByIdQuery : IRequest<Result<GetAllTargetsResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetTargetByIdQueryHandler : IRequestHandler<GetTargetByIdQuery, Result<GetAllTargetsResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetTargetByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllTargetsResponse>> Handle(GetTargetByIdQuery query, CancellationToken cancellationToken)
        {
            var target = await _taxiCompanyUnitOfWork.Repository<TargetHistory>().GetByIdAsync(query.Id);

            var mappedTarget = _mapper.Map<GetAllTargetsResponse>(target);

            return await Result<GetAllTargetsResponse>.SuccessAsync(mappedTarget);
        }
    }
}