﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
namespace NetCabManager.Application.Features.Vehicles.Commands.Delete
{
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    public class DeleteVehicleCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteVehicleCommandHandler : IRequestHandler<DeleteVehicleCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeleteVehicleCommandHandler> _localizer;

        public DeleteVehicleCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, 
                                           IStringLocalizer<DeleteVehicleCommandHandler> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeleteVehicleCommand command, CancellationToken cancellationToken)
        {
            var vehicle = await _taxiCompanyUnitOfWork.Repository<Vehicle>().GetByIdAsync(command.Id);

            if (vehicle != null)
            {
                await _taxiCompanyUnitOfWork.Repository<Vehicle>().DeleteAsync(vehicle, 
                                                                               cancellationToken, 
                                                                               ApplicationConstants.Cache.GetAllVehiclesCacheKey);

                return await Result<int>.SuccessAsync(vehicle.Id, _localizer["Vehicle Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Vechile Not Found!"]);
            }
        }
    }
}