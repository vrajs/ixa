﻿namespace NetCabManager.Application.Features.Vehicles.Queries.GettAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;

    public class GetAllVehiclesPagedQuery : IRequest<PaginatedResult<GetAllVehiclesResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }

        public GetAllVehiclesPagedQuery(int pageNumber, int pageSize, string searchString)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
        }
    }

    internal class GetAllVehiclesPagedQueryHandler : IRequestHandler<GetAllVehiclesPagedQuery, PaginatedResult<GetAllVehiclesResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllVehiclesPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllVehiclesResponse>> Handle(GetAllVehiclesPagedQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<Vehicle, GetAllVehiclesResponse>> expression = e => new GetAllVehiclesResponse
            {
                Id = e.Id,
                Picture = e.Picture,
                RegistrationNumber = e.RegistrationNumber,
                IdCar = e.IdCar,
                IdCarType = e.IdCarType,
                IdColour = e.IdColour,
                EngineDisplacement = e.EngineDisplacement,
                EnginePower = e.EnginePower,
                Year = e.Year,
                NumberOfSeats = e.NumberOfSeats,
                RegistrationDate = e.RegistrationDate,
                OverviewDate = e.OverviewDate,
                Type1 = e.Type1,
                Type2 = e.Type2,
                Type3 = e.Type3,
                Type4 = e.Type4,
                Type5 = e.Type5,
                Type6 = e.Type6,
                Type7 = e.Type7,
                Type8 = e.Type8,
                Type9 = e.Type9,
                Type10 = e.Type10,
                Type11 = e.Type11,
                Type12 = e.Type12,
                Type13 = e.Type13,
                Type14 = e.Type14,
                Type15 = e.Type15,
                Type16 = e.Type16,
                Type17 = e.Type17,
                Type18 = e.Type18,
                Type19 = e.Type19,
                Type20 = e.Type20,
                Note = e.Note,
                IsDeleted = e.IsDeleted,
                VehicleNumber = e.VehicleNumber,
                RegistrationDateTo = e.RegistrationDateTo,
                InsurancePolicy = e.InsurancePolicy,
                InsurancePolicyNumber = e.InsurancePolicyNumber,
                MOTExpirationDate = e.MOTExpirationDate,
                PriceListNumber = e.PriceListNumber,
                LicenseNumber = e.LicenseNumber,
                LicenseExpirationDate = e.LicenseExpirationDate,
                VehicleMake = e.VehicleMake,
                VehicleModel = e.VehicleModel,
                IdInternalDepartment = e.IdInternalDepartment
            };

            var vehiclesSpec = new VehicleFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<Vehicle>().Entities
               .Specify(vehiclesSpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}