﻿namespace NetCabManager.Application.Features.Vehicles.Queries.GettAll
{
    using System;

    public class GetAllVehiclesResponse
    {
        public int Id { get; set; }
        public string RegistrationNumber { get; set; }
        public string IdCar { get; set; }
        public string IdCarType { get; set; }
        public int? IdColour { get; set; }
        public string EngineDisplacement { get; set; }
        public string EnginePower { get; set; }
        public int? Year { get; set; }
        public int? NumberOfSeats { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? OverviewDate { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string Note { get; set; }
        public bool? IsDeleted { get; set; }
        public int? VehicleNumber { get; set; }
        public DateTime? RegistrationDateTo { get; set; }
        public string InsurancePolicy { get; set; }
        public string InsurancePolicyNumber { get; set; }
        public DateTime? MOTExpirationDate { get; set; }
        public string PriceListNumber { get; set; }
        public string LicenseNumber { get; set; }
        public DateTime? LicenseExpirationDate { get; set; }
        public byte[] Picture { get; set; }
        public string ConvertedPicture { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public int? IdInternalDepartment { get; set; }

        public GetAllVehiclesResponse()
        {
            RegistrationDate = DateTime.Today;
            RegistrationDateTo = DateTime.Today;
            OverviewDate = DateTime.Today;
            MOTExpirationDate = DateTime.Today;
            LicenseExpirationDate = DateTime.Today;
        }

        public bool GetTypeValue(int index)
        {
            switch (index)
            {
                case 1: return Convert.ToBoolean(Type1);
                case 2: return Convert.ToBoolean(Type2);
                case 3: return Convert.ToBoolean(Type3);
                case 4: return Convert.ToBoolean(Type4);
                case 5: return Convert.ToBoolean(Type5);
                case 6: return Convert.ToBoolean(Type6);
                case 7: return Convert.ToBoolean(Type7);
                case 8: return Convert.ToBoolean(Type8);
                case 9: return Convert.ToBoolean(Type9);
                case 10: return Convert.ToBoolean(Type10);
                case 11: return Convert.ToBoolean(Type11);
                case 12: return Convert.ToBoolean(Type12);
                case 13: return Convert.ToBoolean(Type13);
                case 14: return Convert.ToBoolean(Type14);
                case 15: return Convert.ToBoolean(Type15);
                case 16: return Convert.ToBoolean(Type16);
                case 17: return Convert.ToBoolean(Type17);
                case 18: return Convert.ToBoolean(Type18);
                case 19: return Convert.ToBoolean(Type19);
                case 20: return Convert.ToBoolean(Type20);
                default: return false;
            }
        }
    }
}