﻿namespace NetCabManager.Application.Features.Vehicles.Queries.GettAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllVehiclesQuery : IRequest<Result<List<GetAllVehiclesResponse>>>
    {
        public GetAllVehiclesQuery()
        {
        }
    }

    internal class GetAllVehiclesQueryHandler : IRequestHandler<GetAllVehiclesQuery, Result<List<GetAllVehiclesResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllVehiclesQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllVehiclesResponse>>> Handle(GetAllVehiclesQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllVehiclesCacheKey);

            Task<List<Vehicle>> GetAllVehicles() => _taxiCompanyUnitOfWork.Repository<Vehicle>().GetAllAsync();

            var vehicleList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllVehiclesCacheKey, GetAllVehicles);

            var mappedVehicles = _mapper.Map<List<GetAllVehiclesResponse>>(vehicleList);

            return await Result<List<GetAllVehiclesResponse>>.SuccessAsync(mappedVehicles);
        }
    }
}