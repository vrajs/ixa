﻿namespace NetCabManager.Application.Features.Vehicles.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetVehicleByIdQuery : IRequest<Result<GetAllVehiclesResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetVehicleByIdQueryHandler : IRequestHandler<GetVehicleByIdQuery, Result<GetAllVehiclesResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetVehicleByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllVehiclesResponse>> Handle(GetVehicleByIdQuery query, CancellationToken cancellationToken)
        {
            var vehicle = await _taxiCompanyUnitOfWork.Repository<Vehicle>().GetByIdAsync(query.Id);

            var mappedVehicle = _mapper.Map<GetAllVehiclesResponse>(vehicle);

            return await Result<GetAllVehiclesResponse>.SuccessAsync(mappedVehicle);
        }
    }
}