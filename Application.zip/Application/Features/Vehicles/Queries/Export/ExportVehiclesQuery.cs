﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Vehicles.Queries.Export
{
    public class ExportVehiclesQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportVehiclesQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportVehiclesQueryHandler : IRequestHandler<ExportVehiclesQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportVehiclesQueryHandler> _localizer;

        public ExportVehiclesQueryHandler(IExcelService excelService,
                                          ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                          IStringLocalizer<ExportVehiclesQueryHandler> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportVehiclesQuery query, CancellationToken cancellationToken)
        {
            var vehicleFilterSpec = new VehicleFilterSpecification(query.SearchString);

            var vehicles = await _taxiCompanyUnitOfWork.Repository<Vehicle>().Entities.Specify(vehicleFilterSpec).ToListAsync(cancellationToken);

            var data = await _excelService.ExportAsync(vehicles, mappers: new Dictionary<string, Func<Vehicle, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["RegistrationNumber"], c => c.RegistrationNumber },
                { _localizer["IdCar"], c => c.IdCar },
                { _localizer["IdCarType"], c => c.IdCarType },
                { _localizer["IdColour"], c => c.IdColour },
                { _localizer["EngineDisplacement"], c => c.EngineDisplacement },
                { _localizer["EnginePower"], c => c.EnginePower },
                { _localizer["Year"], c => c.Year },
                { _localizer["NumberOfSeats"], c => c.NumberOfSeats },
                { _localizer["RegistrationDate"], c => c.RegistrationDate },
                { _localizer["OverviewDate"], c => c.OverviewDate },
                { _localizer["Type1"], c => c.Type1 },
                { _localizer["Type2"], c => c.Type2 },
                { _localizer["Type3"], c => c.Type3 },
                { _localizer["Type4"], c => c.Type4 },
                { _localizer["Type5"], c => c.Type5 },
                { _localizer["Type6"], c => c.Type6 },
                { _localizer["Type7"], c => c.Type7 },
                { _localizer["Type8"], c => c.Type8 },
                { _localizer["Type9"], c => c.Type9 },
                { _localizer["Type10"], c => c.Type10 },
                { _localizer["Type11"], c => c.Type11 },
                { _localizer["Type12"], c => c.Type12 },
                { _localizer["Type13"], c => c.Type13 },
                { _localizer["Type14"], c => c.Type14 },
                { _localizer["Type15"], c => c.Type15 },
                { _localizer["Type16"], c => c.Type16 },
                { _localizer["Type17"], c => c.Type17 },
                { _localizer["Type18"], c => c.Type18 },
                { _localizer["Type19"], c => c.Type19 },
                { _localizer["Type20"], c => c.Type20 },
                { _localizer["Note"], c => c.Note },
                { _localizer["IsDeleted"], c => c.IsDeleted },
                { _localizer["VehicleNumber"], c => c.VehicleNumber },
                { _localizer["RegistrationDateTo"], c => c.RegistrationDateTo },
                { _localizer["InsurancePolicy"], c => c.InsurancePolicy },
                { _localizer["InsurancePolicyNumber"], c => c.InsurancePolicyNumber },
                { _localizer["MOTExpirationDate"], c => c.MOTExpirationDate },
                { _localizer["PriceListNumber"], c => c.PriceListNumber },
                { _localizer["LicenseNumber"], c => c.LicenseNumber },
                { _localizer["LicenseExpirationDate"], c => c.LicenseExpirationDate },
                { _localizer["VehicleMake"], c => c.VehicleMake },
                { _localizer["VehicleModel"], c => c.VehicleModel },
                { _localizer["IdInternalDepartment"], c => c.IdInternalDepartment }
            }, sheetName: _localizer["Vehicles"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }

}