﻿namespace NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllTaxiCompanyRolesQuery : IRequest<Result<List<GetAllTaxiCompanyRolesResponse>>>
    {
        public GetAllTaxiCompanyRolesQuery()
        {
        }
    }

    internal class GetAllTaxiCompanyRolesQueryHandler : IRequestHandler<GetAllTaxiCompanyRolesQuery, Result<List<GetAllTaxiCompanyRolesResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly IAppCache _appCache;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllTaxiCompanyRolesQueryHandler(IMapper mapper, 
                                                  IAppCache appCache,
                                                  ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _appCache = appCache;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<List<GetAllTaxiCompanyRolesResponse>>> Handle(GetAllTaxiCompanyRolesQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllTaxiCompanyRolesCacheKey);

            Task<List<TaxiCompanyRole>> GetAllTaxiCompanyRoles() => _taxiCompanyUnitOfWork.Repository<TaxiCompanyRole>().GetAllAsync();

            var roleList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllTaxiCompanyRolesCacheKey, GetAllTaxiCompanyRoles);

            var mappedRoles = _mapper.Map<List<GetAllTaxiCompanyRolesResponse>>(roleList);

            return await Result<List<GetAllTaxiCompanyRolesResponse>>.SuccessAsync(mappedRoles);
        }
    }
}