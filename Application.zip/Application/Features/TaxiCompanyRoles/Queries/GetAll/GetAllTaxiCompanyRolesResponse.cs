﻿namespace NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll
{
    using NetCabManager.Domain.Entities.TaxiCompany;
    using System.Collections.Generic;

    public class GetAllTaxiCompanyRolesResponse
    {
        public int Id { get; set; }
        public string RoleName { get; set; }
        public virtual ICollection<TaxiCompanyUser> TaxiCompanyUsers { get; set; }
    }
}