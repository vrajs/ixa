﻿namespace NetCabManager.Application.Features.Drivers.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.Drivers.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetDriverByIdQuery : IRequest<Result<GetAllDriversResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetDriverByIdQueryHandler : IRequestHandler<GetDriverByIdQuery, Result<GetAllDriversResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetDriverByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllDriversResponse>> Handle(GetDriverByIdQuery query, CancellationToken cancellationToken)
        {
            var driver = await _taxiCompanyUnitOfWork.Repository<Driver>().GetByIdAsync(query.Id);

            var mappedDriver = _mapper.Map<GetAllDriversResponse>(driver);

            return await Result<GetAllDriversResponse>.SuccessAsync(mappedDriver);
        }
    }
}