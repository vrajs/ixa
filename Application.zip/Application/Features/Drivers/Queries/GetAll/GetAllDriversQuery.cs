﻿namespace NetCabManager.Application.Features.Drivers.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllDriversQuery : IRequest<Result<List<GetAllDriversResponse>>>
    {
        public GetAllDriversQuery()
        {
        }
    }

    internal class GetAllDriversQueryHandler : IRequestHandler<GetAllDriversQuery, Result<List<GetAllDriversResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllDriversQueryHandler(IMapper mapper,
                                         ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                         IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllDriversResponse>>> Handle(GetAllDriversQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllDriversCacheKey);

            Task<List<Driver>> GetAllDrivers() => _taxiCompanyUnitOfWork.Repository<Driver>().GetAllAsync();

            var driverList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllDriversCacheKey, GetAllDrivers);

            var mappedDrivers = _mapper.Map<List<GetAllDriversResponse>>(driverList);

            return await Result<List<GetAllDriversResponse>>.SuccessAsync(mappedDrivers);
        }
    }
}