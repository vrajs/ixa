﻿namespace NetCabManager.Application.Features.Drivers.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllDriversPagedInternalQuery : IRequest<PaginatedResult<GetAllDriversResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }
        public int IdInternalDepartment { get; set; }

        public GetAllDriversPagedInternalQuery(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
            IdInternalDepartment = idInternalDepartment;
        }
    }

    internal class GetAllDriversPagedInternalQueryHandler : IRequestHandler<GetAllDriversPagedInternalQuery, PaginatedResult<GetAllDriversResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllDriversPagedInternalQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllDriversResponse>> Handle(GetAllDriversPagedInternalQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<Driver, GetAllDriversResponse>> expression = e => new GetAllDriversResponse
            {
                Id = e.Id,
                Picture = e.Picture,
                IdUnit = e.IdUnit,
                Name = e.Name,
                Lastname = e.Lastname,
                IsDeleted = e.IsDeleted,
                Password = e.Password,
                GSM = e.GSM,
                RegistrationNumber = e.RegistrationNumber,
                Car = e.Car,
                IMEI = e.IMEI,
                License = e.License,
                Company = e.Company,
                Note = e.Note,
                Type1 = e.Type1,
                Type2 = e.Type2,
                Type3 = e.Type3,
                Type4 = e.Type4,
                Type5 = e.Type5,
                Type6 = e.Type6,
                Type7 = e.Type7,
                Type8 = e.Type8,
                Type9 = e.Type9,
                Type10 = e.Type10,
                Type11 = e.Type11,
                Type12 = e.Type12,
                Type13 = e.Type13,
                Type14 = e.Type14,
                Type15 = e.Type15,
                Type16 = e.Type16,
                Type17 = e.Type17,
                Type18 = e.Type18,
                Type19 = e.Type19,
                Type20 = e.Type20,
                CompanyPhone = e.CompanyPhone,
                HomePhone = e.HomePhone,
                IdCompany = e.IdCompany,
                Address = e.Address,
                IdPost = e.IdPost,
                CarType = e.CarType,
                CarColor = e.CarColor,
                EngineDisplacement = e.EngineDisplacement,
                EnginePower = e.EnginePower,
                Year = e.Year,
                NumberOfSeats = e.NumberOfSeats,
                RegistrationDate = e.RegistrationDate,
                OverviewDate = e.OverviewDate,
                PersonalId = e.PersonalId,
                Master = e.Master,
                ImportedDriverId = e.ImportedDriverId,
                ImportedCarId = e.ImportedCarId,
                Email = e.Email,
                LicenseExpiration = e.LicenseExpiration,
                IdInternalDepartment = e.IdInternalDepartment,
                LastUpdate = e.LastUpdate,
                LastUpdateBy = e.LastUpdateBy,
                IdNetworkProvider = e.IdNetworkProvider,
                Bluetooth = e.Bluetooth,
                IsController = e.IsController
            };

            var driversSpec = new DriverFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<Driver>().Entities
               .Where(d => d.IdInternalDepartment == request.IdInternalDepartment)
               .Specify(driversSpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}