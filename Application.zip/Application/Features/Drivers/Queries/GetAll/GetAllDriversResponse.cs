﻿namespace NetCabManager.Application.Features.Drivers.Queries.GetAll
{
    using System;

    public class GetAllDriversResponse
    {
        public int Id { get; set; }
        public string IdUnit { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public bool IsDeleted { get; set; }
        public string Password { get; set; }
        public string GSM { get; set; }
        public string RegistrationNumber { get; set; }
        public string Car { get; set; }
        public string IMEI { get; set; }
        public string License { get; set; }
        public string Company { get; set; }
        public string Note { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string CompanyPhone { get; set; }
        public string HomePhone { get; set; }
        public int? IdCompany { get; set; }
        public string Address { get; set; }
        public int? IdPost { get; set; }
        public string CarType { get; set; }
        public string CarColor { get; set; }
        public string EngineDisplacement { get; set; }
        public string EnginePower { get; set; }
        public int? Year { get; set; }
        public int? NumberOfSeats { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? OverviewDate { get; set; }
        public string PersonalId { get; set; }
        public int Master { get; set; }
        public int? ImportedDriverId { get; set; }
        public string ImportedCarId { get; set; }
        public string Email { get; set; }
        public DateTime? LicenseExpiration { get; set; }
        public byte[] Picture { get; set; }
        public string ConvertedPicture { get; set; }
        public int? IdInternalDepartment { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public int? IdNetworkProvider { get; set; }
        public bool? Bluetooth { get; set; }
        public bool? IsController { get; set; }

        //public List<Target> Targets { get; set; }

        //public List<Shift> Shifts { get; set; }

        //[ForeignKey("IdCompany")]
        //public virtual PartnerCompany PartnerCompany { get; set; }

        //[ForeignKey("IdPost")]
        //public virtual Post Post { get; set; }

        //[ForeignKey("IDInternalDepartment")]
        //public virtual InternalDepartment InternalDepartment { get; set; }

        //[NotMapped]
        //public List<PartnerCompany> PartnerCompanies { get; set; }

        //[NotMapped]
        //public List<Post> Posts { get; set; }

        //[NotMapped]
        //public List<InternalDepartment> InternalDepartments { get; set; }

        //[NotMapped]
        //public string[] TypesNames { get; set; }

        //[NotMapped]
        //[Display(Name = "Name")]
        //public string Fullname { get => $"{Name} {Lastname}"; }

        //[NotMapped]
        //[Display(Name = "Status")]
        //public string Status { get => Deleted ? "Deleted" : "Active"; }

        //[NotMapped]
        //[Display(Name = "Vehicle")]
        //public string VehicleString { get => $"{RegistrationNumber} {Car} {CarType}"; }
    }
}