﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Drivers.Queries.Export
{
    public class ExportDriversQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportDriversQuery(string searchString = "")
        {
            SearchString = searchString;
        }
    }

    internal class ExportDriversQueryHandler : IRequestHandler<ExportDriversQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportDriversQueryHandler> _localizer;

        public ExportDriversQueryHandler(IExcelService excelService,
                                         ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                         IStringLocalizer<ExportDriversQueryHandler> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportDriversQuery query, CancellationToken cancellationToken)
        {
            var driverFilterSpec = new DriverFilterSpecification(query.SearchString);

            var drivers = await _taxiCompanyUnitOfWork.Repository<Driver>().Entities.Specify(driverFilterSpec).ToListAsync(cancellationToken);

            var data = await _excelService.ExportAsync(drivers, mappers: new Dictionary<string, Func<Driver, object>>
            {
                { _localizer["Id"], c => c.Id },
                { _localizer["Id Unit"], c => c.IdUnit },
                { _localizer["Name"], c => c.Name },
                { _localizer["Lastname"], c => c.Lastname },
                { _localizer["GSM"], c => c.GSM },
                { _localizer["Registration Number"], c => c.RegistrationNumber },
                { _localizer["Car"], c => c.Car },
                { _localizer["IMEI"], c => c.IMEI },
                { _localizer["License"], c => c.License },
                { _localizer["Company"], c => c.Company },
                { _localizer["Note"], c => c.Note },
                { _localizer["Type 1"], c => c.Type1 },
                { _localizer["Type 2"], c => c.Type2 },
                { _localizer["Type 3"], c => c.Type3 },
                { _localizer["Type 4"], c => c.Type4 },
                { _localizer["Type 5"], c => c.Type5 },
                { _localizer["Type 6"], c => c.Type6 },
                { _localizer["Type 7"], c => c.Type7 },
                { _localizer["Type 8"], c => c.Type8 },
                { _localizer["Type 9"], c => c.Type9 },
                { _localizer["Type 10"], c => c.Type10 },
                { _localizer["Type 11"], c => c.Type11 },
                { _localizer["Type 12"], c => c.Type12 },
                { _localizer["Type 13"], c => c.Type13 },
                { _localizer["Type 14"], c => c.Type14 },
                { _localizer["Type 15"], c => c.Type15 },
                { _localizer["Type 16"], c => c.Type16 },
                { _localizer["Type 17"], c => c.Type17 },
                { _localizer["Type 18"], c => c.Type18 },
                { _localizer["Type 19"], c => c.Type19 },
                { _localizer["Type 20"], c => c.Type20 },
                { _localizer["Company Phone"], c => c.CompanyPhone },
                { _localizer["Home Phone"], c => c.HomePhone },
                { _localizer["Id Company"], c => c.IdCompany },
                { _localizer["Address"], c => c.Address },
                { _localizer["Id Post"], c => c.IdPost },
                { _localizer["Car Type"], c => c.CarType },
                { _localizer["Car Color"], c => c.CarColor },
                { _localizer["Engine Displacement"], c => c.EngineDisplacement },
                { _localizer["Engine Power"], c => c.EnginePower },
                { _localizer["Year"], c => c.Year },
                { _localizer["Number Of Seats"], c => c.NumberOfSeats },
                { _localizer["Registration Date"], c => c.RegistrationDate },
                { _localizer["Overview Date"], c => c.OverviewDate },
                { _localizer["Personal Id"], c => c.PersonalId },
                { _localizer["Master"], c => c.Master },
                { _localizer["Imported Driver Id"], c => c.ImportedDriverId },
                { _localizer["Imported Car Id"], c => c.ImportedCarId },
                { _localizer["Email"], c => c.Email },
                { _localizer["License Expiration"], c => c.LicenseExpiration },
                //{ _localizer["Picture"], c => c.Picture },
                { _localizer["Id Internal Department"], c => c.IdInternalDepartment },
                { _localizer["Last Update"], c => c.LastUpdate },
                { _localizer["Last Update By"], c => c.LastUpdateBy },
                { _localizer["Id Network Provider"], c => c.IdNetworkProvider },
                { _localizer["Bluetooth"], c => c.Bluetooth },
                { _localizer["Is Controller"], c => c.IsController }
            }, sheetName: _localizer["Drivers"]);

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}