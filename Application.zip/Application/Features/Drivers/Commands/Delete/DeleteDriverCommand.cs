﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.Drivers.Commands.Delete
{
    public class DeleteDriverCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeleteDriverCommandHandler : IRequestHandler<DeleteDriverCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeleteDriverCommand> _localizer;

        public DeleteDriverCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork, IStringLocalizer<DeleteDriverCommand> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeleteDriverCommand driverCommand, CancellationToken cancellationToken)
        {
            var driver = await _taxiCompanyUnitOfWork.Repository<Driver>().GetByIdAsync(driverCommand.Id);

            if (driver != null)
            {
                await _taxiCompanyUnitOfWork.Repository<Driver>().DeleteAsync(driver, 
                                                                              cancellationToken, 
                                                                              ApplicationConstants.Cache.GetAllDriversCacheKey);

                return await Result<int>.SuccessAsync(driver.Id, _localizer["Driver Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Driver Not Found!"]);
            }
        }
    }
}