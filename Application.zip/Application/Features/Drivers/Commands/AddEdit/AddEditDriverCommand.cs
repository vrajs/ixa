﻿namespace NetCabManager.Application.Features.Drivers.Commands.AddEdit
{
    using AutoMapper;
    using MediatR;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Localization;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public partial class AddEditDriverCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string IdUnit { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public bool IsDeleted { get; set; }
        public string Password { get; set; }
        public string GSM { get; set; }
        public string RegistrationNumber { get; set; }
        public string Car { get; set; }
        public string IMEI { get; set; }
        public string License { get; set; }
        public string Company { get; set; }
        public string Note { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public string CompanyPhone { get; set; }
        public string HomePhone { get; set; }
        public int? IdCompany { get; set; }
        public string Address { get; set; }
        public int? IdPost { get; set; }
        public string CarType { get; set; }
        public string CarColor { get; set; }
        public string EngineDisplacement { get; set; }
        public string EnginePower { get; set; }
        public int? Year { get; set; }
        public int? NumberOfSeats { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? OverviewDate { get; set; }
        public string PersonalId { get; set; }
        public int Master { get; set; }
        public int? ImportedDriverId { get; set; }
        public string ImportedCarId { get; set; }
        public string Email { get; set; }
        public DateTime? LicenseExpiration { get; set; }
        public byte[] Picture { get; set; }
        public int? IdInternalDepartment { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public int? IdNetworkProvider { get; set; }
        public bool? Bluetooth { get; set; }
        public bool? IsController { get; set; }

        public AddEditDriverCommand()
        {
            RegistrationDate = DateTime.Today;
            LicenseExpiration = DateTime.Today;
        }

        public bool GetTypeValue(int index)
        {
            switch (index)
            {
                case 1: return (bool)Type1;
                case 2: return (bool)Type2;
                case 3: return (bool)Type3;
                case 4: return (bool)Type4;
                case 5: return (bool)Type5;
                case 6: return (bool)Type6;
                case 7: return (bool)Type7;
                case 8: return (bool)Type8;
                case 9: return (bool)Type9;
                case 10: return (bool)Type10;
                case 11: return (bool)Type11;
                case 12: return (bool)Type12;
                case 13: return (bool)Type13;
                case 14: return (bool)Type14;
                case 15: return (bool)Type15;
                case 16: return (bool)Type16;
                case 17: return (bool)Type17;
                case 18: return (bool)Type18;
                case 19: return (bool)Type19;
                case 20: return (bool)Type20;
                default: return false;
            }
        }

    }

    internal class AddEditDriverCommandHandler : IRequestHandler<AddEditDriverCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly IStringLocalizer<AddEditDriverCommand> _localizer;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public AddEditDriverCommandHandler(IMapper mapper,
                                           IStringLocalizer<AddEditDriverCommand> localizer,
                                           ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _localizer = localizer;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<int>> Handle(AddEditDriverCommand driverCommand, CancellationToken cancellationToken)
        {
            if (await _taxiCompanyUnitOfWork.Repository<Driver>().Entities.Where(d => d.Id != driverCommand.Id)
                .AnyAsync(d => d.IdUnit == driverCommand.IdUnit, cancellationToken))
            {
                return await Result<int>.FailAsync(_localizer["Id Unit already exists."]);
            }

            if (await _taxiCompanyUnitOfWork.Repository<Driver>().Entities.Where(d => d.Id != driverCommand.Id)
                .AnyAsync(d => d.Password == driverCommand.Password, cancellationToken))
            {
                return await Result<int>.FailAsync(_localizer["Password already exists."]);
            }

            if (driverCommand.Id == 0)
            {
                var driverMapped = _mapper.Map<Driver>(driverCommand);

                await _taxiCompanyUnitOfWork.Repository<Driver>().AddAsync(driverMapped, 
                                                                           cancellationToken, 
                                                                           ApplicationConstants.Cache.GetAllDriversCacheKey);

                return await Result<int>.SuccessAsync(driverMapped.Id, _localizer["Driver Saved."]);
            }
            else
            {
                var driver = await _taxiCompanyUnitOfWork.Repository<Driver>().GetByIdAsync(driverCommand.Id);

                if (driver != null)
                {
                    driver.IdUnit = driverCommand.IdUnit ?? driver.IdUnit;
                    driver.Name = driverCommand.Name ?? driver.Name;
                    driver.Lastname = driverCommand.Lastname ?? driver.Lastname;
                    driver.IsDeleted = driverCommand.IsDeleted;
                    driver.Password = driverCommand.Password ?? driver.Password;
                    driver.GSM = driverCommand.GSM ?? driver.GSM;
                    driver.RegistrationNumber = driverCommand.RegistrationNumber ?? driver.RegistrationNumber;
                    driver.Car = driverCommand.Car ?? driver.Car;
                    driver.IMEI = driverCommand.IMEI ?? driver.IMEI;
                    driver.License = driverCommand.License ?? driver.License;
                    driver.Company = driverCommand.Company ?? driver.Company;
                    driver.Note = driverCommand.Note ?? driver.Note;
                    driver.Type1 = driverCommand.Type1;
                    driver.Type2 = driverCommand.Type2;
                    driver.Type3 = driverCommand.Type3;
                    driver.Type4 = driverCommand.Type4;
                    driver.Type5 = driverCommand.Type5;
                    driver.Type6 = driverCommand.Type6;
                    driver.Type7 = driverCommand.Type7;
                    driver.Type8 = driverCommand.Type8;
                    driver.Type9 = driverCommand.Type9;
                    driver.Type10 = driverCommand.Type10;
                    driver.Type11 = driverCommand.Type11;
                    driver.Type12 = driverCommand.Type12;
                    driver.Type13 = driverCommand.Type13;
                    driver.Type14 = driverCommand.Type14;
                    driver.Type15 = driverCommand.Type15;
                    driver.Type16 = driverCommand.Type16;
                    driver.Type17 = driverCommand.Type17;
                    driver.Type18 = driverCommand.Type18;
                    driver.Type19 = driverCommand.Type19;
                    driver.Type20 = driverCommand.Type20;
                    driver.CompanyPhone = driverCommand.CompanyPhone ?? driver.CompanyPhone;
                    driver.HomePhone = driverCommand.HomePhone ?? driver.HomePhone;
                    driver.IdCompany = (driverCommand.IdCompany < 0) ? driver.IdCompany : driverCommand.IdCompany;
                    driver.Address = driverCommand.Address ?? driver.Address;
                    driver.IdPost = (driverCommand.IdPost < 0) ? driver.IdPost : driverCommand.IdPost;
                    driver.CarType = driverCommand.CarType ?? driver.CarType;
                    driver.CarColor = driverCommand.CarColor ?? driver.CarColor;
                    driver.EngineDisplacement = driverCommand.EngineDisplacement ?? driver.EngineDisplacement;
                    driver.EnginePower = driverCommand.EnginePower ?? driver.EnginePower;
                    driver.Year = (driverCommand.Year <= 0) ? driver.Year : driverCommand.Year;
                    driver.NumberOfSeats = (driverCommand.NumberOfSeats < 0) ? driver.NumberOfSeats : driverCommand.NumberOfSeats;
                    driver.RegistrationDate = driverCommand.RegistrationDate ?? driver.RegistrationDate;
                    driver.OverviewDate = driverCommand.OverviewDate ?? driver.OverviewDate;
                    driver.PersonalId = driverCommand.PersonalId ?? driver.PersonalId;
                    driver.Master = (driverCommand.Master < 0) ? driver.Master : driverCommand.Master;
                    driver.ImportedDriverId = (driverCommand.ImportedDriverId < 0) ? driver.ImportedDriverId : driverCommand.ImportedDriverId;
                    driver.ImportedCarId = driverCommand.ImportedCarId ?? driver.ImportedCarId;
                    driver.Email = driverCommand.Email ?? driver.Email;
                    driver.LicenseExpiration = driverCommand.LicenseExpiration ?? driver.LicenseExpiration;
                    driver.Picture = driverCommand.Picture ?? driver.Picture;
                    driver.IdInternalDepartment = (driverCommand.IdInternalDepartment < 0) ? driver.IdInternalDepartment : driverCommand.IdInternalDepartment;
                    driver.LastUpdate = DateTime.UtcNow;
                    driver.LastUpdateBy = (driverCommand.LastUpdateBy < 0) ? driver.LastUpdateBy : driverCommand.LastUpdateBy;
                    driver.IdNetworkProvider = (driverCommand.IdNetworkProvider < 0) ? driver.IdNetworkProvider : driverCommand.IdNetworkProvider;
                    driver.Bluetooth = driverCommand.Bluetooth;
                    driver.IsController = driverCommand.IsController;

                    await _taxiCompanyUnitOfWork.Repository<Driver>().UpdateAsync(driver, 
                                                                                  cancellationToken, 
                                                                                  ApplicationConstants.Cache.GetAllDriversCacheKey);

                    return await Result<int>.SuccessAsync(driver.Id, _localizer["Driver Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Driver Not Found!"]);
                }
            }
        }
    }
}