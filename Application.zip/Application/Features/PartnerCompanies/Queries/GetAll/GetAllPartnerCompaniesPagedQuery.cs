﻿namespace NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll
{
    using MediatR;
    using NetCabManager.Application.Extensions;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Application.Specifications.Catalog;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllPartnerCompaniesPagedQuery : IRequest<PaginatedResult<GetAllPartnerCompaniesResponse>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SearchString { get; set; }

        public GetAllPartnerCompaniesPagedQuery(int pageNumber, int pageSize, string searchString)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            SearchString = searchString;
        }
    }

    internal class GetAllPartnerCompaniesPagedQueryHandler : IRequestHandler<GetAllPartnerCompaniesPagedQuery, PaginatedResult<GetAllPartnerCompaniesResponse>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetAllPartnerCompaniesPagedQueryHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<PaginatedResult<GetAllPartnerCompaniesResponse>> Handle(GetAllPartnerCompaniesPagedQuery request, CancellationToken cancellationToken)
        {
            Expression<Func<PartnerCompany, GetAllPartnerCompaniesResponse>> expression = expression => new GetAllPartnerCompaniesResponse
            {
                Id = expression.Id,
                Name = expression.Name,
                Address = expression.Address,
                IdPost = expression.IdPost,
                TaxId = expression.TaxId,
                Deleted = expression.Deleted,
                IdRecord = expression.IdRecord,
                InternalCompany = expression.InternalCompany,
                DelayedPaymentDefault = expression.DelayedPaymentDefault,
                Post = expression.Post,
                Phone = expression.Phone,
                IdPaymentTypeDefault = expression.IdPaymentTypeDefault,
                IdTariffDefault = expression.IdTariffDefault,
                ShortName = expression.ShortName,
                ContractNumber = expression.ContractNumber,
                Inserted = expression.Inserted,
                Comment = expression.Comment,
                CouponValue = expression.CouponValue,
                ContractText = expression.ContractText,
                PaymentDueDateText = expression.PaymentDueDateText,
                BookingRemarks = expression.BookingRemarks,
                Einvoice = expression.Einvoice,
                IBAN = expression.IBAN,
                RegisterNumber = expression.RegisterNumber,
                Discount = expression.Discount,
                SignatureInvoice = expression.SignatureInvoice,
                DefaultType1 = expression.DefaultType1,
                DefaultType2 = expression.DefaultType2,
                DefaultType3 = expression.DefaultType3,
                DefaultType4 = expression.DefaultType4,
                DefaultType5 = expression.DefaultType5,
                DefaultType6 = expression.DefaultType6,
                DefaultType7 = expression.DefaultType7,
                DefaultType8 = expression.DefaultType8,
                DefaultType9 = expression.DefaultType9,
                DefaultType10 = expression.DefaultType10,
                DefaultType11 = expression.DefaultType11,
                DefaultType12 = expression.DefaultType12,
                DefaultType13 = expression.DefaultType13,
                DefaultType14 = expression.DefaultType14,
                DefaultType15 = expression.DefaultType15,
                DefaultType16 = expression.DefaultType16,
                DefaultType17 = expression.DefaultType17,
                DefaultType18 = expression.DefaultType18,
                DefaultType19 = expression.DefaultType19,
                DefaultType20 = expression.DefaultType20,
                PassValidation = expression.PassValidation,
                DefaultVehicleType1 = expression.DefaultVehicleType1,
                DefaultVehicleType2 = expression.DefaultVehicleType2,
                DefaultVehicleType3 = expression.DefaultVehicleType3,
                DefaultVehicleType4 = expression.DefaultVehicleType4,
                DefaultVehicleType5 = expression.DefaultVehicleType5,
                DefaultVehicleType6 = expression.DefaultVehicleType6,
                DefaultVehicleType7 = expression.DefaultVehicleType7,
                DefaultVehicleType8 = expression.DefaultVehicleType8,
                DefaultVehicleType9 = expression.DefaultVehicleType9,
                DefaultVehicleType10 = expression.DefaultVehicleType10,
                DefaultVehicleType11 = expression.DefaultVehicleType11,
                DefaultVehicleType12 = expression.DefaultVehicleType12,
                DefaultVehicleType13 = expression.DefaultVehicleType13,
                DefaultVehicleType14 = expression.DefaultVehicleType14,
                DefaultVehicleType15 = expression.DefaultVehicleType15,
                DefaultVehicleType16 = expression.DefaultVehicleType16,
                DefaultVehicleType17 = expression.DefaultVehicleType17,
                DefaultVehicleType18 = expression.DefaultVehicleType18,
                DefaultVehicleType19 = expression.DefaultVehicleType19,
                DefaultVehicleType20 = expression.DefaultVehicleType20,
                IdCompanyBlock = expression.IdCompanyBlock,
                IdCompanySlip = expression.IdCompanySlip,
                OutsourcingCompany = expression.OutsourcingCompany
            };

            var partnerCompanySpec = new PartnerCompanyFilterSpecification(request.SearchString);

            var data = await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().Entities
               .Specify(partnerCompanySpec)
               .Select(expression)
               .ToPaginatedListAsync(request.PageNumber, request.PageSize);

            return data;
        }
    }
}