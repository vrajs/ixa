﻿namespace NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllPartnerCompaniesQuery : IRequest<Result<List<GetAllPartnerCompaniesResponse>>>
    {
        public GetAllPartnerCompaniesQuery()
        {
        }
    }

    internal class GetAllPartnerCompaniesQueryHandler : IRequestHandler<GetAllPartnerCompaniesQuery, Result<List<GetAllPartnerCompaniesResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllPartnerCompaniesQueryHandler(IMapper mapper,
                                                  ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                  IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllPartnerCompaniesResponse>>> Handle(GetAllPartnerCompaniesQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllPartnerCompaniesCacheKey);

            Task<List<PartnerCompany>> getAllPartnerCompanies() => _taxiCompanyUnitOfWork.Repository<PartnerCompany>().GetAllAsync();

            var partnerCompanyList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllPartnerCompaniesCacheKey, getAllPartnerCompanies);

            var mappedPartnerCompanies = _mapper.Map<List<GetAllPartnerCompaniesResponse>>(partnerCompanyList);

            return await Result<List<GetAllPartnerCompaniesResponse>>.SuccessAsync(mappedPartnerCompanies);
        }
    }
}