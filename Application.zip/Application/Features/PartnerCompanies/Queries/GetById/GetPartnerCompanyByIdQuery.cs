﻿namespace NetCabManager.Application.Features.PartnerCompanies.Queries.GetById
{
    using AutoMapper;
    using MediatR;
    using NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Wrapper;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetPartnerCompanyByIdQuery : IRequest<Result<GetAllPartnerCompaniesResponse>>
    {
        public int Id { get; set; }
    }

    internal class GetPartnerCompanyByIdQueryHandler : IRequestHandler<GetPartnerCompanyByIdQuery, Result<GetAllPartnerCompaniesResponse>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;

        public GetPartnerCompanyByIdQueryHandler(IMapper mapper, ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
        }

        public async Task<Result<GetAllPartnerCompaniesResponse>> Handle(GetPartnerCompanyByIdQuery query, CancellationToken cancellationToken)
        {
            var partnerCompany = await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().GetByIdAsync(query.Id);

            var mappedPartnerCompany = _mapper.Map<GetAllPartnerCompaniesResponse>(partnerCompany);

            return await Result<GetAllPartnerCompaniesResponse>.SuccessAsync(mappedPartnerCompany);
        }
    }
}