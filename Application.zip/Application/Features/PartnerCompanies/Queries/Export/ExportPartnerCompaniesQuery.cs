﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Extensions;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Application.Interfaces.Services;
using NetCabManager.Application.Specifications.Catalog;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.PartnerCompanies.Queries.Export
{
    public class ExportPartnerCompaniesQuery : IRequest<Result<string>>
    {
        public string SearchString { get; set; }

        public ExportPartnerCompaniesQuery(string searchString)
        {
            SearchString = searchString;
        }
    }

    internal class ExportPartnerCompaniesQueryHandler : IRequestHandler<ExportPartnerCompaniesQuery, Result<string>>
    {
        private readonly IExcelService _excelService;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<ExportPartnerCompaniesQuery> _localizer;

        public ExportPartnerCompaniesQueryHandler(IExcelService excelService,
                                                  ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                  IStringLocalizer<ExportPartnerCompaniesQuery> localizer)
        {
            _excelService = excelService;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<string>> Handle(ExportPartnerCompaniesQuery query, CancellationToken cancellationToken)
        {
            var partnerCompaniesFilterSpec = new PartnerCompanyFilterSpecification(query.SearchString);

            var partnerCompanies = await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().Entities
                .Specify(partnerCompaniesFilterSpec)
                .ToListAsync(cancellationToken);

            var data = await _excelService.ExportAsync(data: partnerCompanies, mappers: new Dictionary<string, Func<PartnerCompany, object>>
            {
                { _localizer["Id"], item => item.Id },
                { _localizer["Name"], item => item.Name },
                { _localizer["Address"], item => item.Address },
                { _localizer["IdPost"], item => item.IdPost },
                { _localizer["TaxId"], item => item.TaxId },
                { _localizer["Deleted"], item => item.Deleted },
                { _localizer["IdRecord"], item => item.IdRecord },
                { _localizer["InternalCompany"], item => item.InternalCompany },
                { _localizer["DelayedPaymentDefault"], item => item.DelayedPaymentDefault },
                { _localizer["Post"], item => item.Post },
                { _localizer["Phone"], item => item.Phone },
                { _localizer["IdPaymentTypeDefault"], item => item.IdPaymentTypeDefault },
                { _localizer["IdTariffDefault"], item => item.IdTariffDefault },
                { _localizer["ShortName"], item => item.ShortName },
                { _localizer["ContractNumber"], item => item.ContractNumber },
                { _localizer["Inserted"], item => item.Inserted },
                { _localizer["Comment"], item => item.Comment },
                { _localizer["CouponValue"], item => item.CouponValue },
                { _localizer["ContractText"], item => item.ContractText },
                { _localizer["PaymentDueDateText"], item => item.PaymentDueDateText },
                { _localizer["BookingRemarks"], item => item.BookingRemarks },
                { _localizer["Einvoice"], item => item.Einvoice },
                { _localizer["IBAN"], item => item.IBAN },
                { _localizer["RegisterNumber"], item => item.RegisterNumber },
                { _localizer["Discount"], item => item.Discount },
                { _localizer["SignatureInvoice"], item => item.SignatureInvoice },
                { _localizer["DefaultType1"], item => item.DefaultType1 },
                { _localizer["DefaultType2"], item => item.DefaultType2 },
                { _localizer["DefaultType3"], item => item.DefaultType3 },
                { _localizer["DefaultType4"], item => item.DefaultType4 },
                { _localizer["DefaultType5"], item => item.DefaultType5 },
                { _localizer["DefaultType6"], item => item.DefaultType6 },
                { _localizer["DefaultType7"], item => item.DefaultType7 },
                { _localizer["DefaultType8"], item => item.DefaultType8 },
                { _localizer["DefaultType9"], item => item.DefaultType9 },
                { _localizer["DefaultType10"], item => item.DefaultType10 },
                { _localizer["DefaultType11"], item => item.DefaultType11 },
                { _localizer["DefaultType12"], item => item.DefaultType12 },
                { _localizer["DefaultType13"], item => item.DefaultType13 },
                { _localizer["DefaultType14"], item => item.DefaultType14 },
                { _localizer["DefaultType15"], item => item.DefaultType15 },
                { _localizer["DefaultType16"], item => item.DefaultType16 },
                { _localizer["DefaultType17"], item => item.DefaultType17 },
                { _localizer["DefaultType18"], item => item.DefaultType18 },
                { _localizer["DefaultType19"], item => item.DefaultType19 },
                { _localizer["DefaultType20"], item => item.DefaultType20 },
                { _localizer["PassValidation"], item => item.PassValidation },
                { _localizer["DefaultVehicleType1"], item => item.DefaultVehicleType1 },
                { _localizer["DefaultVehicleType2"], item => item.DefaultVehicleType2 },
                { _localizer["DefaultVehicleType3"], item => item.DefaultVehicleType3 },
                { _localizer["DefaultVehicleType4"], item => item.DefaultVehicleType4 },
                { _localizer["DefaultVehicleType5"], item => item.DefaultVehicleType5 },
                { _localizer["DefaultVehicleType6"], item => item.DefaultVehicleType6 },
                { _localizer["DefaultVehicleType7"], item => item.DefaultVehicleType7 },
                { _localizer["DefaultVehicleType8"], item => item.DefaultVehicleType8 },
                { _localizer["DefaultVehicleType9"], item => item.DefaultVehicleType9 },
                { _localizer["DefaultVehicleType10"], item => item.DefaultVehicleType10 },
                { _localizer["DefaultVehicleType11"], item => item.DefaultVehicleType11 },
                { _localizer["DefaultVehicleType12"], item => item.DefaultVehicleType12 },
                { _localizer["DefaultVehicleType13"], item => item.DefaultVehicleType13 },
                { _localizer["DefaultVehicleType14"], item => item.DefaultVehicleType14 },
                { _localizer["DefaultVehicleType15"], item => item.DefaultVehicleType15 },
                { _localizer["DefaultVehicleType16"], item => item.DefaultVehicleType16 },
                { _localizer["DefaultVehicleType17"], item => item.DefaultVehicleType17 },
                { _localizer["DefaultVehicleType18"], item => item.DefaultVehicleType18 },
                { _localizer["DefaultVehicleType19"], item => item.DefaultVehicleType19 },
                { _localizer["DefaultVehicleType20"], item => item.DefaultVehicleType20 },
                { _localizer["IdCompanyBlock"], item => item.IdCompanyBlock },
                { _localizer["IdCompanySlip"], item => item.IdCompanySlip },
                { _localizer["OutsourcingCompany"], item => item.OutsourcingCompany }
            }, sheetName: "PartnerCompanies");

            return await Result<string>.SuccessAsync(data: data);
        }
    }
}