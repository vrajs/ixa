﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit
{
    public class AddEditPartnerCompanyCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int? IdPost { get; set; }
        public string TaxId { get; set; }
        public bool? Deleted { get; set; }
        public int? IdRecord { get; set; }
        public bool? InternalCompany { get; set; }
        public bool DelayedPaymentDefault { get; set; }
        public string Post { get; set; }
        public string Phone { get; set; }
        public int? IdPaymentTypeDefault { get; set; }
        public int? IdTariffDefault { get; set; }
        public string ShortName { get; set; }
        public string ContractNumber { get; set; }
        public DateTime? Inserted { get; set; }
        public string Comment { get; set; }
        public decimal? CouponValue { get; set; }
        public string ContractText { get; set; }
        public string PaymentDueDateText { get; set; }
        public string BookingRemarks { get; set; }
        public bool? Einvoice { get; set; }
        public string IBAN { get; set; }
        public string RegisterNumber { get; set; }
        public decimal? Discount { get; set; }
        public bool SignatureInvoice { get; set; }
        public bool DefaultType1 { get; set; }
        public bool DefaultType2 { get; set; }
        public bool DefaultType3 { get; set; }
        public bool DefaultType4 { get; set; }
        public bool DefaultType5 { get; set; }
        public bool DefaultType6 { get; set; }
        public bool DefaultType7 { get; set; }
        public bool DefaultType8 { get; set; }
        public bool DefaultType9 { get; set; }
        public bool DefaultType10 { get; set; }
        public bool DefaultType11 { get; set; }
        public bool DefaultType12 { get; set; }
        public bool DefaultType13 { get; set; }
        public bool DefaultType14 { get; set; }
        public bool DefaultType15 { get; set; }
        public bool DefaultType16 { get; set; }
        public bool DefaultType17 { get; set; }
        public bool DefaultType18 { get; set; }
        public bool DefaultType19 { get; set; }
        public bool DefaultType20 { get; set; }
        public string PassValidation { get; set; }
        public bool DefaultVehicleType1 { get; set; }
        public bool DefaultVehicleType2 { get; set; }
        public bool DefaultVehicleType3 { get; set; }
        public bool DefaultVehicleType4 { get; set; }
        public bool DefaultVehicleType5 { get; set; }
        public bool DefaultVehicleType6 { get; set; }
        public bool DefaultVehicleType7 { get; set; }
        public bool DefaultVehicleType8 { get; set; }
        public bool DefaultVehicleType9 { get; set; }
        public bool DefaultVehicleType10 { get; set; }
        public bool DefaultVehicleType11 { get; set; }
        public bool DefaultVehicleType12 { get; set; }
        public bool DefaultVehicleType13 { get; set; }
        public bool DefaultVehicleType14 { get; set; }
        public bool DefaultVehicleType15 { get; set; }
        public bool DefaultVehicleType16 { get; set; }
        public bool DefaultVehicleType17 { get; set; }
        public bool DefaultVehicleType18 { get; set; }
        public bool DefaultVehicleType19 { get; set; }
        public bool DefaultVehicleType20 { get; set; }
        public int? IdCompanyBlock { get; set; }
        public int? IdCompanySlip { get; set; }
        public bool? OutsourcingCompany { get; set; }
    }

    internal class AddEditPartnerCompanyCommandHandler : IRequestHandler<AddEditPartnerCompanyCommand, Result<int>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<AddEditPartnerCompanyCommand> _localizer;

        public AddEditPartnerCompanyCommandHandler(IMapper mapper,
                                                   ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                   IStringLocalizer<AddEditPartnerCompanyCommand> localizer)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(AddEditPartnerCompanyCommand command, CancellationToken cancellationToken)
        {
            if (command.Id == 0)
            {
                var partnerCompanyMapped = _mapper.Map<PartnerCompany>(command);

                await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().AddAsync(partnerCompanyMapped, 
                                                                                   cancellationToken, 
                                                                                   ApplicationConstants.Cache.GetAllPartnerCompaniesCacheKey);

                return await Result<int>.SuccessAsync(partnerCompanyMapped.Id, _localizer["Partner Company Saved."]);
            }
            else
            {
                var partnerCompany = await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().GetByIdAsync(command.Id);

                if (partnerCompany != null)
                {
                    partnerCompany.Name = command.Name ?? partnerCompany.Name;
                    partnerCompany.Address = command.Address ?? partnerCompany.Address;
                    partnerCompany.IdPost = command.IdPost ?? partnerCompany.IdPost;
                    partnerCompany.TaxId = command.TaxId ?? partnerCompany.TaxId;
                    partnerCompany.Deleted = command.Deleted ?? partnerCompany.Deleted;
                    partnerCompany.IdRecord = command.IdRecord ?? partnerCompany.IdRecord;
                    partnerCompany.InternalCompany = command.InternalCompany ?? partnerCompany.InternalCompany;
                    partnerCompany.DelayedPaymentDefault = command.DelayedPaymentDefault;
                    partnerCompany.Post = command.Post ?? partnerCompany.Post;
                    partnerCompany.Phone = command.Phone ?? partnerCompany.Phone;
                    partnerCompany.IdPaymentTypeDefault = command.IdPaymentTypeDefault ?? partnerCompany.IdPaymentTypeDefault;
                    partnerCompany.IdTariffDefault = command.IdTariffDefault ?? partnerCompany.IdTariffDefault;
                    partnerCompany.ShortName = command.ShortName ?? partnerCompany.ShortName;
                    partnerCompany.ContractNumber = command.ContractNumber ?? partnerCompany.ContractNumber;
                    partnerCompany.Inserted = command.Inserted ?? partnerCompany.Inserted;
                    partnerCompany.Comment = command.Comment ?? partnerCompany.Comment;
                    partnerCompany.CouponValue = command.CouponValue ?? partnerCompany.CouponValue;
                    partnerCompany.ContractText = command.ContractText ?? partnerCompany.ContractText;
                    partnerCompany.PaymentDueDateText = command.PaymentDueDateText ?? partnerCompany.PaymentDueDateText;
                    partnerCompany.BookingRemarks = command.BookingRemarks ?? partnerCompany.BookingRemarks;
                    partnerCompany.Einvoice = command.Einvoice ?? partnerCompany.Einvoice;
                    partnerCompany.IBAN = command.IBAN ?? partnerCompany.IBAN;
                    partnerCompany.RegisterNumber = command.RegisterNumber ?? partnerCompany.RegisterNumber;
                    partnerCompany.Discount = command.Discount ?? partnerCompany.Discount;
                    partnerCompany.SignatureInvoice = command.SignatureInvoice;
                    partnerCompany.DefaultType1 = command.DefaultType1;
                    partnerCompany.DefaultType2 = command.DefaultType2;
                    partnerCompany.DefaultType3 = command.DefaultType3;
                    partnerCompany.DefaultType4 = command.DefaultType4;
                    partnerCompany.DefaultType5 = command.DefaultType5;
                    partnerCompany.DefaultType6 = command.DefaultType6;
                    partnerCompany.DefaultType7 = command.DefaultType7;
                    partnerCompany.DefaultType8 = command.DefaultType8;
                    partnerCompany.DefaultType9 = command.DefaultType9;
                    partnerCompany.DefaultType10 = command.DefaultType10;
                    partnerCompany.DefaultType11 = command.DefaultType11;
                    partnerCompany.DefaultType12 = command.DefaultType12;
                    partnerCompany.DefaultType13 = command.DefaultType13;
                    partnerCompany.DefaultType14 = command.DefaultType14;
                    partnerCompany.DefaultType15 = command.DefaultType15;
                    partnerCompany.DefaultType16 = command.DefaultType16;
                    partnerCompany.DefaultType17 = command.DefaultType17;
                    partnerCompany.DefaultType18 = command.DefaultType18;
                    partnerCompany.DefaultType19 = command.DefaultType19;
                    partnerCompany.DefaultType20 = command.DefaultType20;
                    partnerCompany.PassValidation = command.PassValidation ?? partnerCompany.PassValidation;
                    partnerCompany.DefaultVehicleType1 = command.DefaultVehicleType1;
                    partnerCompany.DefaultVehicleType2 = command.DefaultVehicleType2;
                    partnerCompany.DefaultVehicleType3 = command.DefaultVehicleType3;
                    partnerCompany.DefaultVehicleType4 = command.DefaultVehicleType4;
                    partnerCompany.DefaultVehicleType5 = command.DefaultVehicleType5;
                    partnerCompany.DefaultVehicleType6 = command.DefaultVehicleType6;
                    partnerCompany.DefaultVehicleType7 = command.DefaultVehicleType7;
                    partnerCompany.DefaultVehicleType8 = command.DefaultVehicleType8;
                    partnerCompany.DefaultVehicleType9 = command.DefaultVehicleType9;
                    partnerCompany.DefaultVehicleType10 = command.DefaultVehicleType10;
                    partnerCompany.DefaultVehicleType11 = command.DefaultVehicleType11;
                    partnerCompany.DefaultVehicleType12 = command.DefaultVehicleType12;
                    partnerCompany.DefaultVehicleType13 = command.DefaultVehicleType13;
                    partnerCompany.DefaultVehicleType14 = command.DefaultVehicleType14;
                    partnerCompany.DefaultVehicleType15 = command.DefaultVehicleType15;
                    partnerCompany.DefaultVehicleType16 = command.DefaultVehicleType16;
                    partnerCompany.DefaultVehicleType17 = command.DefaultVehicleType17;
                    partnerCompany.DefaultVehicleType18 = command.DefaultVehicleType18;
                    partnerCompany.DefaultVehicleType19 = command.DefaultVehicleType19;
                    partnerCompany.DefaultVehicleType20 = command.DefaultVehicleType20;
                    partnerCompany.IdCompanyBlock = command.IdCompanyBlock ?? partnerCompany.IdCompanyBlock;
                    partnerCompany.IdCompanySlip = command.IdCompanySlip ?? partnerCompany.IdCompanySlip;
                    partnerCompany.OutsourcingCompany = command.OutsourcingCompany ?? partnerCompany.OutsourcingCompany;

                    await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().UpdateAsync(partnerCompany,
                                                                                          cancellationToken,
                                                                                          ApplicationConstants.Cache.GetAllPartnerCompaniesCacheKey);

                    return await Result<int>.SuccessAsync(partnerCompany.Id, _localizer["Partner Company Updated."]);
                }
                else
                {
                    return await Result<int>.FailAsync(_localizer["Partner Company Not Found!"]);
                }
            }
        }
    }
}