﻿using MediatR;
using Microsoft.Extensions.Localization;
using NetCabManager.Application.Interfaces.Repositories;
using NetCabManager.Domain.Entities.Catalog;
using NetCabManager.Shared.Constants.Application;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NetCabManager.Application.Features.PartnerCompanies.Commands.Delete
{
    public class DeletePartnerCompanyCommand : IRequest<Result<int>>
    {
        public int Id { get; set; }
    }

    internal class DeletePartnerCompanyCommandHandler : IRequestHandler<DeletePartnerCompanyCommand, Result<int>>
    {
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IStringLocalizer<DeletePartnerCompanyCommand> _localizer;

        public DeletePartnerCompanyCommandHandler(ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                                  IStringLocalizer<DeletePartnerCompanyCommand> localizer)
        {
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _localizer = localizer;
        }

        public async Task<Result<int>> Handle(DeletePartnerCompanyCommand command, CancellationToken cancellationToken)
        {
            var partnerCompany = await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().GetByIdAsync(command.Id);

            if (partnerCompany != null)
            {
                await _taxiCompanyUnitOfWork.Repository<PartnerCompany>().DeleteAsync(partnerCompany, 
                                                                                      cancellationToken, 
                                                                                      ApplicationConstants.Cache.GetAllPartnerCompaniesCacheKey);

                return await Result<int>.SuccessAsync(partnerCompany.Id, _localizer["Partner Company Deleted."]);
            }
            else
            {
                return await Result<int>.FailAsync(_localizer["Partner Company Not Found!"]);
            }
        }
    }
}