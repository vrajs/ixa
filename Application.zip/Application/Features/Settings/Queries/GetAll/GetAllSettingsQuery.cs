﻿namespace NetCabManager.Application.Features.Settings.Queries.GetAll
{
    using AutoMapper;
    using LazyCache;
    using MediatR;
    using NetCabManager.Application.Interfaces.Repositories;
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Shared.Constants.Application;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public class GetAllSettingsQuery : IRequest<Result<List<GetAllSettingsResponse>>>
    {
        public GetAllSettingsQuery()
        {
        }
    }

    internal class GetAllSettingsQueryHandler : IRequestHandler<GetAllSettingsQuery, Result<List<GetAllSettingsResponse>>>
    {
        private readonly IMapper _mapper;
        private readonly ITaxiCompanyUnitOfWork<int> _taxiCompanyUnitOfWork;
        private readonly IAppCache _appCache;

        public GetAllSettingsQueryHandler(IMapper mapper, 
                                          ITaxiCompanyUnitOfWork<int> taxiCompanyUnitOfWork,
                                          IAppCache appCache)
        {
            _mapper = mapper;
            _taxiCompanyUnitOfWork = taxiCompanyUnitOfWork;
            _appCache = appCache;
        }

        public async Task<Result<List<GetAllSettingsResponse>>> Handle(GetAllSettingsQuery query, CancellationToken cancellationToken)
        {
            _appCache.Remove(ApplicationConstants.Cache.GetAllSettingsCacheKey);

            Task<List<Setting>> GetAllSettings() => _taxiCompanyUnitOfWork.Repository<Setting>().GetAllAsync();

            var settingList = await _appCache.GetOrAddAsync(ApplicationConstants.Cache.GetAllSettingsCacheKey, GetAllSettings);

            var mappedSettings = _mapper.Map<List<GetAllSettingsResponse>>(settingList);

            return await Result<List<GetAllSettingsResponse>>.SuccessAsync(mappedSettings);
        }
    }
}