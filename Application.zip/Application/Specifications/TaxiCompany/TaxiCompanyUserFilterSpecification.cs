﻿using NetCabManager.Application.Specifications.Base;
using NetCabManager.Domain.Entities.TaxiCompany;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Specifications.TaxiCompany
{
    public class TaxiCompanyUserFilterSpecification : HeroSpecification<TaxiCompanyUser>
    {
        public TaxiCompanyUserFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => c.Name.Contains(searchString) ||
                                c.Surname.Contains(searchString) ||
                                c.Username.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}