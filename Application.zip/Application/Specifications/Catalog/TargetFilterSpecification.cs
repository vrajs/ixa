﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;

    public class TargetFilterSpecification : HeroSpecification<TargetHistory>
    {
        public TargetFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => c.Phone.Contains(searchString) ||
                                c.Street.Contains(searchString) ||
                                c.Number.Contains(searchString) ||
                                c.Lbl.Contains(searchString) ||
                                c.UnitId.Contains(searchString) ||
                                c.Remark.Contains(searchString) ||
                                c.Destination.Contains(searchString) ||
                                c.Customer.Contains(searchString) ||
                                c.Distance.Contains(searchString) ||
                                c.TimeOfArrival.Contains(searchString) ||
                                c.Gdistance.Contains(searchString) ||
                                c.GtimeOfArrival.Contains(searchString) ||
                                c.OrderByDriver.Contains(searchString) ||
                                c.BillingCenter.Contains(searchString) ||
                                c.Billingcenterr.Contains(searchString) ||
                                c.OrdererName.Contains(searchString) ||
                                c.Passenger.Contains(searchString) ||
                                c.PassengerPhone.Contains(searchString) ||
                                c.CardNumber.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}