﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;
    using System;

    public class VehicleFilterSpecification : HeroSpecification<Vehicle>
    {
        public VehicleFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => c.RegistrationNumber.Contains(searchString) ||
                                //Convert.ToString(c.VehicleNumber).Contains(searchString) ||
                                c.VehicleMake.Contains(searchString) ||
                                c.VehicleModel.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}