﻿using NetCabManager.Application.Specifications.Base;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Specifications.Catalog
{
    public class NetCabToFleetFilterSpecification : HeroSpecification<NetCabToFleet>
    {
        public NetCabToFleetFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => Convert.ToString(c.Id).Contains(searchString) ||
                                c.CompanyIdentification.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}
