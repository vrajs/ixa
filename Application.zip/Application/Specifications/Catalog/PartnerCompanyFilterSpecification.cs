﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;
    using System;

    class PartnerCompanyFilterSpecification : HeroSpecification<PartnerCompany>
    {
        public PartnerCompanyFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = p => Convert.ToString(p.Id).Contains(searchString) ||
                                p.Name.Contains(searchString) ||
                                p.Address.Contains(searchString) ||
                                p.Phone.Contains(searchString) ||
                                p.ShortName.Contains(searchString) ||
                                p.ContractNumber.Contains(searchString) ||
                                p.Comment.Contains(searchString) ||
                                p.ContractText.Contains(searchString) ||
                                p.BookingRemarks.Contains(searchString) ||
                                p.IBAN.Contains(searchString) ||
                                p.RegisterNumber.Contains(searchString);
            }
            else
            {
                Criteria = p => true;
            }
        }
    }
}