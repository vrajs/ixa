﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;
    using System;

    public class DriverFilterSpecification : HeroSpecification<Driver>
    {
        public DriverFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => Convert.ToString(c.Id).Contains(searchString) ||
                                c.Name.Contains(searchString) ||
                                c.Lastname.Contains(searchString) ||
                                c.Password.Contains(searchString) ||
                                c.GSM.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}