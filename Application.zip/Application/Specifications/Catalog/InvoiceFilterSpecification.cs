﻿using NetCabManager.Application.Specifications.Base;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Specifications.Catalog
{
    public class InvoiceFilterSpecification : HeroSpecification<Invoice>
    {
        public InvoiceFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => Convert.ToString(c.Id).Contains(searchString) ||
                                c.DriverName.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}
