﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;
    using System;

    public class InternalDepartmentFilterSpecification : HeroSpecification<InternalDepartment>
    {
        public InternalDepartmentFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => Convert.ToString(c.Id).Contains(searchString) ||
                                c.Internal_Department.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}