﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using System;

    public class UnitFilterSpecification : HeroSpecification<Domain.Entities.Catalog.Unit>
    {
        public UnitFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = p => p.UnitId.Contains(searchString) ||
                                p.IMEI.Contains(searchString) ||
                                p.IMSI.Contains(searchString);
                                //Convert.ToString(p.UnitUpdate).Contains(searchString) ||
                                //Convert.ToString(p.ZoneTo).Contains(searchString) ||
                                //Convert.ToString(p.ZoneArrival).Contains(searchString) ||
                                //Convert.ToString(p.StandArrival).Contains(searchString) ||
                                //Convert.ToString(p.IdVehicle) == searchString ||
                                //Convert.ToString(p.IdDriver) == searchString;
            }
            else
            {
                Criteria = p => true;
            }
        }
    }
}