﻿namespace NetCabManager.Application.Specifications.Catalog
{
    using NetCabManager.Application.Specifications.Base;
    using NetCabManager.Domain.Entities.Catalog;

    public class CompanyFilterSpecification : HeroSpecification<Company>
    {
        public CompanyFilterSpecification(string searchString)
        {
            if (!string.IsNullOrEmpty(searchString))
            {
                Criteria = c => c.SqlServerIp.Contains(searchString) ||
                                c.SqlInstanceName.Contains(searchString) ||
                                c.SqlDatabaseName.Contains(searchString) ||
                                c.SqlServerUsername.Contains(searchString) ||
                                c.CompanyTitle.Contains(searchString) ||
                                c.Note.Contains(searchString) ||
                                c.UnitServerHost.Contains(searchString) ||
                                c.WebServiceHost.Contains(searchString) ||
                                c.PrimaryColor.Contains(searchString);
            }
            else
            {
                Criteria = c => true;
            }
        }
    }
}