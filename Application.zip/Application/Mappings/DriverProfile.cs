﻿using AutoMapper;
using NetCabManager.Application.Features.Drivers.Commands.AddEdit;
using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Drivers.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class DriverProfile : Profile
    {
        public DriverProfile()
        {
            CreateMap<AddEditDriverCommand, Driver>().ReverseMap();
            CreateMap<GetAllDriversResponse, Driver>().ReverseMap();
            CreateMap<GetDriverByIdResponse, Driver>().ReverseMap();
        }
    }
}