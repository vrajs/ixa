﻿using AutoMapper;
using NetCabManager.Application.Features.Targets.Commands.AddEdit;
using NetCabManager.Application.Features.Targets.Queries.GetAll;
using NetCabManager.Application.Features.Targets.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class TargetProfile : Profile
    {
        public TargetProfile()
        {
            CreateMap<AddEditTargetCommand, Target>().ReverseMap();
            CreateMap<GetAllTargetsResponse, Target>().ReverseMap();
            CreateMap<GetTargetByIdResponse, Target>().ReverseMap();
            CreateMap<AddEditTargetCommand, TargetHistory>().ReverseMap();
            CreateMap<GetAllTargetsResponse, TargetHistory>().ReverseMap();
            CreateMap<GetTargetByIdResponse, TargetHistory>().ReverseMap();
        }
    }
}