﻿using AutoMapper;
using NetCabManager.Application.Features.Units.Commands.AddEdit;
using NetCabManager.Application.Features.Units.Queries.GetAll;
using NetCabManager.Application.Features.Units.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class UnitProfile : Profile
    {
        public UnitProfile()
        {
            CreateMap<AddEditUnitCommand, Unit>().ReverseMap();
            CreateMap<GetAllUnitsResponse, Unit>().ReverseMap();
            CreateMap<GetUnitByIdResponse, Unit>().ReverseMap();
        }
    }
}