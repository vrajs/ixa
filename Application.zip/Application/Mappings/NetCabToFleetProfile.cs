﻿using AutoMapper;
using NetCabManager.Application.Features.Drivers.Commands.AddEdit;
using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Drivers.Queries.GetById;
using NetCabManager.Application.Features.NetCabToFleets.Commands.AddEdit;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class NetCabToFleetProfile : Profile
    {
        public NetCabToFleetProfile()
        {
            CreateMap<AddEditNetCabToFleetCommand, NetCabToFleet>().ReverseMap();
            CreateMap<GetAllNetCabToFleetsResponse, NetCabToFleet>().ReverseMap();
            CreateMap<GetNetCabFleetByIdResponse, NetCabToFleet>().ReverseMap();
        }
    }
}