﻿using AutoMapper;
using NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit;
using NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll;
using NetCabManager.Application.Features.PartnerCompanies.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class PartnerCompanyProfile : Profile
    {
        public PartnerCompanyProfile()
        {
            CreateMap<AddEditPartnerCompanyCommand, PartnerCompany>().ReverseMap();
            CreateMap<GetAllPartnerCompaniesResponse, PartnerCompany>().ReverseMap();
            CreateMap<GetPartnerCompanyByIdResponse, PartnerCompany>().ReverseMap();
        }
    }
}