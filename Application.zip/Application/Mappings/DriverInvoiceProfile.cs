﻿using AutoMapper;
using NetCabManager.Application.Features.DriverInvoices.Commands.AddEdit;
using NetCabManager.Application.Features.DriverInvoices.Queries.GetAll;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using NetCabManager.Application.Features.Invoices.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class DriverInvoiceProfile : Profile
    {
        public DriverInvoiceProfile()
        {
            CreateMap<AddEditDriverInvoiceCommand, DriverInvoice>().ReverseMap();
            CreateMap<GetAllDriverInvoiceResponse, DriverInvoice>().ReverseMap();
            //CreateMap<GetDriverInvoiceByIdResponse, DriverInvoice>().ReverseMap();
            CreateMap<HttpResponseMessage, List<GetAllDriverInvoiceResponse>>().ReverseMap();
        }
    }
}
