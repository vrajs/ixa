﻿using AutoMapper;
using NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll;
using NetCabManager.Domain.Entities.TaxiCompany;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings.TaxiCompany
{
    public class TaxiCompanyRoleProfile : Profile
    {
        public TaxiCompanyRoleProfile()
        {
            CreateMap<GetAllTaxiCompanyRolesResponse, TaxiCompanyRole>().ReverseMap();
        }
    }
}