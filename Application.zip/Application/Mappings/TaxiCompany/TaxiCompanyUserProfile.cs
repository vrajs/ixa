﻿using AutoMapper;
using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit;
using NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll;
using NetCabManager.Domain.Entities.TaxiCompany;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings.TaxiCompany
{
    public class TaxiCompanyUserProfile : Profile
    {
        public TaxiCompanyUserProfile()
        {
            CreateMap<GetAllTaxiCompanyUsersResponse, TaxiCompanyUser>().ReverseMap();
            CreateMap<AddEditTaxiCompanyUserCommand, TaxiCompanyUser>().ReverseMap();
        }
    }
}