﻿namespace NetCabManager.Application.Mappings.TaxiCompany
{
    using AutoMapper;
    using NetCabManager.Application.Features.Settings.Queries.GetAll;
    using NetCabManager.Domain.Entities.Catalog;

    public class SettingProfile : Profile
    {
        public SettingProfile()
        {
            CreateMap<GetAllSettingsResponse, Setting>().ReverseMap();
        }
    }
}