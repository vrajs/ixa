﻿using AutoMapper;
using NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit;
using NetCabManager.Application.Features.InternalDepartments.Queries.GetAll;
using NetCabManager.Application.Features.InternalDepartments.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class InternalDepartmentProfile : Profile
    {
        public InternalDepartmentProfile()
        {
            CreateMap<AddEditInternalDepartmentCommand, InternalDepartment>().ReverseMap();
            CreateMap<GetAllInternalDepartmentsResponse, InternalDepartment>().ReverseMap();
            CreateMap<GetInternalDepartmentByIdResponse, InternalDepartment>().ReverseMap();
        }
    }
}