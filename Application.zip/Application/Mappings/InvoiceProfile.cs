﻿using AutoMapper;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using NetCabManager.Application.Features.Invoices.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class InvoiceProfile : Profile
    {
        public InvoiceProfile()
        {
            CreateMap<AddEditInvoiceCommand, Invoice>().ReverseMap();
            CreateMap<GetAllInvoiceResponse, Invoice>().ReverseMap();
            CreateMap<GetInvoiceByIdResponse, Invoice>().ReverseMap();
            CreateMap<HttpResponseMessage, List<GetAllInvoiceResponse>>().ReverseMap();
        }
    }
}
