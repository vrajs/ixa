﻿using AutoMapper;
using NetCabManager.Application.Features.DocumentTypes.Commands.AddEdit;
using NetCabManager.Application.Features.DocumentTypes.Queries.GetAll;
using NetCabManager.Application.Features.DocumentTypes.Queries.GetById;
using NetCabManager.Domain.Entities.Misc;

namespace NetCabManager.Application.Mappings
{
    public class DocumentTypeProfile : Profile
    {
        public DocumentTypeProfile()
        {
            CreateMap<AddEditDocumentTypeCommand, DocumentType>().ReverseMap();
            CreateMap<GetDocumentTypeByIdResponse, DocumentType>().ReverseMap();
            CreateMap<GetAllDocumentTypesResponse, DocumentType>().ReverseMap();
        }
    }
}