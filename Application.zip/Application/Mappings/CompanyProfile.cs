﻿using AutoMapper;
using NetCabManager.Application.Features;
using NetCabManager.Application.Features.Companies.Commands.AddEdit;
using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Application.Features.Companies.Queries.GetById;
using NetCabManager.Domain.Entities.Catalog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Application.Mappings
{
    public class CompanyProfile : Profile
    {
        public CompanyProfile()
        {
            CreateMap<AddEditCompanyCommand, Company>().ReverseMap();
            CreateMap<GetAllCompaniesResponse, Company>().ReverseMap();
            CreateMap<GetCompanyByIdResponse, Company>().ReverseMap();
        }
    }
}