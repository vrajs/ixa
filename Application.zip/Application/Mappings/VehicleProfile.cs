﻿using AutoMapper;
using NetCabManager.Application.Features.Vehicles.Commands.AddEdit;
using NetCabManager.Application.Features.Vehicles.Queries.GetById;
using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
using NetCabManager.Domain.Entities.Catalog;

namespace NetCabManager.Application.Mappings
{
    public class VehicleProfile : Profile
    {
        public VehicleProfile()
        {
            CreateMap<AddEditVehicleCommand, Vehicle>().ReverseMap();
            CreateMap<GetAllVehiclesResponse, Vehicle>().ReverseMap();
            CreateMap<GetVehicleByIdResponse, Vehicle>().ReverseMap();
        }
    }
}