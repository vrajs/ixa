﻿using AutoMapper;
using NetCabManager.Application.Features.Documents.Commands.AddEdit;
using NetCabManager.Application.Features.Documents.Queries.GetById;
using NetCabManager.Domain.Entities.Misc;

namespace NetCabManager.Application.Mappings
{
    public class DocumentProfile : Profile
    {
        public DocumentProfile()
        {
            CreateMap<AddEditDocumentCommand, Document>().ReverseMap();
            CreateMap<GetDocumentByIdResponse, Document>().ReverseMap();
        }
    }
}