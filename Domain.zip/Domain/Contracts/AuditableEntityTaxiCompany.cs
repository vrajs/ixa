﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Contracts
{
    public abstract class AuditableEntityTaxiCompany<TId> : IAuditableEntityTaxiCompany<TId>
    {
        public TId Id { get; set; }
    }
}
