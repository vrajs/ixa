﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Contracts
{
    public interface IAuditableEntityTaxiCompany<TId> : IAuditableEntityTaxiCompany, IEntity<TId>
    {
    }

    public interface IAuditableEntityTaxiCompany : IEntity
    {
    }
}