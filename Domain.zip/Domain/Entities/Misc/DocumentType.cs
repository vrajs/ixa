﻿using NetCabManager.Domain.Contracts;

namespace NetCabManager.Domain.Entities.Misc
{
    public class DocumentType : AuditableEntity<int>
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}