﻿using NetCabManager.Domain.Contracts;
using NetCabManager.Domain.Entities.Misc;

namespace NetCabManager.Domain.Entities.ExtendedAttributes
{
    public class DocumentExtendedAttribute : AuditableEntityExtendedAttribute<int, int, Document>
    {
    }
}