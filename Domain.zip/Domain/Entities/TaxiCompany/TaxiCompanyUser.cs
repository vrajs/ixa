﻿namespace NetCabManager.Domain.Entities.TaxiCompany
{
    using NetCabManager.Domain.Contracts;
    using NetCabManager.Domain.Contracts;

    public class TaxiCompanyUser : AuditableEntityTaxiCompany<int>
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int IdRole { get; set; }
        public bool IsDeleted { get; set; }
        public bool? MustPickInternalDepartment { get; set; }
    }
}