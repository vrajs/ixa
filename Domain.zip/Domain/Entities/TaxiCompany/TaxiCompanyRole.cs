﻿namespace NetCabManager.Domain.Entities.TaxiCompany
{
    using NetCabManager.Domain.Contracts;
    using NetCabManager.Domain.Contracts;
    using System.Collections.Generic;

    public class TaxiCompanyRole : AuditableEntityTaxiCompany<int>
    {
        public string RoleName { get; set; }
    }
}