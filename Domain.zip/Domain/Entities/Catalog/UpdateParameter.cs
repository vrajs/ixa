﻿using NetCabManager.Domain.Contracts;
using System.Collections.Generic;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class UpdateParameter : AuditableEntity<int>
    {
        public string CompanyIdentification { get; set; }
        public int UpdateWeight { get; set; }
        public int HourFrom { get; set; }
        public int HourTo { get; set; }

        /*  DaysOfWeek can be set as follows
         *  M - Monday
         *  T - Tuesday
         *  W - Wednesday
         *  R - Thursday
         *  F - Friday
         *  S - Saturday
         *  U - Sunday
         *  M,T,F would then mean Monday, Tuesday and Friday
         */
        public string DaysOfWeek { get; set; }
        public virtual ICollection<Company> Companies { get; set; }

        /*
        internal UpdateParameter()
        {
            
        }

        public static UpdateParameter GetUpdateParameter(string companyIdentification)
        {
            UpdateParameter result = null;
            using (DatabaseHandler dbHandler = new DatabaseHandler())
            {
                SqlCommand cmd = new SqlCommand{CommandText = "GetUpdateParameter", CommandType = CommandType.StoredProcedure};
                SqlParameter parCompanyIdentification = new SqlParameter("company_identification", SqlDbType.NVarChar, 50){Value = companyIdentification};
                cmd.Parameters.Add(parCompanyIdentification);
                DataTable dt = dbHandler.ExecuteQuery(cmd);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    result = new UpdateParameter
                    {
                        CompanyIdentification = row["company_identification"].ToString(),
                        UpdateWeight = Convert.ToInt32(row["update_weight"].ToString()),
                        HourFrom = Convert.ToInt32(row["hour_from"].ToString()),
                        HourTo = Convert.ToInt32(row["hour_to"].ToString()),
                        DaysOfWeek = row["days_of_week"].ToString()
                    };
                }
            }
            return result;
        }
    }

    public class UpdateQueue
    {
        public int QueuePosition { get; set; }
        public Company Company { get; set; }
        public UpdateParameter UpdateParameter { get; set; }


        public static List<UpdateQueue> GetUpdateQueueList()
        {
            List<UpdateQueue> result = null;
            using (DatabaseHandler dbHandler = new DatabaseHandler())
            {
                SqlCommand cmd = new SqlCommand { CommandText = "GetUpdateQueueList", CommandType = CommandType.StoredProcedure };
                DataTable dt = dbHandler.ExecuteQuery(cmd);
                if (dt.Rows.Count > 0)
                {
                    result = new List<UpdateQueue>();
                    foreach (DataRow row in dt.Rows)
                    {
                        UpdateParameter tmUpdateParameter = new UpdateParameter
                        {
                            CompanyIdentification = row["company_identification"].ToString(),
                            UpdateWeight = Convert.ToInt32(row["update_weight"].ToString()),
                            HourFrom = Convert.ToInt32(row["hour_from"].ToString()),
                            HourTo = Convert.ToInt32(row["hour_to"].ToString()),
                            DaysOfWeek = row["days_of_week"].ToString()
                        };
                        Company tmpCompany = Company.GetCompany(row["company_identification"].ToString());
                        UpdateQueue tmpUpdateQueue = new UpdateQueue
                        {
                            QueuePosition = Convert.ToInt32(row["queue_position"].ToString()),
                            Company = tmpCompany,
                            UpdateParameter = tmUpdateParameter
                        };
                        result.Add(tmpUpdateQueue);
                    }
                }
            }
            return result;
        }
        */
    }
}