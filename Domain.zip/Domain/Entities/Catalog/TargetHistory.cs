﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    [Table("target_history")]

    public class TargetHistory: AuditableEntityTaxiCompany<int>
    {
        public string Phone { get; set; }
        public string Street { get; set; }
        public string Number { get; set; }
        public string Lbl { get; set; }
        public int? Status { get; set; }
        public string UnitId { get; set; }
        public DateTime? AssignedAt { get; set; }
        public string Remark { get; set; }
        public DateTime? DatetimeUpdate { get; set; }
        public int? IdClient { get; set; }
        public bool? IsDeleted { get; set; }
        public int? IdRecord { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? Preorder { get; set; }
        public DateTime? Dispatchat { get; set; }
        public DateTime? RemindAt { get; set; }
        public bool? DispatchNow { get; set; }
        public int IdOperator { get; set; }
        public int? IdDispatcher { get; set; }
        public int? IdPartnerCompany { get; set; }
        public decimal? PurchaseOrder { get; set; }
        public int? HsMid { get; set; }
        public int? TaxiNumber { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public string OrientLatitude { get; set; }
        public string OrientLongitude { get; set; }
        public bool? AutoDispatch { get; set; }
        public bool? AutoDispatched { get; set; }
        public DateTime? DatetimePreorder { get; set; }
        public string Destination { get; set; }
        public string Customer { get; set; }
        public bool? Type1 { get; set; }
        public bool? Type2 { get; set; }
        public bool? Type3 { get; set; }
        public bool? Type4 { get; set; }
        public bool? Type5 { get; set; }
        public bool? Type6 { get; set; }
        public bool? Type7 { get; set; }
        public bool? Type8 { get; set; }
        public bool? Type9 { get; set; }
        public bool? Type10 { get; set; }
        public bool? Type11 { get; set; }
        public bool? Type12 { get; set; }
        public bool? Type13 { get; set; }
        public bool? Type14 { get; set; }
        public bool? Type15 { get; set; }
        public bool? Type16 { get; set; }
        public bool? Type17 { get; set; }
        public bool? Type18 { get; set; }
        public bool? Type19 { get; set; }
        public bool? Type20 { get; set; }
        public int IdStand { get; set; }
        public int IdZone { get; set; }
        public string Distance { get; set; }
        public string TimeOfArrival { get; set; }
        public int? IdCompanyCredential { get; set; }
        public string Gdistance { get; set; }
        public string GtimeOfArrival { get; set; }
        public int? PhoneLine { get; set; }
        public DateTime? RequestedTime { get; set; }
        public string ManualAssignReason { get; set; }
        public string CompanyOrderNote { get; set; }
        public bool Paid { get; set; }
        public decimal DispatchType { get; set; }
        public int CancellationReason { get; set; }
        public DateTime? CpuPickupTime { get; set; }
        public DateTime? DriverPickupTime { get; set; }
        public int? DriverDelay { get; set; }
        public string OrderByDriver { get; set; }
        public bool? DelayedPayment { get; set; }
        public DateTime? Pickup { get; set; }
        public DateTime? DropOffTime { get; set; }
        public DateTime? CpuFirstTime { get; set; }
        public int? DriverPickupMin { get; set; }
        public bool? DriverAtLocation { get; set; }
        public string BillingCenter { get; set; }
        public string Billingcenterr { get; set; }
        public string OrdererName { get; set; }
        public string OrdererNote { get; set; }
        public double? DestinationLatitude { get; set; }
        public double? DestinationLongitude { get; set; }
        public int DispatchSubtype { get; set; }
        public string Passenger { get; set; }
        public int? IdTariff { get; set; }
        public int? IdPaymentType { get; set; }
        public int IdInternalDepartment { get; set; }
        public DateTime? PrimaryDistanceRequestTime { get; set; }
        public DateTime? SecondaryDistanceRequestTime { get; set; }
        public int? IdInternalDepartmentUsed { get; set; }
        public string PurchaseQuantity { get; set; }
        public bool ReceiptedInvoices { get; set; }
        public string TripRemark { get; set; }
        public bool? NoCustomerRequest { get; set; }
        public bool NotifyUnitPending { get; set; }
        public bool? StreetPickup { get; set; }
        public DateTime? LastUpdate { get; set; }
        public int? LastUpdateBy { get; set; }
        public int? AssignedIdDriver { get; set; }
        public int? AssignedIdUnit { get; set; }
        public int? AssignedIdVehicle { get; set; }
        public int? IdServiceType { get; set; }
        public string PassengerPhone { get; set; }
        public DateTime? DispatchTriggered { get; set; }
        public DateTime? CpuFinalDestinationTime { get; set; }
        public string CardNumber { get; set; }
    }
}
