﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class InternalDepartment : AuditableEntityTaxiCompany<int>
    {
        public string Internal_Department { get; set; }
        public DateTime? Inserted { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? Deleted { get; set; }
    }
}