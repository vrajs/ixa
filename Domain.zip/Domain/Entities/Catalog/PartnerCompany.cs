﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class PartnerCompany : AuditableEntityTaxiCompany<int>
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public int? IdPost { get; set; }
        public string TaxId { get; set; }
        public bool? Deleted { get; set; }
        public int? IdRecord { get; set; }
        public bool? InternalCompany { get; set; }
        public bool DelayedPaymentDefault { get; set; }
        public string Post { get; set; }
        public string Phone { get; set; }
        public int? IdPaymentTypeDefault { get; set; }
        public int? IdTariffDefault { get; set; }
        public string ShortName { get; set; }
        public string ContractNumber { get; set; }
        public DateTime? Inserted { get; set; }
        public string Comment { get; set; }
        public decimal? CouponValue { get; set; }
        public string ContractText { get; set; }
        public string PaymentDueDateText { get; set; }
        public string BookingRemarks { get; set; }
        public bool? Einvoice { get; set; }
        public string IBAN { get; set; }
        public string RegisterNumber { get; set; }
        public decimal? Discount { get; set; }
        public bool SignatureInvoice { get; set; }
        public bool DefaultType1 { get; set; }
        public bool DefaultType2 { get; set; }
        public bool DefaultType3 { get; set; }
        public bool DefaultType4 { get; set; }
        public bool DefaultType5 { get; set; }
        public bool DefaultType6 { get; set; }
        public bool DefaultType7 { get; set; }
        public bool DefaultType8 { get; set; }
        public bool DefaultType9 { get; set; }
        public bool DefaultType10 { get; set; }
        public bool DefaultType11 { get; set; }
        public bool DefaultType12 { get; set; }
        public bool DefaultType13 { get; set; }
        public bool DefaultType14 { get; set; }
        public bool DefaultType15 { get; set; }
        public bool DefaultType16 { get; set; }
        public bool DefaultType17 { get; set; }
        public bool DefaultType18 { get; set; }
        public bool DefaultType19 { get; set; }
        public bool DefaultType20 { get; set; }
        public string PassValidation { get; set; }
        public bool DefaultVehicleType1 { get; set; }
        public bool DefaultVehicleType2 { get; set; }
        public bool DefaultVehicleType3 { get; set; }
        public bool DefaultVehicleType4 { get; set; }
        public bool DefaultVehicleType5 { get; set; }
        public bool DefaultVehicleType6 { get; set; }
        public bool DefaultVehicleType7 { get; set; }
        public bool DefaultVehicleType8 { get; set; }
        public bool DefaultVehicleType9 { get; set; }
        public bool DefaultVehicleType10 { get; set; }
        public bool DefaultVehicleType11 { get; set; }
        public bool DefaultVehicleType12 { get; set; }
        public bool DefaultVehicleType13 { get; set; }
        public bool DefaultVehicleType14 { get; set; }
        public bool DefaultVehicleType15 { get; set; }
        public bool DefaultVehicleType16 { get; set; }
        public bool DefaultVehicleType17 { get; set; }
        public bool DefaultVehicleType18 { get; set; }
        public bool DefaultVehicleType19 { get; set; }
        public bool DefaultVehicleType20 { get; set; }
        public int? IdCompanyBlock { get; set; }
        public int? IdCompanySlip { get; set; }
        public bool? OutsourcingCompany { get; set; }
    }
}