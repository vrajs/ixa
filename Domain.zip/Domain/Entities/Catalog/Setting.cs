﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class Setting : AuditableEntityTaxiCompany<int>
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string Comment { get; set; }
        public string DefaultValue { get; set; }
    }
}