﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class Invoice : AuditableEntityTaxiCompany<int>
    {
        public DateTime? InvoiceDate { get; set; }
        public string DriverName { get; set; }
        public string Address { get; set; }
        public int? Price { get; set; }
        public string PaymentMethod { get; set; }
        public string CompanyIdentification { get; set; }
        // public ServiceStatus ServiceStatus { get; set; }
        // public DriverApplicationSetting DriverApplicationSetting { get; set; }
        // public List<JobStatisticDaily> JobStatisticDailies { get; set; }
    }
}
