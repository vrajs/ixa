﻿using NetCabManager.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Domain.Entities.Catalog
{
    public class Company : AuditableEntity<string>
    {
        public bool CanIssueUpdate { get; set; }
        public string SqlServerIp { get; set; }
        public string SqlInstanceName { get; set; }
        public int SqlInstancePort { get; set; }
        public string SqlDatabaseName { get; set; }
        public string SqlServerUsername { get; set; }
        public string SqlServerPassword { get; set; }
        public string CompanyTitle { get; set; }
        public string Note { get; set; }
        public int? UpdateParameterId { get; set; }
        public virtual UpdateParameter UpdateParameter { get; set; }
        public string UnitServerHost { get; set; }
        public int UnitServerPort { get; set; }
        public string WebServiceHost { get; set; }
        public string PrimaryColor { get; set; }
        public int CompanyCounter { get; set; }
        // public ServiceStatus ServiceStatus { get; set; }
        // public DriverApplicationSetting DriverApplicationSetting { get; set; }
        // public List<JobStatisticDaily> JobStatisticDailies { get; set; }
    }
}