﻿namespace NetCabManager.Shared.Settings
{
    public interface IPreference
    {
        public string LanguageCode { get; set; }
    }
}
