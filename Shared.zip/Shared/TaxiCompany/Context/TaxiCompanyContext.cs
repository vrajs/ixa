﻿namespace NetCabManager.Shared.TaxiCompany.Context
{
    using NetCabManager.Domain.Entities.Catalog;
    using NetCabManager.Domain.Entities.TaxiCompany;
    using Microsoft.EntityFrameworkCore;

    public class TaxiCompanyContext : DbContext
    {
        public TaxiCompanyContext(DbContextOptions<TaxiCompanyContext> options) : base(options)
        {
        }

        public DbSet<TaxiCompanyUser> TaxiCompanyUsers { get; set; }
        public DbSet<TaxiCompanyRole> TaxiCompanyRoles { get; set; }
        public DbSet<Setting> Settings { get; set; }
        public DbSet<InternalDepartment> InternalDepartments { get; set; }
        public DbSet<PartnerCompany> PartnerCompanies { get; set; }
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Unit> Units { get; set; }
        public DbSet<Target> Targets { get; set; }
        public DbSet<TargetHistory> TargetHistories { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<TaxiCompanyUser>(entity =>
            {
                entity.ToTable(name: "users", schema: "dbo");

                entity.Property(u => u.Id).HasColumnName(name: "id_user").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(u => u.Name).HasColumnName(name: "name").HasColumnType(typeName: "nvarchar(100)").IsRequired(required: false);
                entity.Property(u => u.Surname).HasColumnName(name: "surname").HasColumnType(typeName: "nvarchar(100)").IsRequired(required: false);
                entity.Property(u => u.Username).HasColumnName(name: "username").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: true);
                entity.Property(u => u.Password).HasColumnName(name: "password").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: true);
                entity.Property(u => u.IdRole).HasColumnName(name: "id_role").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(u => u.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit").IsRequired(required: true);
                entity.Property(u => u.MustPickInternalDepartment).HasColumnName(name: "must_pick_internal_department").HasColumnType(typeName: "bit").IsRequired(required: false);

                entity.HasKey(u => u.Id);
            });

            builder.Entity<TaxiCompanyRole>(entity =>
            {
                entity.ToTable(name: "role", schema: "dbo");

                entity.Property(r => r.Id).HasColumnName(name: "id_role").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(r => r.RoleName).HasColumnName(name: "role_title").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: true);

                entity.HasKey(r => r.Id);
            });

            builder.Entity<Setting>(entity =>
            {
                entity.ToTable(name: "setting", schema: "dbo");

                entity.Property(s => s.Id).HasColumnName(name: "id_setting").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(s => s.Key).HasColumnName(name: "setting_key").HasColumnType(typeName: "varchar(200)").IsRequired(required: true);
                entity.Property(s => s.Value).HasColumnName(name: "setting_value").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: true);
                entity.Property(s => s.Comment).HasColumnName(name: "comment").HasColumnType(typeName: "varchar(max)").IsRequired(required: true);
                entity.Property(s => s.DefaultValue).HasColumnName(name: "default_value").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);

                entity.HasKey(s => s.Id);
            });
            builder.Entity<TargetHistory>(entity =>
            {
                entity.ToTable(name: "target_history", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_target").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.Phone).HasColumnName(name: "phone").HasColumnType(typeName: "varchar(55)").IsRequired(required: false);
                entity.Property(e => e.Street).HasColumnName(name: "street").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.Number).HasColumnName(name: "num").HasColumnType(typeName: "varchar(15)").IsRequired(required: false);
                entity.Property(e => e.Lbl).HasColumnName(name: "lbl").HasColumnType(typeName: "varchar(10)").IsRequired(required: false);
                entity.Property(e => e.Status).HasColumnName(name: "status").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.UnitId).HasColumnName(name: "unit_id").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.AssignedAt).HasColumnName(name: "assigned_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Remark).HasColumnName(name: "remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.DatetimeUpdate).HasColumnName(name: "dt_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.IdClient).HasColumnName(name: "id_client").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdRecord).HasColumnName(name: "IdRecord").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Inserted).HasColumnName(name: "inserted").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Preorder).HasColumnName(name: "preorder").HasColumnType(typeName: "bit").IsRequired(required: false);
                entity.Property(e => e.Dispatchat).HasColumnName(name: "dispatchat").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.RemindAt).HasColumnName(name: "remind_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DispatchNow).HasColumnName(name: "dispatchnow").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdOperator).HasColumnName(name: "id_operator").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.IdDispatcher).HasColumnName(name: "id_dispatcher").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdPartnerCompany).HasColumnName(name: "id_company").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PurchaseOrder).HasColumnName(name: "purchase_order").HasColumnType(typeName: "decimal(10,2)").IsRequired(required: false);
                entity.Property(e => e.HsMid).HasColumnName(name: "hs_mid").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.TaxiNumber).HasColumnName(name: "taxi_number").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Latitude).HasColumnName(name: "lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.Longitude).HasColumnName(name: "lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.OrientLatitude).HasColumnName(name: "orient_lat").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.OrientLongitude).HasColumnName(name: "orient_lon").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.AutoDispatch).HasColumnName(name: "autodispatch").HasColumnType(typeName: "bit");
                entity.Property(e => e.AutoDispatched).HasColumnName(name: "autodispatched").HasColumnType(typeName: "bit");
                entity.Property(e => e.DatetimePreorder).HasColumnName(name: "dt_preorder").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Destination).HasColumnName(name: "destination").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.Customer).HasColumnName(name: "customer").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.Type1).HasColumnName(name: "type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type2).HasColumnName(name: "type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type3).HasColumnName(name: "type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type4).HasColumnName(name: "type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type5).HasColumnName(name: "type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type6).HasColumnName(name: "type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type7).HasColumnName(name: "type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type8).HasColumnName(name: "type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type9).HasColumnName(name: "type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type10).HasColumnName(name: "type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type11).HasColumnName(name: "type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type12).HasColumnName(name: "type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type13).HasColumnName(name: "type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type14).HasColumnName(name: "type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type15).HasColumnName(name: "type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type16).HasColumnName(name: "type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type17).HasColumnName(name: "type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type18).HasColumnName(name: "type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type19).HasColumnName(name: "type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type20).HasColumnName(name: "type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdStand).HasColumnName(name: "id_stand").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.IdZone).HasColumnName(name: "id_zone").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.Distance).HasColumnName(name: "distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.TimeOfArrival).HasColumnName(name: "time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdCompanyCredential).HasColumnName(name: "id_company_credential").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Gdistance).HasColumnName(name: "g_distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.GtimeOfArrival).HasColumnName(name: "g_time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.PhoneLine).HasColumnName(name: "phone_line").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.RequestedTime).HasColumnName(name: "requeste_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.ManualAssignReason).HasColumnName(name: "manual_assign_reason").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
                entity.Property(e => e.CompanyOrderNote).HasColumnName(name: "company_order_note").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
                entity.Property(e => e.Paid).HasColumnName(name: "paid").HasColumnType(typeName: "bit");
                entity.Property(e => e.DispatchType).HasColumnName(name: "dispatch_type").HasColumnType(typeName: "numeric(2,0)").IsRequired(required: true);
                entity.Property(e => e.CancellationReason).HasColumnName(name: "cancellation_reason").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.CpuPickupTime).HasColumnName(name: "cpu_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverPickupTime).HasColumnName(name: "driver_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverDelay).HasColumnName(name: "driver_delay").HasColumnType(typeName: "smallint").IsRequired(required: false);
                entity.Property(e => e.OrderByDriver).HasColumnName(name: "order_by_driver").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.DelayedPayment).HasColumnName(name: "delayed_payment").HasColumnType(typeName: "bit");
                entity.Property(e => e.Pickup).HasColumnName(name: "pickup").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DropOffTime).HasColumnName(name: "drop_off_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CpuFirstTime).HasColumnName(name: "cpu_first_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverPickupMin).HasColumnName(name: "driver_pickup_min").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.DriverAtLocation).HasColumnName(name: "driver_at_location").HasColumnType(typeName: "bit");
                entity.Property(e => e.BillingCenter).HasColumnName(name: "BillingCenter").HasColumnType(typeName: "varchar(150)").IsRequired(required: true);
                entity.Property(e => e.Billingcenterr).HasColumnName(name: "billing_center").HasColumnType(typeName: "varchar(150)").IsRequired(required: false);
                entity.Property(e => e.OrdererName).HasColumnName(name: "orderer_name").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.OrdererNote).HasColumnName(name: "orderer_note").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.DestinationLatitude).HasColumnName(name: "destination_lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DestinationLongitude).HasColumnName(name: "destination_lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DispatchSubtype).HasColumnName(name: "dispatch_subtype").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.Passenger).HasColumnName(name: "passenger").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.IdTariff).HasColumnName(name: "id_tariff").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdPaymentType).HasColumnName(name: "id_payment_type").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.PrimaryDistanceRequestTime).HasColumnName(name: "primary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.SecondaryDistanceRequestTime).HasColumnName(name: "secondary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName(name: "id_internal_department_used").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PurchaseQuantity).HasColumnName(name: "purchase_quantity").HasColumnType(typeName: "nvarchar(20)").IsRequired(required: false);
                entity.Property(e => e.ReceiptedInvoices).HasColumnName(name: "receipted_invoices").HasColumnType(typeName: "bit");
                entity.Property(e => e.TripRemark).HasColumnName(name: "trip_remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.NoCustomerRequest).HasColumnName(name: "no_customer_request").HasColumnType(typeName: "bit");
                entity.Property(e => e.NotifyUnitPending).HasColumnName(name: "notify_unit_pending").HasColumnType(typeName: "bit");
                entity.Property(e => e.StreetPickup).HasColumnName(name: "street_pickup").HasColumnType(typeName: "bit");
                entity.Property(e => e.LastUpdate).HasColumnName(name: "last_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.LastUpdateBy).HasColumnName(name: "last_update_by").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdDriver).HasColumnName(name: "assigned_id_driver").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdUnit).HasColumnName(name: "assigned_id_unit").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdVehicle).HasColumnName(name: "assigned_id_vehicle").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdServiceType).HasColumnName(name: "id_service_type").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PassengerPhone).HasColumnName(name: "passenger_phone").HasColumnType(typeName: "varchar(20)").IsRequired(required: false);
                entity.Property(e => e.DispatchTriggered).HasColumnName(name: "dispatch_triggered").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CpuFinalDestinationTime).HasColumnName(name: "cpu_final_destination_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CardNumber).HasColumnName(name: "card_number").HasColumnType(typeName: "nvarchar(30)").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });
            builder.Entity<InternalDepartment>(entity =>
            {
                entity.ToTable(name: "internal_department", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.Internal_Department).HasColumnName(name: "internal_department").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Inserted).HasColumnName(name: "inserted").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.IsDeleted).HasColumnName(name: "is_deleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.Deleted).HasColumnName(name: "deleted").HasColumnType(typeName: "datetime").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });

            builder.Entity<PartnerCompany>(entity =>
            {
                entity.ToTable(name: "company", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_company").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.Name).HasColumnName(name: "name").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.Address).HasColumnName(name: "address").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.IdPost).HasColumnName(name: "id_post").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.TaxId).HasColumnName(name: "tax_id").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Deleted).HasColumnName(name: "deleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdRecord).HasColumnName(name: "id_record").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.InternalCompany).HasColumnName(name: "internal_company").HasColumnType(typeName: "bit");
                entity.Property(e => e.DelayedPaymentDefault).HasColumnName(name: "delayed_payment_default").HasColumnType(typeName: "bit");
                entity.Property(e => e.Post).HasColumnName(name: "post").HasColumnType(typeName: "nvarchar(100)").IsRequired(required: false);
                entity.Property(e => e.Phone).HasColumnName(name: "phone").HasColumnType(typeName: "nvarchar(20)").IsRequired(required: false);
                entity.Property(e => e.IdPaymentTypeDefault).HasColumnName(name: "id_payment_type_default").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdTariffDefault).HasColumnName(name: "id_tariff_default").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.ShortName).HasColumnName(name: "short_name").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.ContractNumber).HasColumnName(name: "contract_number").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Inserted).HasColumnName(name: "inserted").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Comment).HasColumnName(name: "comment").HasColumnType(typeName: "text").IsRequired(required: false);
                entity.Property(e => e.CouponValue).HasColumnName(name: "coupon_value").HasColumnType(typeName: "decimal(10,2)").IsRequired(required: false);
                entity.Property(e => e.ContractText).HasColumnName(name: "contract_text").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.PaymentDueDateText).HasColumnName(name: "payment_due_date_text").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.BookingRemarks).HasColumnName(name: "booking_remarks").HasColumnType(typeName: "text").IsRequired(required: false);
                entity.Property(e => e.Einvoice).HasColumnName(name: "einvoice").HasColumnType(typeName: "bit");
                entity.Property(e => e.IBAN).HasColumnName(name: "iban").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.RegisterNumber).HasColumnName(name: "register_number").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Discount).HasColumnName(name: "discount").HasColumnType(typeName: "decimal(10,2)").IsRequired(required: false);
                entity.Property(e => e.SignatureInvoice).HasColumnName(name: "signature_invoice").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType1).HasColumnName(name: "default_type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType2).HasColumnName(name: "default_type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType3).HasColumnName(name: "default_type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType4).HasColumnName(name: "default_type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType5).HasColumnName(name: "default_type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType6).HasColumnName(name: "default_type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType7).HasColumnName(name: "default_type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType8).HasColumnName(name: "default_type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType9).HasColumnName(name: "default_type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType10).HasColumnName(name: "default_type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType11).HasColumnName(name: "default_type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType12).HasColumnName(name: "default_type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType13).HasColumnName(name: "default_type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType14).HasColumnName(name: "default_type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType15).HasColumnName(name: "default_type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType16).HasColumnName(name: "default_type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType17).HasColumnName(name: "default_type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType18).HasColumnName(name: "default_type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType19).HasColumnName(name: "default_type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultType20).HasColumnName(name: "default_type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.PassValidation).HasColumnName(name: "pass_validation").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.DefaultVehicleType1).HasColumnName(name: "default_vehicle_type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType2).HasColumnName(name: "default_vehicle_type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType3).HasColumnName(name: "default_vehicle_type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType4).HasColumnName(name: "default_vehicle_type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType5).HasColumnName(name: "default_vehicle_type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType6).HasColumnName(name: "default_vehicle_type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType7).HasColumnName(name: "default_vehicle_type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType8).HasColumnName(name: "default_vehicle_type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType9).HasColumnName(name: "default_vehicle_type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType10).HasColumnName(name: "default_vehicle_type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType11).HasColumnName(name: "default_vehicle_type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType12).HasColumnName(name: "default_vehicle_type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType13).HasColumnName(name: "default_vehicle_type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType14).HasColumnName(name: "default_vehicle_type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType15).HasColumnName(name: "default_vehicle_type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType16).HasColumnName(name: "default_vehicle_type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType17).HasColumnName(name: "default_vehicle_type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType18).HasColumnName(name: "default_vehicle_type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType19).HasColumnName(name: "default_vehicle_type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.DefaultVehicleType20).HasColumnName(name: "default_vehicle_type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdCompanyBlock).HasColumnName(name: "id_company_block").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdCompanySlip).HasColumnName(name: "id_company_slip").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.OutsourcingCompany).HasColumnName(name: "outsourcing_company").HasColumnType(typeName: "bit");

                entity.HasKey(e => e.Id);
            });

            builder.Entity<Driver>(entity =>
            {
                entity.ToTable(name: "driver", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_driver").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation("SqlServer:Identity", "1, 1");
                entity.Property(e => e.IdUnit).HasColumnName(name: "id_unit").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.Name).HasColumnName(name: "name").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Lastname).HasColumnName(name: "lastname").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.Password).HasColumnName(name: "password").HasColumnType(typeName: "varchar(10)").IsRequired(required: false);
                entity.Property(e => e.GSM).HasColumnName(name: "gsm").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.RegistrationNumber).HasColumnName(name: "registration_number").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Car).HasColumnName(name: "car").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IMEI).HasColumnName(name: "imei").HasColumnType(typeName: "varchar(max)").IsRequired(required: false);
                entity.Property(e => e.License).HasColumnName(name: "license").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.Company).HasColumnName(name: "company").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.Note).HasColumnName(name: "note").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.Type1).HasColumnName(name: "type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type2).HasColumnName(name: "type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type3).HasColumnName(name: "type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type4).HasColumnName(name: "type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type5).HasColumnName(name: "type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type6).HasColumnName(name: "type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type7).HasColumnName(name: "type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type8).HasColumnName(name: "type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type9).HasColumnName(name: "type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type10).HasColumnName(name: "type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type11).HasColumnName(name: "type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type12).HasColumnName(name: "type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type13).HasColumnName(name: "type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type14).HasColumnName(name: "type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type15).HasColumnName(name: "type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type16).HasColumnName(name: "type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type17).HasColumnName(name: "type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type18).HasColumnName(name: "type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type19).HasColumnName(name: "type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type20).HasColumnName(name: "type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.CompanyPhone).HasColumnName(name: "company_phone").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.HomePhone).HasColumnName(name: "home_phone").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdCompany).HasColumnName(name: "id_company").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Address).HasColumnName(name: "address").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdPost).HasColumnName(name: "id_post").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.CarType).HasColumnName(name: "car_type").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.CarColor).HasColumnName(name: "car_color").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.EngineDisplacement).HasColumnName(name: "engine_disp").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.EnginePower).HasColumnName(name: "engine_power").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Year).HasColumnName(name: "year_of").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.NumberOfSeats).HasColumnName(name: "num_of_seats").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.RegistrationDate).HasColumnName(name: "regstration_date").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.OverviewDate).HasColumnName(name: "overview_date").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.PersonalId).HasColumnName(name: "personal_id").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Master).HasColumnName(name: "master").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.ImportedDriverId).HasColumnName(name: "imported_driver_id").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.ImportedCarId).HasColumnName(name: "imported_car_id").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Email).HasColumnName(name: "email").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.LicenseExpiration).HasColumnName(name: "license_expiration").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Picture).HasColumnName(name: "picture").HasColumnType(typeName: "varbinary(max)").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "smallint").IsRequired(required: false);
                entity.Property(e => e.LastUpdate).HasColumnName(name: "last_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.LastUpdateBy).HasColumnName(name: "last_update_by").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdNetworkProvider).HasColumnName(name: "id_network_provider").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Bluetooth).HasColumnName(name: "bluetooth").HasColumnType(typeName: "bit");
                entity.Property(e => e.IsController).HasColumnName(name: "is_controller").HasColumnType(typeName: "bit");

                entity.HasKey(e => e.Id);
            });

            builder.Entity<Vehicle>(entity =>
            {
                entity.ToTable(name: "vehicle", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_vehicle").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.RegistrationNumber).HasColumnName(name: "registration_number").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdCar).HasColumnName(name: "id_car").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdCarType).HasColumnName(name: "id_car_type").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdColour).HasColumnName(name: "id_colour").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.EngineDisplacement).HasColumnName(name: "engine_disp").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.EnginePower).HasColumnName(name: "engine_power").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.Year).HasColumnName(name: "year_of").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.NumberOfSeats).HasColumnName(name: "num_of_seats").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.RegistrationDate).HasColumnName(name: "regstration_date").HasColumnType(typeName: "Date").IsRequired(required: false);
                entity.Property(e => e.OverviewDate).HasColumnName(name: "overview_date").HasColumnType(typeName: "Date").IsRequired(required: false);
                entity.Property(e => e.Type1).HasColumnName(name: "type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type2).HasColumnName(name: "type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type3).HasColumnName(name: "type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type4).HasColumnName(name: "type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type5).HasColumnName(name: "type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type6).HasColumnName(name: "type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type7).HasColumnName(name: "type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type8).HasColumnName(name: "type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type9).HasColumnName(name: "type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type10).HasColumnName(name: "type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type11).HasColumnName(name: "type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type12).HasColumnName(name: "type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type13).HasColumnName(name: "type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type14).HasColumnName(name: "type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type15).HasColumnName(name: "type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type16).HasColumnName(name: "type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type17).HasColumnName(name: "type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type18).HasColumnName(name: "type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type19).HasColumnName(name: "type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type20).HasColumnName(name: "type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.Note).HasColumnName(name: "note").HasColumnType(typeName: "text").IsRequired(required: false);
                entity.Property(e => e.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.VehicleNumber).HasColumnName(name: "vehicle_number").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.RegistrationDateTo).HasColumnName(name: "registration_date_to").HasColumnType(typeName: "Date").IsRequired(required: false);
                entity.Property(e => e.InsurancePolicy).HasColumnName(name: "insurance_policy").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.InsurancePolicyNumber).HasColumnName(name: "insurance_policy_number").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.MOTExpirationDate).HasColumnName(name: "mot_expiration_date").HasColumnType(typeName: "Date").IsRequired(required: false);
                entity.Property(e => e.PriceListNumber).HasColumnName(name: "price_list_number").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.LicenseNumber).HasColumnName(name: "license_number").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.LicenseExpirationDate).HasColumnName(name: "license_expiration_date").HasColumnType(typeName: "Date").IsRequired(required: false);
                entity.Property(e => e.Picture).HasColumnName(name: "picture").HasColumnType(typeName: "varbinary(max)").IsRequired(required: false);
                entity.Property(e => e.VehicleMake).HasColumnName(name: "vehicle_make").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.VehicleModel).HasColumnName(name: "vehicle_model").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "smallint").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });

            builder.Entity<Unit>(entity =>
            {
                entity.ToTable(name: "unit", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_unit").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.UnitId).HasColumnName(name: "unit_id").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.IMEI).HasColumnName(name: "imei").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.IMSI).HasColumnName(name: "imsi").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.Latitude).HasColumnName(name: "lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.Longitude).HasColumnName(name: "lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.OrientLatitude).HasColumnName(name: "orient_lat").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.OrientLongitude).HasColumnName(name: "orient_lon").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.Speed).HasColumnName(name: "speed").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DateTimeUpdate).HasColumnName(name: "dt_update").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.DateTimeIdle).HasColumnName(name: "dt_idle").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.Y).HasColumnName(name: "y").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.X).HasColumnName(name: "x").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.Status).HasColumnName(name: "status").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.DateTimeTask).HasColumnName(name: "dt_task").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.SOSPos).HasColumnName(name: "sos_Pos").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.SOS).HasColumnName(name: "sos").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdUnitType).HasColumnName(name: "id_unittype").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.DeviceId).HasColumnName(name: "device_id").HasColumnType(typeName: "varchar(30)").IsRequired(required: false);
                entity.Property(e => e.PhoneNumber).HasColumnName(name: "phone_number").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.IP).HasColumnName(name: "ip").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.UnitUpdate).HasColumnName(name: "unit_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.UnitIdTmp).HasColumnName(name: "unit_id_tmp").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.Position).HasColumnName(name: "position").HasColumnType(typeName: "bit");
                entity.Property(e => e.Service).HasColumnName(name: "service").HasColumnType(typeName: "bit");
                entity.Property(e => e.ZoneIn).HasColumnName(name: "zone_in").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.ZoneTo).HasColumnName(name: "zone_to").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.ZoneArrival).HasColumnName(name: "zone_arrival").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.StandIn).HasColumnName(name: "stand_in").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.StandArrival).HasColumnName(name: "stand_arrival").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.TaxiMeter).HasColumnName(name: "taximeter").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.DestinationArrival).HasColumnName(name: "destination_arrival").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DateTimeTaximeterFree).HasColumnName(name: "dt_taximeter_free").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.RequestedStatus).HasColumnName(name: "requested_status").HasColumnType(typeName: "tinyint").IsRequired(required: true);
                entity.Property(e => e.LocationUpdate).HasColumnName(name: "location_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.ConnectionQuality).HasColumnName(name: "connection_quality").HasColumnType(typeName: "tinyint").IsRequired(required: true);
                entity.Property(e => e.DestinationAddress).HasColumnName(name: "destination_address").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.DestinationLatitude).HasColumnName(name: "destination_lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DestinationLongitude).HasColumnName(name: "destination_lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.DeviceSerialNumber).HasColumnName(name: "device_serial_number").HasColumnType(typeName: "nvarchar(15)").IsRequired(required: false);
                entity.Property(e => e.IdVehicle).HasColumnName(name: "id_vehicle").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdDriver).HasColumnName(name: "id_driver").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.SIMSerialNumber).HasColumnName(name: "sim_serial_number").HasColumnType(typeName: "nvarchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdTracker).HasColumnName(name: "id_tracker").HasColumnType(typeName: "varchar(30)").IsRequired(required: false);
                entity.Property(e => e.NotifyPending).HasColumnName(name: "notify_pending").HasColumnType(typeName: "bit");
                entity.Property(e => e.CurrentTariff).HasColumnName(name: "current_tariff").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Heading).HasColumnName(name: "heading").HasColumnType(typeName: "int").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });

            builder.Entity<Target>(entity =>
            {
                entity.ToTable(name: "target", schema: "dbo");

                entity.Property(e => e.Id).HasColumnName(name: "id_target").HasColumnType(typeName: "int").IsRequired(required: true).HasAnnotation(annotation: "SqlServer:Identity", value: "1, 1");
                entity.Property(e => e.Phone).HasColumnName(name: "phone").HasColumnType(typeName: "varchar(55)").IsRequired(required: false);
                entity.Property(e => e.Street).HasColumnName(name: "street").HasColumnType(typeName: "nvarchar(max)").IsRequired(required: false);
                entity.Property(e => e.Number).HasColumnName(name: "num").HasColumnType(typeName: "varchar(15)").IsRequired(required: false);
                entity.Property(e => e.Lbl).HasColumnName(name: "lbl").HasColumnType(typeName: "varchar(10)").IsRequired(required: false);
                entity.Property(e => e.Status).HasColumnName(name: "status").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.UnitId).HasColumnName(name: "unit_id").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.AssignedAt).HasColumnName(name: "assigned_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Remark).HasColumnName(name: "remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.DatetimeUpdate).HasColumnName(name: "dt_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.IdClient).HasColumnName(name: "id_client").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IsDeleted).HasColumnName(name: "isdeleted").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdRecord).HasColumnName(name: "IdRecord").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Inserted).HasColumnName(name: "inserted").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Preorder).HasColumnName(name: "preorder").HasColumnType(typeName: "bit").IsRequired(required: false);
                entity.Property(e => e.Dispatchat).HasColumnName(name: "dispatchat").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.RemindAt).HasColumnName(name: "remind_at").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DispatchNow).HasColumnName(name: "dispatchnow").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdOperator).HasColumnName(name: "id_operator").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.IdDispatcher).HasColumnName(name: "id_dispatcher").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdPartnerCompany).HasColumnName(name: "id_company").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PurchaseOrder).HasColumnName(name: "purchase_order").HasColumnType(typeName: "decimal(10,2)").IsRequired(required: false);
                entity.Property(e => e.HsMid).HasColumnName(name: "hs_mid").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.TaxiNumber).HasColumnName(name: "taxi_number").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Latitude).HasColumnName(name: "lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.Longitude).HasColumnName(name: "lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.OrientLatitude).HasColumnName(name: "orient_lat").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.OrientLongitude).HasColumnName(name: "orient_lon").HasColumnType(typeName: "nvarchar(1)").IsRequired(required: false);
                entity.Property(e => e.AutoDispatch).HasColumnName(name: "autodispatch").HasColumnType(typeName: "bit");
                entity.Property(e => e.AutoDispatched).HasColumnName(name: "autodispatched").HasColumnType(typeName: "bit");
                entity.Property(e => e.DatetimePreorder).HasColumnName(name: "dt_preorder").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.Destination).HasColumnName(name: "destination").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.Customer).HasColumnName(name: "customer").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.Type1).HasColumnName(name: "type1").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type2).HasColumnName(name: "type2").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type3).HasColumnName(name: "type3").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type4).HasColumnName(name: "type4").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type5).HasColumnName(name: "type5").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type6).HasColumnName(name: "type6").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type7).HasColumnName(name: "type7").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type8).HasColumnName(name: "type8").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type9).HasColumnName(name: "type9").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type10).HasColumnName(name: "type10").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type11).HasColumnName(name: "type11").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type12).HasColumnName(name: "type12").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type13).HasColumnName(name: "type13").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type14).HasColumnName(name: "type14").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type15).HasColumnName(name: "type15").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type16).HasColumnName(name: "type16").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type17).HasColumnName(name: "type17").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type18).HasColumnName(name: "type18").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type19).HasColumnName(name: "type19").HasColumnType(typeName: "bit");
                entity.Property(e => e.Type20).HasColumnName(name: "type20").HasColumnType(typeName: "bit");
                entity.Property(e => e.IdStand).HasColumnName(name: "id_stand").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.IdZone).HasColumnName(name: "id_zone").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.Distance).HasColumnName(name: "distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.TimeOfArrival).HasColumnName(name: "time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.IdCompanyCredential).HasColumnName(name: "id_company_credential").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.Gdistance).HasColumnName(name: "g_distance").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.GtimeOfArrival).HasColumnName(name: "g_time_of_arrival").HasColumnType(typeName: "varchar(50)").IsRequired(required: false);
                entity.Property(e => e.PhoneLine).HasColumnName(name: "phone_line").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.RequestedTime).HasColumnName(name: "requeste_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.ManualAssignReason).HasColumnName(name: "manual_assign_reason").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
                entity.Property(e => e.CompanyOrderNote).HasColumnName(name: "company_order_note").HasColumnType(typeName: "nvarchar(200)").IsRequired(required: false);
                entity.Property(e => e.Paid).HasColumnName(name: "paid").HasColumnType(typeName: "bit");
                entity.Property(e => e.DispatchType).HasColumnName(name: "dispatch_type").HasColumnType(typeName: "numeric(2,0)").IsRequired(required: true);
                entity.Property(e => e.CancellationReason).HasColumnName(name: "cancellation_reason").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.CpuPickupTime).HasColumnName(name: "cpu_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverPickupTime).HasColumnName(name: "driver_pickup_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverDelay).HasColumnName(name: "driver_delay").HasColumnType(typeName: "smallint").IsRequired(required: false);
                entity.Property(e => e.OrderByDriver).HasColumnName(name: "order_by_driver").HasColumnType(typeName: "varchar(45)").IsRequired(required: false);
                entity.Property(e => e.DelayedPayment).HasColumnName(name: "delayed_payment").HasColumnType(typeName: "bit");
                entity.Property(e => e.Pickup).HasColumnName(name: "pickup").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DropOffTime).HasColumnName(name: "drop_off_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CpuFirstTime).HasColumnName(name: "cpu_first_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.DriverPickupMin).HasColumnName(name: "driver_pickup_min").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.DriverAtLocation).HasColumnName(name: "driver_at_location").HasColumnType(typeName: "bit");
                entity.Property(e => e.BillingCenter).HasColumnName(name: "BillingCenter").HasColumnType(typeName: "varchar(150)").IsRequired(required: true);
                entity.Property(e => e.Billingcenterr).HasColumnName(name: "billing_center").HasColumnType(typeName: "varchar(150)").IsRequired(required: false);
                entity.Property(e => e.OrdererName).HasColumnName(name: "orderer_name").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.OrdererNote).HasColumnName(name: "orderer_note").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.DestinationLatitude).HasColumnName(name: "destination_lat").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DestinationLongitude).HasColumnName(name: "destination_lon").HasColumnType(typeName: "float").IsRequired(required: false);
                entity.Property(e => e.DispatchSubtype).HasColumnName(name: "dispatch_subtype").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.Passenger).HasColumnName(name: "passenger").HasColumnType(typeName: "nvarchar(150)").IsRequired(required: false);
                entity.Property(e => e.IdTariff).HasColumnName(name: "id_tariff").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdPaymentType).HasColumnName(name: "id_payment_type").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartment).HasColumnName(name: "id_internal_department").HasColumnType(typeName: "int").IsRequired(required: true);
                entity.Property(e => e.PrimaryDistanceRequestTime).HasColumnName(name: "primary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.SecondaryDistanceRequestTime).HasColumnName(name: "secondary_distance_request_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.IdInternalDepartmentUsed).HasColumnName(name: "id_internal_department_used").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PurchaseQuantity).HasColumnName(name: "purchase_quantity").HasColumnType(typeName: "nvarchar(20)").IsRequired(required: false);
                entity.Property(e => e.ReceiptedInvoices).HasColumnName(name: "receipted_invoices").HasColumnType(typeName: "bit");
                entity.Property(e => e.TripRemark).HasColumnName(name: "trip_remark").HasColumnType(typeName: "nvarchar(250)").IsRequired(required: false);
                entity.Property(e => e.NoCustomerRequest).HasColumnName(name: "no_customer_request").HasColumnType(typeName: "bit");
                entity.Property(e => e.NotifyUnitPending).HasColumnName(name: "notify_unit_pending").HasColumnType(typeName: "bit");
                entity.Property(e => e.StreetPickup).HasColumnName(name: "street_pickup").HasColumnType(typeName: "bit");
                entity.Property(e => e.LastUpdate).HasColumnName(name: "last_update").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.LastUpdateBy).HasColumnName(name: "last_update_by").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdDriver).HasColumnName(name: "assigned_id_driver").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdUnit).HasColumnName(name: "assigned_id_unit").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.AssignedIdVehicle).HasColumnName(name: "assigned_id_vehicle").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.IdServiceType).HasColumnName(name: "id_service_type").HasColumnType(typeName: "int").IsRequired(required: false);
                entity.Property(e => e.PassengerPhone).HasColumnName(name: "passenger_phone").HasColumnType(typeName: "varchar(20)").IsRequired(required: false);
                entity.Property(e => e.DispatchTriggered).HasColumnName(name: "dispatch_triggered").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CpuFinalDestinationTime).HasColumnName(name: "cpu_final_destination_time").HasColumnType(typeName: "datetime").IsRequired(required: false);
                entity.Property(e => e.CardNumber).HasColumnName(name: "card_number").HasColumnType(typeName: "nvarchar(30)").IsRequired(required: false);

                entity.HasKey(e => e.Id);
            });
        }
    }
}