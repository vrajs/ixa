﻿namespace NetCabManager.Shared.Constants.Localization
{
    public static class LocalizationConstants
    {
        public static readonly LanguageCode[] SupportedLanguages = {
            new LanguageCode
            {
                Code = "en-US",
                DisplayName= "English"
            },
            new LanguageCode
            {
                Code = "de-DE",
                DisplayName = "German"
            },
            new LanguageCode
            {
                Code = "sl-SI",
                DisplayName = "Slovenian"
            },
            new LanguageCode
            {
                Code = "sr",
                DisplayName = "Serbian"
            },
            new LanguageCode
            {
                Code = "sq",
                DisplayName = "Albanian"
            },
        };
    }
}
