﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace NetCabManager.Shared.Constants.Permission
{
    public static class Permissions
    {
        public static class Units
        {
            public const string View = "Permissions.Units.View";
            public const string Create = "Permissions.Units.Create";
            public const string Edit = "Permissions.Units.Edit";
            public const string Delete = "Permissions.Units.Delete";
            public const string Export = "Permissions.Units.Export";
            public const string Search = "Permissions.Units.Search";
        }
        public static class NetCabToFleets
        {
            public const string View = "Permissions.NetCabToFleets.View";
            public const string Create = "Permissions.NetCabToFleets.Create";
            public const string Edit = "Permissions.NetCabToFleets.Edit";
            public const string Delete = "Permissions.NetCabToFleets.Delete";
            public const string Export = "Permissions.NetCabToFleets.Export";
            public const string Search = "Permissions.NetCabToFleets.Search";
        }

        public static class Vehicles
        {
            public const string View = "Permissions.Vehicles.View";
            public const string Create = "Permissions.Vehicles.Create";
            public const string Edit = "Permissions.Vehicles.Edit";
            public const string Delete = "Permissions.Vehicles.Delete";
            public const string Export = "Permissions.Vehicles.Export";
            public const string Search = "Permissions.Vehicles.Search";
        }
        public static class Targets
        {
            public const string View = "Permissions.Targets.View";
            public const string Create = "Permissions.Targets.Create";
            public const string Edit = "Permissions.Targets.Edit";
            public const string Delete = "Permissions.Targets.Delete";
            public const string Export = "Permissions.Targets.Export";
            public const string Search = "Permissions.Targets.Search";
        }
        public static class Invoices
        {
            public const string View = "Permissions.Invoices.View";
            public const string Create = "Permissions.Invoices.Create";
            public const string Edit = "Permissions.Invoices.Edit";
            public const string Delete = "Permissions.Invoices.Delete";
            public const string Export = "Permissions.Invoices.Export";
            public const string Search = "Permissions.Invoices.Search";
        }
        public static class DriverInvoices
        {
            public const string View = "Permissions.DriverInvoices.View";
            public const string Create = "Permissions.DriverInvoices.Create";
            public const string Edit = "Permissions.DriverInvoices.Edit";
            public const string Delete = "Permissions.DriverInvoices.Delete";
            public const string Export = "Permissions.DriverInvoices.Export";
            public const string Search = "Permissions.DriverInvoices.Search";
        }
        public static class Drivers
        {
            public const string View = "Permissions.Drivers.View";
            public const string Create = "Permissions.Drivers.Create";
            public const string Edit = "Permissions.Drivers.Edit";
            public const string Delete = "Permissions.Drivers.Delete";
            public const string Export = "Permissions.Drivers.Export";
            public const string Search = "Permissions.Drivers.Search";
        }
        public static class InternalDepartments
        {
            public const string View = "Permissions.InternalDepartments.View";
            public const string Create = "Permissions.InternalDepartments.Create";
            public const string Edit = "Permissions.InternalDepartments.Edit";
            public const string Delete = "Permissions.InternalDepartments.Delete";
            public const string Export = "Permissions.InternalDepartments.Export";
            public const string Search = "Permissions.InternalDepartments.Search";
        }
        public static class PartnerCompanies
        {
            public const string View = "Permissions.PartnerCompanies.View";
            public const string Create = "Permissions.PartnerCompanies.Create";
            public const string Edit = "Permissions.PartnerCompanies.Edit";
            public const string Delete = "Permissions.PartnerCompanies.Delete";
            public const string Export = "Permissions.PartnerCompanies.Export";
            public const string Search = "Permissions.PartnerCompanies.Search";
        }
        public static class TaxiCompanyRoles
        {
            public const string View = "Permissions.TaxiCompanyRoles.View";
            public const string Create = "Permissions.TaxiCompanyRoles.Create";
            public const string Edit = "Permissions.TaxiCompanyRoles.Edit";
            public const string Delete = "Permissions.TaxiCompanyRoles.Delete";
            public const string Export = "Permissions.TaxiCompanyRoles.Export";
            public const string Search = "Permissions.TaxiCompanyRoles.Search";
        }
        public static class TaxiCompanyUsers
        {
            public const string View = "Permissions.TaxiCompanyUsers.View";
            public const string Create = "Permissions.TaxiCompanyUsers.Create";
            public const string Edit = "Permissions.TaxiCompanyUsers.Edit";
            public const string Delete = "Permissions.TaxiCompanyUsers.Delete";
            public const string Export = "Permissions.TaxiCompanyUsers.Export";
            public const string Search = "Permissions.TaxiCompanyUsers.Search";
        }
        public static class Settings
        {
            public const string View = "Permissions.Settings.View";
            public const string Create = "Permissions.Settings.Create";
            public const string Edit = "Permissions.Settings.Edit";
            public const string Delete = "Permissions.Settings.Delete";
            public const string Export = "Permissions.Settings.Export";
            public const string Search = "Permissions.Settings.Search";
        }
        public static class Companies
        {
            public const string View = "Permissions.Companies.View";
            public const string Create = "Permissions.Companies.Create";
            public const string Edit = "Permissions.Companies.Edit";
            public const string Delete = "Permissions.Companies.Delete";
            public const string Export = "Permissions.Companies.Export";
            public const string Search = "Permissions.Companies.Search";
            public const string Login = "Permissions.Companies.Login";
        }

        [DisplayName("Documents")]
        [Description("Documents Permissions")]
        public static class Documents
        {
            public const string View = "Permissions.Documents.View";
            public const string Create = "Permissions.Documents.Create";
            public const string Edit = "Permissions.Documents.Edit";
            public const string Delete = "Permissions.Documents.Delete";
            public const string Search = "Permissions.Documents.Search";
        }

        [DisplayName("Document Types")]
        [Description("Document Types Permissions")]
        public static class DocumentTypes
        {
            public const string View = "Permissions.DocumentTypes.View";
            public const string Create = "Permissions.DocumentTypes.Create";
            public const string Edit = "Permissions.DocumentTypes.Edit";
            public const string Delete = "Permissions.DocumentTypes.Delete";
            public const string Export = "Permissions.DocumentTypes.Export";
            public const string Search = "Permissions.DocumentTypes.Search";
        }

        [DisplayName("Document Extended Attributes")]
        [Description("Document Extended Attributes Permissions")]
        public static class DocumentExtendedAttributes
        {
            public const string View = "Permissions.DocumentExtendedAttributes.View";
            public const string Create = "Permissions.DocumentExtendedAttributes.Create";
            public const string Edit = "Permissions.DocumentExtendedAttributes.Edit";
            public const string Delete = "Permissions.DocumentExtendedAttributes.Delete";
            public const string Export = "Permissions.DocumentExtendedAttributes.Export";
            public const string Search = "Permissions.DocumentExtendedAttributes.Search";
        }

        [DisplayName("Users")]
        [Description("Users Permissions")]
        public static class Users
        {
            public const string View = "Permissions.Users.View";
            public const string Create = "Permissions.Users.Create";
            public const string Edit = "Permissions.Users.Edit";
            public const string Delete = "Permissions.Users.Delete";
            public const string Export = "Permissions.Users.Export";
            public const string Search = "Permissions.Users.Search";
        }

        [DisplayName("Roles")]
        [Description("Roles Permissions")]
        public static class Roles
        {
            public const string View = "Permissions.Roles.View";
            public const string Create = "Permissions.Roles.Create";
            public const string Edit = "Permissions.Roles.Edit";
            public const string Delete = "Permissions.Roles.Delete";
            public const string Search = "Permissions.Roles.Search";
        }

        [DisplayName("Role Claims")]
        [Description("Role Claims Permissions")]
        public static class RoleClaims
        {
            public const string View = "Permissions.RoleClaims.View";
            public const string Create = "Permissions.RoleClaims.Create";
            public const string Edit = "Permissions.RoleClaims.Edit";
            public const string Delete = "Permissions.RoleClaims.Delete";
            public const string Search = "Permissions.RoleClaims.Search";
        }

        [DisplayName("Communication")]
        [Description("Communication Permissions")]
        public static class Communication
        {
            public const string Chat = "Permissions.Communication.Chat";
        }

        [DisplayName("Preferences")]
        [Description("Preferences Permissions")]
        public static class Preferences
        {
            public const string ChangeLanguage = "Permissions.Preferences.ChangeLanguage";

            //TODO - add permissions
        }

        [DisplayName("Dashboards")]
        [Description("Dashboards Permissions")]
        public static class Dashboards
        {
            public const string View = "Permissions.Dashboards.View";
        }

        [DisplayName("Hangfire")]
        [Description("Hangfire Permissions")]
        public static class Hangfire
        {
            public const string View = "Permissions.Hangfire.View";
        }

        [DisplayName("Audit Trails")]
        [Description("Audit Trails Permissions")]
        public static class AuditTrails
        {
            public const string View = "Permissions.AuditTrails.View";
            public const string Export = "Permissions.AuditTrails.Export";
            public const string Search = "Permissions.AuditTrails.Search";
        }

        /// <summary>
        /// Returns a list of Permissions.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetRegisteredPermissions()
        {
            var permissions = new List<string>();
            foreach (var prop in typeof(Permissions).GetNestedTypes().SelectMany(c => c.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)))
            {
                var propertyValue = prop.GetValue(null);
                if (propertyValue is not null)
                    permissions.Add(propertyValue.ToString());
            }
            return permissions;
        }
    }
}