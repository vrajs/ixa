﻿namespace NetCabManager.Shared.Constants.Permission
{
    public static class ApplicationClaimTypes
    {
        public const string Permission = "Permission";
    }
}