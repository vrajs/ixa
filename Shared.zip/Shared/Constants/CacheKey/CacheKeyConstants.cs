﻿namespace NetCabManager.Shared.Constants.CacheKey
{
    public static class CacheKeyConstants
    {
        public const string UserKey = "user";
        public const string UsersKey = "users";
        public const string CompanyKey = "company";
        public const string CompaniesKey = "companies";
        public const string InternalDepartmentsKey = "internalDepartments";
        public const string PartnerCompaniesKey = "partnerCompanies";
        public const string DriversKey = "drivers";
        public const string VehiclesKey = "vehicles";
        public const string UnitsKey = "units";
        public const string TargetKey = "target";
        public const string TargetsKey = "targets";
    }
}