﻿namespace NetCabManager.Shared.Constants.Role
{
    public static class RoleConstants
    {
        public const string AdministratorRole = "Administrator";
        public const string DriverRole = "Driver";
        public const string CompanyManagerRole = "CompanyManager";
        public const string OperatorRole = "Operator";
        public const string DispatcherRole = "Dispatcher";
        public const string SystemDistributorRole = "SystemDistributor";
        public const string PartnerCompanyManagerInternalRole = "PartnerCompanyManagerInternal";
        public const string PartnerCompanyManagerExternalRole = "PartnerCompanyManagerExternal";
        public const string BasicRole = "Basic";
        public const string DefaultPassword = "123Pa$$word!";
    }
}