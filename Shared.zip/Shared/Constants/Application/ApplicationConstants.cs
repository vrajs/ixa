﻿namespace NetCabManager.Shared.Constants.Application
{
    public static class ApplicationConstants
    {
        public static class SignalR
        {
            public const string HubUrl = "/signalRHub";
            public const string SendUpdateDashboard = "UpdateDashboardAsync";
            public const string SendUpdateHomePage = "UpdateHomePageAsync";
            public const string SendUpdateInternalDepartmentsPage = "UpdateInternalDepartmentsPageAsync";
            public const string SendUpdateNetCabToFleetsPage = "UpdateNetCabToFleetsPageAsync";
            public const string SendUpdateInvoicePage = "UpdateInvoicePageAsync";
            public const string SendUpdateDriverInvoicePage = "UpdateDriverInvoicePageAsync";
            public const string SendUpdateTargetsPage = "UpdateTargetsPageAsync";
            public const string SendUpdateTargetsPartnerCompanyManagerPage = "UpdateTargetsPartnerCompanyManagerPageAsync";
            public const string SendUpdatePartnerCompaniesPage = "UpdatePartnerCompaniesPageAsync";
            public const string SendUpdatePartnerCompanyProfilePage = "UpdatePartnerCompanyProfilePageAsync";
            public const string SendUpdateUnitsPage = "UpdateUnitsPageAsync";
            public const string SendUpdateUnitProfilePage = "UpdateUnitProfilePageAsync";
            public const string SendUpdateUnitsPartnerCompanyManagerInternalPage = "UpdateUnitsPartnerCompanyManagerInternalPageAsync";
            public const string SendUpdateVehiclesPage = "UpdateVehiclesPageAsync";
            public const string SendUpdateVehicleProfilePage = "UpdateVehicleProfilePageAsync";
            public const string SendUpdateVehiclesPartnerCompanyManagerInternalPage = "UpdateVehiclesPartnerCompanyManagerInternalPageAsync";
            public const string SendUpdateCompanyProfilePage = "UpdateCompanyProfilePageAsync";
            public const string SendUpdateDriverProfilePage = "UpdateDriverProfilePageAsync";
            public const string SendUpdateCompaniesPage = "UpdateCompaniesPageAsync";
            public const string SendUpdateDriversPage = "UpdateDriversPageAsync";
            public const string SendUpdateDriversPartnerCompanyManagerInternalPage = "UpdateDriversPartnerCompanyManagerInternalPageAsync";
            public const string ReceiveUpdateDashboard = "UpdateDashboard";
            public const string ReceiveUpdateHomePage = "UpdateHomePage";
            public const string ReceiveUpdateTargetsPartnerCompanyManagerPage = "UpdateTargetsPartnerCompanyManagerPage";
            public const string ReceiveUpdateInternalDepartmentsPage = "UpdateInternalDepartmentsPage";
            public const string ReceiveUpdateNetCabToFleetsPage = "UpdateNetCabToFleetsPage";
            public const string ReceiveUpdateInvoicePage = "UpdateInvoicePage";
            public const string ReceiveUpdateDriverInvoicePage = "UpdateDriverInvoicePage";
            public const string ReceiveUpdateTargetsPage = "UpdateTargetsPage";
            public const string ReceiveUpdatePartnerCompaniesPage = "UpdatePartnerCompaniesPage";
            public const string ReceiveUpdatePartnerCompanyProfilePage = "UpdatePartnerCompanyProfilePage";
            public const string ReceiveUpdateUnitsPage = "UpdateUnitsPage";
            public const string ReceiveUpdateUnitProfilePage = "UpdateUnitProfilePage";
            public const string ReceiveUpdateUnitsPartnerCompanyManagerInternalPage = "UpdateUnitsPartnerCompanyManagerInternalPage";
            public const string ReceiveUpdateVehiclesPage = "UpdateVehiclesPage";
            public const string ReceiveUpdateVehicleProfilePage = "UpdateVehicleProfilePage";
            public const string ReceiveUpdateVehiclesPartnerCompanyManagerInternalPage = "UpdateVehiclesPartnerCompanyManagerInternalPage";
            public const string ReceiveUpdateCompaniesPage = "UpdateCompaniesPage";
            public const string ReceiveUpdateCompanyProfilePage = "UpdateCompanyProfilePage";
            public const string ReceiveUpdateDriverProfilePage = "UpdateDriverProfilePage";
            public const string ReceiveUpdateDriversPage = "UpdateDriversPage";
            public const string ReceiveUpdateDriversPartnerCompanyManagerInternalPage = "UpdateDriversPartnerCompanyManagerInternalPage";
            public const string SendRegenerateTokens = "RegenerateTokensAsync";
            public const string ReceiveRegenerateTokens = "RegenerateTokens";
            public const string ReceiveChatNotification = "ReceiveChatNotification";
            public const string SendChatNotification = "ChatNotificationAsync";
            public const string ReceiveMessage = "ReceiveMessage";
            public const string SendMessage = "SendMessageAsync";

            public const string OnConnect = "OnConnectAsync";
            public const string ConnectUser = "ConnectUser";
            public const string OnDisconnect = "OnDisconnectAsync";
            public const string DisconnectUser = "DisconnectUser";
            public const string OnChangeRolePermissions = "OnChangeRolePermissions";
            public const string LogoutUsersByRole = "LogoutUsersByRole";

            public const string PingRequest = "PingRequestAsync";
            public const string PingResponse = "PingResponseAsync";

        }
        public static class Cache
        {
            public const string GetAllBrandsCacheKey = "all-brands";
            public const string GetAllNetCabFleetCachekey = "all-netcab-fleets";
            public const string GetAllSettingsCacheKey = "all-settings";
            public const string GetAllTaxiCompanyUsersCacheKey = "all-taxi-company-users";
            public const string GetAllTaxiCompanyRolesCacheKey = "all-taxi-company-roles";
            public const string GetAllInternalDepartmentsCacheKey = "all-internal-departments";
            public const string GetAllInvoicesCacheKey = "all-invoices";
            public const string GetAllDriverInvoicesCacheKey = "all-driver-invoices";
            public const string GetAllTargetsCacheKey = "all-targets";
            public const string GetAllPartnerCompaniesCacheKey = "all-partner-companies";
            public const string GetAllUnitsCacheKey = "all-units";
            public const string GetAllVehiclesCacheKey = "all-vehicles";
            public const string GetAllDriversCacheKey = "all-drivers";
            public const string GetAllCompaniesCacheKey = "all-companies";
            public const string GetAllDocumentTypesCacheKey = "all-document-types";
            public const string GetAllUsersCacheKey = "all-users";

            public static string GetAllEntityExtendedAttributesCacheKey(string entityFullName)
            {
                return $"all-{entityFullName}-extended-attributes";
            }

            public static string GetAllEntityExtendedAttributesByEntityIdCacheKey<TEntityId>(string entityFullName, TEntityId entityId)
            {
                return $"all-{entityFullName}-extended-attributes-{entityId}";
            }
        }

        public static class MimeTypes
        {
            public const string OpenXml = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
    }
}