﻿namespace NetCabManager.Infrastructure.Shared.Services
{
    internal class SendGridMailService
    {
    }
}