﻿namespace NetCabManager.Client.Infrastructure.Routes
{
    class RoleClaimsEndpoints
    {
        public static string Delete = "api/identity/roleClaim";
        public static string GetAll = "api/identity/roleClaim";
        public static string Save = "api/identity/roleClaim";
    }
}