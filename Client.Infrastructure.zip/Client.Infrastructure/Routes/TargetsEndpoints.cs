﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes
{
    public static class TargetsEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string GetAllPaged(int pageNumber, int pageSize, string searchString, int radioValue, DateTime startDate, DateTime endDate)
        {
            return $"api/v1/targets/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&radioValue={radioValue}&startDate={startDate}&endDate={endDate}";
        }

        public static string GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            return $"api/v1/targets/pagedInternal?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}$idInternalDepartment={idInternalDepartment}";
        }

        public static string Export = "api/v1/targets/export";
        public static string GetAll = "api/v1/targets";
        public static string GetById = "api/v1/targets";
        public static string Delete = "api/v1/targets";
        public static string Save = "api/v1/targets";
        public static string GetCount = "api/v1/targets/count";
    }
}