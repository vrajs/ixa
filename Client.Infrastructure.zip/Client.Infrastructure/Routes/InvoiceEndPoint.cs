﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes
{
    public class InvoiceEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string GetAllPaged(int pageNumber, int pageSize, string searchString,int? month,string driverName)
        {
            return $"api/v1/invoice/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&month={month.ToString()}&driverName={driverName}";
        }

        public static string Export = "api/v1/invoice/export";
        public static string GetAll = "api/v1/invoice";
        public static string GetById = "api/v1/invoice";
        public static string Delete = "api/v1/invoice";
        public static string Save = "api/v1/invoice";
        public static string GetCount = "api/v1/invoice/count";
    }
}
