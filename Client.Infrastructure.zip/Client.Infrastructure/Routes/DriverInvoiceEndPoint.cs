﻿using MudBlazor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes
{
    public class DriverInvoiceEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }
        public static string GetAllRidesByDriverId(int pageNumber, int pageSize, string searchString,string driverId)
        {
            return $"api/v1/driverinvoice/getAllRides?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&driverId={driverId}";
        }
        public static string GetAllPaged(int pageNumber, int pageSize, string searchString, int? month, string driverName)
        {
            return $"api/v1/driverinvoice/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&month={month}&driverName={driverName}";
        }

        public static string Export = "api/v1/driverinvoice/export";
        public static string GetAll = "api/v1/driverinvoice";
        public static string GetAllRides = "api/v1/driverinvoice";
        public static string GetById = "api/v1/driverinvoice";
        public static string Delete = "api/v1/driverinvoice";
        public static string Save = "api/v1/driverinvoice";
        public static string GetCount = "api/v1/driverinvoice/count";
    }
}
