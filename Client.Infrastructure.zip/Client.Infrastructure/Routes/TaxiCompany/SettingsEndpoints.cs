﻿namespace NetCabManager.Client.Infrastructure.Routes.TaxiCompany
{
    public static class SettingsEndpoints
    {
        public static string GetAll = "api/v1/settings";
    }
}