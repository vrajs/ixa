﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes.TaxiCompany
{
    public static class TaxiCompanyRolesEndpoints
    {
        public static string GetAll = "api/v1/taxicompanyroles";
    }
}