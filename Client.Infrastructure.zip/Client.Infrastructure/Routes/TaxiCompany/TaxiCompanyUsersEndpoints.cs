﻿namespace NetCabManager.Client.Infrastructure.Routes.TaxiCompany
{
    public static class TaxiCompanyUsersEndpoints
    {
        public static string GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            return $"api/v1/taxicompanyusers/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}";
        }

        public static string Export = "api/v1/taxicompanyusers/export";
        public static string GetAll = "api/v1/taxicompanyusers";
        public static string GetById = "api/v1/taxicompanyusers";
        public static string Delete = "api/v1/taxicompanyusers";
        public static string Save = "api/v1/taxicompanyusers";
        public static string GetCount = "api/v1/taxicompanyusers/count";
    }
}