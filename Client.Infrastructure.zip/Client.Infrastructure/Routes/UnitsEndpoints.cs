﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes
{
    public static class UnitsEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            return $"api/v1/units/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}";
        }

        public static string GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            return $"api/v1/units/pagedInternal?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&idInternalDepartment={idInternalDepartment}";
        }

        public static string Export = "api/v1/units/export";
        public static string GetAll = "api/v1/units";
        public static string GetById = "api/v1/units";
        public static string Delete = "api/v1/units";
        public static string Save = "api/v1/units";
        public static string GetCount = "api/v1/units/count";
    }
}