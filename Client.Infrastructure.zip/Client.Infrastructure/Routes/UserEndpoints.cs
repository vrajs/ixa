﻿namespace NetCabManager.Client.Infrastructure.Routes
{
    public static class UserEndpoints
    {
        public static string GetAll = "api/identity/user";
        public static string GetUserWithRoles = "api/identity/user/userwithrole";
        //public static string GetDecrypted = "api/identity/user/decyptPass";

        public static string Get(string userId)
        {
            return $"api/identity/user/{userId}";
        }

        public static string GetUserRoles(string userId)
        {
            return $"api/identity/user/roles/{userId}";
        }
        public static string GetDecrypted(string password)
        {
            password= password.Replace("<","");
            return $"api/identity/user/decyptPass/{password}";
        }

        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string Delete = "api/identity/user";
        public static string Export = "api/identity/user/export";
        public static string Register = "api/identity/user";
        public static string ToggleUserStatus = "api/identity/user/toggle-status";
        public static string ForgotPassword = "api/identity/user/forgot-password";
        public static string ResetPassword = "api/identity/user/reset-password";
    }
}