﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Routes
{
    public static class PartnerCompaniesEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            return $"api/v1/partnerCompanies/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}";
        }

        public static string Export = "api/v1/partnerCompanies/export";
        public static string GetAll = "api/v1/partnerCompanies";
        public static string GetById = "api/v1/partnerCompanies";
        public static string Delete = "api/v1/partnerCompanies";
        public static string Save = "api/v1/partnerCompanies";
        public static string GetCount = "api/v1/partnerCompanies/count";
    }
}