﻿namespace NetCabManager.Client.Infrastructure.Routes
{
    public static class DriversEndpoints
    {
        public static string ExportFiltered(string searchString)
        {
            return $"{Export}?searchString={searchString}";
        }

        public static string GetAllPaged(int pageNumber, int pageSize, string searchString)
        {
            return $"api/v1/drivers/paged?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}";
        }

        public static string GetAllPagedInternal(int pageNumber, int pageSize, string searchString, int idInternalDepartment)
        {
            return $"api/v1/drivers/pagedInternal?pageNumber={pageNumber}&pageSize={pageSize}&searchString={searchString}&idInternalDepartment={idInternalDepartment}";
        }

        public static string Export = "api/v1/drivers/export";
        public static string GetAll = "api/v1/drivers";
        public static string GetById = "api/v1/drivers";
        public static string Delete = "api/v1/drivers";
        public static string Save = "api/v1/drivers";
        public static string GetCount = "api/v1/drivers/count";
    }
}