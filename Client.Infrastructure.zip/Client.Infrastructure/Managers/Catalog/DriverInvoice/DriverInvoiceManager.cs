﻿using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using NetCabManager.Application.Features.DriverInvoices.Queries.GetAll;
using NetCabManager.Application.Features.DriverInvoices.Commands.AddEdit;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.DriverInvoice
{
    public class DriverInvoiceManager : IDriverInvoiceManager
    {
        private readonly HttpClient _httpClient;

        public DriverInvoiceManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllDriverInvoiceResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.DriverInvoiceEndpoints.GetAll);

            return await response.ToResult<List<GetAllDriverInvoiceResponse>>();
        }
        public async Task<IResult<List<GetAllRidesResponse>>> GetAllRidesAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.DriverInvoiceEndpoints.GetAllRidesByDriverId(request.PageNumber, request.PageSize, request.SearchString, request.DriverId));

            return await response.ToResult<List<GetAllRidesResponse>>();
        }
        public async Task<IResult<List<GetAllDriverInvoiceResponse>>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.DriverInvoiceEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString,request.Month,request.DriverName));
            //var responseAsString = await response.Content.ReadAsStringAsync();
            //var responseObject = JsonSerializer.Deserialize<List<GetAllInvoiceResponse>>(responseAsString);
            //return  responseObject;
            return await response.ToResult<List<GetAllDriverInvoiceResponse>>();
        }

        public async Task<IResult<GetAllDriverInvoiceResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.DriverInvoiceEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllDriverInvoiceResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditDriverInvoiceCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.DriverInvoiceEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.DriverInvoiceEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.DriverInvoiceEndpoints.Export
                : Routes.DriverInvoiceEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}
