﻿using NetCabManager.Application.Requests.Documents;
using NetCabManager.Shared.Wrapper;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetCabManager.Application.Features.DriverInvoices.Queries.GetAll;
using NetCabManager.Application.Features.DriverInvoices.Commands.AddEdit;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.DriverInvoice
{
    public interface IDriverInvoiceManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllDriverInvoiceResponse>>> GetAllAsync();
        Task<IResult<List<GetAllDriverInvoiceResponse>>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<List<GetAllRidesResponse>>> GetAllRidesAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllDriverInvoiceResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditDriverInvoiceCommand request);
    }
}
