﻿using NetCabManager.Application.Features.NetCabToFleets.Commands.AddEdit;
using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.NetCabToFleet
{
    public class NetCabToFleetManager : INetCabToFleetManager
    {
        private readonly HttpClient _httpClient;

        public NetCabToFleetManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllNetCabToFleetsResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.NetCabToFleetsEndpoints.GetAll);

            return await response.ToResult<List<GetAllNetCabToFleetsResponse>>();
        }

        public async Task<PaginatedResult<GetAllNetCabToFleetsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.NetCabToFleetsEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllNetCabToFleetsResponse>();
        }

        public async Task<IResult<GetAllNetCabToFleetsResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.NetCabToFleetsEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllNetCabToFleetsResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditNetCabToFleetCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.NetCabToFleetsEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(string id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.NetCabToFleetsEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.NetCabToFleetsEndpoints.Export
                : Routes.NetCabToFleetsEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}