﻿namespace NetCabManager.Client.Infrastructure.Managers.Catalog.NetCabToFleet
{
    using NetCabManager.Application.Features.NetCabToFleets.Commands.AddEdit;
    using NetCabManager.Application.Features.NetCabToFleets.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Client.Infrastructure.Managers;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface INetCabToFleetManager : IManager
    {
        Task<IResult<int>> DeleteAsync(string id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllNetCabToFleetsResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllNetCabToFleetsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllNetCabToFleetsResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditNetCabToFleetCommand request);
    }
}