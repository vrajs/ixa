﻿using NetCabManager.Application.Features.Units.Commands.AddEdit;
using NetCabManager.Application.Features.Units.Queries.GetAll;
using NetCabManager.Application.Features.Units.Queries.GetById;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Unit
{
    public class UnitManager : IUnitManager
    {
        private readonly HttpClient _httpClient;

        public UnitManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllUnitsResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.UnitsEndpoints.GetAll);

            return await response.ToResult<List<GetAllUnitsResponse>>();
        }

        public async Task<PaginatedResult<GetAllUnitsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.UnitsEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllUnitsResponse>();
        }

        public async Task<PaginatedResult<GetAllUnitsResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.UnitsEndpoints.GetAllPagedInternal(request.PageNumber, request.PageSize, request.SearchString, request.IdInternalDepartment));

            return await response.ToPaginatedResult<GetAllUnitsResponse>();
        }

        public async Task<IResult<GetAllUnitsResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.UnitsEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllUnitsResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditUnitCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.UnitsEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.UnitsEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.UnitsEndpoints.Export
                : Routes.UnitsEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}