﻿using NetCabManager.Application.Features.Units.Commands.AddEdit;
using NetCabManager.Application.Features.Units.Queries.GetAll;
using NetCabManager.Application.Features.Units.Queries.GetById;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Unit
{
    public interface IUnitManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllUnitsResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllUnitsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<PaginatedResult<GetAllUnitsResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllUnitsResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditUnitCommand request);
    }
}