﻿using NetCabManager.Application.Features.Vehicles.Commands.AddEdit;
using NetCabManager.Application.Features.Vehicles.Queries.GetById;
using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Vehicle
{
    public class VehicleManager : IVehicleManager
    {
        private readonly HttpClient _httpClient;

        public VehicleManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllVehiclesResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.VehiclesEndpoints.GetAll);

            return await response.ToResult<List<GetAllVehiclesResponse>>();
        }

        public async Task<PaginatedResult<GetAllVehiclesResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.VehiclesEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllVehiclesResponse>();
        }

        public async Task<PaginatedResult<GetAllVehiclesResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.VehiclesEndpoints.GetAllPagedInternal(request.PageNumber, request.PageSize, request.SearchString, request.IdInternalDepartment));

            return await response.ToPaginatedResult<GetAllVehiclesResponse>();
        }

        public async Task<IResult<GetAllVehiclesResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.VehiclesEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllVehiclesResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditVehicleCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.VehiclesEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.VehiclesEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.VehiclesEndpoints.Export
                : Routes.VehiclesEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}