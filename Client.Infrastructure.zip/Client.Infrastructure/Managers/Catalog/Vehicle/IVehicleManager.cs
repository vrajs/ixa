﻿namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Vehicle
{
    using NetCabManager.Application.Features.Vehicles.Commands.AddEdit;
    using NetCabManager.Application.Features.Vehicles.Queries.GetById;
    using NetCabManager.Application.Features.Vehicles.Queries.GettAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IVehicleManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllVehiclesResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllVehiclesResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<PaginatedResult<GetAllVehiclesResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllVehiclesResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditVehicleCommand request);
    }
}