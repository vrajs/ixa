﻿using NetCabManager.Application.Features.Drivers.Commands.AddEdit;
using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Drivers.Queries.GetById;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Driver
{
    public interface IDriverManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllDriversResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllDriversResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<PaginatedResult<GetAllDriversResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllDriversResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditDriverCommand request);
    }
}