﻿using NetCabManager.Application.Features.Drivers.Commands.AddEdit;
using NetCabManager.Application.Features.Drivers.Queries.GetAll;
using NetCabManager.Application.Features.Drivers.Queries.GetById;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Driver
{
    public class DriverManager : IDriverManager
    {
        private readonly HttpClient _httpClient;

        public DriverManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllDriversResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.DriversEndpoints.GetAll);

            return await response.ToResult<List<GetAllDriversResponse>>();
        }

        public async Task<PaginatedResult<GetAllDriversResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.DriversEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllDriversResponse>();
        }

        public async Task<PaginatedResult<GetAllDriversResponse>> GetAllPagedInternalAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.DriversEndpoints.GetAllPagedInternal(request.PageNumber, request.PageSize, request.SearchString, request.IdInternalDepartment));

            return await response.ToPaginatedResult<GetAllDriversResponse>();
        }

        public async Task<IResult<GetAllDriversResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.DriversEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllDriversResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditDriverCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.DriversEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.DriversEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.DriversEndpoints.Export
                : Routes.DriversEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}