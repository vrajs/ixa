﻿namespace NetCabManager.Client.Infrastructure.Managers.Catalog.PartnerCompany
{
    using NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit;
    using NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Client.Infrastructure.Managers;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IPartnerCompanyManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllPartnerCompaniesResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllPartnerCompaniesResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllPartnerCompaniesResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditPartnerCompanyCommand request);
    }
}