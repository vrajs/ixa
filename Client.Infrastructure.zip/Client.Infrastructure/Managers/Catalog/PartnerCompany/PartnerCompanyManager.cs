﻿namespace NetCabManager.Client.Infrastructure.Managers.Catalog.PartnerCompany
{
    using NetCabManager.Application.Features.PartnerCompanies.Commands.AddEdit;
    using NetCabManager.Application.Features.PartnerCompanies.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Client.Infrastructure.Extensions;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Json;
    using System.Threading.Tasks;

    public class PartnerCompanyManager : IPartnerCompanyManager
    {
        private readonly HttpClient _httpClient;

        public PartnerCompanyManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllPartnerCompaniesResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.PartnerCompaniesEndpoints.GetAll);

            return await response.ToResult<List<GetAllPartnerCompaniesResponse>>();
        }

        public async Task<PaginatedResult<GetAllPartnerCompaniesResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.PartnerCompaniesEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllPartnerCompaniesResponse>();
        }

        public async Task<IResult<GetAllPartnerCompaniesResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.PartnerCompaniesEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllPartnerCompaniesResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditPartnerCompanyCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.PartnerCompaniesEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.PartnerCompaniesEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.PartnerCompaniesEndpoints.Export
                : Routes.PartnerCompaniesEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}