﻿using NetCabManager.Application.Features;
using NetCabManager.Client.Infrastructure.Managers;
using NetCabManager.Shared.Wrapper;
using NetCabManager.Application.Features.Companies.Commands.AddEdit;
using NetCabManager.Application.Features.Companies.Queries.GetAll;
using NetCabManager.Application.Features.Companies.Queries.GetById;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Company
{
    public interface ICompanyManager : IManager
    {
        Task<IResult<string>> DeleteAsync(string id);
        Task<IResult<List<GetAllCompaniesResponse>>> GetAllAsync();
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<GetCompanyByIdResponse>> GetByIdAsync(string id);
        Task<IResult<string>> SaveAsync(AddEditCompanyCommand request);
    }
}