﻿using NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit;
using NetCabManager.Application.Features.InternalDepartments.Queries.GetAll;
using NetCabManager.Application.Requests.Documents;
using NetCabManager.Client.Infrastructure.Extensions;
using NetCabManager.Shared.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.InternalDepartment
{
    public class InternalDepartmentManager : IInternalDepartmentManager
    {
        private readonly HttpClient _httpClient;

        public InternalDepartmentManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllInternalDepartmentsResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.InternalDepartmentsEndpoints.GetAll);

            return await response.ToResult<List<GetAllInternalDepartmentsResponse>>();
        }

        public async Task<PaginatedResult<GetAllInternalDepartmentsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.InternalDepartmentsEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllInternalDepartmentsResponse>();
        }

        public async Task<IResult<GetAllInternalDepartmentsResponse>> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{Routes.InternalDepartmentsEndpoints.GetById}/{id}");

            return await response.ToResult<GetAllInternalDepartmentsResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditInternalDepartmentCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.InternalDepartmentsEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.InternalDepartmentsEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }

        public async Task<IResult<string>> ExportToExcelAsync(string searchString = "")
        {
            var response = await _httpClient.GetAsync(string.IsNullOrWhiteSpace(searchString)
                ? Routes.InternalDepartmentsEndpoints.Export
                : Routes.InternalDepartmentsEndpoints.ExportFiltered(searchString));

            return await response.ToResult<string>();
        }
    }
}