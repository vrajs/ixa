﻿namespace NetCabManager.Client.Infrastructure.Managers.Catalog.InternalDepartment
{
    using NetCabManager.Application.Features.InternalDepartments.Commands.AddEdit;
    using NetCabManager.Application.Features.InternalDepartments.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Client.Infrastructure.Managers;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IInternalDepartmentManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllInternalDepartmentsResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllInternalDepartmentsResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllInternalDepartmentsResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditInternalDepartmentCommand request);
    }
}