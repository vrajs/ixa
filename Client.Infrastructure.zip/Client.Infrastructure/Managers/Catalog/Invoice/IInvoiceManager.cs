﻿using NetCabManager.Application.Requests.Documents;
using NetCabManager.Shared.Wrapper;
using NetCabManager.Application.Features.Invoices.Commands.AddEdit;
using NetCabManager.Application.Features.Invoices.Queries.GetAll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Catalog.Invoice
{
    public interface IInvoiceManager : IManager
    {
        Task<IResult<int>> DeleteAsync(int id);
        Task<IResult<string>> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<GetAllInvoiceResponse>>> GetAllAsync();
        Task<IResult<List<GetAllInvoiceResponse>>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<GetAllInvoiceResponse>> GetByIdAsync(int id);
        Task<IResult<int>> SaveAsync(AddEditInvoiceCommand request);
    }
}
