﻿using NetCabManager.Application.Models.Chat;
using NetCabManager.Application.Responses.Identity;
using NetCabManager.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;
using NetCabManager.Application.Interfaces.Chat;

namespace NetCabManager.Client.Infrastructure.Managers.Communication
{
    public interface IChatManager : IManager
    {
        Task<IResult<IEnumerable<ChatUserResponse>>> GetChatUsersAsync();

        Task<IResult> SaveMessageAsync(ChatHistory<IChatUser> chatHistory);

        Task<IResult<IEnumerable<ChatHistoryResponse>>> GetChatHistoryAsync(string cId);
    }
}