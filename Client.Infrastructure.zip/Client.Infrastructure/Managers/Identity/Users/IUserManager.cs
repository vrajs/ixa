﻿using NetCabManager.Application.Requests.Identity;
using NetCabManager.Application.Responses.Identity;
using NetCabManager.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NetCabManager.Client.Infrastructure.Managers.Identity.Users
{
    public interface IUserManager : IManager
    {
        Task<IResult<List<UserResponse>>> GetAllAsync();
        Task<IResult<string>> GetDecryptedPass(string pass);
        Task<IResult> ForgotPasswordAsync(ForgotPasswordRequest request);
        Task<IResult> DeleteAsync(string userId);
        Task<IResult> ResetPasswordAsync(ResetPasswordRequest request);

        Task<IResult<UserResponse>> GetAsync(string userId);

        Task<IResult<UserRolesResponse>> GetRolesAsync(string userId);

        Task<IResult> RegisterUserAsync(RegisterRequest request);

        Task<IResult> ToggleUserStatusAsync(ToggleUserStatusRequest request);

        Task<IResult> UpdateRolesAsync(UpdateUserRolesRequest request);

        Task<string> ExportToExcelAsync(string searchString = "");
        Task<IResult<List<UserResponse>>> GetAllUserRolesAsync();
    }
}