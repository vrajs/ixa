﻿namespace NetCabManager.Client.Infrastructure.Managers
{
    public interface IManager
    {
    }
}