﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.Setting
{
    using NetCabManager.Application.Features.Settings.Queries.GetAll;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ISettingManager : IManager
    {
        Task<IResult<List<GetAllSettingsResponse>>> GetAllSettingsAsync();
    }
}