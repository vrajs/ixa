﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.Setting
{
    using NetCabManager.Application.Features.Settings.Queries.GetAll;
    using NetCabManager.Client.Infrastructure.Extensions;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;

    public class SettingManager : ISettingManager
    {
        private readonly HttpClient _httpClient;

        public SettingManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllSettingsResponse>>> GetAllSettingsAsync()
        {
            var response = await _httpClient.GetAsync(Routes.TaxiCompany.SettingsEndpoints.GetAll);

            return await response.ToResult<List<GetAllSettingsResponse>>();
        }
    }
}