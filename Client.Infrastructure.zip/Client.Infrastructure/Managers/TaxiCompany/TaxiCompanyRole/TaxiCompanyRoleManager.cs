﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.TaxiCompanyRole
{
    using NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll;
    using NetCabManager.Client.Infrastructure.Extensions;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;

    public class TaxiCompanyRoleManager : ITaxiCompanyRoleManager
    {
        private readonly HttpClient _httpClient;

        public TaxiCompanyRoleManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllTaxiCompanyRolesResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.TaxiCompany.TaxiCompanyRolesEndpoints.GetAll);

            return await response.ToResult<List<GetAllTaxiCompanyRolesResponse>>();
        }
    }
}