﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.TaxiCompanyRole
{
    using NetCabManager.Application.Features.TaxiCompanyRoles.Queries.GetAll;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ITaxiCompanyRoleManager : IManager
    {
        Task<IResult<List<GetAllTaxiCompanyRolesResponse>>> GetAllAsync();
    }
}