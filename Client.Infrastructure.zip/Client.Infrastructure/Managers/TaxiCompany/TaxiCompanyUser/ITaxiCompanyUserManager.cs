﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.TaxiCompanyUser
{
    using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ITaxiCompanyUserManager : IManager
    {
        Task<IResult<List<GetAllTaxiCompanyUsersResponse>>> GetAllAsync();
        Task<PaginatedResult<GetAllTaxiCompanyUsersResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request);
        Task<IResult<int>> SaveAsync(AddEditTaxiCompanyUserCommand request);
        Task<IResult<int>> DeleteAsync(int id);
    }
}