﻿namespace NetCabManager.Client.Infrastructure.Managers.TaxiCompany.TaxiCompanyUser
{
    using NetCabManager.Application.Features.TaxiCompanyUsers.Commands.AddEdit;
    using NetCabManager.Application.Features.TaxiCompanyUsers.Queries.GetAll;
    using NetCabManager.Application.Requests.Documents;
    using NetCabManager.Client.Infrastructure.Extensions;
    using NetCabManager.Shared.Wrapper;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Json;
    using System.Threading.Tasks;

    public class TaxiCompanyUserManager : ITaxiCompanyUserManager
    {
        private readonly HttpClient _httpClient;

        public TaxiCompanyUserManager(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IResult<List<GetAllTaxiCompanyUsersResponse>>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(Routes.TaxiCompany.TaxiCompanyUsersEndpoints.GetAll);

            return await response.ToResult<List<GetAllTaxiCompanyUsersResponse>>();
        }

        public async Task<PaginatedResult<GetAllTaxiCompanyUsersResponse>> GetAllPagedAsync(GetAllPagedDocumentsRequest request)
        {
            var response = await _httpClient.GetAsync(Routes.TaxiCompany.TaxiCompanyUsersEndpoints.GetAllPaged(request.PageNumber, request.PageSize, request.SearchString));

            return await response.ToPaginatedResult<GetAllTaxiCompanyUsersResponse>();
        }

        public async Task<IResult<int>> SaveAsync(AddEditTaxiCompanyUserCommand request)
        {
            var response = await _httpClient.PostAsJsonAsync(Routes.TaxiCompany.TaxiCompanyUsersEndpoints.Save, request);

            return await response.ToResult<int>();
        }

        public async Task<IResult<int>> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{Routes.TaxiCompany.TaxiCompanyUsersEndpoints.Delete}/{id}");

            return await response.ToResult<int>();
        }
    }
}