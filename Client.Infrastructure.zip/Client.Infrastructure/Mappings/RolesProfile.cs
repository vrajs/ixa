﻿using AutoMapper;
using NetCabManager.Application.Requests.Identity;
using NetCabManager.Application.Responses.Identity;

namespace NetCabManager.Client.Infrastructure.Mappings
{
    public class RoleProfile : Profile
    {
        public RoleProfile()
        {
            CreateMap<PermissionResponse, PermissionRequest>().ReverseMap();
            CreateMap<RoleClaimResponse, RoleClaimRequest>().ReverseMap();
        }
    }
}